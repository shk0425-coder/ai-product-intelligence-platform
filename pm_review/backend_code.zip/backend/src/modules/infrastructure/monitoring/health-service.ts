import { cacheManager } from '../cache/cache-manager.js';

export class InfrastructureHealthMonitor {
  static async checkHealth() {
    let redisStatus = 'ONLINE';
    let redisPing = 'FAILED';

    try {
      redisPing = await cacheManager.getRedisProvider().ping();
    } catch (_err) {
      redisStatus = 'OFFLINE';
    }

    const fallbackActive = cacheManager.isFallbackActive();

    return {
      status: redisStatus === 'ONLINE' ? 'UP' : 'DEGRADED',
      details: {
        redis: {
          status: redisStatus,
          ping: redisPing,
          fallbackActive,
          circuitState: fallbackActive ? 'OPEN' : 'CLOSED',
        },
        memory: {
          status: 'ONLINE',
          healthy: true,
        },
      },
    };
  }
}
