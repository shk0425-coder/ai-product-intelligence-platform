import { MetricsRegistry } from '../registry.js';

export class WorkflowMetricsCollector {
  static recordWorkflowStart(workflowName: string, workspaceId: string): void {
    MetricsRegistry.gauge('active_workflows', 1, { workflow: workflowName, workspace_id: workspaceId });
  }

  static recordWorkflowCompletion(workflowName: string, durationMs: number, workspaceId: string): void {
    MetricsRegistry.counter('workflow_completed_total', 1, { workflow: workflowName, workspace_id: workspaceId });
    MetricsRegistry.histogram('workflow_duration_seconds', durationMs / 1000, { workflow: workflowName, workspace_id: workspaceId });
    MetricsRegistry.gauge('active_workflows', 0, { workflow: workflowName, workspace_id: workspaceId });
  }

  static recordWorkflowFailure(workflowName: string, workspaceId: string): void {
    MetricsRegistry.counter('workflow_failed_total', 1, { workflow: workflowName, workspace_id: workspaceId });
    MetricsRegistry.gauge('active_workflows', 0, { workflow: workflowName, workspace_id: workspaceId });
  }
}
