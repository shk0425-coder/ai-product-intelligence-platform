import { FeedbackIntelligenceRepository } from './repository.js';
import { AnalyzeFeedbackDto, ReanalyzeFeedbackDto, FeedbackIntelligenceDto } from './dto.js';
import { FeedbackIntelligenceMapper } from './mapper.js';
import { FeedbackIntelligenceAnalyzer } from './analyzer.js';
import { FeedbackIntelligenceHooks } from './hooks.js';
import {
  FeedbackNotFoundError,
  PerformanceNotFoundError,
  DuplicateFeedbackIntelligenceError,
  FeedbackIntelligenceNotFoundError,
  WorkspaceForbiddenError,
} from '@/common/errors/index.js';
import { SupabaseClient } from '@supabase/supabase-js';

export class FeedbackIntelligenceService {
  constructor(private readonly repository: FeedbackIntelligenceRepository) {}

  async analyze(dto: AnalyzeFeedbackDto, actorId: string): Promise<FeedbackIntelligenceDto> {
    const { feedbackScoreId, ruleVersion = 'v1' } = dto;
    const startTime = Date.now();

    // 1. Verify Ownership
    const isOwner = await this.repository.verifyFeedbackOwner(feedbackScoreId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this feedback score record',
      );
    }

    // 2. Fetch Feedback Score
    const supabase = (this.repository as unknown as { supabase: SupabaseClient }).supabase;
    const { data: feedbackScore, error: scoreError } = await supabase
      .from('feedback_scores')
      .select('*')
      .eq('id', feedbackScoreId)
      .maybeSingle();

    if (scoreError || !feedbackScore) {
      throw new FeedbackNotFoundError('Feedback score record not found');
    }

    // 3. Fetch Parent Performance & Metrics
    const { data: performance } = await supabase
      .from('product_performance')
      .select('*')
      .eq('id', feedbackScore.performance_id)
      .is('deleted_at', null)
      .maybeSingle();

    if (!performance) {
      throw new PerformanceNotFoundError('Performance snapshot not found or has been deleted');
    }

    const { data: metrics } = await supabase
      .from('performance_metrics')
      .select('*')
      .eq('performance_id', feedbackScore.performance_id)
      .maybeSingle();

    // 4. Check for Existing Intelligence Report
    const existing = await this.repository.findByFeedback(feedbackScoreId, ruleVersion);
    if (existing) {
      throw new DuplicateFeedbackIntelligenceError(
        `Feedback intelligence report already generated for score ${feedbackScoreId} and rule version ${ruleVersion}. Use reanalyze instead.`,
      );
    }

    // 5. Execute Analysis Pipeline
    const analysisResults = FeedbackIntelligenceAnalyzer.analyze({
      feedbackScore,
      performance,
      metrics,
    });

    const executionTimeMs = Date.now() - startTime;

    // 6. Persist to DB
    const insertPayload = {
      feedback_score_id: feedbackScoreId,
      analysis_version: 1,
      rule_version: ruleVersion,
      strength_summary: analysisResults.strengthSummary,
      weakness_summary: analysisResults.weaknessSummary,
      bottleneck_summary: analysisResults.bottleneckSummary,
      improvement_summary: analysisResults.improvementSummary,
      root_causes: analysisResults.rootCauses,
      recommendations: analysisResults.recommendations,
      detected_rules: analysisResults.detectedRules,
      impact_score: analysisResults.impactScore,
      confidence_score: analysisResults.confidenceScore,
      execution_time_ms: executionTimeMs,
      analyzed_at: new Date().toISOString(),
    };

    const createdEntity = await this.repository.create(insertPayload);
    const result = FeedbackIntelligenceMapper.toResponseDto(createdEntity);

    // 7. Trigger Domain Hook
    await FeedbackIntelligenceHooks.onFeedbackIntelligenceCreated({
      intelligence: result,
      actorId,
      timestamp: new Date().toISOString(),
    });

    return result;
  }

  async reanalyze(dto: ReanalyzeFeedbackDto, actorId: string): Promise<FeedbackIntelligenceDto> {
    const { feedbackScoreId, ruleVersion = 'v1' } = dto;
    const startTime = Date.now();

    // 1. Verify Ownership
    const isOwner = await this.repository.verifyFeedbackOwner(feedbackScoreId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this feedback score record',
      );
    }

    // 2. Fetch Feedback Score & Performance Data
    const supabase = (this.repository as unknown as { supabase: SupabaseClient }).supabase;
    const { data: feedbackScore } = await supabase
      .from('feedback_scores')
      .select('*')
      .eq('id', feedbackScoreId)
      .maybeSingle();

    if (!feedbackScore) {
      throw new FeedbackNotFoundError('Feedback score record not found');
    }

    const { data: performance } = await supabase
      .from('product_performance')
      .select('*')
      .eq('id', feedbackScore.performance_id)
      .is('deleted_at', null)
      .maybeSingle();

    if (!performance) {
      throw new PerformanceNotFoundError('Performance snapshot not found or has been deleted');
    }

    const { data: metrics } = await supabase
      .from('performance_metrics')
      .select('*')
      .eq('performance_id', feedbackScore.performance_id)
      .maybeSingle();

    // 3. Fetch Existing Intelligence Report to increment analysis_version
    const existing = await this.repository.findByFeedback(feedbackScoreId, ruleVersion);
    const nextVersion = existing ? existing.analysis_version + 1 : 1;

    // 4. Run Analysis
    const analysisResults = FeedbackIntelligenceAnalyzer.analyze({
      feedbackScore,
      performance,
      metrics,
    });

    const executionTimeMs = Date.now() - startTime;

    let updatedEntity;

    if (existing) {
      const { data, error } = await supabase
        .from('feedback_intelligence')
        .update({
          analysis_version: nextVersion,
          strength_summary: analysisResults.strengthSummary,
          weakness_summary: analysisResults.weaknessSummary,
          bottleneck_summary: analysisResults.bottleneckSummary,
          improvement_summary: analysisResults.improvementSummary,
          root_causes: analysisResults.rootCauses,
          recommendations: analysisResults.recommendations,
          detected_rules: analysisResults.detectedRules,
          impact_score: analysisResults.impactScore,
          confidence_score: analysisResults.confidenceScore,
          execution_time_ms: executionTimeMs,
          analyzed_at: new Date().toISOString(),
        })
        .eq('id', existing.id)
        .select('*')
        .single();

      if (error) throw error;
      updatedEntity = data;
    } else {
      const payload = {
        feedback_score_id: feedbackScoreId,
        analysis_version: 1,
        rule_version: ruleVersion,
        strength_summary: analysisResults.strengthSummary,
        weakness_summary: analysisResults.weaknessSummary,
        bottleneck_summary: analysisResults.bottleneckSummary,
        improvement_summary: analysisResults.improvementSummary,
        root_causes: analysisResults.rootCauses,
        recommendations: analysisResults.recommendations,
        detected_rules: analysisResults.detectedRules,
        impact_score: analysisResults.impactScore,
        confidence_score: analysisResults.confidenceScore,
        execution_time_ms: executionTimeMs,
        analyzed_at: new Date().toISOString(),
      };
      updatedEntity = await this.repository.create(payload);
    }

    const result = FeedbackIntelligenceMapper.toResponseDto(updatedEntity);

    // 5. Trigger Reanalyze Domain Hook
    await FeedbackIntelligenceHooks.onFeedbackIntelligenceReanalyzed({
      intelligence: result,
      actorId,
      timestamp: new Date().toISOString(),
    });

    return result;
  }

  async findByFeedback(feedbackId: string, actorId: string): Promise<FeedbackIntelligenceDto> {
    const isOwner = await this.repository.verifyFeedbackOwner(feedbackId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this feedback score record',
      );
    }

    const entity = await this.repository.findByFeedback(feedbackId);
    if (!entity) {
      throw new FeedbackIntelligenceNotFoundError(
        `Feedback intelligence report not found for score ${feedbackId}`,
      );
    }

    return FeedbackIntelligenceMapper.toResponseDto(entity);
  }

  async findLatest(productId: string, actorId: string): Promise<FeedbackIntelligenceDto> {
    const isOwner = await this.repository.verifyProductOwner(productId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product record');
    }

    const entity = await this.repository.findLatest(productId);
    if (!entity) {
      throw new FeedbackIntelligenceNotFoundError(
        `Feedback intelligence report not found for product ${productId}`,
      );
    }

    return FeedbackIntelligenceMapper.toResponseDto(entity);
  }

  async findHistory(productId: string, actorId: string): Promise<FeedbackIntelligenceDto[]> {
    const isOwner = await this.repository.verifyProductOwner(productId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product record');
    }

    const entities = await this.repository.findHistory(productId);
    return FeedbackIntelligenceMapper.toResponseDtoList(entities);
  }
}
