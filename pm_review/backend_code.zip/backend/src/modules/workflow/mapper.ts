import { WorkflowDefinitionEntity, WorkflowVersionEntity, WorkflowExecutionEntity } from './types.js';
import { WorkflowDefinitionDto, WorkflowVersionDto, WorkflowExecutionDto } from './dto.js';

export class WorkflowMapper {
  static toDefinitionDto(entity: WorkflowDefinitionEntity): WorkflowDefinitionDto {
    return {
      id: entity.id,
      workspaceId: entity.workspace_id,
      name: entity.name,
      description: entity.description,
      latestVersion: entity.latest_version,
      currentVersionId: entity.current_version_id,
      status: entity.status,
      createdAt: entity.created_at,
      updatedAt: entity.updated_at,
    };
  }

  static toDefinitionDtoList(entities: WorkflowDefinitionEntity[]): WorkflowDefinitionDto[] {
    return entities.map((e) => this.toDefinitionDto(e));
  }

  static toVersionDto(entity: WorkflowVersionEntity): WorkflowVersionDto {
    return {
      id: entity.id,
      workflowId: entity.workflow_id,
      version: entity.version,
      graph: entity.graph,
      checksum: entity.checksum,
      changeSummary: entity.change_summary,
      createdAt: entity.created_at,
    };
  }

  static toVersionDtoList(entities: WorkflowVersionEntity[]): WorkflowVersionDto[] {
    return entities.map((e) => this.toVersionDto(e));
  }

  static toExecutionDto(entity: WorkflowExecutionEntity): WorkflowExecutionDto {
    return {
      id: entity.id,
      workspaceId: entity.workspace_id,
      workflowId: entity.workflow_id,
      versionId: entity.version_id,
      status: entity.status,
      executionKey: entity.execution_key,
      input: entity.input,
      output: entity.output,
      snapshot: entity.snapshot,
      startedAt: entity.started_at,
      finishedAt: entity.finished_at,
      durationMs: entity.duration_ms,
      estimatedCost: Number(entity.estimated_cost),
      errorMessage: entity.error_message,
      createdAt: entity.created_at,
    };
  }

  static toExecutionDtoList(entities: WorkflowExecutionEntity[]): WorkflowExecutionDto[] {
    return entities.map((e) => this.toExecutionDto(e));
  }
}
export default WorkflowMapper;
