import { WorkflowGraph, WorkflowStatus, ExecutionStatus } from './types.js';

export interface CreateWorkflowDto {
  workspaceId: string;
  name: string;
  description?: string;
  graph: WorkflowGraph;
}

export interface CreateWorkflowVersionDto {
  graph: WorkflowGraph;
  changeSummary?: string;
}

export interface ExecuteWorkflowDto {
  workspaceId: string;
  input: Record<string, unknown>;
}

export interface PreviewWorkflowDto {
  workspaceId: string;
  graph: WorkflowGraph;
  input: Record<string, unknown>;
}

export interface WorkflowDefinitionDto {
  id: string;
  workspaceId: string;
  name: string;
  description?: string;
  latestVersion: number;
  currentVersionId?: string;
  status: WorkflowStatus;
  createdAt: string;
  updatedAt: string;
}

export interface WorkflowVersionDto {
  id: string;
  workflowId: string;
  version: number;
  graph: WorkflowGraph;
  checksum: string;
  changeSummary?: string;
  createdAt: string;
}

export interface WorkflowExecutionDto {
  id: string;
  workspaceId: string;
  workflowId: string;
  versionId: string;
  status: ExecutionStatus;
  executionKey: string;
  input: Record<string, unknown>;
  output: Record<string, unknown>;
  snapshot: Record<string, unknown>;
  startedAt?: string;
  finishedAt?: string;
  durationMs: number;
  estimatedCost: number;
  errorMessage?: string;
  createdAt: string;
}

export interface PreviewWorkflowResponseDto {
  executionGraph: WorkflowGraph;
  executionOrder: string[];
  parallelGroups: string[][];
  estimatedCost: number;
  estimatedDuration: number;
}
