import crypto from 'crypto';

export interface BackupPayload {
  timestamp: number;
  type: 'Full' | 'Incremental';
  data: string;
  checksum: string;
}

export class BackupManager {
  private static backups: BackupPayload[] = [];

  static async createBackup(type: 'Full' | 'Incremental', statePayload: string): Promise<BackupPayload> {
    const checksum = crypto.createHash('sha256').update(statePayload).digest('hex');
    const backup: BackupPayload = {
      timestamp: Date.now(),
      type,
      data: statePayload,
      checksum,
    };

    this.backups.push(backup);
    return backup;
  }

  static async restoreBackup(backup: BackupPayload): Promise<string | null> {
    const check = crypto.createHash('sha256').update(backup.data).digest('hex');
    if (check !== backup.checksum) {
      return null; // Compromised backup integrity
    }
    return backup.data;
  }

  static getBackupsCount(): number {
    return this.backups.length;
  }

  static clear(): void {
    this.backups = [];
  }
}
export default BackupManager;
