import { FastifyInstance } from 'fastify';
import { AIProviderController } from './controller.js';
import { AIProviderService } from './service.js';
import { AIProviderRepository } from './repository.js';
import { supabase } from '@/config/supabase.js';

export async function aiProviderRoutes(fastify: FastifyInstance) {
  const repository = new AIProviderRepository(supabase);
  const service = new AIProviderService(repository);
  const controller = new AIProviderController(service);

  fastify.get('/', (req, rep) => controller.getConfigs(req, rep));
  fastify.get('/models', (req, rep) => controller.getModels(req, rep));
  fastify.get('/health', (req, rep) => controller.getHealth(req, rep));
  fastify.get('/metrics', (req, rep) => controller.getMetrics(req, rep));
  fastify.patch('/configs/:provider/:model', (req, rep) =>
    controller.patchConfig(
      req as import('fastify').FastifyRequest<{ Params: { provider: string; model: string }; Body: import('./dto.js').PatchAIProviderConfigDto }>,
      rep
    )
  );
  fastify.post('/health-check', (req, rep) => controller.runHealthCheck(req, rep));
  fastify.post('/test', (req, rep) =>
    controller.testCall(req as import('fastify').FastifyRequest<{ Body: import('./dto.js').TestAIProviderDto }>, rep)
  );
}
export default aiProviderRoutes;
