import { TraceManager, Span } from '../tracing/trace-manager.js';
import { AsyncContextManager, ObservabilityContext } from '../context/context-manager.js';
import { MetricsRegistry } from '../metrics/registry.js';

export interface EventTraceHeaders {
  traceId?: string;
  spanId?: string;
  correlationId?: string;
  workspaceId?: string;
}

export class EventBusInstrumentation {
  static injectContext(headers: Record<string, unknown> = {}): Record<string, unknown> {
    const store = AsyncContextManager.getStore() || {};
    headers['x-trace-id'] = store.traceId;
    headers['x-span-id'] = store.spanId;
    headers['x-correlation-id'] = store.correlationId;
    headers['x-workspace-id'] = store.workspaceId;
    return headers;
  }

  static extractContext(headers: Record<string, unknown>): ObservabilityContext {
    return {
      traceId: headers['x-trace-id'] as string || undefined,
      spanId: headers['x-span-id'] as string || undefined,
      correlationId: headers['x-correlation-id'] as string || undefined,
      workspaceId: headers['x-workspace-id'] as string || undefined,
    };
  }

  static startPublish(eventType: string, workspaceId: string): Span {
    // Inject current tracing context
    const span = TraceManager.startSpan(`EventBus Publish ${eventType}`);
    span.setAttribute('event.type', eventType);
    span.setAttribute('workspace_id', workspaceId);

    MetricsRegistry.counter('eventbus_publish_total', 1, { event: eventType, workspace_id: workspaceId });
    return span;
  }

  static endPublish(span: Span): void {
    span.end();
  }

  static startConsume(eventType: string, headers: Record<string, unknown>): Span {
    const extracted = this.extractContext(headers);
    // Restore parent trace context from incoming message headers
    const span = TraceManager.startSpan(`EventBus Consume ${eventType}`, extracted);
    span.setAttribute('event.type', eventType);
    if (extracted.workspaceId) {
      span.setAttribute('workspace_id', extracted.workspaceId);
    }
    
    MetricsRegistry.counter('eventbus_consume_total', 1, { event: eventType, workspace_id: extracted.workspaceId });
    return span;
  }

  static endConsume(span: Span, success = true): void {
    span.setStatus(success ? 'OK' : 'ERROR');
    span.end();
  }
}
