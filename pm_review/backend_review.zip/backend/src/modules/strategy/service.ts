export class StrategyService {}
