import { JobQueueRepository } from './repository.js';
import { JobQueueEntity } from './types.js';
import { QUEUE_CONSTANTS } from './constants.js';

export class LeaseManager {
  constructor(
    private readonly repository: JobQueueRepository,
    private readonly leaseOwnerId: string
  ) {}

  async acquire(jobId: string): Promise<JobQueueEntity | null> {
    const visibilitySeconds = QUEUE_CONSTANTS.DEFAULT_VISIBILITY_TIMEOUT_SEC;
    return this.repository.acquireLease(jobId, this.leaseOwnerId, visibilitySeconds);
  }

  async heartbeat(jobId: string): Promise<boolean> {
    const visibilitySeconds = QUEUE_CONSTANTS.DEFAULT_VISIBILITY_TIMEOUT_SEC;
    const updated = await this.repository.updateHeartbeat(jobId, visibilitySeconds);
    return !!updated;
  }

  async release(jobId: string): Promise<void> {
    await this.repository.updateJob(jobId, {
      lease_owner: null,
      lease_until: null,
      heartbeat_at: null,
    });
  }

  static isLeaseExpired(job: JobQueueEntity): boolean {
    if (!job.lease_until) return true;
    return new Date(job.lease_until).getTime() < Date.now();
  }
}
