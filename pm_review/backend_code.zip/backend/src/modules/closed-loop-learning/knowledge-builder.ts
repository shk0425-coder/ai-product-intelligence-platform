import { FeatureSet } from './feature-extractor.js';
import { DetectedPattern } from './pattern-detector.js';

export interface KnowledgeTexts {
  featureSummary: string;
  successPattern: string;
  failurePattern: string;
  improvementPattern: string;
}

export const KnowledgeBuilder = {
  build(features: FeatureSet, patterns: DetectedPattern[]): KnowledgeTexts {
    // 1. Build Feature Summary
    const fSum = `강점 ${features.strengths.length}건, 약점 ${features.weaknesses.length}건, 병목 ${features.bottlenecks.length}건 식별 완료.`;

    // 2. Build Success Pattern
    let successPattern = '검출된 주요 판매 촉진 패턴이 관찰되지 않습니다.';
    if (features.strengths.length > 0) {
      successPattern = `만족도 피드백 유지 양상 발견: ${features.strengths.join(' | ')}`;
    }

    // 3. Build Failure Pattern
    let failurePattern = '특이한 하향 성과 패턴이 검출되지 않았습니다.';
    const failurePatternsList = patterns.filter((p) => p.severity >= 4);
    if (failurePatternsList.length > 0) {
      failurePattern = `심각수준 병목 요인 패턴 식별: ${failurePatternsList
        .map((p) => `[${p.category}] 빈도: ${p.frequency}건, 심각도: ${p.severity}`)
        .join(' | ')}`;
    }

    // 4. Build Improvement Pattern
    let improvementPattern = '현재 추가적인 프로세스 최적화 개선안이 식별되지 않았습니다.';
    if (features.improvements.length > 0) {
      improvementPattern = `스토어 기획 튜닝 권장안: ${features.improvements.join(' | ')}`;
    }

    return {
      featureSummary: fSum,
      successPattern,
      failurePattern,
      improvementPattern,
    };
  },
};
export default KnowledgeBuilder;
