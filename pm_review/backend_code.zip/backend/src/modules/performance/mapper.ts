import { ProductPerformance, PerformanceMetrics, PerformanceSource } from './types.js';
import { PerformanceResponseDto } from './dto.js';

export class PerformanceMapper {
  static toResponseDto(
    entity: ProductPerformance,
    metrics?: PerformanceMetrics | null,
    source?: PerformanceSource | null,
  ): PerformanceResponseDto {
    return {
      performanceId: entity.id,
      workspaceId: entity.workspace_id,
      productId: entity.product_id,
      analysisRunId: entity.analysis_run_id,
      strategyId: entity.strategy_id,
      creativeId: entity.creative_id,
      periodStart: entity.period_start,
      periodEnd: entity.period_end,
      salesCount: entity.sales_count,
      salesAmount: Number(entity.sales_amount),
      refundCount: entity.refund_count,
      reviewCount: entity.review_count,
      reviewScore: Number(entity.review_score),
      favoriteCount: entity.favorite_count,
      version: entity.version,
      lastCollectedAt: entity.last_collected_at,
      createdAt: entity.created_at,
      updatedAt: entity.updated_at,
      metrics: metrics
        ? {
            impressions: metrics.impressions,
            clicks: metrics.clicks,
            conversionCount: metrics.conversion_count,
            conversionRate: Number(metrics.conversion_rate),
            ctr: Number(metrics.ctr),
            adCost: Number(metrics.ad_cost),
            profit: Number(metrics.profit),
            marginRate: Number(metrics.margin_rate),
            roi: Number(metrics.roi),
          }
        : null,
      source: source
        ? {
            marketplaceCode: source.marketplace_code,
            marketplaceName: source.marketplace_name,
            collectionJobId: source.collection_job_id,
            sourceVersion: source.source_version,
            collectedAt: source.collected_at,
            rawPayloadHash: source.raw_payload_hash,
          }
        : null,
    };
  }
}
