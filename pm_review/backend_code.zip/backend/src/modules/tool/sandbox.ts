export interface SandboxResult {
  success: boolean;
  data: Record<string, unknown>;
  errorMessage?: string;
}

export class ToolSandbox {
  static async run(
    executionFn: () => Promise<Record<string, unknown>>,
    timeoutMs: number
  ): Promise<SandboxResult> {
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => reject(new Error(`Tool execution timed out after ${timeoutMs}ms`)), timeoutMs);
    });

    try {
      const data = await Promise.race([executionFn(), timeoutPromise]);

      // Enforce output size limit (e.g. 5MB)
      const size = Buffer.byteLength(JSON.stringify(data));
      if (size > 5 * 1024 * 1024) {
        throw new Error('Tool output size exceeded limit of 5MB');
      }

      return {
        success: true,
        data,
      };
    } catch (err: unknown) {
      return {
        success: false,
        data: {},
        errorMessage: err instanceof Error ? err.message : String(err),
      };
    }
  }
}
export default ToolSandbox;
