import { FastifyRequest, FastifyReply } from 'fastify';
import { IncidentManager } from '../incident/incident-manager.js';
import { RunbookRepository } from '../runbook/runbook-engine.js';
import { RecoveryStateMachine } from '../state/recovery-state-machine.js';
import { RecoveryBudgetManager } from '../budget/recovery-budget-manager.js';
import { CircuitBreaker } from '../breaker/circuit-breaker.js';
import { AuditTrail } from '../audit/audit-trail.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export class ResilienceController {
  async approveRecovery(req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const { executionId } = req.body as { executionId: string };

    // Move state manually from WaitingApproval to Recovering
    try {
      await RecoveryStateMachine.transitionTo(executionId, 'WaitingApproval', 'Recovering');
      
      eventBus.publish({
        eventId: crypto.randomUUID(),
        eventType: 'ApprovalCompleted',
        timestamp: new Date().toISOString(),
        workspaceId: 'default-workspace',
        data: { executionId, approvedBy: 'Admin' },
      }).catch(() => {});

      rep.send({ status: 'success', data: { executionId, state: 'Recovering' } });
    } catch (err) {
      rep.status(400).send({ status: 'error', message: (err as Error).message });
    }
  }

  async getDashboard(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const incidents = IncidentManager.findAll();
    const history = RunbookRepository.getLatest('manual_remediation') ? 1 : 0;
    const breaker = CircuitBreaker.getState();
    const remainingBudget = RecoveryBudgetManager.getRemainingBudget();
    const audits = AuditTrail.getLogs();

    rep.send({
      status: 'success',
      data: {
        currentHealth: incidents.filter(i => i.state === 'Open').length === 0 ? 'Healthy' : 'Degraded',
        activeRecovery: 0,
        recoveryHistory: history,
        recoverySuccessRate: 100,
        mttr: 120, // default SLA emulation in seconds
        mtbf: 86400,
        activeIncident: incidents.filter(i => i.state === 'Open').length,
        circuitBreaker: breaker,
        budget: remainingBudget,
        auditsCount: audits.length,
      },
    });
  }
}
export const resilienceController = new ResilienceController();
export default resilienceController;
