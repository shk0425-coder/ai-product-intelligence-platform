export class SingleFlight {
  private static readonly flights = new Map<string, Promise<unknown>>();

  static async do<T>(key: string, fn: () => Promise<T>, timeoutMs = 15000): Promise<T> {
    const existing = this.flights.get(key);
    if (existing) {
      return existing as Promise<T>;
    }

    const promise = new Promise<T>((resolve, reject) => {
      let isSettled = false;

      const timeout = setTimeout(() => {
        if (!isSettled) {
          isSettled = true;
          this.flights.delete(key);
          reject(new Error(`SingleFlight operation timed out for key: ${key}`));
        }
      }, timeoutMs);

      fn()
        .then((result) => {
          if (!isSettled) {
            isSettled = true;
            clearTimeout(timeout);
            this.flights.delete(key);
            resolve(result);
          }
        })
        .catch((err) => {
          if (!isSettled) {
            isSettled = true;
            clearTimeout(timeout);
            this.flights.delete(key);
            reject(err);
          }
        });
    });

    this.flights.set(key, promise);
    return promise;
  }

  static clear(): void {
    this.flights.clear();
  }
}
