import { ToolDefinitionEntity, ToolVersionEntity } from './types.js';
import { ToolSchemaValidator } from './validator.js';
import { ToolPermissionChecker } from './permission.js';
import { ToolSandbox, SandboxResult } from './sandbox.js';
import { ToolExecutor } from './executor.js';

export class ToolRegistry {
  private static readonly definitions = new Map<string, ToolDefinitionEntity>();
  private static readonly versions = new Map<string, ToolVersionEntity>();

  static cacheDefinition(def: ToolDefinitionEntity): void {
    this.definitions.set(def.id, def);
  }

  static getDefinition(id: string): ToolDefinitionEntity | null {
    return this.definitions.get(id) || null;
  }

  static cacheVersion(ver: ToolVersionEntity): void {
    this.versions.set(ver.id, ver);
  }

  static getVersion(id: string): ToolVersionEntity | null {
    return this.versions.get(id) || null;
  }

  static clear(): void {
    this.definitions.clear();
    this.versions.clear();
  }
}

export class ToolRuntime {
  static async execute(
    version: ToolVersionEntity,
    request: Record<string, unknown>,
    workspacePermissions: string[]
  ): Promise<SandboxResult> {
    // 1. Permission checks
    ToolPermissionChecker.verify(version.permission || [], workspacePermissions);

    // 2. Validate Input parameters
    ToolSchemaValidator.validate(version.input_schema || {}, request);

    // 3. Execution isolated under Sandbox
    const sandboxResult = await ToolSandbox.run(async () => {
      const output = await ToolExecutor.run(version.manifest.category, request);

      // Validate Output parameters
      ToolSchemaValidator.validate(version.output_schema || {}, output);

      return output;
    }, version.timeout_ms || 5000);

    return sandboxResult;
  }
}
