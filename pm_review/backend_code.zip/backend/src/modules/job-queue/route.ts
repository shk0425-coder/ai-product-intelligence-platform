import { FastifyInstance } from 'fastify';
import { JobQueueController } from './controller.js';
import { JobQueueService } from './service.js';
import { JobQueueRepository } from './repository.js';
import { supabase } from '@/config/supabase.js';

export async function jobQueueRoutes(fastify: FastifyInstance) {
  const repository = new JobQueueRepository(supabase);
  const service = new JobQueueService(repository);
  const controller = new JobQueueController(service);

  // Authentication check is handled globally or via preValidation in Fastify hooks
  fastify.post('/enqueue', (req, rep) => controller.enqueue(req as import('fastify').FastifyRequest<{ Body: import('./dto.js').EnqueueJobDto }>, rep));
  fastify.post('/retry', (req, rep) => controller.retry(req as import('fastify').FastifyRequest<{ Body: import('./dto.js').JobActionDto }>, rep));
  fastify.post('/cancel', (req, rep) => controller.cancel(req as import('fastify').FastifyRequest<{ Body: import('./dto.js').JobActionDto }>, rep));
  fastify.get('/status/:jobId', (req, rep) => controller.getStatus(req as import('fastify').FastifyRequest<{ Params: { jobId: string } }>, rep));
  fastify.get('/history', (req, rep) => controller.getHistory(req as import('fastify').FastifyRequest<{ Querystring: { workspaceId: string } }>, rep));
  fastify.get('/dead-letter', (req, rep) => controller.getDeadLetters(req, rep));
  fastify.post('/dead-letter/recover', (req, rep) => controller.recoverDeadLetter(req as import('fastify').FastifyRequest<{ Body: { deadLetterId: string } }>, rep));
}
