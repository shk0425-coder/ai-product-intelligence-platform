import { TraceManager, Span } from '../tracing/trace-manager.js';
import { MetricsRegistry } from '../metrics/registry.js';
import { Logger } from '../logging/logger.js';

export class HttpInstrumentation {
  static startRequest(endpoint: string, method: string): Span {
    const span = TraceManager.startSpan(`HTTP ${method} ${endpoint}`);
    span.setAttribute('endpoint', endpoint);
    span.setAttribute('method', method);
    
    Logger.info({
      message: `HTTP Request Started: ${method} ${endpoint}`,
      module: 'HTTP',
      action: 'Request',
    });

    return span;
  }

  static endRequest(span: Span, endpoint: string, method: string, statusCode: number, durationMs: number): void {
    span.setAttribute('status_code', statusCode);
    span.setStatus(statusCode >= 400 ? 'ERROR' : 'OK');
    span.end();

    MetricsRegistry.counter('http_requests_total', 1, { endpoint, status: String(statusCode) });
    MetricsRegistry.histogram('http_request_duration_seconds', durationMs / 1000, { endpoint, status: String(statusCode) });

    Logger.info({
      message: `HTTP Request Completed: ${method} ${endpoint} - ${statusCode}`,
      module: 'HTTP',
      action: 'Response',
      durationMs,
      status: String(statusCode),
    });
  }

  static recordError(span: Span, endpoint: string, err: Error): void {
    span.setStatus('ERROR', err.message);
    MetricsRegistry.counter('http_errors_total', 1, { endpoint });
    
    Logger.error({
      message: `HTTP Request Failed: ${err.message}`,
      module: 'HTTP',
      action: 'Error',
      errorCode: 'HTTP_FAIL',
    });
  }
}
