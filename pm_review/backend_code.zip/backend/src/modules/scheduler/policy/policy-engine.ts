import { JobDefinition } from '../persistence/job-repository.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export interface SchedulerPolicy {
  name: string;
  evaluate(job: JobDefinition): Promise<{ allowed: boolean; reason?: string }>;
}

export class TimeoutPolicy implements SchedulerPolicy {
  name = 'TimeoutPolicy';
  private defaultTimeout = 60000; // 60s

  async evaluate(job: JobDefinition): Promise<{ allowed: boolean; reason?: string }> {
    const timeout = job.timeoutMs || Number(process.env.DEFAULT_TIMEOUT) || this.defaultTimeout;
    if (timeout <= 0) {
      return { allowed: false, reason: 'Invalid job timeout threshold' };
    }
    return { allowed: true };
  }
}

export class RetryPolicy implements SchedulerPolicy {
  name = 'RetryPolicy';
  async evaluate(job: JobDefinition): Promise<{ allowed: boolean; reason?: string }> {
    if (job.maxRetry < 0 || job.backoffMs < 0) {
      return { allowed: false, reason: 'Retry counts or backoff delay cannot be negative' };
    }
    return { allowed: true };
  }
}

export class PriorityPolicy implements SchedulerPolicy {
  name = 'PriorityPolicy';
  private allowedPriorities = new Set(['Critical', 'High', 'Normal', 'Low']);

  async evaluate(job: JobDefinition): Promise<{ allowed: boolean; reason?: string }> {
    if (!this.allowedPriorities.has(job.priority)) {
      return { allowed: false, reason: `Unknown priority tier: ${job.priority}` };
    }
    return { allowed: true };
  }
}

export class DependencyPolicy implements SchedulerPolicy {
  name = 'DependencyPolicy';
  async evaluate(_job: JobDefinition): Promise<{ allowed: boolean; reason?: string }> {
    // Empty DAG validation placeholder.
    // Core dependency DAG evaluation is handled in dag-executor.ts.
    return { allowed: true };
  }
}

export class RateLimitPolicy implements SchedulerPolicy {
  name = 'RateLimitPolicy';
  async evaluate(_job: JobDefinition): Promise<{ allowed: boolean; reason?: string }> {
    // Rate Limit token validations.
    // Core rate limit checking is processed inside rate-limiter.ts.
    return { allowed: true };
  }
}

export class PolicyEngine {
  private static readonly policies: SchedulerPolicy[] = [
    new TimeoutPolicy(),
    new RetryPolicy(),
    new PriorityPolicy(),
    new DependencyPolicy(),
    new RateLimitPolicy(),
  ];

  static async inspect(job: JobDefinition): Promise<{ allowed: boolean; reason?: string }> {
    for (const policy of this.policies) {
      const res = await policy.evaluate(job);
      if (!res.allowed) {
        MetricsRegistry.counter('scheduler_policy_violation_total', 1, { queue: job.name });
        
        eventBus.publish({
          eventId: crypto.randomUUID(),
          eventType: 'PolicyViolation',
          timestamp: new Date().toISOString(),
          workspaceId: (job.metadata.workspaceId as string) || 'default-workspace',
          data: { jobId: job.id, policyName: policy.name, reason: res.reason },
        }).catch(() => {});

        return { allowed: false, reason: `[${policy.name}] ${res.reason}` };
      }
    }
    return { allowed: true };
  }
}
