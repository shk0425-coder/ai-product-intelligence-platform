import { ValidationError } from '../../common/errors/index.js';
import { VariableParserResult } from './types.js';

export class VariableParser {
  static parse(text: string): VariableParserResult[] {
    const results: VariableParserResult[] = [];
    const regex = /\{\{([a-zA-Z0-9_?|]+)\}\}/g;
    let match;

    while ((match = regex.exec(text)) !== null) {
      const rawVar = match[1];
      
      let name = rawVar;
      let defaultValue: string | undefined = undefined;
      let isNullable = false;

      // Handle nullable modifier '?'
      if (name.endsWith('?')) {
        isNullable = true;
        name = name.slice(0, -1);
      }

      // Handle default value separator '|'
      if (name.includes('|')) {
        const parts = name.split('|');
        name = parts[0];
        defaultValue = parts[1];
      }

      // Ensure deduplicated list
      if (!results.some((r) => r.name === name)) {
        results.push({ name, defaultValue, isNullable });
      }
    }

    return results;
  }

  static validateAndInject(
    text: string,
    variables: Record<string, unknown>,
    declaredVars: VariableParserResult[]
  ): string {
    let rendered = text;

    for (const dVar of declaredVars) {
      const value = variables[dVar.name];

      // Validation check for missing and non-nullable fields
      if (value === undefined || value === null) {
        if (dVar.defaultValue !== undefined) {
          rendered = this.replaceAll(rendered, dVar.name, dVar.defaultValue);
        } else if (dVar.isNullable) {
          rendered = this.replaceAll(rendered, dVar.name, '');
        } else {
          throw new ValidationError(`Required prompt variable is missing: ${dVar.name}`);
        }
      } else {
        // Safe string casting for rendering
        const stringVal = typeof value === 'object' ? JSON.stringify(value) : String(value);
        rendered = this.replaceAll(rendered, dVar.name, stringVal);
      }
    }

    // Double check for any leftover unrendered braces
    const remaining = /\{\{([a-zA-Z0-9_?|]+)\}\}/.exec(rendered);
    if (remaining) {
      throw new ValidationError(`Prompt injection check failed. Found unresolved variable: ${remaining[1]}`);
    }

    return rendered;
  }

  private static replaceAll(text: string, varName: string, value: string): string {
    // Regex matches {{varName}} or {{varName|default}} or {{varName?}}
    const escapedVar = varName.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(`\\{\\{${escapedVar}(\\?[^}]*|\\|[^}]*|)\\}\\}`, 'g');
    return text.replace(regex, value);
  }
}
export default VariableParser;
