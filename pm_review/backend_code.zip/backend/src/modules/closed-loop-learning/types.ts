import { LearningKnowledgeDto, LearningVectorDto } from './dto.js';

export interface LearningKnowledgeEntity {
  id: string; // UUID Primary Key
  intelligence_id: string; // UUID FK
  knowledge_version: number; // INTEGER
  feature_summary: string; // TEXT
  success_pattern: string; // TEXT
  failure_pattern: string; // TEXT
  improvement_pattern: string; // TEXT
  knowledge_score: number; // NUMERIC(6,3)
  confidence_score: number; // NUMERIC(6,3)
  created_at: string; // TIMESTAMPTZ
  updated_at: string; // TIMESTAMPTZ
}

export interface LearningVectorEntity {
  id: string; // UUID PRIMARY KEY
  knowledge_id: string; // UUID FK
  vector_version: string; // VARCHAR(20)
  vector_data: Record<string, unknown>; // JSONB
  feature_count: number; // INTEGER
  checksum: string; // VARCHAR(128)
  created_at: string; // TIMESTAMPTZ
}

export interface LearningPatternEntity {
  id: string; // UUID PRIMARY KEY
  knowledge_id: string; // UUID FK
  category: string; // VARCHAR(50)
  severity: number; // INTEGER
  frequency: number; // INTEGER
  pattern_hash: string; // VARCHAR(128)
  pattern_data: Record<string, unknown>; // JSONB
  created_at: string; // TIMESTAMPTZ
}

export interface LearningAuditEntity {
  id: string; // UUID PRIMARY KEY
  knowledge_id: string; // UUID FK
  action: string; // VARCHAR(20)
  actor_id: string; // UUID
  knowledge_version: number; // INTEGER
  timestamp: string; // TIMESTAMPTZ
  metadata: Record<string, unknown>; // JSONB
}

export interface ILearningRepository {
  createKnowledge(payload: Partial<LearningKnowledgeEntity>): Promise<LearningKnowledgeEntity>;
  createVector(payload: Partial<LearningVectorEntity>): Promise<LearningVectorEntity>;
  createPattern(payload: Partial<LearningPatternEntity>): Promise<LearningPatternEntity>;
  createAudit(payload: Partial<LearningAuditEntity>): Promise<LearningAuditEntity>;

  findKnowledge(knowledgeId: string): Promise<LearningKnowledgeEntity | null>;
  findLatest(productId: string): Promise<LearningKnowledgeEntity | null>;
  findHistory(productId: string): Promise<LearningKnowledgeEntity[]>;

  exists(intelligenceId: string, version?: number): Promise<boolean>;
}

export interface LearningEventPayload {
  knowledge: LearningKnowledgeDto;
  actorId: string;
  timestamp: string;
}

export interface ILearningHooks {
  onLearningKnowledgeCreated(payload: LearningEventPayload): Promise<void>;
  onLearningKnowledgeUpdated(payload: LearningEventPayload): Promise<void>;
  onLearningVectorGenerated(payload: { vector: LearningVectorDto; actorId: string }): Promise<void>;
}
