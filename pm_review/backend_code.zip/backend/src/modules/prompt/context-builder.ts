import {
  WorkspaceContextProvider,
  UserContextProvider,
  ProductContextProvider,
  ReviewContextProvider,
  JTBDContextProvider,
  MarketContextProvider,
  HistoryContextProvider,
  CustomContextProvider,
} from './context-provider.js';

export class DynamicContextBuilder {
  private static readonly providers = [
    new WorkspaceContextProvider(),
    new UserContextProvider(),
    new ProductContextProvider(),
    new ReviewContextProvider(),
    new JTBDContextProvider(),
    new MarketContextProvider(),
    new HistoryContextProvider(),
    new CustomContextProvider(),
  ];

  static async build(workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    let combinedContext: Record<string, unknown> = {};

    // Executes in fixed, deterministic order
    for (const provider of this.providers) {
      try {
        const partialContext = await provider.provide(workspaceId, variables);
        combinedContext = {
          ...combinedContext,
          ...partialContext,
        };
      } catch (_err) {
        // Suppress individual context provider errors or propagate
      }
    }

    return combinedContext;
  }
}
export default DynamicContextBuilder;
