export interface GenerateLearningDto {
  intelligenceId: string;
  vectorVersion?: string;
}

export interface RegenerateLearningDto {
  intelligenceId: string;
  vectorVersion?: string;
}

export interface LearningVectorDto {
  vectorId: string;
  knowledgeId: string;
  vectorVersion: string;
  vectorData: Record<string, unknown>;
  featureCount: number;
  checksum: string;
  createdAt: string;
}

export interface LearningKnowledgeDto {
  knowledgeId: string;
  intelligenceId: string;
  knowledgeVersion: number;
  featureSummary: string;
  successPattern: string;
  failurePattern: string;
  improvementPattern: string;
  knowledgeScore: number;
  confidenceScore: number;
  vector?: LearningVectorDto;
  createdAt: string;
  updatedAt: string;
}

export interface LearningHistoryDto {
  history: LearningKnowledgeDto[];
  totalCount: number;
}
