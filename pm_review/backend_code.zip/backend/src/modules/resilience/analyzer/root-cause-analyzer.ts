import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export interface AnalysisResult {
  rootCause: string;
  confidence: number;
  suggestedAction: string;
}

export class RootCauseAnalyzer {
  static async analyze(incidentSource: string): Promise<AnalysisResult> {
    let result: AnalysisResult = {
      rootCause: 'Unknown infrastructure anomaly',
      confidence: 50,
      suggestedAction: 'manual_remediation',
    };

    if (incidentSource.includes('redis')) {
      result = {
        rootCause: 'Redis connection timeout or memory pressure',
        confidence: 90,
        suggestedAction: 'reconnect_redis',
      };
    } else if (incidentSource.includes('queue')) {
      result = {
        rootCause: 'Queue worker capacity exhausted',
        confidence: 85,
        suggestedAction: 'retry_queue',
      };
    } else if (incidentSource.includes('worker')) {
      result = {
        rootCause: 'Background node process terminated abnormally',
        confidence: 95,
        suggestedAction: 'restart_worker',
      };
    }

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'RootCauseDetected',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { source: incidentSource, ...result },
    }).catch(() => {});

    return result;
  }
}
export default RootCauseAnalyzer;
