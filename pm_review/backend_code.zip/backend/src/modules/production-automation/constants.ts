/**
 * Production Automation Domain Constants
 */

export const AUTOMATION_LIMITS = {
  MAX_RETRY_COUNT: 3,
};

export const PROMPT_SECTIONS = {
  SYSTEM: 'System Prompt',
  RULES: 'Planning Rules',
  SUMMARY: 'Learning Summary',
  PATTERNS: 'Detected Patterns',
  VECTOR: 'Feature Vector',
  STRATEGY: 'Improvement Strategy',
  PRACTICE: 'Best Practices',
  REQUEST: 'User Request',
};
