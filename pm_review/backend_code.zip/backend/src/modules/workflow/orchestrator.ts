import { WorkflowGraph } from './types.js';

export class AgentOrchestrator {
  static getExecutionOrder(graph: WorkflowGraph): string[][] {
    const nodes = graph.nodes || [];
    const edges = graph.edges || [];

    const startNode = nodes.find((n) => n.type === 'Start');
    if (!startNode) return [];

    // Topological Sort / Level Order Traversal (BFS) for grouping execution layers
    const adj: Record<string, string[]> = {};
    const inDegree: Record<string, number> = {};

    for (const node of nodes) {
      adj[node.id] = [];
      inDegree[node.id] = 0;
    }

    for (const edge of edges) {
      adj[edge.from].push(edge.to);
      inDegree[edge.to]++;
    }

    const queue: string[] = [startNode.id];
    const orderGroups: string[][] = [];

    while (queue.length > 0) {
      const levelSize = queue.length;
      const currentLevel: string[] = [];

      for (let i = 0; i < levelSize; i++) {
        const u = queue.shift()!;
        currentLevel.push(u);

        for (const v of adj[u]) {
          inDegree[v]--;
          if (inDegree[v] === 0) {
            queue.push(v);
          }
        }
      }

      orderGroups.push(currentLevel);
    }

    return orderGroups;
  }
}
export default AgentOrchestrator;
