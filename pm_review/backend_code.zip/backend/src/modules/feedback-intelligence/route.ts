import { FastifyInstance, FastifyPluginOptions, FastifyRequest } from 'fastify';
import { FeedbackIntelligenceRepository } from './repository.js';
import { FeedbackIntelligenceService } from './service.js';
import { FeedbackIntelligenceController } from './controller.js';
import { authMiddleware } from '@/middleware/auth.middleware.js';
import {
  analyzeFeedbackSchema,
  reanalyzeFeedbackSchema,
  feedbackIdParamSchema,
  feedbackIntelProductParamSchema,
} from './schema.js';
import { ValidationError } from '@/common/errors/index.js';
import { z } from 'zod';

const validateBody =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.body);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.body = result.data;
  };

const validateParams =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.params);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.params = result.data;
  };

export default async function feedbackIntelligenceRoutes(
  fastify: FastifyInstance,
  _options: FastifyPluginOptions,
): Promise<void> {
  const repository = new FeedbackIntelligenceRepository(fastify.supabase);
  const service = new FeedbackIntelligenceService(repository);
  const controller = new FeedbackIntelligenceController(service);

  // Apply authentication globally
  fastify.addHook('preHandler', authMiddleware);

  // POST /analyze
  fastify.post('/analyze', {
    preValidation: validateBody(analyzeFeedbackSchema),
    handler: controller.analyze,
  });

  // POST /reanalyze
  fastify.post('/reanalyze', {
    preValidation: validateBody(reanalyzeFeedbackSchema),
    handler: controller.reanalyze,
  });

  // GET /feedback/:feedbackId
  fastify.get('/feedback/:feedbackId', {
    preValidation: validateParams(feedbackIdParamSchema),
    handler: controller.findByFeedback,
  });

  // GET /history/:productId
  fastify.get('/history/:productId', {
    preValidation: validateParams(feedbackIntelProductParamSchema),
    handler: controller.findHistory,
  });

  // GET /latest/:productId
  fastify.get('/latest/:productId', {
    preValidation: validateParams(feedbackIntelProductParamSchema),
    handler: controller.findLatest,
  });
}
