import crypto from 'crypto';
import { GenerateResponse } from './types.js';
import { CACHE_TTL_MS } from './constants.js';

interface CacheEntry {
  response: GenerateResponse;
  expiresAt: number;
}

export class ResponseCache {
  private static readonly cache = new Map<string, CacheEntry>();

  static get(prompt: string, workspaceId: string): GenerateResponse | null {
    const key = this.generateKey(prompt, workspaceId);
    const entry = this.cache.get(key);
    
    if (!entry) return null;

    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return entry.response;
  }

  static set(prompt: string, workspaceId: string, response: GenerateResponse, ttlMs: number = CACHE_TTL_MS): void {
    const key = this.generateKey(prompt, workspaceId);
    this.cache.set(key, {
      response,
      expiresAt: Date.now() + ttlMs,
    });
  }

  static delete(prompt: string, workspaceId: string): void {
    const key = this.generateKey(prompt, workspaceId);
    this.cache.delete(key);
  }

  static clear(): void {
    this.cache.clear();
  }

  private static generateKey(prompt: string, workspaceId: string): string {
    const hash = crypto.createHash('sha256').update(prompt).digest('hex');
    return `${workspaceId}:${hash}`;
  }
}
export default ResponseCache;
