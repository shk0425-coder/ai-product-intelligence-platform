import crypto from 'crypto';

export interface AuditRecord {
  logId: string;
  action: string;
  timestamp: number;
  hash: string;
}

export class AuditTrail {
  private static readonly logs: AuditRecord[] = [];
  private static lastHash = '0000000000000000000000000000000000000000000000000000000000000000';

  static async record(action: string): Promise<AuditRecord> {
    const timestamp = Date.now();
    const logId = crypto.randomUUID();

    const payload = `${logId}-${action}-${timestamp}-${this.lastHash}`;
    const hash = crypto.createHash('sha256').update(payload).digest('hex');

    const record: AuditRecord = {
      logId,
      action,
      timestamp,
      hash,
    };

    this.logs.push(record);
    this.lastHash = hash;
    return record;
  }

  static validateChain(): boolean {
    let prevHash = '0000000000000000000000000000000000000000000000000000000000000000';
    for (const log of this.logs) {
      const payload = `${log.logId}-${log.action}-${log.timestamp}-${prevHash}`;
      const hash = crypto.createHash('sha256').update(payload).digest('hex');
      if (hash !== log.hash) {
        return false; // Blockchain hash verification failed, compromised!
      }
      prevHash = hash;
    }
    return true;
  }

  static getLogs(): AuditRecord[] {
    return [...this.logs];
  }

  static clear(): void {
    this.logs.length = 0;
    this.lastHash = '0000000000000000000000000000000000000000000000000000000000000000';
  }
}
export default AuditTrail;
