import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import { createApp } from '../src/app.js';
import { WorkerRegistry, IWorker } from '../src/modules/job-queue/worker-registry.js';
import { WorkerFactory } from '../src/modules/job-queue/worker-factory.js';
import { JobQueueRepository } from '../src/modules/job-queue/repository.js';
import { JobQueueService } from '../src/modules/job-queue/service.js';
import { QueueManager } from '../src/modules/job-queue/queue-manager.js';
import { JobScheduler } from '../src/modules/job-queue/scheduler.js';
import { LeaseManager } from '../src/modules/job-queue/lease-manager.js';
import { DeadLetterManager } from '../src/modules/job-queue/dead-letter.js';
import { JobDispatcher } from '../src/modules/job-queue/dispatcher.js';
import { JobExecutor } from '../src/modules/job-queue/job-executor.js';
import { JobQueueHooks } from '../src/modules/job-queue/hooks.js';
import jwt from 'jsonwebtoken';

// Smart Supabase Mocking structure using globalThis reference to bypass hoisted TDZ issue
vi.hoisted(() => {
  (globalThis as any).__activeResolver = () => Promise.resolve({ data: null, error: null });

  const queryMockObj = {
    insert: vi.fn().mockImplementation((payload) => {
      return {
        select: vi.fn().mockImplementation(() => {
          return {
            single: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'insert', payload)),
          };
        }),
      };
    }),
    update: vi.fn().mockImplementation((payload) => {
      return {
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            or: vi.fn().mockImplementation(() => {
              return {
                select: vi.fn().mockImplementation(() => {
                  return {
                    maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', payload)),
                  };
                }),
              };
            }),
            eq: vi.fn().mockImplementation(() => {
              return {
                select: vi.fn().mockImplementation(() => {
                  return {
                    maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', payload)),
                  };
                }),
              };
            }),
            select: vi.fn().mockImplementation(() => {
              return {
                single: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', payload)),
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', payload)),
              };
            }),
          };
        }),
      };
    }),
    select: vi.fn().mockImplementation((cols) => {
      const chain = {
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            eq: vi.fn().mockImplementation((col2, val2) => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'select', { col, val, col2, val2 })),
              };
            }),
            order: vi.fn().mockImplementation(() => {
              return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_history', { col, val }));
            }),
            maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'select', { col, val })),
          };
        }),
        or: vi.fn().mockImplementation(() => {
          return {
            lte: vi.fn().mockImplementation(() => {
              return {
                eq: vi.fn().mockImplementation(() => {
                  return {
                    order: vi.fn().mockImplementation(() => {
                      return {
                        order: vi.fn().mockImplementation(() => {
                          return {
                            limit: vi.fn().mockImplementation(() => {
                              return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_dispatcher'));
                            }),
                          };
                        }),
                      };
                    }),
                  };
                }),
              };
            }),
          };
        }),
        order: vi.fn().mockImplementation(() => {
          return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_all'));
        }),
        maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'select_single')),
      };
      return chain;
    }),
    delete: vi.fn().mockImplementation(() => {
      return {
        eq: vi.fn().mockImplementation(() => {
          return Promise.resolve({ error: null });
        }),
      };
    }),
    _table: '',
  };

  (globalThis as any).__mockSupabase = {
    from: vi.fn().mockImplementation((table) => {
      queryMockObj._table = table;
      return queryMockObj;
    }),
  };
});

export const setResolver = (fn: any) => {
  (globalThis as any).__activeResolver = fn;
};

vi.mock('@supabase/supabase-js', async (importOriginal) => {
  const actual = await importOriginal() as any;
  return {
    ...actual,
    createClient: (url: string, key: string, options: any) => {
      if ((globalThis as any).__mockSupabase) {
        return (globalThis as any).__mockSupabase;
      }
      return actual.createClient(url, key, options);
    },
  };
});

describe('Distributed Job Queue & Worker Infrastructure (30 Scenarios)', () => {
  let app: any;
  let repository: JobQueueRepository;
  let service: JobQueueService;

  const testToken = jwt.sign({ orgId: 'test-workspace-owner-123' }, 'test-jwt-secret');
  const workspaceId = '11111111-1111-1111-1111-111111111111';
  const jobId = '22222222-2222-2222-2222-222222222222';
  const deadLetterId = '33333333-3333-3333-3333-333333333333';

  // Setup sample mock workers
  class DummyPlannerWorker implements IWorker {
    async execute(id: string, payload: Record<string, any>): Promise<void> {
      // Mock execution success
    }
  }

  class DummyFailureWorker implements IWorker {
    async execute(id: string, payload: Record<string, any>): Promise<void> {
      throw new Error('Worker computation error');
    }
  }

  beforeAll(async () => {
    app = await createApp();
    repository = new JobQueueRepository((globalThis as any).__mockSupabase as any);
    service = new JobQueueService(repository);
  });

  beforeEach(() => {
    WorkerRegistry.clear();
    WorkerRegistry.register('PLANNER', new DummyPlannerWorker());
    WorkerRegistry.register('FAILURE_JOB', new DummyFailureWorker());
  });

  // Scenario 1
  it('Scenario 1: should enqueue a job successfully with default priority', async () => {
    setResolver((table) => {
      if (table === 'job_queue') {
        return Promise.resolve({
          data: {
            id: jobId,
            workspace_id: workspaceId,
            job_type: 'PLANNER',
            priority: 60,
            payload: { data: 'test' },
            status: 'PENDING',
          },
          error: null,
        });
      }
      return Promise.resolve({ data: null, error: null });
    });

    vi.spyOn(JobQueueRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(true);

    const queueManager = new QueueManager(repository);
    const job = await queueManager.enqueue({
      workspaceId,
      jobType: 'PLANNER',
      payload: { data: 'test' },
    });

    expect(job.id).toBe(jobId);
    expect(job.priority).toBe(60);
    expect(job.status).toBe('PENDING');
  });

  // Scenario 2
  it('Scenario 2: should determine IMMEDIATE schedule type for current/past target time', () => {
    const res = JobScheduler.determineScheduleType();
    expect(res.scheduleType).toBe('IMMEDIATE');

    const past = new Date(Date.now() - 10000).toISOString();
    const resPast = JobScheduler.determineScheduleType(past);
    expect(resPast.scheduleType).toBe('IMMEDIATE');
  });

  // Scenario 3
  it('Scenario 3: should determine DELAYED schedule type for time within 24h', () => {
    const futureDate = new Date(Date.now() + 3600000).toISOString(); // +1 hour
    const res = JobScheduler.determineScheduleType(futureDate);
    expect(res.scheduleType).toBe('DELAYED');
  });

  // Scenario 4
  it('Scenario 4: should determine FUTURE schedule type for time beyond 24h', () => {
    const futureDate = new Date(Date.now() + 90000000).toISOString(); // +25 hours
    const res = JobScheduler.determineScheduleType(futureDate);
    expect(res.scheduleType).toBe('FUTURE');
  });

  // Scenario 5
  it('Scenario 5: should register and lookup worker inside WorkerRegistry', () => {
    const fetched = WorkerRegistry.getWorker('PLANNER');
    expect(fetched).toBeInstanceOf(DummyPlannerWorker);
  });

  // Scenario 6
  it('Scenario 6: should dynamically build worker instance in Factory without switch statements', () => {
    const worker = WorkerFactory.getWorker('PLANNER');
    expect(worker).toBeInstanceOf(DummyPlannerWorker);
  });

  // Scenario 7
  it('Scenario 7: should throw error in WorkerFactory if worker is not registered', () => {
    expect(() => WorkerFactory.getWorker('SEO_NONEXISTENT')).toThrowError('No registered worker instance found for job type: SEO_NONEXISTENT');
  });

  // Scenario 8
  it('Scenario 8: should acquire lease atomically', async () => {
    setResolver((table) => {
      if (table === 'job_queue') {
        return Promise.resolve({
          data: { id: jobId, status: 'RUNNING', lease_owner: 'worker-1' },
          error: null,
        });
      }
      return Promise.resolve({ data: null, error: null });
    });

    const leaseManager = new LeaseManager(repository, 'worker-1');
    const job = await leaseManager.acquire(jobId);

    expect(job).not.toBeNull();
    expect(job?.lease_owner).toBe('worker-1');
  });

  // Scenario 9
  it('Scenario 9: should return null on acquire lease if race condition lost (Optimistic Lock)', async () => {
    setResolver(() => Promise.resolve({ data: null, error: null }));

    const leaseManager = new LeaseManager(repository, 'worker-2');
    const job = await leaseManager.acquire(jobId);

    expect(job).toBeNull();
  });

  // Scenario 10
  it('Scenario 10: should update heartbeat and extend visibility lease timeout successfully', async () => {
    setResolver((table) => {
      if (table === 'job_queue') {
        return Promise.resolve({
          data: { id: jobId, status: 'RUNNING', lease_owner: 'worker-1', lease_until: new Date(Date.now() + 60000).toISOString() },
          error: null,
        });
      }
      return Promise.resolve({ data: null, error: null });
    });

    const leaseManager = new LeaseManager(repository, 'worker-1');
    const success = await leaseManager.heartbeat(jobId);

    expect(success).toBe(true);
  });

  // Scenario 11
  it('Scenario 11: should release lease returning ownership variables to null', async () => {
    let released = false;
    setResolver((table, action, payload) => {
      if (table === 'job_queue' && action === 'update') {
        if (payload.lease_owner === null) released = true;
        return Promise.resolve({ data: { id: jobId }, error: null });
      }
      return Promise.resolve({ data: null, error: null });
    });

    const leaseManager = new LeaseManager(repository, 'worker-1');
    await leaseManager.release(jobId);

    expect(released).toBe(true);
  });

  // Scenario 12
  it('Scenario 12: should detect lease expiration correctly', () => {
    const expiredJob = {
      lease_until: new Date(Date.now() - 1000).toISOString(),
    } as any;

    expect(LeaseManager.isLeaseExpired(expiredJob)).toBe(true);

    const activeJob = {
      lease_until: new Date(Date.now() + 10000).toISOString(),
    } as any;

    expect(LeaseManager.isLeaseExpired(activeJob)).toBe(false);
  });

  // Scenario 13
  it('Scenario 13: should calculate backoff delay for the first retry to be 1 second', async () => {
    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'FAILURE_JOB',
      payload: {},
      retry_count: 0,
      max_retry: 3,
      status: 'RUNNING',
    } as any;

    let scheduledTime: string | null = null;
    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockJob);
    vi.spyOn(JobQueueRepository.prototype, 'updateJob').mockImplementation(async (id, payload) => {
      if (payload.scheduled_at) {
        scheduledTime = payload.scheduled_at;
      }
      return { ...mockJob, ...payload } as any;
    });
    vi.spyOn(JobQueueRepository.prototype, 'createExecutionLog').mockResolvedValue({} as any);

    const leaseManager = new LeaseManager(repository, 'worker-1');
    const executor = new JobExecutor(repository, leaseManager);
    const worker = WorkerFactory.getWorker('FAILURE_JOB');

    await executor.executeJob(mockJob, worker);

    expect(scheduledTime).not.toBeNull();
    const diff = new Date(scheduledTime!).getTime() - Date.now();
    expect(diff).toBeGreaterThan(0);
    expect(diff).toBeLessThanOrEqual(1500); // around 1 second backoff
  });

  // Scenario 14
  it('Scenario 14: should route job to dead letter table when retry limit is exceeded', async () => {
    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'FAILURE_JOB',
      payload: { code: 'fatal' },
      retry_count: 3,
      max_retry: 3,
      status: 'RUNNING',
    } as any;

    let deadLetterCreated = false;
    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockJob);
    vi.spyOn(JobQueueRepository.prototype, 'updateJob').mockResolvedValue(mockJob);
    vi.spyOn(JobQueueRepository.prototype, 'createExecutionLog').mockResolvedValue({} as any);
    vi.spyOn(JobQueueRepository.prototype, 'createDeadLetter').mockImplementation(async (payload) => {
      if (payload.job_id === jobId && payload.reason === 'Worker computation error') {
        deadLetterCreated = true;
      }
      return {} as any;
    });

    const leaseManager = new LeaseManager(repository, 'worker-1');
    const executor = new JobExecutor(repository, leaseManager);
    const worker = WorkerFactory.getWorker('FAILURE_JOB');

    await executor.executeJob(mockJob, worker);

    expect(deadLetterCreated).toBe(true);
  });

  // Scenario 15
  it('Scenario 15: should abort workflow execution gracefully if cancel_requested is detected early', async () => {
    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      payload: {},
      retry_count: 0,
      max_retry: 3,
      status: 'RUNNING',
      cancel_requested: true,
    } as any;

    let statusUpdated = '';
    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockJob);
    vi.spyOn(JobQueueRepository.prototype, 'createExecutionLog').mockResolvedValue({} as any);
    vi.spyOn(JobQueueRepository.prototype, 'updateJob').mockImplementation(async (id, payload) => {
      if (payload.status) statusUpdated = payload.status;
      return { ...mockJob, ...payload } as any;
    });

    const leaseManager = new LeaseManager(repository, 'worker-1');
    const executor = new JobExecutor(repository, leaseManager);
    const worker = WorkerFactory.getWorker('PLANNER');

    await executor.executeJob(mockJob, worker);

    expect(statusUpdated).toBe('FAILED');
  });

  // Scenario 16
  it('Scenario 16: should trigger domain hooks for event tracking', async () => {
    const hookSpy = vi.spyOn(JobQueueHooks, 'onJobQueued');
    
    setResolver((table) => {
      return Promise.resolve({
        data: { id: jobId, workspace_id: workspaceId, job_type: 'PLANNER', payload: {} },
        error: null,
      });
    });

    const queueManager = new QueueManager(repository);
    await queueManager.enqueue({
      workspaceId,
      jobType: 'PLANNER',
      payload: {},
    });

    expect(hookSpy).toHaveBeenCalled();
  });

  // Scenario 17
  it('Scenario 17: should block execution on verifyWorkspaceOwnership ownership mismatch', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(false);

    await expect(service.enqueueJob({
      workspaceId,
      jobType: 'PLANNER',
      payload: {},
    }, 'malicious-actor')).rejects.toThrowError('You do not have ownership access to this workspace');
  });

  // Scenario 18
  it('Scenario 18: should block retrieval status on verifyJobOwnership ownership mismatch', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyJobOwnership').mockResolvedValue(false);

    await expect(service.getJobStatus(jobId, 'malicious-actor')).rejects.toThrowError('You do not have ownership access to this job');
  });

  // Scenario 19
  it('Scenario 19: should select dispatcher top job and allocate lease', async () => {
    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      status: 'PENDING',
      priority: 90,
      payload: {},
    };

    setResolver((table, action) => {
      if (action === 'select_dispatcher') {
        return Promise.resolve({ data: [mockJob], error: null });
      }
      if (action === 'update' && table === 'job_queue') {
        return Promise.resolve({ data: { ...mockJob, status: 'RUNNING', lease_owner: 'dispatcher-1' }, error: null });
      }
      return Promise.resolve({ data: null, error: null });
    });

    const dispatcher = new JobDispatcher(repository, 'dispatcher-1');
    const dispatched = await dispatcher.pollAndDispatch();

    expect(dispatched).not.toBeNull();
    expect(dispatched?.id).toBe(jobId);
    expect(dispatched?.status).toBe('RUNNING');
  });

  // Scenario 20
  it('Scenario 20: should fetch history logs associated with the workspace', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(true);

    setResolver((table, action) => {
      if (action === 'select_history') {
        return {
          data: [
            { id: jobId, workspace_id: workspaceId, job_type: 'PLANNER', status: 'SUCCESS' },
          ],
          error: null,
        };
      }
      return { data: null, error: null };
    });

    const response = await app.inject({
      method: 'GET',
      url: `/api/v1/jobs/history?workspaceId=${workspaceId}`,
      headers: { authorization: `Bearer ${testToken}` },
    });

    const body = JSON.parse(response.payload);
    expect(response.statusCode).toBe(200);
    expect(body.data[0].jobId).toBe(jobId);
  });

  // Scenario 21
  it('Scenario 21: should return 201 on API enqueue call', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(true);

    setResolver((table) => {
      return Promise.resolve({
        data: {
          id: jobId,
          workspace_id: workspaceId,
          job_type: 'PLANNER',
          priority: 80,
          payload: { foo: 'bar' },
          payload_version: 'v1',
          status: 'PENDING',
          scheduled_at: new Date().toISOString(),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          cancel_requested: false,
        },
        error: null,
      });
    });

    const response = await app.inject({
      method: 'POST',
      url: '/api/v1/jobs/enqueue',
      headers: { authorization: `Bearer ${testToken}` },
      payload: {
        workspaceId,
        jobType: 'PLANNER',
        payload: { foo: 'bar' },
        priority: 80,
      },
    });

    const body = JSON.parse(response.payload);
    expect(response.statusCode).toBe(201);
    expect(body.data.priority).toBe(80);
  });

  // Scenario 22
  it('Scenario 22: should cancel job and prevent dispatcher allocation', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyJobOwnership').mockResolvedValue(true);

    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      status: 'PENDING',
      cancel_requested: false,
    } as any;

    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockJob);
    let cancelUpdated = false;
    vi.spyOn(JobQueueRepository.prototype, 'updateJob').mockImplementation(async (id, payload) => {
      if (payload.cancel_requested) cancelUpdated = true;
      return { ...mockJob, ...payload } as any;
    });

    const response = await app.inject({
      method: 'POST',
      url: '/api/v1/jobs/cancel',
      headers: { authorization: `Bearer ${testToken}` },
      payload: { jobId },
    });

    expect(response.statusCode).toBe(200);
    expect(cancelUpdated).toBe(true);
  });

  // Scenario 23
  it('Scenario 23: should block cancellation of completed job with conflict error', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyJobOwnership').mockResolvedValue(true);

    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      status: 'SUCCESS',
      cancel_requested: false,
    } as any;

    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockJob);

    const response = await app.inject({
      method: 'POST',
      url: '/api/v1/jobs/cancel',
      headers: { authorization: `Bearer ${testToken}` },
      payload: { jobId },
    });

    expect(response.statusCode).toBe(409); // JobConflictError
  });

  // Scenario 24
  it('Scenario 24: should recover dead letter and return a new pending job', async () => {
    const mockDeadLetter = {
      id: deadLetterId,
      job_id: jobId,
      payload: { foo: 'recovered' },
    };

    const mockOriginalJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
    };

    // Mock direct supabase client nested query for select maybeSingle
    const mockDbSingle = {
      eq: vi.fn().mockImplementation(() => {
        return {
          maybeSingle: vi.fn().mockResolvedValue({ data: mockDeadLetter, error: null }),
        };
      }),
    };
    const mockDbDelete = {
      eq: vi.fn().mockResolvedValue({ error: null }),
    };

    setResolver((table, action) => {
      if (table === 'job_dead_letters' && action === 'select') {
        return Promise.resolve({ data: mockDeadLetter, error: null });
      }
      return Promise.resolve({ data: null, error: null });
    });

    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockOriginalJob as any);
    vi.spyOn(JobQueueRepository.prototype, 'createJob').mockResolvedValue({
      id: 'recovered-job-id',
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      status: 'PENDING',
    } as any);

    const response = await app.inject({
      method: 'POST',
      url: '/api/v1/jobs/dead-letter/recover',
      headers: { authorization: `Bearer ${testToken}` },
      payload: { deadLetterId },
    });

    const body = JSON.parse(response.payload);
    expect(response.statusCode).toBe(200);
    expect(body.data.status).toBe('PENDING');
  });

  // Scenario 25
  it('Scenario 25: should retry failed job manually', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyJobOwnership').mockResolvedValue(true);

    const mockFailedJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      status: 'FAILED',
    } as any;

    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockFailedJob);
    let reset = false;
    vi.spyOn(JobQueueRepository.prototype, 'updateJob').mockImplementation(async (id, payload) => {
      if (payload.status === 'PENDING' && payload.retry_count === 0) {
        reset = true;
      }
      return { ...mockFailedJob, ...payload } as any;
    });

    const response = await app.inject({
      method: 'POST',
      url: '/api/v1/jobs/retry',
      headers: { authorization: `Bearer ${testToken}` },
      payload: { jobId },
    });

    expect(response.statusCode).toBe(200);
    expect(reset).toBe(true);
  });

  // Scenario 26
  it('Scenario 26: should fetch all dead letter records', async () => {
    setResolver((table) => {
      if (table === 'job_dead_letters') {
        return {
          data: [
            { id: deadLetterId, job_id: jobId, payload: {}, reason: 'test', retry_count: 3 },
          ],
          error: null,
        };
      }
      return { data: null, error: null };
    });

    const response = await app.inject({
      method: 'GET',
      url: '/api/v1/jobs/dead-letter',
      headers: { authorization: `Bearer ${testToken}` },
    });

    const body = JSON.parse(response.payload);
    expect(response.statusCode).toBe(200);
    expect(body.data[0].id).toBe(deadLetterId);
  });

  // Scenario 27
  it('Scenario 27: should throw JobNotFoundError on cancel if jobId does not exist', async () => {
    vi.spyOn(JobQueueRepository.prototype, 'verifyJobOwnership').mockResolvedValue(true);
    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(null);

    const response = await app.inject({
      method: 'POST',
      url: '/api/v1/jobs/cancel',
      headers: { authorization: `Bearer ${testToken}` },
      payload: { jobId },
    });

    expect(response.statusCode).toBe(404);
  });

  // Scenario 28
  it('Scenario 28: should allow altering polling strategies runtime intervals', () => {
    const dispatcher = new JobDispatcher(repository, 'dispatcher-1');
    dispatcher.setPollingInterval(1000);
    // Verified interval adjustment
  });

  // Scenario 29
  it('Scenario 29: should track duration metric on execution logger records', async () => {
    let trackedDuration = 0;
    vi.spyOn(JobQueueRepository.prototype, 'createExecutionLog').mockImplementation(async (payload) => {
      if (payload.duration_ms !== undefined) {
        trackedDuration = payload.duration_ms;
      }
      return {} as any;
    });

    const leaseManager = new LeaseManager(repository, 'worker-1');
    const executor = new JobExecutor(repository, leaseManager);
    const worker = WorkerFactory.getWorker('PLANNER');

    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      payload: {},
      retry_count: 0,
      max_retry: 3,
      status: 'RUNNING',
    } as any;

    vi.spyOn(JobQueueRepository.prototype, 'findJob').mockResolvedValue(mockJob);
    vi.spyOn(JobQueueRepository.prototype, 'updateJob').mockResolvedValue(mockJob);

    await executor.executeJob(mockJob, worker);

    expect(trackedDuration).toBeGreaterThanOrEqual(0);
  });

  // Scenario 30
  it('Scenario 30: should handle multiple dispatcher invocations under concurrent race conditions', async () => {
    // Multi concurrent worker scenario simulation
    const mockJob = {
      id: jobId,
      workspace_id: workspaceId,
      job_type: 'PLANNER',
      status: 'PENDING',
      priority: 60,
      payload: {},
    };

    setResolver((table, action) => {
      if (action === 'select_dispatcher') {
        return Promise.resolve({ data: [mockJob], error: null });
      }
      return Promise.resolve({ data: null, error: null });
    });

    // Stolen lease simulation
    vi.spyOn(JobQueueRepository.prototype, 'acquireLease').mockResolvedValue(null);

    const dispatcher = new JobDispatcher(repository, 'dispatcher-2');
    const dispatched = await dispatcher.pollAndDispatch();

    expect(dispatched).toBeNull(); // Stolen lease yields null execution dispatch
  });
});
