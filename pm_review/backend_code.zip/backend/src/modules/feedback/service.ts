import { FeedbackRepository } from './repository.js';
import { CalculateFeedbackDto, RecalculateFeedbackDto, FeedbackResponseDto } from './dto.js';
import { FeedbackMapper } from './mapper.js';
import { FeedbackCalculator } from './calculator.js';
import { FeedbackGrading } from './grading.js';
import { FEEDBACK_WEIGHTS } from './weights.js';
import { FeedbackHooks } from './hooks.js';
import {
  FeedbackNotFoundError,
  DuplicateFeedbackError,
  PerformanceNotFoundError,
  WorkspaceForbiddenError,
} from '@/common/errors/index.js';
import { SupabaseClient } from '@supabase/supabase-js';

export class FeedbackService {
  constructor(private readonly feedbackRepository: FeedbackRepository) {}

  async calculate(dto: CalculateFeedbackDto, actorId: string): Promise<FeedbackResponseDto> {
    const { performanceId, formulaVersion = 'v1' } = dto;

    // 1. Verify Ownership
    const isOwner = await this.feedbackRepository.verifyPerformanceOwner(performanceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this performance record',
      );
    }

    // 2. Fetch Performance Snapshot
    const supabase = (this.feedbackRepository as unknown as { supabase: SupabaseClient }).supabase;
    const { data: performance, error: perfError } = await supabase
      .from('product_performance')
      .select('*')
      .eq('id', performanceId)
      .is('deleted_at', null)
      .maybeSingle();

    if (perfError || !performance) {
      throw new PerformanceNotFoundError('Performance snapshot not found or has been deleted');
    }

    // 3. Fetch Metrics Snapshot
    const { data: metrics, error: metricsError } = await supabase
      .from('performance_metrics')
      .select('*')
      .eq('performance_id', performanceId)
      .maybeSingle();

    if (metricsError || !metrics) {
      throw new PerformanceNotFoundError('Performance metrics not found');
    }

    // 4. Check for Existing Feedback
    const existing = await this.feedbackRepository.findByPerformance(performanceId, formulaVersion);
    if (existing) {
      throw new DuplicateFeedbackError(
        `Feedback score already calculated for performance ${performanceId} and formula ${formulaVersion}. Use recalculate instead.`,
      );
    }

    // 5. Calculate Score & Grade
    const calculatorInput = {
      sales_count: performance.sales_count,
      review_score: performance.review_score,
      conversion_rate: performance.conversion_score || 0.0, // fallback if named differently
      ctr: metrics.ctr || 0.0,
      roi: metrics.roi || 0.0,
      profit: metrics.profit || 0.0,
      favorite_count: performance.favorite_count,
      refund_count: performance.refund_count,
    };

    // Correct conversion_rate from performance snapshot (default conversion_score fallback)
    calculatorInput.conversion_rate = performance.conversion_score
      ? Number(performance.conversion_score)
      : metrics.conversion_rate
        ? Number(metrics.conversion_rate)
        : 0.0;

    const scores = FeedbackCalculator.calculate(calculatorInput);
    const grade = FeedbackGrading.calculateGrade(scores.overallScore);

    // 6. Persist to DB
    const insertPayload = {
      performance_id: performanceId,
      calculation_version: 1,
      sales_score: scores.salesScore,
      review_score: scores.reviewScore,
      conversion_score: scores.conversionScore,
      engagement_score: scores.engagementScore,
      profitability_score: scores.profitabilityScore,
      refund_penalty: scores.refundPenalty,
      overall_score: scores.overallScore,
      grade,
      weight_snapshot: FEEDBACK_WEIGHTS,
      formula_version: formulaVersion,
      calculated_at: new Date().toISOString(),
    };

    const createdEntity = await this.feedbackRepository.create(insertPayload);

    const result = FeedbackMapper.toResponseDto(createdEntity);

    // 7. Trigger Domain Hook
    await FeedbackHooks.onFeedbackCalculated({
      feedback: result,
      actorId,
      timestamp: new Date().toISOString(),
    });

    return result;
  }

  async recalculate(dto: RecalculateFeedbackDto, actorId: string): Promise<FeedbackResponseDto> {
    const { performanceId, formulaVersion = 'v1' } = dto;

    // 1. Verify Ownership
    const isOwner = await this.feedbackRepository.verifyPerformanceOwner(performanceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this performance record',
      );
    }

    // 2. Fetch Performance & Metrics Snapshots
    const supabase = (this.feedbackRepository as unknown as { supabase: SupabaseClient }).supabase;
    const { data: performance } = await supabase
      .from('product_performance')
      .select('*')
      .eq('id', performanceId)
      .is('deleted_at', null)
      .maybeSingle();

    if (!performance) {
      throw new PerformanceNotFoundError('Performance snapshot not found or has been deleted');
    }

    const { data: metrics } = await supabase
      .from('performance_metrics')
      .select('*')
      .eq('performance_id', performanceId)
      .maybeSingle();

    if (!metrics) {
      throw new PerformanceNotFoundError('Performance metrics not found');
    }

    // 3. Fetch Existing Feedback to increment calculation_version
    const existing = await this.feedbackRepository.findByPerformance(performanceId, formulaVersion);
    const nextVersion = existing ? existing.calculation_version + 1 : 1;

    // 4. Calculate Score & Grade
    const calculatorInput = {
      sales_count: performance.sales_count,
      review_score: performance.review_score,
      conversion_rate: performance.conversion_score
        ? Number(performance.conversion_score)
        : metrics.conversion_rate
          ? Number(metrics.conversion_rate)
          : 0.0,
      ctr: metrics.ctr || 0.0,
      roi: metrics.roi || 0.0,
      profit: metrics.profit || 0.0,
      favorite_count: performance.favorite_count,
      refund_count: performance.refund_count,
    };

    const scores = FeedbackCalculator.calculate(calculatorInput);
    const grade = FeedbackGrading.calculateGrade(scores.overallScore);

    let updatedEntity;

    // Transactional Update/Insert using DB Upsert with explicit calculation version increment
    if (existing) {
      const { data, error } = await supabase
        .from('feedback_scores')
        .update({
          calculation_version: nextVersion,
          sales_score: scores.salesScore,
          review_score: scores.reviewScore,
          conversion_score: scores.conversionScore,
          engagement_score: scores.engagementScore,
          profitability_score: scores.profitabilityScore,
          refund_penalty: scores.refundPenalty,
          overall_score: scores.overallScore,
          grade,
          weight_snapshot: FEEDBACK_WEIGHTS,
          calculated_at: new Date().toISOString(),
        })
        .eq('id', existing.id)
        .select('*')
        .single();

      if (error) throw error;
      updatedEntity = data;
    } else {
      const payload = {
        performance_id: performanceId,
        calculation_version: 1,
        sales_score: scores.salesScore,
        review_score: scores.reviewScore,
        conversion_score: scores.conversionScore,
        engagement_score: scores.engagementScore,
        profitability_score: scores.profitabilityScore,
        refund_penalty: scores.refundPenalty,
        overall_score: scores.overallScore,
        grade,
        weight_snapshot: FEEDBACK_WEIGHTS,
        formula_version: formulaVersion,
        calculated_at: new Date().toISOString(),
      };
      updatedEntity = await this.feedbackRepository.create(payload);
    }

    const result = FeedbackMapper.toResponseDto(updatedEntity);

    // 5. Trigger Recalculate Hook
    await FeedbackHooks.onFeedbackRecalculated({
      feedback: result,
      actorId,
      timestamp: new Date().toISOString(),
    });

    return result;
  }

  async findByPerformance(performanceId: string, actorId: string): Promise<FeedbackResponseDto> {
    const isOwner = await this.feedbackRepository.verifyPerformanceOwner(performanceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this performance record',
      );
    }

    const entity = await this.feedbackRepository.findByPerformance(performanceId);
    if (!entity) {
      throw new FeedbackNotFoundError(
        `Feedback score not found for performance run ${performanceId}`,
      );
    }

    return FeedbackMapper.toResponseDto(entity);
  }

  async findLatest(productId: string, actorId: string): Promise<FeedbackResponseDto> {
    const isOwner = await this.feedbackRepository.verifyProductOwner(productId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product record');
    }

    const entity = await this.feedbackRepository.findLatest(productId);
    if (!entity) {
      throw new FeedbackNotFoundError(`Feedback score not found for product ${productId}`);
    }

    return FeedbackMapper.toResponseDto(entity);
  }

  async findHistory(productId: string, actorId: string): Promise<FeedbackResponseDto[]> {
    const isOwner = await this.feedbackRepository.verifyProductOwner(productId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product record');
    }

    const entities = await this.feedbackRepository.findHistory(productId);
    return FeedbackMapper.toResponseDtoList(entities);
  }
}
