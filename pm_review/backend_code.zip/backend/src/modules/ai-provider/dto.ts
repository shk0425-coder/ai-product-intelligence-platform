import { ProviderCapability, ModelMetadata, ProviderHealthStatus } from './types.js';

export interface PatchAIProviderConfigDto {
  priority?: number;
  enabled?: boolean;
  rpm?: number;
  tpm?: number;
  retry_count?: number;
  timeout_seconds?: number;
  metadata?: Partial<ModelMetadata>;
}

export interface TestAIProviderDto {
  provider: string;
  model: string;
  prompt: string;
  workspaceId: string;
  capabilities?: ProviderCapability[];
  systemInstruction?: string;
  temperature?: number;
  responseSchema?: Record<string, unknown>;
}

export interface AIProviderConfigDto {
  provider: string;
  model: string;
  version: string;
  priority: number;
  enabled: boolean;
  rpm: number;
  tpm: number;
  retryCount: number;
  timeoutSeconds: number;
  metadata: ModelMetadata;
}

export interface AIProviderHealthDto {
  provider: string;
  model: string;
  status: ProviderHealthStatus;
  failureCount: number;
  lastCheckedAt: string;
}

export interface AIProviderMetricDto {
  provider: string;
  model: string;
  latencyMs: number;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  estimatedCost: number;
  cacheHit: boolean;
  createdAt: string;
}
