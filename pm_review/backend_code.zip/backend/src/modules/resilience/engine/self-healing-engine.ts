import { IncidentManager } from '../incident/incident-manager.js';
import { RootCauseAnalyzer } from '../analyzer/root-cause-analyzer.js';
import { RecoveryStateMachine } from '../state/recovery-state-machine.js';
import { RecoveryBudgetManager } from '../budget/recovery-budget-manager.js';
import { CircuitBreaker } from '../breaker/circuit-breaker.js';
import { RunbookEngine } from '../runbook/runbook-engine.js';
import { AuditTrail } from '../audit/audit-trail.js';

export class SelfHealingEngine {
  static async handleIncidentTrigger(incidentSource: string, severity: 'Critical' | 'High' | 'Normal' | 'Low'): Promise<boolean> {
    const enabled = process.env.SELF_HEALING_ENABLED !== 'false';
    if (!enabled) return false;

    // 1. Create Incident
    const incident = await IncidentManager.createIncident(incidentSource, severity);
    const executionId = `healing_${incident.id}`;

    // 2. State transition: Detected -> Classified
    await RecoveryStateMachine.transitionTo(executionId, 'Detected', 'Classified');

    // 3. Analyze root cause
    const analysis = await RootCauseAnalyzer.analyze(incidentSource);
    await IncidentManager.classifyIncident(incident.id, analysis.rootCause);

    // 4. Budget check
    if (!RecoveryBudgetManager.consume()) {
      await RecoveryStateMachine.transitionTo(executionId, 'Classified', 'Failed');
      await AuditTrail.record(`Recovery failed for incident ${incident.id}: budget exceeded`);
      return false;
    }

    // 5. Circuit Breaker protection check
    if (!CircuitBreaker.attemptRemediation()) {
      await RecoveryStateMachine.transitionTo(executionId, 'Classified', 'Failed');
      return false;
    }

    // 6. Approval check (Critical incidents require MANUAL or HYBRID approval)
    if (severity === 'Critical') {
      await RecoveryStateMachine.transitionTo(executionId, 'Classified', 'WaitingApproval');
      return false; // Blocks auto execution, waiting for admin manually trigger approval
    }

    // 7. Proceed to auto execute matched Runbook
    await RecoveryStateMachine.transitionTo(executionId, 'Classified', 'Recovering');
    await AuditTrail.record(`Auto recovery started for incident ${incident.id} using runbook ${analysis.suggestedAction}`);

    const runSuccess = await RunbookEngine.execute(analysis.suggestedAction, executionId);
    if (runSuccess) {
      await RecoveryStateMachine.transitionTo(executionId, 'Recovering', 'Validating');
      // Validate healing results
      CircuitBreaker.recordSuccess();
      await RecoveryStateMachine.transitionTo(executionId, 'Validating', 'Completed');
      await IncidentManager.resolveIncident(incident.id);
      await AuditTrail.record(`Auto recovery completed successfully for incident ${incident.id}`);
      return true;
    } else {
      CircuitBreaker.recordFailure();
      await RecoveryStateMachine.transitionTo(executionId, 'Recovering', 'Failed');
      await AuditTrail.record(`Auto recovery failed for incident ${incident.id}`);
      return false;
    }
  }
}
export default SelfHealingEngine;
