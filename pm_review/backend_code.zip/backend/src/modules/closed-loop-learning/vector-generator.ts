import crypto from 'crypto';
import { FeatureSet } from './feature-extractor.js';
import { DetectedPattern } from './pattern-detector.js';

export interface VectorGenerationResult {
  vectorVersion: string;
  vectorData: Record<string, unknown>;
  featureCount: number;
  checksum: string;
}

export const VectorGenerator = {
  generate(
    features: FeatureSet,
    patterns: DetectedPattern[],
    intelligence: { impactScore?: number; confidenceScore?: number },
    version: string = 'v1',
  ): VectorGenerationResult {
    // 1. Build prompt-ready vector JSON payload
    const vectorData: Record<string, unknown> = {
      overallScore:
        intelligence.impactScore !== undefined ? 100.0 - Number(intelligence.impactScore) : 100.0,
      confidenceScore:
        intelligence.confidenceScore !== undefined ? Number(intelligence.confidenceScore) : 100.0,
      criticalBottlenecks: features.bottlenecks,
      vulnerabilities: features.weaknesses,
      recommendations: features.improvements,
      activePatterns: patterns.map((p) => ({
        category: p.category,
        severity: p.severity,
        frequency: p.frequency,
      })),
      extractedTimestamp: new Date().toISOString(),
    };

    // 2. Compute total feature counts
    const featureCount =
      features.strengths.length +
      features.weaknesses.length +
      features.bottlenecks.length +
      features.improvements.length +
      features.risks.length;

    // 3. Generate SHA-256 checksum for data integrity
    const payloadString = JSON.stringify(vectorData);
    const checksum = crypto.createHash('sha256').update(payloadString).digest('hex');

    return {
      vectorVersion: version,
      vectorData,
      featureCount,
      checksum,
    };
  },
};
export default VectorGenerator;
