import { FastifyReply, FastifyRequest } from 'fastify';
import { ClosedLoopLearningService } from './service.js';
import {
  GenerateLearningInput,
  RegenerateLearningInput,
  LearningIdParamInput,
  LearningProductParamInput,
} from './schema.js';
import { successResponse } from '@/common/responses/index.js';

export class ClosedLoopLearningController {
  constructor(private readonly service: ClosedLoopLearningService) {}

  generate = async (
    request: FastifyRequest<{ Body: GenerateLearningInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.generate(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Learning assets generated successfully'));
  };

  regenerate = async (
    request: FastifyRequest<{ Body: RegenerateLearningInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.regenerate(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Learning assets regenerated successfully'));
  };

  findKnowledge = async (
    request: FastifyRequest<{ Params: LearningIdParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findKnowledge(request.params.knowledgeId, userId);
    return reply.status(200).send(successResponse(result));
  };

  findHistory = async (
    request: FastifyRequest<{ Params: LearningProductParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findHistory(request.params.productId, userId);
    return reply.status(200).send(successResponse(result));
  };

  findLatest = async (
    request: FastifyRequest<{ Params: LearningProductParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findLatest(request.params.productId, userId);
    return reply.status(200).send(successResponse(result));
  };
}
export default ClosedLoopLearningController;
