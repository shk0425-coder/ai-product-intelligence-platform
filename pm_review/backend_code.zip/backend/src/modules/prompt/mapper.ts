import { PromptTemplateEntity, PromptVersionEntity } from './types.js';
import { PromptTemplateDto, PromptVersionDto } from './dto.js';

export class PromptMapper {
  static toTemplateDto(entity: PromptTemplateEntity): PromptTemplateDto {
    return {
      id: entity.id,
      workspaceId: entity.workspace_id,
      category: entity.category,
      name: entity.name,
      description: entity.description,
      latestVersion: entity.latest_version,
      currentVersionId: entity.current_version_id,
      status: entity.status,
      modelCapability: entity.model_capability,
      defaultProvider: entity.default_provider,
      defaultModel: entity.default_model,
      temperature: Number(entity.temperature),
      topP: Number(entity.top_p),
      maxTokens: entity.max_tokens,
      responseSchema: entity.response_schema,
      variables: entity.variables || [],
      tags: entity.tags || [],
      createdAt: entity.created_at,
      updatedAt: entity.updated_at,
    };
  }

  static toTemplateDtoList(entities: PromptTemplateEntity[]): PromptTemplateDto[] {
    return entities.map((e) => this.toTemplateDto(e));
  }

  static toVersionDto(entity: PromptVersionEntity): PromptVersionDto {
    return {
      id: entity.id,
      templateId: entity.template_id,
      version: entity.version,
      systemPrompt: entity.system_prompt,
      userPrompt: entity.user_prompt,
      changeSummary: entity.change_summary,
      variables: entity.variables || [],
      checksum: entity.checksum,
      createdAt: entity.created_at,
    };
  }

  static toVersionDtoList(entities: PromptVersionEntity[]): PromptVersionDto[] {
    return entities.map((e) => this.toVersionDto(e));
  }
}
export default PromptMapper;
