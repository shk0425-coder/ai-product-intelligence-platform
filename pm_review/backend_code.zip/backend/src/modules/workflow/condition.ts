export class WorkflowConditionEvaluator {
  static evaluate(expression: string, context: Record<string, unknown>): boolean {
    if (!expression) return true;

    // Supported formats: "context.key > value", "context.key === value", "context.key < value"
    const match = /context\.([a-zA-Z0-9_]+)\s*(===|>|<|!==)\s*(.+)/.exec(expression.trim());
    if (!match) return false;

    const key = match[1];
    const op = match[2];
    const rawVal = match[3].trim();

    const actual = context[key];
    let expected: unknown = rawVal;

    // Cast raw expected value to correct type
    if (rawVal === 'true') expected = true;
    else if (rawVal === 'false') expected = false;
    else if (!isNaN(Number(rawVal))) expected = Number(rawVal);
    else if (rawVal.startsWith('"') && rawVal.endsWith('"')) {
      expected = rawVal.slice(1, -1);
    } else if (rawVal.startsWith("'") && rawVal.endsWith("'")) {
      expected = rawVal.slice(1, -1);
    }

    switch (op) {
      case '===':
        return actual === expected;
      case '!==':
        return actual !== expected;
      case '>':
        return Number(actual) > Number(expected);
      case '<':
        return Number(actual) < Number(expected);
      default:
        return false;
    }
  }
}
export default WorkflowConditionEvaluator;
