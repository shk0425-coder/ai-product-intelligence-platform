import crypto from 'crypto';
import { DistributedLockProvider } from './lock-provider.js';
import { MetricsCollector } from '../monitoring/metrics-service.js';

export class RedisLockProvider implements DistributedLockProvider {
  // Simulating Redis key-value store for lock keys
  private readonly locks = new Map<string, { ownerToken: string; expiresAt: number }>();
  private readonly extendTimers = new Map<string, NodeJS.Timeout>();

  async acquire(lockKey: string, ttlMs: number): Promise<string | null> {
    const now = Date.now();
    const existing = this.locks.get(lockKey);

    if (existing && now < existing.expiresAt) {
      MetricsCollector.recordLockWait(lockKey);
      return null; // Lock already held
    }

    const ownerToken = crypto.randomUUID();
    this.locks.set(lockKey, {
      ownerToken,
      expiresAt: now + ttlMs,
    });
    MetricsCollector.recordLockAcquire(lockKey);

    // Setup Lease extension simulation daemon helper
    this.startAutoExtension(lockKey, ownerToken, ttlMs);

    return ownerToken;
  }

  async release(lockKey: string, ownerToken: string): Promise<boolean> {
    const existing = this.locks.get(lockKey);
    if (!existing) {
      MetricsCollector.recordLockRelease(lockKey, 'failure');
      return false;
    }

    // Lua Script Atomic Release emulation: Compare and delete
    if (existing.ownerToken === ownerToken) {
      this.locks.delete(lockKey);
      this.stopAutoExtension(lockKey);
      MetricsCollector.recordLockRelease(lockKey, 'success');
      return true;
    }

    MetricsCollector.recordLockRelease(lockKey, 'failure');
    return false; // Forbidden (Ownership mismatched)
  }

  async extend(lockKey: string, ownerToken: string, ttlMs: number): Promise<boolean> {
    const now = Date.now();
    const existing = this.locks.get(lockKey);

    if (!existing || now >= existing.expiresAt) {
      return false; // Lock expired or doesn't exist
    }

    if (existing.ownerToken === ownerToken) {
      existing.expiresAt = now + ttlMs;
      this.locks.set(lockKey, existing);
      return true;
    }

    return false; // Owner mismatch
  }

  private startAutoExtension(lockKey: string, ownerToken: string, ttlMs: number): void {
    this.stopAutoExtension(lockKey);

    // Auto-extend and apply Clock Drift Buffer (renew 2s early if TTL is large)
    let intervalMs = Math.floor(ttlMs * 0.3);
    if (ttlMs > 5000) {
      intervalMs = Math.max(100, intervalMs - 2000); // 2s safe buffer margin
    }

    const timer = setInterval(async () => {
      const success = await this.extend(lockKey, ownerToken, ttlMs);
      if (!success) {
        this.stopAutoExtension(lockKey);
      }
    }, intervalMs);

    // Ensure timer doesn't block node process exit in tests
    timer.unref();
    this.extendTimers.set(lockKey, timer);
  }

  private stopAutoExtension(lockKey: string): void {
    const timer = this.extendTimers.get(lockKey);
    if (timer) {
      clearInterval(timer);
      this.extendTimers.delete(lockKey);
    }
  }

  clearAll(): void {
    for (const key of this.extendTimers.keys()) {
      this.stopAutoExtension(key);
    }
    this.locks.clear();
  }
}

export const lockProvider = new RedisLockProvider();
export default lockProvider;
