export interface AggregateResult {
  min: number;
  max: number;
  avg: number;
  count: number;
  sum: number;
}

export class MetricsAggregator {
  // Store raw metrics values in memory with timestamps: key -> [{ value, time }]
  private static rawStore = new Map<string, { value: number; timestamp: number }[]>();
  // Store aggregated window intervals: key -> { windowMinutes -> AggregateResult }
  private static aggregatedStore = new Map<string, Map<number, AggregateResult>>();
  private static cleanupInterval: NodeJS.Timeout | null = null;

  static init(): void {
    const flushIntervalMs = Number(process.env.METRIC_FLUSH_INTERVAL) || 60000;
    this.cleanupInterval = setInterval(() => {
      this.runRetentionCleanup();
      this.aggregateWindows();
    }, flushIntervalMs);

    if (this.cleanupInterval.unref) {
      this.cleanupInterval.unref();
    }
  }

  static record(key: string, value: number): void {
    const list = this.rawStore.get(key) || [];
    list.push({ value, timestamp: Date.now() });
    this.rawStore.set(key, list);
  }

  static getAggregated(key: string, windowMinutes: number): AggregateResult | null {
    const windowsMap = this.aggregatedStore.get(key);
    if (!windowsMap) return null;
    return windowsMap.get(windowMinutes) || null;
  }

  private static aggregateWindows(): void {
    const windows = [1, 5, 15, 60, 1440]; // 1m, 5m, 15m, 1h, 24h
    const now = Date.now();

    for (const [key, list] of this.rawStore.entries()) {
      const windowsMap = this.aggregatedStore.get(key) || new Map<number, AggregateResult>();
      
      for (const win of windows) {
        const threshold = now - win * 60000;
        const matched = list.filter(item => item.timestamp >= threshold);

        if (matched.length === 0) {
          continue;
        }

        const values = matched.map(m => m.value);
        const min = Math.min(...values);
        const max = Math.max(...values);
        const sum = values.reduce((acc, val) => acc + val, 0);
        const avg = sum / values.length;

        windowsMap.set(win, {
          min,
          max,
          avg,
          count: values.length,
          sum,
        });
      }

      this.aggregatedStore.set(key, windowsMap);
    }
  }

  private static runRetentionCleanup(): void {
    // Retention duration in hours (default: 24)
    const retentionHours = Number(process.env.METRIC_RETENTION) || 24;
    const threshold = Date.now() - retentionHours * 3600000;

    for (const [key, list] of this.rawStore.entries()) {
      // Automatic cleanup older than retention limit
      const filtered = list.filter(item => item.timestamp >= threshold);
      
      // Emulating Down Sampling: Compress raw metrics older than 1 hour into 5-minute averages
      const downsampled: { value: number; timestamp: number }[] = [];
      const oneHourAgo = Date.now() - 3600000;
      
      const toDownsample = filtered.filter(item => item.timestamp < oneHourAgo);
      const activeRaw = filtered.filter(item => item.timestamp >= oneHourAgo);

      if (toDownsample.length > 0) {
        // Group by 5 minute intervals and calculate average
        const groups = new Map<number, number[]>();
        for (const item of toDownsample) {
          const groupKey = Math.floor(item.timestamp / 300000) * 300000;
          const vals = groups.get(groupKey) || [];
          vals.push(item.value);
          groups.set(groupKey, vals);
        }

        for (const [time, vals] of groups.entries()) {
          const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
          downsampled.push({ value: avg, timestamp: time });
        }
      }

      this.rawStore.set(key, [...downsampled, ...activeRaw]);
    }
  }

  static clear(): void {
    this.rawStore.clear();
    this.aggregatedStore.clear();
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }
}
