export const JobScheduler = {
  determineScheduleType(scheduledAtStr?: string): {
    scheduleType: 'IMMEDIATE' | 'DELAYED' | 'FUTURE';
    scheduledAt: string;
  } {
    if (!scheduledAtStr) {
      return {
        scheduleType: 'IMMEDIATE',
        scheduledAt: new Date().toISOString(),
      };
    }

    const scheduledTime = new Date(scheduledAtStr).getTime();
    const now = Date.now();

    if (scheduledTime <= now) {
      return {
        scheduleType: 'IMMEDIATE',
        scheduledAt: new Date(scheduledTime).toISOString(),
      };
    }

    const diffMs = scheduledTime - now;
    const scheduleType = diffMs > 86400000 ? 'FUTURE' : 'DELAYED'; // Delayed if within 24h, future otherwise

    return {
      scheduleType,
      scheduledAt: new Date(scheduledTime).toISOString(),
    };
  },
};
