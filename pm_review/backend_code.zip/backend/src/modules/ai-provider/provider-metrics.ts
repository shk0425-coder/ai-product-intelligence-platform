import { AIProviderMetricEntity } from './types.js';

export class ProviderMetricsCollector {
  private static readonly metricsBuffer: AIProviderMetricEntity[] = [];

  static record(metric: Omit<AIProviderMetricEntity, 'id' | 'created_at'>): void {
    const fullMetric: AIProviderMetricEntity = {
      id: crypto.randomUUID(),
      ...metric,
      created_at: new Date().toISOString(),
    };
    this.metricsBuffer.push(fullMetric);
    if (this.metricsBuffer.length > 500) {
      this.metricsBuffer.shift(); // keep sliding memory limit
    }
  }

  static getMetrics(): AIProviderMetricEntity[] {
    return [...this.metricsBuffer];
  }

  static clear(): void {
    this.metricsBuffer.length = 0;
  }
}
export default ProviderMetricsCollector;
