export interface WorkspacePlaceholder {}
