export class StrategyRepository {}
