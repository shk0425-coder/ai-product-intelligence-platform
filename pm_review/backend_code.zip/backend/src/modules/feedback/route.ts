import { FastifyInstance, FastifyPluginOptions, FastifyRequest } from 'fastify';
import { FeedbackRepository } from './repository.js';
import { FeedbackService } from './service.js';
import { FeedbackController } from './controller.js';
import { authMiddleware } from '@/middleware/auth.middleware.js';
import {
  calculateFeedbackSchema,
  recalculateFeedbackSchema,
  feedbackPerformanceParamSchema,
  feedbackProductParamSchema,
} from './schema.js';
import { ValidationError } from '@/common/errors/index.js';
import { z } from 'zod';

const validateBody =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.body);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.body = result.data;
  };

const validateParams =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.params);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.params = result.data;
  };

export default async function feedbackRoutes(
  fastify: FastifyInstance,
  _options: FastifyPluginOptions,
): Promise<void> {
  const repository = new FeedbackRepository(fastify.supabase);
  const service = new FeedbackService(repository);
  const controller = new FeedbackController(service);

  // Secure all routes with authentication middleware
  fastify.addHook('preHandler', authMiddleware);

  // POST /calculate
  fastify.post('/calculate', {
    preValidation: validateBody(calculateFeedbackSchema),
    handler: controller.calculate,
  });

  // POST /recalculate
  fastify.post('/recalculate', {
    preValidation: validateBody(recalculateFeedbackSchema),
    handler: controller.recalculate,
  });

  // GET /performance/:performanceId
  fastify.get('/performance/:performanceId', {
    preValidation: validateParams(feedbackPerformanceParamSchema),
    handler: controller.findByPerformance,
  });

  // GET /history/:productId
  fastify.get('/history/:productId', {
    preValidation: validateParams(feedbackProductParamSchema),
    handler: controller.findHistory,
  });

  // GET /latest/:productId
  fastify.get('/latest/:productId', {
    preValidation: validateParams(feedbackProductParamSchema),
    handler: controller.findLatest,
  });
}
