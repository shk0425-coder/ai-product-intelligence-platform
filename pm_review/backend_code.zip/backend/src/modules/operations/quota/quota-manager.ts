import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { UsageMeter } from '../metering/usage-meter.js';

export class QuotaManager {
  private static quotaLimit = 100; // API units quota limit

  static setLimit(limit: number): void {
    this.quotaLimit = limit;
  }

  static checkQuota(requested: number): boolean {
    const current = UsageMeter.getUsage();
    if (current + requested > this.quotaLimit) {
      MetricsRegistry.counter('quota_exceeded_total', 1);
      return false; // Quota breach
    }
    return true;
  }

  static clear(): void {
    this.quotaLimit = 100;
  }
}
export default QuotaManager;
