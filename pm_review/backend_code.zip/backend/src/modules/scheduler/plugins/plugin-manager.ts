import { SchedulerPlugin, BaseSchedulerPlugin } from './plugin.js';

export class CronPlugin extends BaseSchedulerPlugin { name = 'CronPlugin'; }
export class AutomationPlugin extends BaseSchedulerPlugin { name = 'AutomationPlugin'; }
export class RetryPlugin extends BaseSchedulerPlugin { name = 'RetryPlugin'; }
export class MaintenancePlugin extends BaseSchedulerPlugin { name = 'MaintenancePlugin'; }
export class CleanupPlugin extends BaseSchedulerPlugin { name = 'CleanupPlugin'; }

export class PluginManager {
  private static readonly loadedPlugins: SchedulerPlugin[] = [];

  static async loadAll(): Promise<void> {
    const enabled = process.env.SCHEDULER_PLUGIN_ENABLED !== 'false';
    if (!enabled) return;

    // Load default plugin list
    const defaults = [
      new CronPlugin(),
      new AutomationPlugin(),
      new RetryPlugin(),
      new MaintenancePlugin(),
      new CleanupPlugin(),
    ];

    for (const plugin of defaults) {
      await plugin.register();
      await plugin.initialize();
      this.loadedPlugins.push(plugin);
    }
  }

  static async startAll(): Promise<void> {
    for (const plugin of this.loadedPlugins) {
      await plugin.start();
    }
  }

  static async stopAll(): Promise<void> {
    for (const plugin of this.loadedPlugins) {
      await plugin.stop();
    }
  }

  static async shutdownAll(): Promise<void> {
    for (const plugin of this.loadedPlugins) {
      await plugin.shutdown();
    }
    this.loadedPlugins.length = 0;
  }

  static getLoadedPlugins(): SchedulerPlugin[] {
    return [...this.loadedPlugins];
  }
}
export default PluginManager;
