import { CacheProvider } from './provider.js';
import { CacheSerializer } from './serializer.js';

export class MemoryCacheProvider implements CacheProvider {
  private readonly store = new Map<string, { value: string; expiresAt: number }>();
  private readonly counters = new Map<string, number>();

  async get(key: string): Promise<Record<string, unknown> | null> {
    const item = this.store.get(key);
    if (!item) return null;

    if (Date.now() > item.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return CacheSerializer.deserialize(item.value) as Record<string, unknown> | null;
  }

  async set(key: string, value: Record<string, unknown>, ttlMs: number): Promise<void> {
    this.store.set(key, {
      value: CacheSerializer.serialize(value),
      expiresAt: Date.now() + ttlMs,
    });
  }

  async delete(key: string): Promise<void> {
    this.store.delete(key);
    this.counters.delete(key);
  }

  async exists(key: string): Promise<boolean> {
    const item = this.store.get(key);
    if (!item) return false;
    if (Date.now() > item.expiresAt) {
      this.store.delete(key);
      return false;
    }
    return true;
  }

  async expire(key: string, ttlMs: number): Promise<boolean> {
    const item = this.store.get(key);
    if (!item) return false;
    item.expiresAt = Date.now() + ttlMs;
    return true;
  }

  async ttl(key: string): Promise<number> {
    const item = this.store.get(key);
    if (!item) return -2;
    const diff = item.expiresAt - Date.now();
    return diff > 0 ? diff : -1;
  }

  async increment(key: string): Promise<number> {
    const val = (this.counters.get(key) || 0) + 1;
    this.counters.set(key, val);
    return val;
  }

  async decrement(key: string): Promise<number> {
    const val = (this.counters.get(key) || 0) - 1;
    this.counters.set(key, val);
    return val;
  }

  async clearNamespace(namespace: string): Promise<void> {
    const prefix = `${namespace}:`;
    for (const key of this.store.keys()) {
      if (key.startsWith(prefix)) {
        this.store.delete(key);
      }
    }
    for (const key of this.counters.keys()) {
      if (key.startsWith(prefix)) {
        this.counters.delete(key);
      }
    }
  }
}
export default MemoryCacheProvider;
