import crypto from 'crypto';
import { CacheNamespaceValidator } from './cache-namespace.js';

export class CacheKeyBuilder {
  static build(
    namespace: string,
    workspaceId: string,
    version: number | string,
    capability: string,
    requestPayload: Record<string, unknown>
  ): string {
    CacheNamespaceValidator.validate(namespace);

    const payloadString = JSON.stringify(requestPayload || {});
    const sha256 = crypto.createHash('sha256').update(payloadString).digest('hex');

    // standard cache key scheme: v1:{namespace}:{workspace_id}:{version}:{capability}:{sha256}
    return `v1:${namespace}:${workspaceId}:${version}:${capability}:${sha256}`;
  }
}
