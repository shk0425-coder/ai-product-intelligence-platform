import { MetricLabels, MetricsProviderFactory } from './metrics-provider.js';

export class MetricsRegistry {
  private static readonly allowedLabels = new Set([
    'workspace_id',
    'user_id',
    'workflow',
    'provider',
    'model',
    'queue',
    'endpoint',
    'status',
    'region',
    'instance',
  ]);

  static validateMetricName(name: string, type: 'counter' | 'gauge' | 'histogram' | 'summary'): void {
    if (type === 'counter' && !name.endsWith('_total')) {
      throw new Error(`Metric Naming Violation: Counter metric "${name}" must end with "_total"`);
    }
    if (type === 'histogram' && !name.endsWith('_duration_seconds')) {
      throw new Error(`Metric Naming Violation: Histogram metric "${name}" must end with "_duration_seconds"`);
    }
    if (type === 'summary' && !name.endsWith('_summary')) {
      throw new Error(`Metric Naming Violation: Summary metric "${name}" must end with "_summary"`);
    }
  }

  private static filterLabels(labels?: MetricLabels): MetricLabels {
    if (!labels) return {};
    const filtered: MetricLabels = {};
    for (const key of Object.keys(labels)) {
      if (this.allowedLabels.has(key)) {
        filtered[key] = labels[key];
      }
    }
    return filtered;
  }

  static counter(name: string, value: number, labels?: MetricLabels): void {
    this.validateMetricName(name, 'counter');
    const cleanLabels = this.filterLabels(labels);
    MetricsProviderFactory.getProvider().counter(name, value, cleanLabels);
  }

  static gauge(name: string, value: number, labels?: MetricLabels): void {
    this.validateMetricName(name, 'gauge');
    const cleanLabels = this.filterLabels(labels);
    MetricsProviderFactory.getProvider().gauge(name, value, cleanLabels);
  }

  static histogram(name: string, value: number, labels?: MetricLabels): void {
    this.validateMetricName(name, 'histogram');
    const cleanLabels = this.filterLabels(labels);
    MetricsProviderFactory.getProvider().histogram(name, value, cleanLabels);
  }

  static summary(name: string, value: number, labels?: MetricLabels): void {
    this.validateMetricName(name, 'summary');
    const cleanLabels = this.filterLabels(labels);
    MetricsProviderFactory.getProvider().summary(name, value, cleanLabels);
  }
}
