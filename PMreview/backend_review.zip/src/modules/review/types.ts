export interface ReviewPlaceholder {}
