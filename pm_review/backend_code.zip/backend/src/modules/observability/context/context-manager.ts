import { AsyncLocalStorage } from 'async_hooks';

export interface ObservabilityContext {
  traceId?: string;
  spanId?: string;
  correlationId?: string;
  workspaceId?: string;
  userId?: string;
  workflowId?: string;
}

export class AsyncContextManager {
  private static readonly storage = new AsyncLocalStorage<ObservabilityContext>();

  static run<T>(context: ObservabilityContext, fn: () => T): T {
    return this.storage.run({ ...context }, fn);
  }

  static getStore(): ObservabilityContext | undefined {
    return this.storage.getStore();
  }

  static getTraceId(): string | undefined {
    return this.storage.getStore()?.traceId;
  }

  static getSpanId(): string | undefined {
    return this.storage.getStore()?.spanId;
  }

  static getCorrelationId(): string | undefined {
    return this.storage.getStore()?.correlationId;
  }

  static getWorkspaceId(): string | undefined {
    return this.storage.getStore()?.workspaceId;
  }

  static getUserId(): string | undefined {
    return this.storage.getStore()?.userId;
  }

  static getWorkflowId(): string | undefined {
    return this.storage.getStore()?.workflowId;
  }

  static updateContext(update: Partial<ObservabilityContext>): void {
    const store = this.storage.getStore();
    if (store) {
      Object.assign(store, update);
    }
  }
}
