import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export type ApprovalTier = 'AUTO' | 'MANUAL' | 'HYBRID';

export interface RunbookDefinition {
  id: string;
  name: string;
  version: number;
  approvalPolicy: ApprovalTier;
  dependencies: string[]; // parent runbook IDs
  steps: string[];
}

export interface RunbookHistoryRecord {
  runbookId: string;
  executionId: string;
  version: number;
  status: 'Started' | 'Completed' | 'Failed' | 'RolledBack';
  timestamp: number;
}

export class RunbookRepository {
  private static readonly runbooks = new Map<string, RunbookDefinition[]>();

  static register(runbook: RunbookDefinition): void {
    const versions = this.runbooks.get(runbook.id) || [];
    versions.push(runbook);
    // Sort descending by version number
    versions.sort((a, b) => b.version - a.version);
    this.runbooks.set(runbook.id, versions);
  }

  static getLatest(id: string): RunbookDefinition | undefined {
    const versions = this.runbooks.get(id);
    return versions && versions.length > 0 ? versions[0] : undefined;
  }

  static getVersion(id: string, version: number): RunbookDefinition | undefined {
    const versions = this.runbooks.get(id);
    return versions ? versions.find(v => v.version === version) : undefined;
  }

  static clear(): void {
    this.runbooks.clear();
  }
}

export class RunbookDependencyManager {
  private static readonly deps = new Map<string, string[]>();

  static register(runbookId: string, parentRunbookId: string): void {
    const list = this.deps.get(runbookId) || [];
    if (!list.includes(parentRunbookId)) {
      list.push(parentRunbookId);
    }
    this.deps.set(runbookId, list);
  }

  static getParents(runbookId: string): string[] {
    return this.deps.get(runbookId) || [];
  }

  static clear(): void {
    this.deps.clear();
  }
}

export class RunbookEngine {
  private static readonly history: RunbookHistoryRecord[] = [];

  static async execute(runbookId: string, executionId: string): Promise<boolean> {
    const latest = RunbookRepository.getLatest(runbookId);
    if (!latest) return false;

    // Check Runbook dependencies
    const parents = RunbookDependencyManager.getParents(runbookId);
    const parentRecords = this.history.filter(h => parents.includes(h.runbookId) && h.executionId === executionId);
    const allParentsPassed = parents.every(p => parentRecords.some(r => r.runbookId === p && r.status === 'Completed'));
    if (parents.length > 0 && !allParentsPassed) {
      return false; // Dependencies block execution
    }

    this.recordHistory(runbookId, executionId, latest.version, 'Started');
    MetricsRegistry.counter('runbook_execution_total', 1, { runbook: latest.name });

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'RunbookStarted',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { runbookId, executionId, version: latest.version },
    }).catch(() => {});

    // Emulate runbook steps execution
    this.recordHistory(runbookId, executionId, latest.version, 'Completed');
    MetricsRegistry.counter('runbook_execution_completed_total', 1, { runbook: latest.name });

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'RunbookCompleted',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { runbookId, executionId, version: latest.version },
    }).catch(() => {});

    return true;
  }

  static async rollback(runbookId: string, executionId: string, targetVersion: number): Promise<boolean> {
    const runbook = RunbookRepository.getVersion(runbookId, targetVersion);
    if (!runbook) return false;

    this.recordHistory(runbookId, executionId, targetVersion, 'RolledBack');
    MetricsRegistry.counter('rollback_total', 1, { runbook: runbook.name });

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'RollbackCompleted',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { runbookId, executionId, rolledBackToVersion: targetVersion },
    }).catch(() => {});

    return true;
  }

  private static recordHistory(runbookId: string, executionId: string, version: number, status: 'Started' | 'Completed' | 'Failed' | 'RolledBack'): void {
    this.history.push({
      runbookId,
      executionId,
      version,
      status,
      timestamp: Date.now(),
    });
  }

  static getHistory(): RunbookHistoryRecord[] {
    return [...this.history];
  }

  static clear(): void {
    this.history.length = 0;
  }
}
export default RunbookEngine;
