import { FeedbackNormalization } from './normalization.js';
import { FEEDBACK_WEIGHTS, PENALTY_WEIGHTS } from './weights.js';

export interface FeedbackCalculatorInput {
  sales_count: number;
  review_score: number;
  conversion_rate: number;
  ctr: number;
  roi: number;
  profit: number;
  favorite_count: number;
  refund_count: number;
}

export interface FeedbackResult {
  salesScore: number;
  reviewScore: number;
  conversionScore: number;
  engagementScore: number;
  profitabilityScore: number;
  refundPenalty: number;
  overallScore: number;
}

export const FeedbackCalculator = {
  calculate(input: FeedbackCalculatorInput): FeedbackResult {
    // 1. Normalize all inputs to [0, 100]
    const salesNormalized = FeedbackNormalization.normalizeSales(input.sales_count);
    const reviewNormalized = FeedbackNormalization.normalizeReview(input.review_score);
    const conversionNormalized = FeedbackNormalization.normalizeConversion(input.conversion_rate);
    const ctrNormalized = FeedbackNormalization.normalizeCtr(input.ctr);
    const roiNormalized = FeedbackNormalization.normalizeRoi(input.roi);
    const profitNormalized = FeedbackNormalization.normalizeProfit(input.profit);
    const favoriteNormalized = FeedbackNormalization.normalizeFavorite(input.favorite_count);
    const refundNormalized = FeedbackNormalization.normalizeRefund(input.refund_count);

    // 2. Aggregate Component Scores (Weighted average within subgroups for output display if needed)
    // Engagement subgroup: CTR (10) & Favorite (5). Max weight = 15
    const engagementScore =
      (ctrNormalized * FEEDBACK_WEIGHTS.ctr + favoriteNormalized * FEEDBACK_WEIGHTS.favorite) /
      (FEEDBACK_WEIGHTS.ctr + FEEDBACK_WEIGHTS.favorite);

    // Profitability subgroup: ROI (15) & Profit (10). Max weight = 25
    const profitabilityScore =
      (roiNormalized * FEEDBACK_WEIGHTS.roi + profitNormalized * FEEDBACK_WEIGHTS.profit) /
      (FEEDBACK_WEIGHTS.roi + FEEDBACK_WEIGHTS.profit);

    // 3. Penalty Calculations
    // Refund weight is -10. Penalty contribution to overall score = refundNormalized * 10 / 100 = refundNormalized * 0.1
    const refundPenalty = refundNormalized * (Math.abs(PENALTY_WEIGHTS.refund) / 100.0);

    // 4. Overall Score Calculation
    const weightedSum =
      salesNormalized * FEEDBACK_WEIGHTS.sales +
      reviewNormalized * FEEDBACK_WEIGHTS.review +
      conversionNormalized * FEEDBACK_WEIGHTS.conversion +
      ctrNormalized * FEEDBACK_WEIGHTS.ctr +
      roiNormalized * FEEDBACK_WEIGHTS.roi +
      profitNormalized * FEEDBACK_WEIGHTS.profit +
      favoriteNormalized * FEEDBACK_WEIGHTS.favorite;

    // Overall = Weighted positive score sum / 100 - refund penalty
    const positiveScore = weightedSum / 100.0;
    const overallScore = Math.max(0.0, Math.min(100.0, positiveScore - refundPenalty));

    return {
      salesScore: salesNormalized,
      reviewScore: reviewNormalized,
      conversionScore: conversionNormalized,
      engagementScore,
      profitabilityScore,
      refundPenalty: refundNormalized, // Penalty raw percentage (0-100) or overall impact. Let's return raw normalized refund for detail tracking.
      overallScore,
    };
  },
};
export default FeedbackCalculator;
