export class LogMasker {
  private static readonly emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  private static readonly phoneRegex = /(\d{2,3})[-. ]?(\d{3,4})[-. ]?(\d{4})/g;
  private static readonly apiKeyRegex = /(api_?key\s+)[a-zA-Z0-9_-]+/gi;
  private static readonly passwordRegex = /(password\s+)[a-zA-Z0-9_-]+/gi;
  private static readonly tokenRegex = /(token\s+)[a-zA-Z0-9._-]+/gi;
  private static readonly secretRegex = /(secret\s+)[a-zA-Z0-9_-]+/gi;

  // Mask string representation or deep keys of an object
  static mask(value: unknown): unknown {
    if (value === null || value === undefined) {
      return value;
    }

    if (typeof value === 'string') {
      return this.maskString(value);
    }

    if (Array.isArray(value)) {
      return value.map(item => this.mask(item));
    }

    if (typeof value === 'object') {
      const copy: Record<string, unknown> = {};
      for (const key of Object.keys(value as Record<string, unknown>)) {
        const val = (value as Record<string, unknown>)[key];
        if (this.isSensitiveKey(key)) {
          copy[key] = '[MASKED]';
        } else {
          copy[key] = this.mask(val);
        }
      }
      return copy;
    }

    return value;
  }

  private static isSensitiveKey(key: string): boolean {
    const lowerKey = key.toLowerCase();
    return (
      lowerKey.includes('apikey') ||
      lowerKey.includes('api_key') ||
      lowerKey.includes('accesstoken') ||
      lowerKey.includes('access_token') ||
      lowerKey.includes('refreshtoken') ||
      lowerKey.includes('refresh_token') ||
      lowerKey.includes('password') ||
      lowerKey.includes('secret') ||
      lowerKey.includes('token')
    );
  }

  private static maskString(str: string): string {
    let masked = str;
    // Mask emails
    masked = masked.replace(this.emailRegex, '***@***.***');
    // Mask phone numbers
    masked = masked.replace(this.phoneRegex, '$1-****-****');
    // Mask keywords inside text
    masked = masked.replace(this.apiKeyRegex, '$1[MASKED]');
    masked = masked.replace(this.passwordRegex, '$1[MASKED]');
    masked = masked.replace(this.tokenRegex, '$1[MASKED]');
    masked = masked.replace(this.secretRegex, '$1[MASKED]');
    return masked;
  }
}
