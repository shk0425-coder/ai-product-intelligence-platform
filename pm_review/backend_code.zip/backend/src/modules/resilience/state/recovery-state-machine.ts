import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export type RecoveryState =
  | 'Detected'
  | 'Classified'
  | 'WaitingApproval'
  | 'Recovering'
  | 'Validating'
  | 'Completed'
  | 'Failed'
  | 'RolledBack'
  | 'RollbackValidation'
  | 'RollbackCompleted'
  | 'RollbackFailed';

export class RecoveryStateMachine {
  private static readonly allowedTransitions = new Map<RecoveryState, RecoveryState[]>([
    ['Detected', ['Classified']],
    ['Classified', ['WaitingApproval', 'Recovering']],
    ['WaitingApproval', ['Recovering', 'Failed']],
    ['Recovering', ['Validating', 'Failed']],
    ['Validating', ['Completed', 'Failed']],
    ['Failed', ['RolledBack', 'Completed']],
    ['RolledBack', ['RollbackValidation']],
    ['RollbackValidation', ['RollbackCompleted', 'RollbackFailed']],
    ['Completed', []],
    ['RollbackCompleted', []],
    ['RollbackFailed', []],
  ]);

  private static readonly history = new Map<string, { state: RecoveryState; timestamp: number }[]>();

  static async transitionTo(executionId: string, fromState: RecoveryState, toState: RecoveryState): Promise<void> {
    const list = this.allowedTransitions.get(fromState) || [];
    if (!list.includes(toState)) {
      throw new Error(`Illegal state transition from ${fromState} to ${toState}`);
    }

    const records = this.history.get(executionId) || [];
    records.push({ state: toState, timestamp: Date.now() });
    this.history.set(executionId, records);

    MetricsRegistry.counter('recovery_state_transition_total', 1, { from: fromState, to: toState });

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'RecoveryStateChanged',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { executionId, fromState, toState },
    }).catch(() => {});
  }

  static getHistory(executionId: string): { state: RecoveryState; timestamp: number }[] {
    return this.history.get(executionId) || [];
  }

  static clear(): void {
    this.history.clear();
  }
}
export default RecoveryStateMachine;
