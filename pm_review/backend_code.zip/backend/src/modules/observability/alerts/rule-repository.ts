export type AlertSeverity = 'INFO' | 'WARNING' | 'CRITICAL';
export type AlertPriority = 'LOW' | 'MEDIUM' | 'HIGH';

export interface AlertRule {
  id: string;
  name: string;
  metricName: string;
  operator: 'GT' | 'LT' | 'EQ';
  threshold: number;
  windowMinutes: number;
  cooldownMinutes: number;
  severity: AlertSeverity;
  priority: AlertPriority;
  enabled: boolean;
  tags: string[];
}

export class AlertRuleRepository {
  private static readonly rules = new Map<string, AlertRule>();

  static register(rule: AlertRule): void {
    this.rules.set(rule.id, rule);
  }

  static get(id: string): AlertRule | undefined {
    return this.rules.get(id);
  }

  static getAll(): AlertRule[] {
    return Array.from(this.rules.values());
  }

  static getEnabledRules(): AlertRule[] {
    return this.getAll().filter(r => r.enabled);
  }

  static update(id: string, update: Partial<AlertRule>): boolean {
    const existing = this.rules.get(id);
    if (!existing) return false;
    this.rules.set(id, { ...existing, ...update });
    return true;
  }

  static delete(id: string): boolean {
    return this.rules.delete(id);
  }

  static clear(): void {
    this.rules.clear();
  }
}
