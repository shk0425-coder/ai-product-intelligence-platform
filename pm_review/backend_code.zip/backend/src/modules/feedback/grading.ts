/**
 * Pure functions for assigning Grades based on Overall Score.
 */
export const FeedbackGrading = {
  calculateGrade(score: number): 'S' | 'A+' | 'A' | 'B' | 'C' | 'D' {
    if (score >= 95.0) {
      return 'S';
    }
    if (score >= 90.0) {
      return 'A+';
    }
    if (score >= 80.0) {
      return 'A';
    }
    if (score >= 70.0) {
      return 'B';
    }
    if (score >= 60.0) {
      return 'C';
    }
    return 'D';
  },
};
export default FeedbackGrading;
