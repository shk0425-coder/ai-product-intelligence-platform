export interface LatencyStats {
  p50: number;
  p90: number;
  p95: number;
  p99: number;
  max: number;
  avg: number;
  count: number;
}

export class PerformanceProfiler {
  private static latencyMap = new Map<string, number[]>();

  static recordLatency(endpoint: string, latencyMs: number): void {
    const list = this.latencyMap.get(endpoint) || [];
    list.push(latencyMs);
    this.latencyMap.set(endpoint, list);
  }

  static getStats(endpoint: string): LatencyStats | null {
    const list = this.latencyMap.get(endpoint);
    if (!list || list.length === 0) return null;

    // Sort list for percentile calculations
    const sorted = [...list].sort((a, b) => a - b);
    const count = sorted.length;
    const sum = sorted.reduce((a, b) => a + b, 0);

    const getPercentile = (p: number) => {
      const idx = Math.ceil((p / 100) * count) - 1;
      return sorted[Math.max(0, idx)];
    };

    return {
      p50: getPercentile(50),
      p90: getPercentile(90),
      p95: getPercentile(95),
      p99: getPercentile(99),
      max: sorted[count - 1],
      avg: sum / count,
      count,
    };
  }

  static getTopSlowEndpoints(limit = 5): { endpoint: string; avg: number; max: number }[] {
    const results: { endpoint: string; avg: number; max: number }[] = [];
    for (const [endpoint, list] of this.latencyMap.entries()) {
      if (list.length === 0) continue;
      const sum = list.reduce((a, b) => a + b, 0);
      const avg = sum / list.length;
      const max = Math.max(...list);
      results.push({ endpoint, avg, max });
    }

    return results.sort((a, b) => b.avg - a.avg).slice(0, limit);
  }

  static clear(): void {
    this.latencyMap.clear();
  }
}
