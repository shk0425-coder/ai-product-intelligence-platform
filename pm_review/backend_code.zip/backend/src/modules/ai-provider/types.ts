export type ProviderCapability =
  | 'TEXT'
  | 'CHAT'
  | 'VISION'
  | 'IMAGE_GENERATION'
  | 'IMAGE_EDITING'
  | 'EMBEDDING'
  | 'STRUCTURED_OUTPUT'
  | 'FUNCTION_CALLING';

export type ProviderHealthStatus = 'HEALTHY' | 'DEGRADED' | 'UNAVAILABLE';

export interface ModelMetadata {
  provider: string;
  model: string;
  version: string;
  contextWindow: number;
  maxOutputTokens: number;
  supportsStreaming: boolean;
  supportsVision: boolean;
  supportsText: boolean;
  supportsImageGeneration: boolean;
  supportsImageEditing: boolean;
  supportsEmbedding: boolean;
  supportsStructuredOutput: boolean;
  supportsFunctionCalling: boolean;
  inputCost: number; // Cost per 1k tokens
  outputCost: number; // Cost per 1k tokens
  enabled: boolean;
}

export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export interface GenerateResponse {
  content: string;
  finishReason: 'STOP' | 'LENGTH' | 'TOOL_CALL' | 'CONTENT_FILTER' | 'ERROR';
  usage: TokenUsage;
  provider: string;
  model: string;
  cost: number;
}

export interface AIProviderRequest {
  prompt: string;
  workspaceId: string;
  systemInstruction?: string;
  temperature?: number;
  maxTokens?: number;
  responseSchema?: Record<string, unknown>; // JSON Schema for Structured Output
  capabilities?: ProviderCapability[]; // requested capabilities
  timeoutMs?: number;
}

export interface AIProviderAdapter {
  generate(request: AIProviderRequest, metadata: ModelMetadata): Promise<GenerateResponse>;
  generateStream(request: AIProviderRequest, metadata: ModelMetadata): Promise<AsyncIterable<string>>;
}

export interface AIProvider {
  readonly providerId: string;
  readonly modelId: string;
  readonly metadata: ModelMetadata;
  readonly rpm: number;
  readonly tpm: number;
  generate(request: AIProviderRequest): Promise<GenerateResponse>;
  generateStream(request: AIProviderRequest): Promise<AsyncIterable<string>>;
  healthCheck(): Promise<ProviderHealthStatus>;
}

export interface AIProviderConfigEntity {
  id: string;
  provider: string;
  model: string;
  version: string;
  priority: number;
  metadata: ModelMetadata;
  enabled: boolean;
  rpm: number;
  tpm: number;
  retry_count: number;
  timeout_seconds: number;
  created_at: string;
  updated_at: string;
}

export interface AIProviderMetricEntity {
  id: string;
  provider: string;
  model: string;
  status: 'SUCCESS' | 'FAILED';
  latency_ms: number;
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  estimated_cost: number;
  cache_hit: boolean;
  created_at: string;
}

export interface AIProviderHealthEntity {
  id: string;
  provider: string;
  model: string;
  status: ProviderHealthStatus;
  failure_count: number;
  last_checked_at: string;
  created_at: string;
}
