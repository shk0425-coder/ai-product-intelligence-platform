-- 38_create_job_queue.sql
-- Distributed Job Queue & Worker Infrastructure tables

BEGIN;

-- 1. job_queue
CREATE TABLE IF NOT EXISTS public.job_queue (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    job_type VARCHAR(50) NOT NULL,
    priority INTEGER NOT NULL DEFAULT 60,
    payload JSONB NOT NULL,
    payload_version VARCHAR(20) NOT NULL DEFAULT 'v1',
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    retry_count INTEGER NOT NULL DEFAULT 0,
    max_retry INTEGER NOT NULL DEFAULT 3,
    lease_owner VARCHAR(100),
    lease_until TIMESTAMPTZ,
    heartbeat_at TIMESTAMPTZ,
    cancel_requested BOOLEAN NOT NULL DEFAULT false,
    schedule_type VARCHAR(20) NOT NULL DEFAULT 'IMMEDIATE',
    scheduled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_job_queue PRIMARY KEY (id),
    CONSTRAINT fk_job_queue_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.job_queue IS '분산 비동기 처리 작업을 보관하는 작업 큐';
COMMENT ON COLUMN public.job_queue.id IS '작업 고유 UUID 식별자';
COMMENT ON COLUMN public.job_queue.priority IS '작업 우선순위 (높을수록 먼저 소비됨)';
COMMENT ON COLUMN public.job_queue.status IS '작업 진행 상태 (PENDING, QUEUED, RUNNING, SUCCESS, FAILED)';
COMMENT ON COLUMN public.job_queue.lease_until IS 'Visibility Timeout 만료 시각';

-- 2. job_execution_logs
CREATE TABLE IF NOT EXISTS public.job_execution_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    job_id UUID NOT NULL,
    worker VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_job_execution_logs PRIMARY KEY (id),
    CONSTRAINT fk_job_execution_logs_job FOREIGN KEY (job_id) REFERENCES public.job_queue(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.job_execution_logs IS '워커별 작업 실행 단위 감사 및 처리시간 성능 로그';

-- 3. job_dead_letters
CREATE TABLE IF NOT EXISTS public.job_dead_letters (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    job_id UUID NOT NULL,
    payload JSONB NOT NULL,
    reason TEXT NOT NULL,
    retry_count INTEGER NOT NULL DEFAULT 0,
    failed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_job_dead_letters PRIMARY KEY (id)
);

COMMENT ON TABLE public.job_dead_letters IS '최대 재시도 한도를 초과하여 격리된 Dead Job 정보';

-- Performance Index
CREATE INDEX IF NOT EXISTS idx_job_queue_workspace ON public.job_queue(workspace_id);
CREATE INDEX IF NOT EXISTS idx_job_queue_status_priority ON public.job_queue(status, priority DESC, scheduled_at ASC);
CREATE INDEX IF NOT EXISTS idx_job_queue_lease ON public.job_queue(lease_until);

COMMIT;
