export class LearningRepository {}
