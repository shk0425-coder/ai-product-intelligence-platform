import { FastifyRequest, FastifyReply } from 'fastify';
import { PromptService } from './service.js';
import { CreatePromptTemplateDto, CreatePromptVersionDto, RenderPromptDto, PreviewPromptDto } from './dto.js';

export class PromptController {
  constructor(private readonly service: PromptService) {}

  async getConfigs(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getTemplates();
    return reply.status(200).send({ data: result });
  }

  async getTemplateById(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.getTemplateById(id);
    return reply.status(200).send({ data: result });
  }

  async createTemplate(req: FastifyRequest<{ Body: CreatePromptTemplateDto }>, reply: FastifyReply) {
    const result = await this.service.createTemplate(req.body);
    return reply.status(201).send({ data: result });
  }

  async createVersion(
    req: FastifyRequest<{ Params: { id: string }; Body: CreatePromptVersionDto }>,
    reply: FastifyReply
  ) {
    const { id } = req.params;
    const result = await this.service.createVersion(id, req.body);
    return reply.status(201).send({ data: result });
  }

  async approveTemplate(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    // Mock user for approval workflow
    const result = await this.service.approveTemplate(id, 'admin-user-id');
    return reply.status(200).send({ data: result });
  }

  async reviewTemplate(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.reviewTemplate(id);
    return reply.status(200).send({ data: result });
  }

  async deprecateTemplate(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.deprecateTemplate(id);
    return reply.status(200).send({ data: result });
  }

  async rollbackTemplate(
    req: FastifyRequest<{ Params: { id: string }; Body: { versionId: string } }>,
    reply: FastifyReply
  ) {
    const { id } = req.params;
    const { versionId } = req.body;
    const result = await this.service.rollbackTemplateVersion(id, versionId);
    return reply.status(200).send({ data: result });
  }

  async renderPrompt(req: FastifyRequest<{ Params: { id: string }; Body: RenderPromptDto }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.render(id, req.body);
    return reply.status(200).send({ data: result });
  }

  async previewPrompt(req: FastifyRequest<{ Body: PreviewPromptDto }>, reply: FastifyReply) {
    const result = await this.service.preview(req.body);
    return reply.status(200).send({ data: result });
  }

  async executePrompt(req: FastifyRequest<{ Params: { id: string }; Body: RenderPromptDto }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.execute(id, req.body);
    return reply.status(200).send({ data: result });
  }

  async getVersions(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.getVersions(id);
    return reply.status(200).send({ data: result });
  }

  async getHistory(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getHistory();
    return reply.status(200).send({ data: result });
  }
}
export default PromptController;
