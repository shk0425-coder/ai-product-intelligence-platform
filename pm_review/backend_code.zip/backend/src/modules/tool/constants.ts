export const TOOL_STATUS_LIST = ['DRAFT', 'REVIEW', 'APPROVED', 'DEPRECATED'] as const;

export const APPROVAL_STATUS_LIST = [
  'PENDING',
  'APPROVED',
  'REJECTED',
  'TIMEOUT',
  'CANCELLED',
] as const;

export const DEFAULT_TOOL_TIMEOUT_MS = 5000;
export const DEFAULT_TOOL_RETRY_LIMIT = 3;
export const DEFAULT_TOOL_CACHE_TTL_MS = 600000; // 10 minutes
export const DEFAULT_TOOL_VERSION = 1;
