import { z } from 'zod';

export const calculateFeedbackSchema = z.object({
  performanceId: z.string().uuid('Performance ID must be a valid UUID'),
  formulaVersion: z.string().trim().max(20).default('v1'),
});

export const recalculateFeedbackSchema = z.object({
  performanceId: z.string().uuid('Performance ID must be a valid UUID'),
  formulaVersion: z.string().trim().max(20).default('v1'),
});

export const feedbackIdParamSchema = z.object({
  id: z.string().uuid('Invalid feedback ID format'),
});

export const feedbackPerformanceParamSchema = z.object({
  performanceId: z.string().uuid('Invalid performance ID format'),
});

export const feedbackProductParamSchema = z.object({
  productId: z.string().uuid('Invalid product ID format'),
});

export type CalculateFeedbackInput = z.infer<typeof calculateFeedbackSchema>;
export type RecalculateFeedbackInput = z.infer<typeof recalculateFeedbackSchema>;
export type FeedbackIdParamInput = z.infer<typeof feedbackIdParamSchema>;
export type FeedbackPerformanceParamInput = z.infer<typeof feedbackPerformanceParamSchema>;
export type FeedbackProductParamInput = z.infer<typeof feedbackProductParamSchema>;
