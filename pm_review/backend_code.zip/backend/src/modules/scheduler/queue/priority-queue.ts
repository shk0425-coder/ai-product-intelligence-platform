import { JobDefinition } from '../persistence/job-repository.js';
import { ExecutionRepository } from '../persistence/execution-repository.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';

export class PriorityQueue {
  private static readonly queue: JobDefinition[] = [];
  private static readonly priorityWeight: Record<string, number> = {
    Critical: 4,
    High: 3,
    Normal: 2,
    Low: 1,
  };

  static async push(job: JobDefinition, idempotencyKey?: string): Promise<boolean> {
    // 1. Idempotency & Duplicate detection check
    if (idempotencyKey) {
      const existing = await ExecutionRepository.findByIdempotencyKey(idempotencyKey);
      if (existing && ['Pending', 'Running', 'Scheduled', 'Retrying'].includes(existing.state)) {
        // Duplicate request detected, ignore push
        return false;
      }
    }

    this.queue.push(job);
    // Sort queue by priority weight descending
    this.queue.sort((a, b) => this.priorityWeight[b.priority] - this.priorityWeight[a.priority]);

    MetricsRegistry.gauge('queue_depth', this.queue.length, { queue: job.name });
    return true;
  }

  static async pop(): Promise<JobDefinition | undefined> {
    const job = this.queue.shift();
    if (job) {
      MetricsRegistry.gauge('queue_depth', this.queue.length, { queue: job.name });
    }
    return job;
  }

  static getDepth(): number {
    return this.queue.length;
  }

  static clear(): void {
    this.queue.length = 0;
  }
}
export default PriorityQueue;
