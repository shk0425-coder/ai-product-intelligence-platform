-- 34_create_feedback_scores.sql
-- Feedback Score Calculation Domain tables

BEGIN;

CREATE TABLE IF NOT EXISTS public.feedback_scores (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    performance_id UUID NOT NULL,
    calculation_version INTEGER NOT NULL DEFAULT 1,
    sales_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    review_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    conversion_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    engagement_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    profitability_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    refund_penalty NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    overall_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    grade VARCHAR(2) NOT NULL,
    weight_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
    formula_version VARCHAR(20) NOT NULL DEFAULT 'v1',
    calculated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_feedback_scores PRIMARY KEY (id),
    CONSTRAINT uq_feedback_scores_performance_formula UNIQUE (performance_id, formula_version),
    CONSTRAINT fk_feedback_scores_performance FOREIGN KEY (performance_id) REFERENCES public.product_performance(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.feedback_scores IS '스토어 성과 스냅샷 기반 피드백 종합 점수 및 등급 정보 테이블';
COMMENT ON COLUMN public.feedback_scores.id IS '피드백 스코어 식별 UUID';
COMMENT ON COLUMN public.feedback_scores.performance_id IS '부모 스토어 성과 스냅샷 UUID';
COMMENT ON COLUMN public.feedback_scores.calculation_version IS '성과 재계산에 따른 피드백 스코어 차수 버전';
COMMENT ON COLUMN public.feedback_scores.sales_score IS '정규화 판매량 스코어 (0.000 ~ 100.000)';
COMMENT ON COLUMN public.feedback_scores.review_score IS '정규화 리뷰 평점/수량 스코어 (0.000 ~ 100.000)';
COMMENT ON COLUMN public.feedback_scores.conversion_score IS '정규화 전환율 스코어 (0.000 ~ 100.000)';
COMMENT ON COLUMN public.feedback_scores.engagement_score IS '정규화 노출/클릭 인게이지먼트 스코어 (0.000 ~ 100.000)';
COMMENT ON COLUMN public.feedback_scores.profitability_score IS '정규화 마진/ROI 수익성 스코어 (0.000 ~ 100.000)';
COMMENT ON COLUMN public.feedback_scores.refund_penalty IS '환불 패널티 스코어 (0.000 ~ 100.000)';
COMMENT ON COLUMN public.feedback_scores.overall_score IS '최종 가중 종합 스코어 (0.000 ~ 100.000)';
COMMENT ON COLUMN public.feedback_scores.grade IS '최종 종합 등급 (S, A+, A, B, C, D)';
COMMENT ON COLUMN public.feedback_scores.weight_snapshot IS '연산 당시 가중치 설정 스냅샷';
COMMENT ON COLUMN public.feedback_scores.formula_version IS '연산 당시 사용된 평가 공식 버전';
COMMENT ON COLUMN public.feedback_scores.calculated_at IS '평가 연산 수행 일시';

-- Indexes for performance optimization
CREATE INDEX IF NOT EXISTS idx_feedback_performance ON public.feedback_scores(performance_id);
CREATE INDEX IF NOT EXISTS idx_feedback_grade ON public.feedback_scores(grade);
CREATE INDEX IF NOT EXISTS idx_feedback_formula ON public.feedback_scores(formula_version);
CREATE INDEX IF NOT EXISTS idx_feedback_created ON public.feedback_scores(created_at DESC);

COMMIT;
