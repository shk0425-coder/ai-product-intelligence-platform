import { MetricsRegistry } from '../../observability/metrics/registry.js';

export interface DataPayload {
  workspaceId: string;
  payload: string;
}

export class IsolationAuditor {
  static auditCrossAccess(activeWorkspaceId: string, resourcePayloads: DataPayload[]): boolean {
    const leak = resourcePayloads.some(p => p.workspaceId !== activeWorkspaceId);
    if (leak) {
      MetricsRegistry.counter('workspace_isolation_failed_total', 1);
      return false; // Multi-tenant isolation breach detected!
    }
    return true; // Safe
  }
}
export default IsolationAuditor;
