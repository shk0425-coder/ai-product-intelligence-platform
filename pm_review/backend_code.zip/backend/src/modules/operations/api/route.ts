import { FastifyInstance } from 'fastify';
import { operationsController } from './controller.js';

export async function operationsRoutes(fastify: FastifyInstance) {
  fastify.get('/dashboard', (req, rep) => operationsController.getDashboard(req, rep));
  fastify.post('/audit/search', (req, rep) => operationsController.searchAudits(req, rep));
  fastify.get('/audit/export', (req, rep) => operationsController.exportAudits(req, rep));
}

export async function capabilityRoutes(fastify: FastifyInstance) {
  fastify.get('/capabilities', (req, rep) => operationsController.getCapabilities(req, rep));
  fastify.get('/capabilities/:name', (req, rep) => operationsController.getCapability(req, rep));
}
