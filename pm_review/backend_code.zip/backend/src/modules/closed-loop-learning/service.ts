import { LearningRepository } from './repository.js';
import { GenerateLearningDto, RegenerateLearningDto, LearningKnowledgeDto } from './dto.js';
import { LearningMapper } from './mapper.js';
import { FeatureExtractor } from './feature-extractor.js';
import { PatternDetector } from './pattern-detector.js';
import { KnowledgeBuilder } from './knowledge-builder.js';
import { VectorGenerator } from './vector-generator.js';
import { KnowledgeScorer } from './knowledge-scorer.js';
import { LearningHooks } from './hooks.js';
import {
  IntelligenceNotFoundError,
  DuplicateLearningKnowledgeError,
  LearningKnowledgeNotFoundError,
  WorkspaceForbiddenError,
} from '@/common/errors/index.js';
import { SupabaseClient } from '@supabase/supabase-js';

export class ClosedLoopLearningService {
  constructor(private readonly repository: LearningRepository) {}

  async generate(dto: GenerateLearningDto, actorId: string): Promise<LearningKnowledgeDto> {
    const { intelligenceId, vectorVersion = 'v1' } = dto;

    // 1. Verify Ownership
    const isOwner = await this.repository.verifyIntelligenceOwner(intelligenceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this intelligence report',
      );
    }

    // 2. Check Parent Intelligence Existence
    const supabase = (this.repository as unknown as { supabase: SupabaseClient }).supabase;
    const { data: intelligence, error: intelError } = await supabase
      .from('feedback_intelligence')
      .select('*')
      .eq('id', intelligenceId)
      .maybeSingle();

    if (intelError || !intelligence) {
      throw new IntelligenceNotFoundError('Feedback intelligence report not found');
    }

    // 3. Prevent Duplicate Generation for version 1
    const exists = await this.repository.exists(intelligenceId, 1);
    if (exists) {
      throw new DuplicateLearningKnowledgeError(
        `Learning assets already generated for intelligence ID ${intelligenceId} and version 1. Use regenerate instead.`,
      );
    }

    // 4. Fetch additional context: feedback score & performance metrics
    const { data: feedbackScore } = await supabase
      .from('feedback_scores')
      .select('*')
      .eq('id', intelligence.feedback_score_id)
      .maybeSingle();

    const performanceId = feedbackScore ? feedbackScore.performance_id : null;

    const { data: _performance } = await supabase
      .from('product_performance')
      .select('*')
      .eq('id', performanceId)
      .maybeSingle();

    const { data: _metrics } = await supabase
      .from('performance_metrics')
      .select('*')
      .eq('id', performanceId)
      .maybeSingle();

    // 5. Run Pure Engines
    const features = FeatureExtractor.extract(intelligence);
    const patterns = PatternDetector.detect(intelligence);
    const texts = KnowledgeBuilder.build(features, patterns);
    const vectorResult = VectorGenerator.generate(features, patterns, intelligence, vectorVersion);
    const knowledgeScore = KnowledgeScorer.calculate(
      vectorResult.featureCount,
      patterns.length,
      Number(intelligence.confidence_score),
    );

    // 6. DB Inserts inside transaction structure (single writes)
    const knowledgePayload = {
      intelligence_id: intelligenceId,
      knowledge_version: 1,
      feature_summary: texts.featureSummary,
      success_pattern: texts.successPattern,
      failure_pattern: texts.failurePattern,
      improvement_pattern: texts.improvementPattern,
      knowledge_score: knowledgeScore,
      confidence_score: Number(intelligence.confidence_score),
    };

    const knowledgeEntity = await this.repository.createKnowledge(knowledgePayload);

    const vectorPayload = {
      knowledge_id: knowledgeEntity.id,
      vector_version: vectorResult.vectorVersion,
      vector_data: vectorResult.vectorData,
      feature_count: vectorResult.featureCount,
      checksum: vectorResult.checksum,
    };

    const vectorEntity = await this.repository.createVector(vectorPayload);

    for (const pattern of patterns) {
      await this.repository.createPattern({
        knowledge_id: knowledgeEntity.id,
        category: pattern.category,
        severity: pattern.severity,
        frequency: pattern.frequency,
        pattern_hash: pattern.patternHash,
        pattern_data: pattern.patternData,
      });
    }

    // Create Audit
    await this.repository.createAudit({
      knowledge_id: knowledgeEntity.id,
      action: 'GENERATE',
      actor_id: actorId,
      knowledge_version: 1,
      metadata: {
        trigger: 'GENERATE',
        vectorVersion: vectorResult.vectorVersion,
        patternCount: patterns.length,
        knowledgeScore,
      },
    });

    const resultDto = LearningMapper.toKnowledgeDto(knowledgeEntity, vectorEntity);

    // 7. Emit Domain Hooks
    await LearningHooks.onLearningKnowledgeCreated({
      knowledge: resultDto,
      actorId,
      timestamp: new Date().toISOString(),
    });

    if (resultDto.vector) {
      await LearningHooks.onLearningVectorGenerated({
        vector: resultDto.vector,
        actorId,
      });
    }

    return resultDto;
  }

  async regenerate(dto: RegenerateLearningDto, actorId: string): Promise<LearningKnowledgeDto> {
    const { intelligenceId, vectorVersion = 'v1' } = dto;

    // 1. Verify Ownership
    const isOwner = await this.repository.verifyIntelligenceOwner(intelligenceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this intelligence report',
      );
    }

    // 2. Fetch Intelligence Report
    const supabase = (this.repository as unknown as { supabase: SupabaseClient }).supabase;
    const { data: intelligence } = await supabase
      .from('feedback_intelligence')
      .select('*')
      .eq('id', intelligenceId)
      .maybeSingle();

    if (!intelligence) {
      throw new IntelligenceNotFoundError('Feedback intelligence report not found');
    }

    // 3. Resolve next knowledge version (fetch all existing versions)
    const { data: existingList } = await supabase
      .from('learning_knowledge')
      .select('knowledge_version')
      .eq('intelligence_id', intelligenceId);

    const maxVersion = existingList
      ? existingList.reduce((max, item) => Math.max(max, Number(item.knowledge_version)), 0)
      : 0;
    const nextVersion = maxVersion + 1;

    // 4. Fetch context and run Pure Engines
    const { data: feedbackScore } = await supabase
      .from('feedback_scores')
      .select('*')
      .eq('id', intelligence.feedback_score_id)
      .maybeSingle();

    const performanceId = feedbackScore ? feedbackScore.performance_id : null;
    const { data: _performance } = await supabase
      .from('product_performance')
      .select('*')
      .eq('id', performanceId)
      .maybeSingle();

    const { data: _metrics } = await supabase
      .from('performance_metrics')
      .select('*')
      .eq('id', performanceId)
      .maybeSingle();

    const features = FeatureExtractor.extract(intelligence);
    const patterns = PatternDetector.detect(intelligence);
    const texts = KnowledgeBuilder.build(features, patterns);
    const vectorResult = VectorGenerator.generate(features, patterns, intelligence, vectorVersion);
    const knowledgeScore = KnowledgeScorer.calculate(
      vectorResult.featureCount,
      patterns.length,
      Number(intelligence.confidence_score),
    );

    // 5. Persist regenerations (Insert brand new knowledge version record)
    const knowledgePayload = {
      intelligence_id: intelligenceId,
      knowledge_version: nextVersion,
      feature_summary: texts.featureSummary,
      success_pattern: texts.successPattern,
      failure_pattern: texts.failurePattern,
      improvement_pattern: texts.improvementPattern,
      knowledge_score: knowledgeScore,
      confidence_score: Number(intelligence.confidence_score),
    };

    const knowledgeEntity = await this.repository.createKnowledge(knowledgePayload);

    const vectorPayload = {
      knowledge_id: knowledgeEntity.id,
      vector_version: vectorResult.vectorVersion,
      vector_data: vectorResult.vectorData,
      feature_count: vectorResult.featureCount,
      checksum: vectorResult.checksum,
    };

    const vectorEntity = await this.repository.createVector(vectorPayload);

    for (const pattern of patterns) {
      await this.repository.createPattern({
        knowledge_id: knowledgeEntity.id,
        category: pattern.category,
        severity: pattern.severity,
        frequency: pattern.frequency,
        pattern_hash: pattern.patternHash,
        pattern_data: pattern.patternData,
      });
    }

    // Create Audit
    await this.repository.createAudit({
      knowledge_id: knowledgeEntity.id,
      action: 'REGENERATE',
      actor_id: actorId,
      knowledge_version: nextVersion,
      metadata: {
        trigger: 'REGENERATE',
        vectorVersion: vectorResult.vectorVersion,
        patternCount: patterns.length,
        knowledgeScore,
      },
    });

    const resultDto = LearningMapper.toKnowledgeDto(knowledgeEntity, vectorEntity);

    // 6. Hook emissions
    await LearningHooks.onLearningKnowledgeUpdated({
      knowledge: resultDto,
      actorId,
      timestamp: new Date().toISOString(),
    });

    if (resultDto.vector) {
      await LearningHooks.onLearningVectorGenerated({
        vector: resultDto.vector,
        actorId,
      });
    }

    return resultDto;
  }

  async findKnowledge(knowledgeId: string, actorId: string): Promise<LearningKnowledgeDto> {
    const isOwner = await this.repository.verifyKnowledgeOwner(knowledgeId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this knowledge record',
      );
    }

    const knowledge = await this.repository.findKnowledge(knowledgeId);
    if (!knowledge) {
      throw new LearningKnowledgeNotFoundError(
        `Learning knowledge record ${knowledgeId} not found`,
      );
    }

    const vector = await this.repository.findVectorByKnowledge(knowledgeId);
    return LearningMapper.toKnowledgeDto(knowledge, vector || undefined);
  }

  async findLatest(productId: string, actorId: string): Promise<LearningKnowledgeDto> {
    const isOwner = await this.repository.verifyProductOwner(productId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product record');
    }

    const knowledge = await this.repository.findLatest(productId);
    if (!knowledge) {
      throw new LearningKnowledgeNotFoundError(
        `Learning knowledge record not found for product ${productId}`,
      );
    }

    const vector = await this.repository.findVectorByKnowledge(knowledge.id);
    return LearningMapper.toKnowledgeDto(knowledge, vector || undefined);
  }

  async findHistory(productId: string, actorId: string): Promise<LearningKnowledgeDto[]> {
    const isOwner = await this.repository.verifyProductOwner(productId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product record');
    }

    const knowledges = await this.repository.findHistory(productId);

    // Batch query vectors to prevent N+1 query issue
    const knowledgeIds = knowledges.map((k) => k.id);
    const vectorsMap = new Map<string, import('./types.js').LearningVectorEntity>();

    if (knowledgeIds.length > 0) {
      const supabase = (this.repository as unknown as { supabase: SupabaseClient }).supabase;
      const { data: vectorsList } = await supabase
        .from('learning_vectors')
        .select('*')
        .in('knowledge_id', knowledgeIds);

      if (vectorsList) {
        for (const v of vectorsList) {
          vectorsMap.set(v.knowledge_id, v);
        }
      }
    }

    return LearningMapper.toKnowledgeDtoList(knowledges, vectorsMap);
  }
}
export default ClosedLoopLearningService;
