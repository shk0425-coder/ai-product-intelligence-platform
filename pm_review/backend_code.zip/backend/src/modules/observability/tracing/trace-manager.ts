import crypto from 'crypto';
import { AsyncContextManager, ObservabilityContext } from '../context/context-manager.js';
import { TracingExporter, ConsoleTracingExporter, SpanRecord } from './exporter.js';

export type SamplingPolicy = 'ALWAYS' | 'NEVER' | 'RATIO' | 'ADAPTIVE';

export class Span {
  readonly traceId: string;
  readonly spanId: string;
  readonly parentSpanId?: string;
  readonly name: string;
  readonly startTime: number;
  private endTime?: number;
  readonly attributes: Record<string, unknown> = {};
  private status: 'OK' | 'ERROR' = 'OK';
  private error?: string;
  private active = true;

  constructor(name: string, traceId: string, parentSpanId?: string) {
    this.name = name;
    this.traceId = traceId;
    this.spanId = crypto.randomUUID();
    this.parentSpanId = parentSpanId;
    this.startTime = Date.now();
  }

  setAttribute(key: string, value: unknown): void {
    this.attributes[key] = value;
  }

  setStatus(status: 'OK' | 'ERROR', errorMsg?: string): void {
    this.status = status;
    if (errorMsg) this.error = errorMsg;
  }

  end(): void {
    if (!this.active) return;
    this.endTime = Date.now();
    this.active = false;
    TraceManager.recordSpanEnd(this);
  }

  isActive(): boolean {
    return this.active;
  }

  toRecord(): SpanRecord {
    return {
      traceId: this.traceId,
      spanId: this.spanId,
      parentSpanId: this.parentSpanId,
      name: this.name,
      startTime: this.startTime,
      endTime: this.endTime,
      durationMs: this.endTime ? this.endTime - this.startTime : undefined,
      attributes: { ...this.attributes },
      status: this.status,
      error: this.error,
    };
  }
}

export class TraceManager {
  private static exporter: TracingExporter = new ConsoleTracingExporter();
  private static samplingPolicy: SamplingPolicy = 'ALWAYS';
  private static sampleRatio = 1.0; // range [0.0, 1.0]
  private static readonly activeSpans = new Map<string, { span: Span; createdAt: number }>();
  private static leakInterval: NodeJS.Timeout | null = null;
  private static leakDetectionTimeoutMs = 30000; // 30s leak detection timeout
  private static leakCallback?: (span: Span) => void;

  static init(leakCallback?: (span: Span) => void, checkIntervalMs = 5000): void {
    this.leakCallback = leakCallback;
    this.startLeakDetection(checkIntervalMs);
  }

  static setExporter(exporter: TracingExporter): void {
    this.exporter = exporter;
  }

  static setSamplingPolicy(policy: SamplingPolicy, ratio = 1.0): void {
    this.samplingPolicy = policy;
    this.sampleRatio = ratio;
  }

  static shouldSample(traceId: string): boolean {
    const enabled = process.env.OBS_TRACING_ENABLED !== 'false';
    if (!enabled) return false;

    if (this.samplingPolicy === 'NEVER') return false;
    if (this.samplingPolicy === 'ALWAYS') return true;

    if (this.samplingPolicy === 'RATIO' || this.samplingPolicy === 'ADAPTIVE') {
      // Deterministic sampling based on traceId hash
      let hash = 0;
      for (let i = 0; i < traceId.length; i++) {
        hash = (hash << 5) - hash + traceId.charCodeAt(i);
        hash |= 0; // Convert to 32bit integer
      }
      const normalized = Math.abs(hash) % 10000;
      return normalized < this.sampleRatio * 10000;
    }

    return true;
  }

  static startSpan(name: string, parentContext?: ObservabilityContext): Span {
    const enabled = process.env.OBS_TRACING_ENABLED !== 'false';
    if (!enabled) {
      // Return a dummy inactive span
      const dummy = new Span(name, 'noop-trace');
      dummy.end();
      return dummy;
    }

    const currentContext = parentContext || AsyncContextManager.getStore() || {};
    const traceId = currentContext.traceId || crypto.randomUUID();
    const correlationId = currentContext.correlationId || crypto.randomUUID();
    const parentSpanId = currentContext.spanId;

    const span = new Span(name, traceId, parentSpanId);

    // Track active spans for leak detection
    this.activeSpans.set(span.spanId, { span, createdAt: Date.now() });

    // Set new context
    const nextContext: ObservabilityContext = {
      ...currentContext,
      traceId,
      spanId: span.spanId,
      correlationId,
    };
    AsyncContextManager.updateContext(nextContext);

    return span;
  }

  static recordSpanEnd(span: Span): void {
    this.activeSpans.delete(span.spanId);

    if (this.shouldSample(span.traceId)) {
      try {
        this.exporter.export(span.toRecord());
      } catch {
        // Enforce resilience
      }
    }
  }

  private static startLeakDetection(checkIntervalMs = 5000): void {
    this.stopLeakDetection();
    this.leakInterval = setInterval(() => {
      const now = Date.now();
      for (const [spanId, item] of this.activeSpans.entries()) {
        if (now - item.createdAt > this.leakDetectionTimeoutMs) {
          // Span leak detected
          this.activeSpans.delete(spanId);
          if (this.leakCallback) {
            try {
              this.leakCallback(item.span);
            } catch {}
          }
        }
      }
    }, checkIntervalMs);

    // Do not block Node process exit in tests
    if (this.leakInterval.unref) {
      this.leakInterval.unref();
    }
  }

  static stopLeakDetection(): void {
    if (this.leakInterval) {
      clearInterval(this.leakInterval);
      this.leakInterval = null;
    }
  }

  static getActiveSpanCount(): number {
    return this.activeSpans.size;
  }

  static clearActiveSpans(): void {
    this.activeSpans.clear();
  }
}
