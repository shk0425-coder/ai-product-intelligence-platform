import { FastifyInstance, FastifyPluginOptions, FastifyRequest } from 'fastify';
import { LearningRepository } from './repository.js';
import { ClosedLoopLearningService } from './service.js';
import { ClosedLoopLearningController } from './controller.js';
import { authMiddleware } from '@/middleware/auth.middleware.js';
import {
  generateLearningSchema,
  regenerateLearningSchema,
  learningIdParamSchema,
  learningProductParamSchema,
} from './schema.js';
import { ValidationError } from '@/common/errors/index.js';
import { z } from 'zod';

const validateBody =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.body);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.body = result.data;
  };

const validateParams =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.params);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.params = result.data;
  };

export default async function closedLoopLearningRoutes(
  fastify: FastifyInstance,
  _options: FastifyPluginOptions,
): Promise<void> {
  const repository = new LearningRepository(fastify.supabase);
  const service = new ClosedLoopLearningService(repository);
  const controller = new ClosedLoopLearningController(service);

  // Apply authentication globally
  fastify.addHook('preHandler', authMiddleware);

  // POST /generate
  fastify.post('/generate', {
    preValidation: validateBody(generateLearningSchema),
    handler: controller.generate,
  });

  // POST /regenerate
  fastify.post('/regenerate', {
    preValidation: validateBody(regenerateLearningSchema),
    handler: controller.regenerate,
  });

  // GET /knowledge/:knowledgeId
  fastify.get('/knowledge/:knowledgeId', {
    preValidation: validateParams(learningIdParamSchema),
    handler: controller.findKnowledge,
  });

  // GET /history/:productId
  fastify.get('/history/:productId', {
    preValidation: validateParams(learningProductParamSchema),
    handler: controller.findHistory,
  });

  // GET /latest/:productId
  fastify.get('/latest/:productId', {
    preValidation: validateParams(learningProductParamSchema),
    handler: controller.findLatest,
  });
}
