export interface MetricLabels {
  workspace_id?: string;
  user_id?: string;
  workflow?: string;
  provider?: string;
  model?: string;
  queue?: string;
  endpoint?: string;
  status?: string;
  region?: string;
  instance?: string;
  [key: string]: string | undefined;
}

export interface MetricsProvider {
  counter(name: string, value: number, labels?: MetricLabels): void;
  gauge(name: string, value: number, labels?: MetricLabels): void;
  histogram(name: string, value: number, labels?: MetricLabels): void;
  summary(name: string, value: number, labels?: MetricLabels): void;
}

export class NoopMetricsProvider implements MetricsProvider {
  counter(_name: string, _value: number, _labels?: MetricLabels): void {}
  gauge(_name: string, _value: number, _labels?: MetricLabels): void {}
  histogram(_name: string, _value: number, _labels?: MetricLabels): void {}
  summary(_name: string, _value: number, _labels?: MetricLabels): void {}
}

export class PrometheusProvider implements MetricsProvider {
  private metrics: Record<string, { type: string; values: { value: number; labels?: MetricLabels; timestamp: number }[] }> = {};

  counter(name: string, value: number, labels?: MetricLabels): void {
    this.record(name, 'counter', value, labels);
  }

  gauge(name: string, value: number, labels?: MetricLabels): void {
    this.record(name, 'gauge', value, labels);
  }

  histogram(name: string, value: number, labels?: MetricLabels): void {
    this.record(name, 'histogram', value, labels);
  }

  summary(name: string, value: number, labels?: MetricLabels): void {
    this.record(name, 'summary', value, labels);
  }

  private record(name: string, type: string, value: number, labels?: MetricLabels): void {
    if (!this.metrics[name]) {
      this.metrics[name] = { type, values: [] };
    }
    this.metrics[name].values.push({ value, labels, timestamp: Date.now() });
  }

  getRawMetrics() {
    return this.metrics;
  }

  toPrometheusFormat(): string {
    let output = '';
    for (const [name, data] of Object.entries(this.metrics)) {
      output += `# HELP ${name} System collected metric ${name}\n`;
      output += `# TYPE ${name} ${data.type.toUpperCase()}\n`;
      for (const entry of data.values) {
        const labelPairs = entry.labels
          ? Object.entries(entry.labels)
              .filter(([_, v]) => v !== undefined)
              .map(([k, v]) => `${k}="${v}"`)
              .join(',')
          : '';
        const labelStr = labelPairs ? `{${labelPairs}}` : '';
        output += `${name}${labelStr} ${entry.value}\n`;
      }
      output += '\n';
    }
    return output.trim();
  }

  clear(): void {
    this.metrics = {};
  }
}

export class MetricsProviderFactory {
  private static provider: MetricsProvider = new NoopMetricsProvider();

  static getProvider(): MetricsProvider {
    const enabled = process.env.OBS_METRICS_ENABLED !== 'false';
    if (!enabled) {
      return new NoopMetricsProvider();
    }
    return this.provider;
  }

  static setProvider(provider: MetricsProvider): void {
    this.provider = provider;
  }
}
