import { PromptTemplateEntity, PromptVersionEntity } from './types.js';
import { PromptRenderer, RenderedPromptResult } from './renderer.js';

export class PromptPreviewer {
  static async preview(
    template: PromptTemplateEntity,
    version: PromptVersionEntity,
    variables: Record<string, unknown>,
    model: string
  ): Promise<RenderedPromptResult & { variables: Record<string, unknown> }> {
    const rendered = await PromptRenderer.render(template, version, variables, model);
    return {
      ...rendered,
      variables,
    };
  }
}
export default PromptPreviewer;
