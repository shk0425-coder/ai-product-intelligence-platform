import { FastifyRequest, FastifyReply } from 'fastify';
import { JobRepository } from '../persistence/job-repository.js';
import { SchedulerEngine } from '../engine/scheduler-engine.js';
import { SchedulerStateRepository } from '../persistence/scheduler-state-repository.js';
import { ExecutionRepository } from '../persistence/execution-repository.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export class SchedulerController {
  async runJob(req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const { jobName, forceRun } = req.body as { jobName: string; forceRun?: boolean };

    const job = await JobRepository.findByName(jobName);
    if (!job) {
      rep.status(404).send({ status: 'error', message: `Job ${jobName} not found` });
      return;
    }

    const success = await SchedulerEngine.triggerJob(job, !!forceRun);
    rep.send({ status: success ? 'success' : 'failed', data: { success } });
  }

  async startMaintenance(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    await SchedulerStateRepository.saveState({ maintenanceMode: true });
    MetricsRegistry.counter('scheduler_maintenance_total', 1);

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'SchedulerMaintenanceStarted',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: {},
    }).catch(() => {});

    rep.send({ status: 'success', data: { maintenanceMode: true } });
  }

  async stopMaintenance(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    await SchedulerStateRepository.saveState({ maintenanceMode: false });

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'SchedulerMaintenanceStopped',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: {},
    }).catch(() => {});

    rep.send({ status: 'success', data: { maintenanceMode: false } });
  }

  async getMaintenanceStatus(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const state = await SchedulerStateRepository.getState();
    rep.send({ status: 'success', data: { maintenanceMode: state.maintenanceMode } });
  }

  async getDashboard(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const registered = await JobRepository.findAll();
    const history = await ExecutionRepository.getHistory();
    const running = history.filter(h => h.state === 'Running');
    const failed = history.filter(h => h.state === 'Failed' || h.state === 'Timeout');
    const successCount = history.filter(h => h.state === 'Success').length;
    
    const successRate = history.length > 0 ? (successCount / history.length) * 100 : 100;
    const avgDuration = history.length > 0 
      ? history.reduce((acc, h) => acc + (h.durationMs || 0), 0) / history.length 
      : 0;

    rep.send({
      status: 'success',
      data: {
        registeredJobs: registered.length,
        runningJobs: running.length,
        failedJobs: failed.length,
        retryQueue: 0,
        successRate,
        averageDuration: avgDuration,
      },
    });
  }
}
export const schedulerController = new SchedulerController();
export default schedulerController;
