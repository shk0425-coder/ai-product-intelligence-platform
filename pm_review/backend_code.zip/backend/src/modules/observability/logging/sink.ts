export interface LogSink {
  write(log: Record<string, unknown>): void;
}

export class ConsoleSink implements LogSink {
  write(log: Record<string, unknown>): void {
    console.log(JSON.stringify(log));
  }
}

export class FileSink implements LogSink {
  private logs: Record<string, unknown>[] = [];

  write(log: Record<string, unknown>): void {
    this.logs.push(log);
    // Emulated persistence for file logs.
    // In production, this would write to a writeStream on disk.
  }

  getLogs(): Record<string, unknown>[] {
    return [...this.logs];
  }

  clear(): void {
    this.logs = [];
  }
}

export class OltpSink implements LogSink {
  private sentLogs: Record<string, unknown>[] = [];

  write(log: Record<string, unknown>): void {
    this.sentLogs.push(log);
    // Emulated OTLP network exporter stream.
  }

  getSentLogs(): Record<string, unknown>[] {
    return [...this.sentLogs];
  }
}

export class LokiSink implements LogSink {
  write(_log: Record<string, unknown>): void {
    // Emulated Loki stream ingestion.
  }
}

export class ElasticsearchSink implements LogSink {
  write(_log: Record<string, unknown>): void {
    // Emulated ES bulk insert.
  }
}
