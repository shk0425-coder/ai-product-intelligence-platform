import { FastifyRequest, FastifyReply } from 'fastify';
import { ToolService } from './service.js';
import { CreateToolDto, CreateToolVersionDto, ExecuteToolDto } from './dto.js';

export class ToolController {
  constructor(private readonly service: ToolService) {}

  async getTools(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getTools();
    return reply.status(200).send({ data: result });
  }

  async getToolById(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.getToolById(id);
    return reply.status(200).send({ data: result });
  }

  async createTool(req: FastifyRequest<{ Body: CreateToolDto }>, reply: FastifyReply) {
    const result = await this.service.createTool(req.body);
    return reply.status(201).send({ data: result });
  }

  async createVersion(
    req: FastifyRequest<{ Params: { id: string }; Body: CreateToolVersionDto }>,
    reply: FastifyReply
  ) {
    const { id } = req.params;
    const result = await this.service.createVersion(id, req.body);
    return reply.status(201).send({ data: result });
  }

  async approveTool(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.approveTool(id);
    return reply.status(200).send({ data: result });
  }

  async reviewTool(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.reviewTool(id);
    return reply.status(200).send({ data: result });
  }

  async deprecateTool(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.deprecateTool(id);
    return reply.status(200).send({ data: result });
  }

  async executeTool(
    req: FastifyRequest<{ Params: { id: string }; Body: ExecuteToolDto }>,
    reply: FastifyReply
  ) {
    const { id } = req.params;
    const result = await this.service.execute(id, req.body);
    return reply.status(200).send({ data: result });
  }

  async getHistory(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getHistory();
    return reply.status(200).send({ data: result });
  }

  // --- Approvals ---
  async getApprovals(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getApprovals();
    return reply.status(200).send({ data: result });
  }

  async getApprovalById(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.getApprovalById(id);
    return reply.status(200).send({ data: result });
  }

  async approveApproval(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.approveApproval(id, 'admin-approver-id');
    return reply.status(200).send({ data: result });
  }

  async rejectApproval(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.rejectApproval(id, 'admin-approver-id');
    return reply.status(200).send({ data: result });
  }

  async cancelApproval(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.cancelApproval(id, 'admin-approver-id');
    return reply.status(200).send({ data: result });
  }
}
export default ToolController;
