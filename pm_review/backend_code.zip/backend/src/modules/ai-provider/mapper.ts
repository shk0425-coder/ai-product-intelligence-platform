import { AIProviderConfigEntity, AIProviderHealthEntity, AIProviderMetricEntity } from './types.js';
import { AIProviderConfigDto, AIProviderHealthDto, AIProviderMetricDto } from './dto.js';

export class AIProviderMapper {
  static toConfigDto(entity: AIProviderConfigEntity): AIProviderConfigDto {
    return {
      provider: entity.provider,
      model: entity.model,
      version: entity.version,
      priority: entity.priority,
      enabled: entity.enabled,
      rpm: entity.rpm,
      tpm: entity.tpm,
      retryCount: entity.retry_count,
      timeoutSeconds: entity.timeout_seconds,
      metadata: entity.metadata,
    };
  }

  static toConfigDtoList(entities: AIProviderConfigEntity[]): AIProviderConfigDto[] {
    return entities.map((e) => this.toConfigDto(e));
  }

  static toHealthDto(entity: AIProviderHealthEntity): AIProviderHealthDto {
    return {
      provider: entity.provider,
      model: entity.model,
      status: entity.status,
      failureCount: entity.failure_count,
      lastCheckedAt: entity.last_checked_at,
    };
  }

  static toHealthDtoList(entities: AIProviderHealthEntity[]): AIProviderHealthDto[] {
    return entities.map((e) => this.toHealthDto(e));
  }

  static toMetricDto(entity: AIProviderMetricEntity): AIProviderMetricDto {
    return {
      provider: entity.provider,
      model: entity.model,
      latencyMs: entity.latency_ms,
      promptTokens: entity.prompt_tokens,
      completionTokens: entity.completion_tokens,
      totalTokens: entity.total_tokens,
      estimatedCost: entity.estimated_cost,
      cacheHit: entity.cache_hit,
      createdAt: entity.created_at,
    };
  }

  static toMetricDtoList(entities: AIProviderMetricEntity[]): AIProviderMetricDto[] {
    return entities.map((e) => this.toMetricDto(e));
  }
}
export default AIProviderMapper;
