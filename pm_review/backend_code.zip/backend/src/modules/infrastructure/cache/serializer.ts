export class CacheSerializer {
  static serialize(value: unknown): string {
    const seen = new WeakSet<object>();

    const preTraverse = (val: unknown): unknown => {
      if (val === null || val === undefined) {
        return val;
      }

      if (val instanceof Date) {
        return `__DATE__:${val.toISOString()}`;
      }

      if (typeof val === 'bigint') {
        return `__BIGINT__:${val.toString()}`;
      }

      if (val instanceof Buffer || (val && typeof val === 'object' && (val as { type: string; data: number[] }).type === 'Buffer' && Array.isArray((val as { type: string; data: number[] }).data))) {
        const buf = Buffer.isBuffer(val) ? val : Buffer.from((val as { type: string; data: number[] }).data);
        return `__BUFFER__:${buf.toString('base64')}`;
      }

      if (val && typeof val === 'object' && typeof (val as { toNumber: () => number }).toNumber === 'function') {
        return `__DECIMAL__:${(val as { toString: () => string }).toString()}`;
      }

      if (typeof val === 'object') {
        if (seen.has(val)) {
          return '__CIRCULAR__';
        }
        seen.add(val);

        if (Array.isArray(val)) {
          return val.map(item => preTraverse(item));
        }

        const copy: Record<string, unknown> = {};
        for (const key of Object.keys(val)) {
          copy[key] = preTraverse((val as Record<string, unknown>)[key]);
        }
        return copy;
      }

      return val;
    };

    const replacer = (_key: string, val: unknown) => {
      if (val === undefined) {
        return '__UNDEFINED__';
      }
      return val;
    };

    const preprocessed = preTraverse(value);
    return JSON.stringify(preprocessed, replacer);
  }

  static deserialize(str: string | null): unknown {
    if (str === null) return null;

    const reviver = (_key: string, val: unknown) => {
      if (typeof val === 'string') {
        if (val.startsWith('__BIGINT__:')) {
          return BigInt(val.slice(11));
        }
        if (val.startsWith('__DATE__:')) {
          return new Date(val.slice(9));
        }
        if (val.startsWith('__BUFFER__:')) {
          return Buffer.from(val.slice(11), 'base64');
        }
        if (val.startsWith('__DECIMAL__:')) {
          return Number(val.slice(12));
        }
        if (val === '__UNDEFINED__') {
          return undefined;
        }
        if (val === '__CIRCULAR__') {
          return '[Circular]';
        }
      }
      return val;
    };

    try {
      return JSON.parse(str, reviver);
    } catch {
      return str;
    }
  }
}
