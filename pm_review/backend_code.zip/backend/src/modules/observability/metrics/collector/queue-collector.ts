import { MetricsRegistry } from '../registry.js';

export class QueueMetricsCollector {
  static updateQueueDepth(queueName: string, depth: number): void {
    MetricsRegistry.gauge('queue_depth', depth, { queue: queueName });
  }

  static updateActiveWorkers(queueName: string, workers: number): void {
    MetricsRegistry.gauge('active_workers', workers, { queue: queueName });
  }
}
