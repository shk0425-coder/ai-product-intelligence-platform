import { SupabaseClient } from '@supabase/supabase-js';
import { AIProviderConfigEntity, AIProviderHealthEntity, AIProviderMetricEntity } from './types.js';

export class AIProviderRepository {
  constructor(private readonly supabase: SupabaseClient) {}

  async findConfigs(): Promise<AIProviderConfigEntity[]> {
    const { data, error } = await this.supabase
      .from('ai_provider_configs')
      .select('*')
      .order('priority', { ascending: false });

    if (error) return [];
    return (data || []) as AIProviderConfigEntity[];
  }

  async findHealths(): Promise<AIProviderHealthEntity[]> {
    const { data, error } = await this.supabase
      .from('ai_provider_health')
      .select('*');

    if (error) return [];
    return (data || []) as AIProviderHealthEntity[];
  }

  async updateConfig(provider: string, model: string, payload: Partial<AIProviderConfigEntity>): Promise<AIProviderConfigEntity | null> {
    const { data, error } = await this.supabase
      .from('ai_provider_configs')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('provider', provider.toUpperCase())
      .eq('model', model.toLowerCase())
      .select('*')
      .maybeSingle();

    if (error) return null;
    return data as AIProviderConfigEntity;
  }

  async createMetric(metric: Omit<AIProviderMetricEntity, 'id' | 'created_at'>): Promise<AIProviderMetricEntity | null> {
    const { data, error } = await this.supabase
      .from('ai_provider_metrics')
      .insert({
        ...metric,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as AIProviderMetricEntity;
  }

  async updateHealth(provider: string, model: string, health: Partial<AIProviderHealthEntity>): Promise<AIProviderHealthEntity | null> {
    const { data, error } = await this.supabase
      .from('ai_provider_health')
      .update({
        ...health,
        last_checked_at: new Date().toISOString(),
      })
      .eq('provider', provider.toUpperCase())
      .eq('model', model.toLowerCase())
      .select('*')
      .maybeSingle();

    if (error) {
      // Optimistic insert if not found
      const { data: inserted, error: insertError } = await this.supabase
        .from('ai_provider_health')
        .insert({
          provider: provider.toUpperCase(),
          model: model.toLowerCase(),
          status: health.status || 'HEALTHY',
          failure_count: health.failure_count || 0,
          last_checked_at: new Date().toISOString(),
        })
        .select('*')
        .single();
      
      if (insertError) return null;
      return inserted as AIProviderHealthEntity;
    }
    return data as AIProviderHealthEntity;
  }
}
export default AIProviderRepository;
