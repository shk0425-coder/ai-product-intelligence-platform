import { WorkflowDefinitionEntity, WorkflowVersionEntity } from './types.js';
import { ValidationError } from '../../common/errors/index.js';
import { WorkflowGraphValidator } from './graph-validator.js';

export class WorkflowValidator {
  static validate(
    workflow: WorkflowDefinitionEntity | null,
    version: WorkflowVersionEntity | null
  ): void {
    if (!workflow) {
      throw new ValidationError('Workflow definition not found');
    }
    if (!version) {
      throw new ValidationError('Workflow version details not found');
    }

    // 1. Approval validation
    if (workflow.status !== 'APPROVED') {
      throw new ValidationError(`Workflow execution is restricted: current status is ${workflow.status}. Only APPROVED workflows can be run.`);
    }

    // 2. DAG graph integrity checks
    WorkflowGraphValidator.validate(version.graph);
  }
}
export default WorkflowValidator;
