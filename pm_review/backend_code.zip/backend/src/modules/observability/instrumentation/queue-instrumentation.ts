import { TraceManager, Span } from '../tracing/trace-manager.js';
import { MetricsRegistry } from '../metrics/registry.js';
import { QueueMetricsCollector } from '../metrics/collector/queue-collector.js';

export class QueueInstrumentation {
  static startJobPush(queueName: string, jobId: string): Span {
    const span = TraceManager.startSpan(`Queue Push ${queueName}`);
    span.setAttribute('queue.name', queueName);
    span.setAttribute('queue.job_id', jobId);
    return span;
  }

  static endJobPush(span: Span, queueName: string): void {
    span.end();
    MetricsRegistry.counter('queue_pushes_total', 1, { queue: queueName });
  }

  static startJobProcess(queueName: string, jobId: string): Span {
    const span = TraceManager.startSpan(`Queue Process ${queueName}`);
    span.setAttribute('queue.name', queueName);
    span.setAttribute('queue.job_id', jobId);
    return span;
  }

  static endJobProcess(span: Span, queueName: string, durationMs: number, success = true): void {
    span.setStatus(success ? 'OK' : 'ERROR');
    span.end();

    MetricsRegistry.counter('queue_processed_total', 1, { queue: queueName, status: success ? 'success' : 'failure' });
    MetricsRegistry.histogram('queue_process_duration_seconds', durationMs / 1000, { queue: queueName });
  }

  static updateQueueState(queueName: string, depth: number, activeWorkers: number): void {
    QueueMetricsCollector.updateQueueDepth(queueName, depth);
    QueueMetricsCollector.updateActiveWorkers(queueName, activeWorkers);
  }
}
