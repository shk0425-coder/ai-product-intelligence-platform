import { z } from 'zod';

export const EnqueueJobSchema = z.object({
  workspaceId: z.string().uuid(),
  jobType: z.string().min(1).max(50),
  payload: z.record(z.any()),
  priority: z.number().int().optional(),
  scheduledAt: z.string().datetime().optional(),
});

export const JobActionSchema = z.object({
  jobId: z.string().uuid(),
});
