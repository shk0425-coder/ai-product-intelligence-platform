export const PROMPT_STATUS_LIST = ['DRAFT', 'REVIEW', 'APPROVED', 'DEPRECATED'] as const;

export const PROMPT_CACHE_TTL_MS = 600000; // 10 minutes (10 * 60 * 1000)

export const DEFAULT_PROMPT_VERSION = 1;
