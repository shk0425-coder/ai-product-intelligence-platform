import { FeedbackRule } from './rules.js';

export const ImpactCalculator = {
  calculate(matchedRules: FeedbackRule[]): number {
    if (matchedRules.length === 0) {
      return 0.0;
    }
    const sumSeverity = matchedRules.reduce((acc, rule) => acc + rule.severity, 0);
    // Score linear mapping: each severity point contributes 10.0 points, capped at 100.0
    return Math.min(100.0, Math.max(0.0, sumSeverity * 10.0));
  },
};
export default ImpactCalculator;
