import { FastifyRequest, FastifyReply } from 'fastify';
import { AIProviderService } from './service.js';
import { PatchAIProviderConfigDto, TestAIProviderDto } from './dto.js';

export class AIProviderController {
  constructor(private readonly service: AIProviderService) {}

  async getConfigs(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getConfigs();
    return reply.status(200).send({ data: result });
  }

  async patchConfig(
    req: FastifyRequest<{ Params: { provider: string; model: string }; Body: PatchAIProviderConfigDto }>,
    reply: FastifyReply
  ) {
    const { provider, model } = req.params;
    const result = await this.service.patchConfig(provider, model, req.body);
    return reply.status(200).send({ data: result });
  }

  async getHealth(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getHealthStatus();
    return reply.status(200).send({ data: result });
  }

  async runHealthCheck(req: FastifyRequest, reply: FastifyReply) {
    await this.service.runHealthCheck();
    return reply.status(200).send({ message: 'Batch Health Check triggered successfully' });
  }

  async getMetrics(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getMetricsSummary();
    return reply.status(200).send({ data: result });
  }

  async getModels(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getSupportedModels();
    return reply.status(200).send({ data: result });
  }

  async testCall(req: FastifyRequest<{ Body: TestAIProviderDto }>, reply: FastifyReply) {
    const result = await this.service.testCall(req.body);
    return reply.status(200).send({ data: result });
  }
}
export default AIProviderController;
