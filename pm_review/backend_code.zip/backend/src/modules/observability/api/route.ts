import { FastifyInstance } from 'fastify';
import { observabilityController } from './controller.js';

export async function monitoringRoutes(fastify: FastifyInstance) {
  fastify.get('/summary', (req, rep) => observabilityController.getSummary(req, rep));
  fastify.get('/health', (req, rep) => observabilityController.getHealth(req, rep));
  fastify.get('/metrics', (req, rep) => observabilityController.getMetrics(req, rep));
  fastify.get('/logs', (req, rep) => observabilityController.getLogs(req, rep));
  fastify.get('/traces', (req, rep) => observabilityController.getTraces(req, rep));
  fastify.get('/alerts', (req, rep) => observabilityController.getAlerts(req, rep));
  fastify.get('/dashboard', (req, rep) => observabilityController.getDashboard(req, rep));
  fastify.get('/diagnostics', (req, rep) => observabilityController.getDiagnostics(req, rep));
}
export default monitoringRoutes;
