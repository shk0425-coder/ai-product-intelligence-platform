import feedbackRoutes from './route.js';

export * from './types.js';
export * from './dto.js';
export * from './schema.js';
export * from './repository.js';
export * from './service.js';
export * from './calculator.js';
export * from './grading.js';
export * from './normalization.js';
export * from './weights.js';
export * from './hooks.js';

export default feedbackRoutes;
