import crypto from 'crypto';
import { SchedulerStateRepository } from '../persistence/scheduler-state-repository.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { Logger } from '../../observability/logging/logger.js';

export class LeaderElection {
  private static readonly nodeId = `node_${crypto.randomUUID().slice(0, 8)}`;
  private static isLeaderNode = false;
  private static electionInterval: NodeJS.Timeout | null = null;
  private static leaseDurationMs = 10000; // 10s lease timeout
  private static checkIntervalMs = 3000;  // Check every 3s

  static init(leaseDurationMs = 10000, checkIntervalMs = 3000): void {
    this.leaseDurationMs = leaseDurationMs;
    this.checkIntervalMs = checkIntervalMs;

    const enabled = process.env.LEADER_ELECTION_ENABLED !== 'false';
    if (!enabled) {
      // If leader election is disabled, this node is always the leader
      this.isLeaderNode = true;
      MetricsRegistry.gauge('leader_status', 1, { instance: this.nodeId });
      return;
    }

    this.runElectionCycle().catch(() => {});
    this.startElectionLoop();
  }

  static isLeader(): boolean {
    return this.isLeaderNode;
  }

  static getNodeId(): string {
    return this.nodeId;
  }

  private static startElectionLoop(): void {
    this.stopElectionLoop();
    
    this.electionInterval = setInterval(async () => {
      try {
        await this.runElectionCycle();
      } catch {
        // Enforce resilience: election cycle failure should not crash application
      }
    }, this.checkIntervalMs);

    if (this.electionInterval.unref) {
      this.electionInterval.unref();
    }
  }

  private static async runElectionCycle(): Promise<void> {
    const now = Date.now();
    const state = await SchedulerStateRepository.getState();

    // 1. Leader check
    if (state.leaderNodeId && state.leaderLeaseExpiresAt && state.leaderLeaseExpiresAt > now) {
      if (state.leaderNodeId === this.nodeId) {
        // We are the leader, renew lease
        const newExpiry = now + this.leaseDurationMs;
        await SchedulerStateRepository.saveState({ leaderLeaseExpiresAt: newExpiry });
        if (!this.isLeaderNode) {
          this.promoteToLeader();
        }
      } else {
        // Another active node holds the leadership
        if (this.isLeaderNode) {
          this.demoteFromLeader();
        }
      }
    } else {
      // 2. Leader expired or vacant, attempt election
      const newExpiry = now + this.leaseDurationMs;
      const previousLeader = state.leaderNodeId;

      await SchedulerStateRepository.saveState({
        leaderNodeId: this.nodeId,
        leaderLeaseExpiresAt: newExpiry,
      });

      if (previousLeader !== this.nodeId) {
        this.promoteToLeader();
      }
    }
  }

  private static promoteToLeader(): void {
    this.isLeaderNode = true;
    MetricsRegistry.gauge('leader_status', 1, { instance: this.nodeId });
    MetricsRegistry.counter('leader_changes_total', 1);

    Logger.info({
      message: `Node ${this.nodeId} promoted to Cluster Leader.`,
      module: 'SCHEDULER',
      action: 'LeaderPromotion',
    });

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'LeaderChanged',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { leaderNodeId: this.nodeId },
    }).catch(() => {});
  }

  private static demoteFromLeader(): void {
    this.isLeaderNode = false;
    MetricsRegistry.gauge('leader_status', 0, { instance: this.nodeId });

    Logger.info({
      message: `Node ${this.nodeId} demoted from Cluster Leader.`,
      module: 'SCHEDULER',
      action: 'LeaderDemotion',
    });
  }

  static stopElectionLoop(): void {
    if (this.electionInterval) {
      clearInterval(this.electionInterval);
      this.electionInterval = null;
    }
  }

  static async forceRelease(): Promise<void> {
    const state = await SchedulerStateRepository.getState();
    if (state.leaderNodeId === this.nodeId) {
      await SchedulerStateRepository.saveState({
        leaderNodeId: undefined,
        leaderLeaseExpiresAt: undefined,
      });
      this.demoteFromLeader();
    }
  }
}
export default LeaderElection;
