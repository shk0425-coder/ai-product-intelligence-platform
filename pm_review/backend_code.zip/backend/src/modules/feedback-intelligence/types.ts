import { IBaseRepository } from '@/repositories/interfaces/base.repository.js';
import { FeedbackIntelligenceDto } from './dto.js';

export interface FeedbackIntelligenceEntity {
  id: string; // UUID Primary Key
  feedback_score_id: string; // UUID FK
  analysis_version: number; // INTEGER
  rule_version: string; // VARCHAR(20)
  strength_summary: string; // TEXT
  weakness_summary: string; // TEXT
  bottleneck_summary: string; // TEXT
  improvement_summary: string; // TEXT
  root_causes: string[]; // JSONB (casted array of strings)
  recommendations: Array<{
    priority: number;
    category: string;
    recommendation: string;
    expectedImpact: number;
  }>; // JSONB (casted array of recommendation objects)
  detected_rules: Array<{
    ruleId: string;
    category: string;
    severity: number;
    message: string;
  }>; // JSONB (casted array of detected rule objects)
  impact_score: number; // NUMERIC(6,3)
  confidence_score: number; // NUMERIC(6,3)
  execution_time_ms: number; // INTEGER
  analyzed_at: string; // TIMESTAMPTZ
  created_at: string; // TIMESTAMPTZ
}

export interface IFeedbackIntelligenceRepository extends IBaseRepository<FeedbackIntelligenceEntity> {
  findByFeedback(
    feedbackScoreId: string,
    ruleVersion?: string,
  ): Promise<FeedbackIntelligenceEntity | null>;
  findLatest(productId: string): Promise<FeedbackIntelligenceEntity | null>;
  findHistory(productId: string): Promise<FeedbackIntelligenceEntity[]>;
}

export interface FeedbackIntelEventPayload {
  intelligence: FeedbackIntelligenceDto;
  actorId: string;
  timestamp: string;
}

export interface IFeedbackIntelligenceHooks {
  onFeedbackIntelligenceCreated(payload: FeedbackIntelEventPayload): Promise<void>;
  onFeedbackIntelligenceUpdated(payload: FeedbackIntelEventPayload): Promise<void>;
  onFeedbackIntelligenceReanalyzed(payload: FeedbackIntelEventPayload): Promise<void>;
}
