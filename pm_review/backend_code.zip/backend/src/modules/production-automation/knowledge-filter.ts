export interface FilterCriteria {
  minKnowledgeScore?: number;
  minConfidenceScore?: number;
}

export const KnowledgeFilter = {
  filter(
    knowledgeList: Record<string, unknown>[],
    criteria: FilterCriteria = { minKnowledgeScore: 70.0, minConfidenceScore: 70.0 },
  ): Record<string, unknown>[] {
    const minScore = criteria.minKnowledgeScore ?? 70.0;
    const minConf = criteria.minConfidenceScore ?? 70.0;

    // 1. Core Filtering
    const filtered = knowledgeList.filter((k) => {
      const score = Number(k.knowledge_score || 0);
      const conf = Number(k.confidence_score || 0);
      return score >= minScore && conf >= minConf;
    });

    // 2. Sort: Latest Version First, High Score Second
    const sorted = [...filtered].sort((a, b) => {
      const vA = Number(a.knowledge_version || 0);
      const vB = Number(b.knowledge_version || 0);
      if (vA !== vB) {
        return vB - vA; // descending version
      }
      const sA = Number(a.knowledge_score || 0);
      const sB = Number(b.knowledge_score || 0);
      return sB - sA; // descending score
    });

    // 3. Deduplicate based on feature_summary and success_pattern uniqueness
    const seen = new Set<string>();
    const deduplicated: Record<string, unknown>[] = [];

    for (const item of sorted) {
      const key = `${String(item.feature_summary || '')}:${String(item.success_pattern || '')}`;
      if (!seen.has(key)) {
        seen.add(key);
        deduplicated.push(item);
      }
    }

    return deduplicated;
  },
};
export default KnowledgeFilter;
