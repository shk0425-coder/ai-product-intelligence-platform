export class StrategyController {}
