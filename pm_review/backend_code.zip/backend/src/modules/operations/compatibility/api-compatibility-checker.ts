import { MetricsRegistry } from '../../observability/metrics/registry.js';

export interface RouteSpec {
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  requiredParams: string[];
}

export class ApiCompatibilityChecker {
  static verifyRoutes(productionSpec: RouteSpec[], stagingSpec: RouteSpec[]): boolean {
    // Detect breaking change: parameter removed or route path/method signature modified
    const isBroken = productionSpec.some(p => {
      const matched = stagingSpec.find(s => s.path === p.path && s.method === p.method);
      if (!matched) return true; // Route was removed entirely

      // Check if any previously required parameter is missing in staging
      return p.requiredParams.some(param => !matched.requiredParams.includes(param));
    });

    if (isBroken) {
      MetricsRegistry.counter('api_compatibility_failed_total', 1);
      return false; // Breaking Change detected
    }

    return true; // Compatible
  }
}
export default ApiCompatibilityChecker;
