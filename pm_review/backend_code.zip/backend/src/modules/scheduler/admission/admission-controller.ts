import { JobDefinition } from '../persistence/job-repository.js';
import { ExecutionRepository } from '../persistence/execution-repository.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export interface AdmissionResult {
  decision: 'ADMIT' | 'DELAY' | 'REJECT';
  reason?: string;
}

export class AdmissionController {
  private static maxConcurrentJobs = 10;
  private static maxQueueSize = 100;
  private static workspaceLimit = 5;

  static setLimits(maxConcurrent: number, maxQueue: number): void {
    this.maxConcurrentJobs = maxConcurrent;
    this.maxQueueSize = maxQueue;
  }

  static async inspect(job: JobDefinition, queueDepth: number): Promise<AdmissionResult> {
    // 1. Queue capacity check
    if (queueDepth >= this.maxQueueSize) {
      MetricsRegistry.counter('scheduler_admission_rejected_total', 1, { queue: job.name });
      eventBus.publish({
        eventId: crypto.randomUUID(),
        eventType: 'AdmissionRejected',
        timestamp: new Date().toISOString(),
        workspaceId: (job.metadata.workspaceId as string) || 'default-workspace',
        data: { jobId: job.id, reason: 'Queue size limit reached (Backpressure)' },
      }).catch(() => {});

      return { decision: 'REJECT', reason: 'Queue capacity reached (Backpressure)' };
    }

    // 2. Concurrent Execution Limit
    const history = await ExecutionRepository.getHistory();
    const runningJobs = history.filter(h => h.state === 'Running');
    if (runningJobs.length >= this.maxConcurrentJobs) {
      MetricsRegistry.counter('scheduler_admission_delayed_total', 1, { queue: job.name });
      eventBus.publish({
        eventId: crypto.randomUUID(),
        eventType: 'AdmissionDelayed',
        timestamp: new Date().toISOString(),
        workspaceId: (job.metadata.workspaceId as string) || 'default-workspace',
        data: { jobId: job.id, reason: 'Max concurrent execution limit reached' },
      }).catch(() => {});

      return { decision: 'DELAY', reason: 'Max concurrent limit reached' };
    }

    // 3. Workspace execution limits
    const wsId = job.metadata.workspaceId as string || 'default';
    const runningInWorkspace = runningJobs.filter(h => h.idempotencyKey?.startsWith(`ws:${wsId}:`));
    if (runningInWorkspace.length >= this.workspaceLimit) {
      MetricsRegistry.counter('scheduler_admission_delayed_total', 1, { queue: job.name });
      return { decision: 'DELAY', reason: `Workspace ${wsId} quota exceeded` };
    }

    return { decision: 'ADMIT' };
  }
}
export default AdmissionController;
