import { z } from 'zod';

export const patchAIProviderConfigSchema = z.object({
  priority: z.number().int().min(1).max(100).optional(),
  enabled: z.boolean().optional(),
  rpm: z.number().int().min(1).optional(),
  tpm: z.number().int().min(1).optional(),
  retry_count: z.number().int().min(0).max(10).optional(),
  timeout_seconds: z.number().int().min(1).max(300).optional(),
  metadata: z.record(z.any()).optional(),
});

export const testAIProviderSchema = z.object({
  provider: z.string().min(1),
  model: z.string().min(1),
  prompt: z.string().min(1),
  workspaceId: z.string().uuid(),
  capabilities: z.array(z.string()).optional(),
  systemInstruction: z.string().optional(),
  temperature: z.number().min(0.0).max(2.0).optional(),
  responseSchema: z.record(z.any()).optional(),
});
