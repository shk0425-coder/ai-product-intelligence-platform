import { pino } from 'pino';
import { FeedbackIntelEventPayload, IFeedbackIntelligenceHooks } from './types.js';

const logger = pino();

export const FeedbackIntelligenceHooks: IFeedbackIntelligenceHooks = {
  async onFeedbackIntelligenceCreated(payload: FeedbackIntelEventPayload): Promise<void> {
    logger.info(
      {
        intelligenceId: payload.intelligence.intelligenceId,
        feedbackScoreId: payload.intelligence.feedbackScoreId,
        actorId: payload.actorId,
        impactScore: payload.intelligence.impactScore,
        confidenceScore: payload.intelligence.confidenceScore,
      },
      'Domain Hook [FeedbackIntelligenceCreated] triggered',
    );
    // Future integration point for Sprint 5-4 Closed-loop Learning Engine
  },

  async onFeedbackIntelligenceUpdated(payload: FeedbackIntelEventPayload): Promise<void> {
    logger.info(
      {
        intelligenceId: payload.intelligence.intelligenceId,
        feedbackScoreId: payload.intelligence.feedbackScoreId,
        actorId: payload.actorId,
      },
      'Domain Hook [FeedbackIntelligenceUpdated] triggered',
    );
    // Future integration point for Sprint 5-4 Closed-loop Learning Engine
  },

  async onFeedbackIntelligenceReanalyzed(payload: FeedbackIntelEventPayload): Promise<void> {
    logger.info(
      {
        intelligenceId: payload.intelligence.intelligenceId,
        feedbackScoreId: payload.intelligence.feedbackScoreId,
        actorId: payload.actorId,
        analysisVersion: payload.intelligence.analysisVersion,
      },
      'Domain Hook [FeedbackIntelligenceReanalyzed] triggered',
    );
    // Future integration point for Sprint 5-4 Closed-loop Learning Engine
  },
};
