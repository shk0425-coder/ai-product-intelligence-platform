import { PromptValidationError } from '@/common/errors/index.js';

export interface ValidationTarget {
  workspace?: string;
  category?: string;
  learningSummary?: string;
  patterns?: string;
  featureVector?: string;
  improvementStrategy?: string;
  bestPractice?: string;
  userRequest?: string;
}

export const PromptValidator = {
  validate(target: ValidationTarget): void {
    const requiredKeys: Array<keyof ValidationTarget> = [
      'workspace',
      'category',
      'learningSummary',
      'patterns',
      'featureVector',
      'improvementStrategy',
      'bestPractice',
      'userRequest',
    ];

    const missing: string[] = [];

    for (const key of requiredKeys) {
      if (target[key] === undefined || target[key] === null || String(target[key]).trim() === '') {
        missing.push(key);
      }
    }

    if (missing.length > 0) {
      throw new PromptValidationError(
        `Prompt validation failed. Missing required sections: [${missing.join(', ')}]`,
      );
    }
  },
};
export default PromptValidator;
