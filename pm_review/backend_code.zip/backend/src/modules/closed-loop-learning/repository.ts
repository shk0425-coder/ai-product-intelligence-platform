import { SupabaseClient } from '@supabase/supabase-js';
import {
  LearningKnowledgeEntity,
  LearningVectorEntity,
  LearningPatternEntity,
  LearningAuditEntity,
  ILearningRepository,
} from './types.js';

export class LearningRepository implements ILearningRepository {
  constructor(private readonly supabase: SupabaseClient) {}

  async createKnowledge(
    payload: Partial<LearningKnowledgeEntity>,
  ): Promise<LearningKnowledgeEntity> {
    const { data, error } = await this.supabase
      .from('learning_knowledge')
      .insert(payload)
      .select('*')
      .single();

    if (error) throw error;
    return data as LearningKnowledgeEntity;
  }

  async createVector(payload: Partial<LearningVectorEntity>): Promise<LearningVectorEntity> {
    const { data, error } = await this.supabase
      .from('learning_vectors')
      .insert(payload)
      .select('*')
      .single();

    if (error) throw error;
    return data as LearningVectorEntity;
  }

  async createPattern(payload: Partial<LearningPatternEntity>): Promise<LearningPatternEntity> {
    const { data, error } = await this.supabase
      .from('learning_patterns')
      .insert(payload)
      .select('*')
      .single();

    if (error) throw error;
    return data as LearningPatternEntity;
  }

  async createAudit(payload: Partial<LearningAuditEntity>): Promise<LearningAuditEntity> {
    const { data, error } = await this.supabase
      .from('learning_audit_logs')
      .insert(payload)
      .select('*')
      .single();

    if (error) throw error;
    return data as LearningAuditEntity;
  }

  async findKnowledge(knowledgeId: string): Promise<LearningKnowledgeEntity | null> {
    const { data, error } = await this.supabase
      .from('learning_knowledge')
      .select('*')
      .eq('id', knowledgeId)
      .maybeSingle();

    if (error || !data) return null;
    return data as LearningKnowledgeEntity;
  }

  async findLatest(productId: string): Promise<LearningKnowledgeEntity | null> {
    const { data, error } = await this.supabase
      .from('learning_knowledge')
      .select(
        `
        *,
        feedback_intelligence!inner(
          feedback_scores!inner(
            product_performance!inner(product_id)
          )
        )
      `,
      )
      .eq('feedback_intelligence.feedback_scores.product_performance.product_id', productId)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error || !data) return null;

    const { feedback_intelligence: _, ...entity } = data as unknown as {
      feedback_intelligence: unknown;
    };
    return entity as LearningKnowledgeEntity;
  }

  async findHistory(productId: string): Promise<LearningKnowledgeEntity[]> {
    const { data, error } = await this.supabase
      .from('learning_knowledge')
      .select(
        `
        *,
        feedback_intelligence!inner(
          feedback_scores!inner(
            product_performance!inner(product_id)
          )
        )
      `,
      )
      .eq('feedback_intelligence.feedback_scores.product_performance.product_id', productId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((item: unknown) => {
      const { feedback_intelligence: _, ...entity } = item as { feedback_intelligence: unknown };
      return entity as LearningKnowledgeEntity;
    });
  }

  async exists(intelligenceId: string, version?: number): Promise<boolean> {
    let query = this.supabase
      .from('learning_knowledge')
      .select('id', { count: 'exact', head: true })
      .eq('intelligence_id', intelligenceId);

    if (version !== undefined) {
      query = query.eq('knowledge_version', version);
    }

    const { count, error } = await query;
    if (error || count === null) return false;
    return count > 0;
  }

  // Helper method to fetch vector by knowledge ID
  async findVectorByKnowledge(knowledgeId: string): Promise<LearningVectorEntity | null> {
    const { data, error } = await this.supabase
      .from('learning_vectors')
      .select('*')
      .eq('knowledge_id', knowledgeId)
      .limit(1)
      .maybeSingle();

    if (error || !data) return null;
    return data as LearningVectorEntity;
  }

  // Ownership verification helpers
  async verifyProductOwner(productId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('products')
      .select(
        `
        product_id,
        workspaces!inner(org_id)
      `,
      )
      .eq('product_id', productId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const product = data as unknown as { workspaces: { org_id: string } };
    return product.workspaces?.org_id === userId;
  }

  async verifyIntelligenceOwner(intelligenceId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('feedback_intelligence')
      .select(
        `
        id,
        feedback_scores!inner(
          product_performance!inner(
            workspaces!inner(org_id)
          )
        )
      `,
      )
      .eq('id', intelligenceId)
      .maybeSingle();
    if (error || !data) return false;
    const intel = data as unknown as {
      feedback_scores: { product_performance: { workspaces: { org_id: string } } };
    };
    return intel.feedback_scores?.product_performance?.workspaces?.org_id === userId;
  }

  async verifyKnowledgeOwner(knowledgeId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('learning_knowledge')
      .select(
        `
        id,
        feedback_intelligence!inner(
          feedback_scores!inner(
            product_performance!inner(
              workspaces!inner(org_id)
            )
          )
        )
      `,
      )
      .eq('id', knowledgeId)
      .maybeSingle();
    if (error || !data) return false;
    const knowledge = data as unknown as {
      feedback_intelligence: {
        feedback_scores: { product_performance: { workspaces: { org_id: string } } };
      };
    };
    return (
      knowledge.feedback_intelligence?.feedback_scores?.product_performance?.workspaces?.org_id ===
      userId
    );
  }
}
export default LearningRepository;
