export interface RedisConfig {
  host: string;
  port: number;
  db: number;
  namespacePrefix: string;
}

export class ConfigurationProvider {
  private static readonly config = {
    redis: {
      host: process.env.REDIS_HOST || '127.0.0.1',
      port: Number(process.env.REDIS_PORT) || 6379,
      db: Number(process.env.REDIS_DB) || 0,
      namespacePrefix: process.env.REDIS_PREFIX || 'jtbd',
    },
    cache: {
      defaultTtlMs: 600000, // 10 minutes
    },
    lock: {
      defaultTtlMs: 30000, // 30 seconds
    },
    retry: {
      maxAttempts: 3,
    },
  };

  static getRedisConfig(): RedisConfig {
    return this.config.redis;
  }

  static getCacheConfig() {
    return this.config.cache;
  }

  static getLockConfig() {
    return this.config.lock;
  }

  static getRetryConfig() {
    return this.config.retry;
  }
}
