import { describe, it, expect, vi, beforeEach, beforeAll, afterEach } from 'vitest';
import { createApp } from '../src/app.js';
import { RecoveryLockManager } from '../src/modules/operations/lock/recovery-lock-manager.js';
import { RecoveryIdempotency } from '../src/modules/operations/idempotency/recovery-idempotency.js';
import { ConfigurationManager } from '../src/modules/operations/configuration/configuration-manager.js';
import { SecretManager } from '../src/modules/operations/secret/secret-manager.js';
import { NotificationManager } from '../src/modules/operations/notification/notification-manager.js';
import { HealthValidator } from '../src/modules/operations/validator/health-validator.js';
import { LicenseManager } from '../src/modules/operations/subscription/license-manager.js';
import { UsageMeter } from '../src/modules/operations/metering/usage-meter.js';
import { QuotaManager } from '../src/modules/operations/quota/quota-manager.js';
import { MaintenanceManager } from '../src/modules/operations/maintenance/maintenance-manager.js';
import { DeploymentCoordinator } from '../src/modules/operations/deployment/deployment-coordinator.js';
import { UpgradeManager } from '../src/modules/operations/upgrade/upgrade-manager.js';
import { IsolationAuditor } from '../src/modules/operations/workspace/isolation-auditor.js';
import { ApiCompatibilityChecker, RouteSpec } from '../src/modules/operations/compatibility/api-compatibility-checker.js';
import { AuditCenter } from '../src/modules/operations/audit/audit-center.js';
import { AuditTrail } from '../src/modules/resilience/audit/audit-trail.js';
import { CapabilityRegistry } from '../src/modules/operations/capability/capability-registry.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeSystemResolver = () => Promise.resolve({ data: null, error: null });
  (globalThis as any).__mockSupabaseForSystem = {
    from: vi.fn().mockImplementation(() => ({
      select: vi.fn().mockImplementation(() => Promise.resolve({ data: [], error: null })),
    })),
  };
});

describe('Enterprise Operations Platform (Integration & Unit Tests)', () => {
  let app: any;
  const testToken = jwt.sign({ orgId: 'test-org-456' }, 'test-jwt-secret');

  beforeAll(async () => {
    app = await createApp();
  });

  beforeEach(async () => {
    RecoveryLockManager.clear();
    RecoveryIdempotency.clear();
    ConfigurationManager.clear();
    SecretManager.clear();
    NotificationManager.clear();
    LicenseManager.clear();
    UsageMeter.clear();
    QuotaManager.clear();
    MaintenanceManager.clear();
    UpgradeManager.clear();
    AuditTrail.clear();
    CapabilityRegistry.clear();
  });

  // 1. Distributed Recovery Lock & Renewal
  describe('Distributed Lock Manager', () => {
    it('should acquire, renew, and release recovery locks correctly', async () => {
      const acquired = await RecoveryLockManager.acquireLock('inc-lock-1', 'node-1', 1000);
      expect(acquired).toBe(true);

      const blocked = await RecoveryLockManager.acquireLock('inc-lock-1', 'node-2', 1000);
      expect(blocked).toBe(false);

      const renewed = await RecoveryLockManager.renewLease('inc-lock-1', 'node-1', 2000);
      expect(renewed).toBe(true);

      const released = await RecoveryLockManager.releaseLock('inc-lock-1', 'node-1');
      expect(released).toBe(true);
    });
  });

  // 2. Recovery Idempotency
  describe('Recovery Idempotency Exactly Once Check', () => {
    it('should identify duplicate recovery executions', () => {
      const execId = 'rec-exec-789';
      expect(RecoveryIdempotency.isDuplicate(execId)).toBe(false);

      RecoveryIdempotency.recordExecution(execId);
      expect(RecoveryIdempotency.isDuplicate(execId)).toBe(true);
    });
  });

  // 3. Dynamic Configuration Reload
  describe('Dynamic Configuration & Secrets Management', () => {
    it('should dynamically update config and rotate secrets on the fly', () => {
      ConfigurationManager.updateConfig({ redisTimeoutMs: 5000 });
      expect(ConfigurationManager.getConfig().redisTimeoutMs).toBe(5000);

      SecretManager.rotateSecret('AI_PROVIDER_KEY', 'sk-new-gemini-key');
      expect(SecretManager.getSecret('AI_PROVIDER_KEY')).toBe('sk-new-gemini-key');
    });
  });

  // 4. Notification Dispatcher
  describe('Notification Dispatcher Center', () => {
    it('should dispatch operations notifications to multiple channels', async () => {
      const ok = await NotificationManager.dispatch({
        title: 'Incident Resolved',
        body: 'Job auto resolved successfully',
        channels: ['Slack', 'Email'],
      });
      expect(ok).toBe(true);
      expect(NotificationManager.getHistory().length).toBe(1);
    });
  });

  // 5. Health Validation
  describe('Health Validator', () => {
    it('should execute liveness and readiness validations', async () => {
      const healthy = await HealthValidator.validateHealth();
      expect(healthy).toBe(true);
    });
  });

  // 6. SaaS License Gates & Quota Metering
  describe('Billing Quota and Subscription controls', () => {
    it('should enforce quotas and block premium features on license tiers', () => {
      // 1. Starter blocks premium DR features
      LicenseManager.setTier('Starter');
      expect(LicenseManager.isFeatureAllowed('ai_advanced_analysis')).toBe(false);
      expect(LicenseManager.isFeatureAllowed('advanced_disaster_recovery')).toBe(false);

      // 2. Upgrade to Pro
      LicenseManager.setTier('Pro');
      expect(LicenseManager.isFeatureAllowed('ai_advanced_analysis')).toBe(true);
      expect(LicenseManager.isFeatureAllowed('advanced_disaster_recovery')).toBe(false);

      // 3. Usage & Quota enforcement
      UsageMeter.recordUsage(60);
      QuotaManager.setLimit(100);

      expect(QuotaManager.checkQuota(30)).toBe(true); // 60 + 30 <= 100
      expect(QuotaManager.checkQuota(50)).toBe(false); // 60 + 50 > 100 (quota breach)
    });
  });

  // 7. Maintenance Read Only Mode
  describe('Maintenance and Read Only Mode', () => {
    it('should restrict operations writes in read-only maintenance mode', () => {
      expect(MaintenanceManager.isReadOnly()).toBe(false);

      MaintenanceManager.startMaintenance(true); // Start ReadOnly maintenance
      expect(MaintenanceManager.isReadOnly()).toBe(true);

      MaintenanceManager.stopMaintenance();
      expect(MaintenanceManager.isReadOnly()).toBe(false);
    });
  });

  // 8. Pre-Deployment Validation & Rollout
  describe('Deployment Coordinator pre-verifications', () => {
    it('should fail deployment if pre-validation token is invalid', async () => {
      const fail = await DeploymentCoordinator.validateAndDeploy({
        version: 'v2.0.0',
        strategy: 'BlueGreen',
        validationToken: 'invalid-signature-error',
      });
      expect(fail).toBe(false);

      const pass = await DeploymentCoordinator.validateAndDeploy({
        version: 'v2.0.0',
        strategy: 'BlueGreen',
        validationToken: 'valid-signature-passed',
      });
      expect(pass).toBe(true);
    });
  });

  // 9. Multi-Tenant Isolation Audit
  describe('Multi-tenant Workspace Isolation Auditor', () => {
    it('should detect and audit cross-workspace leaks', () => {
      const payloads = [
        { workspaceId: 'ws-123', payload: 'valid data 1' },
        { workspaceId: 'ws-123', payload: 'valid data 2' },
      ];
      expect(IsolationAuditor.auditCrossAccess('ws-123', payloads)).toBe(true);

      const compromisedPayloads = [
        { workspaceId: 'ws-123', payload: 'valid data 1' },
        { workspaceId: 'ws-999', payload: 'leaked data' }, // Cross access
      ];
      expect(IsolationAuditor.auditCrossAccess('ws-123', compromisedPayloads)).toBe(false);
    });
  });

  // 10. API Compatibility Checker
  describe('API Compatibility Checker', () => {
    it('should detect breaking changes in parameter specification', () => {
      const prodSpec: RouteSpec[] = [
        { path: '/api/v1/reviews', method: 'GET', requiredParams: ['keyword'] },
      ];

      const compatibleSpec: RouteSpec[] = [
        { path: '/api/v1/reviews', method: 'GET', requiredParams: ['keyword', 'provider'] },
      ];

      const brokenSpec: RouteSpec[] = [
        { path: '/api/v1/reviews', method: 'GET', requiredParams: [] }, // keyword parameter removed!
      ];

      expect(ApiCompatibilityChecker.verifyRoutes(prodSpec, compatibleSpec)).toBe(true);
      expect(ApiCompatibilityChecker.verifyRoutes(prodSpec, brokenSpec)).toBe(false);
    });
  });

  // 11. Central Audit Center Queries & Exporters
  describe('Audit Center and Retention Policies', () => {
    it('should query timeline history, export CSV formats and prune expired logs', async () => {
      await AuditTrail.record('User Login');
      await AuditTrail.record('Runbook Started');
      await AuditTrail.record('Recovery Completed');

      const logs = AuditCenter.searchLogs({ action: 'Runbook' });
      expect(logs.length).toBe(1);
      expect(logs[0].action).toBe('Runbook Started');

      const csv = AuditCenter.exportLogs({}, 'CSV');
      expect(csv).toContain('logId,action,timestamp,hash');
      expect(csv).toContain('User Login');

      // Prune retention
      const pruned = AuditCenter.enforceRetention(30);
      expect(pruned).toBe(0); // None deleted because logs were recorded just now
    });
  });

  // 12. Capability Registry discovery checks
  describe('System Capability Registry discovery checks', () => {
    it('should list capability availability mapped with feature-flag and license tier', () => {
      CapabilityRegistry.register({
        name: 'AI_ANALYSIS',
        version: '1.2.0',
        enabled: true,
        requiredLicense: 'Pro',
        dependencies: [],
      });

      LicenseManager.setTier('Starter');
      // AI_ANALYSIS is disabled for Starter license
      let cap = CapabilityRegistry.getCapability('AI_ANALYSIS');
      expect(cap?.enabled).toBe(false);

      LicenseManager.setTier('Pro');
      cap = CapabilityRegistry.getCapability('AI_ANALYSIS');
      expect(cap?.enabled).toBe(true);

      // Disable Feature Flag via ConfigManager
      ConfigurationManager.updateConfig({
        featureFlags: { AI_ANALYSIS: false },
      });

      cap = CapabilityRegistry.getCapability('AI_ANALYSIS');
      expect(cap?.enabled).toBe(false); // Flag disables it
    });
  });

  // 13. REST APIs Integration checks
  describe('Operations and Capabilities REST integration', () => {
    it('should fetch capabilities lists via inject requests', async () => {
      CapabilityRegistry.register({
        name: 'SCHEDULER',
        version: '2.0.0',
        enabled: true,
        requiredLicense: 'Starter',
        dependencies: [],
      });

      const res = await app.inject({
        method: 'GET',
        url: '/api/v1/system/capabilities',
        headers: { authorization: `Bearer ${testToken}` },
      });
      expect(res.statusCode).toBe(200);
      const body = JSON.parse(res.payload);
      expect(body.data.some((c: any) => c.name === 'SCHEDULER')).toBe(true);
    });
  });
});
