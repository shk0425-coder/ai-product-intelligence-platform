import { ValidationError } from '../../common/errors/index.js';

export class ToolPermissionChecker {
  static verify(
    requiredPermissions: string[],
    grantedPermissions: string[]
  ): void {
    if (requiredPermissions.length === 0) return;

    for (const req of requiredPermissions) {
      if (!grantedPermissions.includes(req)) {
        throw new ValidationError(`Permission denied: missing required privilege "${req}"`);
      }
    }
  }
}
export default ToolPermissionChecker;
