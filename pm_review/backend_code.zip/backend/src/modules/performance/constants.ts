/**
 * Performance Domain Constants
 */

export const PERFORMANCE_MONITORING = {
  SLOW_QUERY_THRESHOLD_MS: 100, // Warn if query takes > 100ms
  CRITICAL_QUERY_THRESHOLD_MS: 200, // Critical if query takes > 200ms
  API_RESPONSE_WARN_MS: 500, // Warn if API takes > 500ms
  API_RESPONSE_CRITICAL_MS: 1500, // Critical if API takes > 1500ms
  VALIDATION_ERROR_RATE_LIMIT: 0.05, // 5%
  TRANSACTION_FAILURE_RATE_LIMIT: 0.01, // 1%
};

export const MARKETPLACE_CODES = {
  NAVER: 'NAVER',
  COUPANG: 'COUPANG',
};
