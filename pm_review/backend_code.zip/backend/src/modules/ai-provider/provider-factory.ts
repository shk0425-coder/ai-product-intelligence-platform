import { AIProvider } from './types.js';
import { ProviderRegistry } from './provider-registry.js';
import { ProviderNotFoundError } from '../../common/errors/index.js';

export class ProviderFactory {
  static create(providerId: string, modelId: string): AIProvider {
    const provider = ProviderRegistry.getProvider(providerId, modelId);
    if (!provider) {
      throw new ProviderNotFoundError(`AI Provider mapping not found for ${providerId}:${modelId}`);
    }
    return provider;
  }
}
