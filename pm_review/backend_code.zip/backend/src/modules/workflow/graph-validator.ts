import { WorkflowGraph } from './types.js';
import { ValidationError } from '../../common/errors/index.js';

export class WorkflowGraphValidator {
  static validate(graph: WorkflowGraph): void {
    const nodes = graph.nodes || [];
    const edges = graph.edges || [];

    if (nodes.length === 0) {
      throw new ValidationError('Workflow must contain at least one node');
    }

    // 1. Check for unique node IDs
    const idSet = new Set<string>();
    for (const node of nodes) {
      if (idSet.has(node.id)) {
        throw new ValidationError(`Duplicate node ID found: ${node.id}`);
      }
      idSet.add(node.id);
    }

    // 2. Locate Start and End nodes
    const starts = nodes.filter((n) => n.type === 'Start');
    const ends = nodes.filter((n) => n.type === 'End');

    if (starts.length !== 1) {
      throw new ValidationError(`Workflow must have exactly one Start node (found ${starts.length})`);
    }
    if (ends.length !== 1) {
      throw new ValidationError(`Workflow must have exactly one End node (found ${ends.length})`);
    }

    const startNode = starts[0];
    const endNode = ends[0];

    // 3. Build Adjacency List for Graph traversal
    const adj: Record<string, string[]> = {};
    const incoming: Record<string, string[]> = {};

    for (const node of nodes) {
      adj[node.id] = [];
      incoming[node.id] = [];
    }

    for (const edge of edges) {
      if (!idSet.has(edge.from)) {
        throw new ValidationError(`Edge refers to missing source node: ${edge.from}`);
      }
      if (!idSet.has(edge.to)) {
        throw new ValidationError(`Edge refers to missing target node: ${edge.to}`);
      }
      adj[edge.from].push(edge.to);
      incoming[edge.to].push(edge.from);
    }

    // 4. Cycle Detection using DFS (Recursion Stack)
    const visited = new Set<string>();
    const recStack = new Set<string>();

    const hasCycle = (nodeId: string): boolean => {
      visited.add(nodeId);
      recStack.add(nodeId);

      for (const neighbor of adj[nodeId]) {
        if (!visited.has(neighbor)) {
          if (hasCycle(neighbor)) return true;
        } else if (recStack.has(neighbor)) {
          return true;
        }
      }

      recStack.delete(nodeId);
      return false;
    };

    // Begin cycle detection from Start node
    if (hasCycle(startNode.id)) {
      throw new ValidationError('Workflow contains a directed cycle (not a DAG)');
    }

    // Also run cycle detection on any unvisited node in case of disjoint cycles
    for (const node of nodes) {
      if (!visited.has(node.id)) {
        if (hasCycle(node.id)) {
          throw new ValidationError('Workflow contains a directed cycle (not a DAG)');
        }
      }
    }

    // 5. Orphan/Unreachable Node Detection
    // Run DFS from Start node to find all reachable nodes
    const reachableFromStart = new Set<string>();
    const dfsReach = (nodeId: string) => {
      reachableFromStart.add(nodeId);
      for (const neighbor of adj[nodeId]) {
        if (!reachableFromStart.has(neighbor)) {
          dfsReach(neighbor);
        }
      }
    };
    dfsReach(startNode.id);

    // Any node not reachable from Start is an orphan
    for (const node of nodes) {
      if (!reachableFromStart.has(node.id)) {
        throw new ValidationError(`Orphan node detected: ${node.id} (${node.name}) is unreachable from Start`);
      }
    }

    // Run DFS backwards from End node to verify all nodes can reach the End
    const canReachEnd = new Set<string>();
    const dfsBack = (nodeId: string) => {
      canReachEnd.add(nodeId);
      for (const prev of incoming[nodeId]) {
        if (!canReachEnd.has(prev)) {
          dfsBack(prev);
        }
      }
    };
    dfsBack(endNode.id);

    for (const node of nodes) {
      if (!canReachEnd.has(node.id)) {
        throw new ValidationError(`Dead-end node detected: ${node.id} (${node.name}) cannot reach End node`);
      }
    }
  }
}
export default WorkflowGraphValidator;
