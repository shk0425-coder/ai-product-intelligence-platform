import { WorkflowGraph } from './types.js';
import { AgentOrchestrator } from './orchestrator.js';
import { WorkflowGraphValidator } from './graph-validator.js';
import { PreviewWorkflowResponseDto } from './dto.js';

export class WorkflowPreviewer {
  static preview(graph: WorkflowGraph): PreviewWorkflowResponseDto {
    // 1. Verify DAG graph
    WorkflowGraphValidator.validate(graph);

    // 2. Fetch parallel groupings
    const orderGroups = AgentOrchestrator.getExecutionOrder(graph);
    const executionOrder = orderGroups.flat();

    // 3. Estimate cost and duration based on Node properties
    let estimatedCost = 0.0;
    let estimatedDuration = 0; // ms

    for (const group of orderGroups) {
      // Parallel execution duration is max of individual node timeouts or defaults
      let maxGroupDuration = 500; // default default 500ms mock
      for (const nodeId of group) {
        const node = graph.nodes.find((n) => n.id === nodeId);
        if (node) {
          if (node.type === 'Agent') {
            estimatedCost += 0.005; // Mock prompt cost
          }
          if (node.timeoutMs) {
            maxGroupDuration = Math.max(maxGroupDuration, node.timeoutMs);
          }
        }
      }
      estimatedDuration += maxGroupDuration;
    }

    return {
      executionGraph: graph,
      executionOrder,
      parallelGroups: orderGroups,
      estimatedCost,
      estimatedDuration,
    };
  }
}
export default WorkflowPreviewer;
