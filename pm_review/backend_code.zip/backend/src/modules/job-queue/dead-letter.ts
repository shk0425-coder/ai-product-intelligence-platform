import { JobQueueRepository } from './repository.js';
import { JobQueueEntity } from './types.js';
import { JobQueueHooks } from './hooks.js';

export const DeadLetterManager = {
  async routeToDeadLetter(
    repository: JobQueueRepository,
    job: JobQueueEntity,
    reason: string
  ): Promise<void> {
    // 1. Write to job_dead_letters
    await repository.createDeadLetter({
      job_id: job.id,
      payload: job.payload,
      reason,
      retry_count: job.retry_count,
    });

    // 2. Mark queue job status as FAILED with error message
    await repository.updateJob(job.id, {
      status: 'FAILED',
      error_message: `Moved to Dead Letter: ${reason}`,
      completed_at: new Date().toISOString(),
    });

    // 3. Trigger domain hook
    await JobQueueHooks.onDeadLetterCreated(job.id, reason);
  },

  async recoverJob(
    repository: JobQueueRepository,
    deadLetterId: string
  ): Promise<JobQueueEntity> {
    // Fetch dead letter
    const { data: deadLetter, error } = await (repository as unknown as { supabase: import('@supabase/supabase-js').SupabaseClient }).supabase
      .from('job_dead_letters')
      .select('*')
      .eq('id', deadLetterId)
      .maybeSingle();

    if (error || !deadLetter) {
      throw new Error('Dead letter record not found');
    }

    // Find original job details to copy its workspace_id and job_type
    const originalJob = await repository.findJob(deadLetter.job_id);
    const workspaceId = originalJob?.workspace_id || '00000000-0000-0000-0000-000000000000';
    const jobType = originalJob?.job_type || 'RECOVERED';

    // Re-create as PENDING fresh job
    const newJob = await repository.createJob({
      workspace_id: workspaceId,
      job_type: jobType,
      payload: deadLetter.payload,
      status: 'PENDING',
      retry_count: 0,
      max_retry: 3,
      scheduled_at: new Date().toISOString(),
    });

    // Delete dead letter once recovered
    await (repository as unknown as { supabase: import('@supabase/supabase-js').SupabaseClient }).supabase
      .from('job_dead_letters')
      .delete()
      .eq('id', deadLetterId);

    return newJob;
  },
};
