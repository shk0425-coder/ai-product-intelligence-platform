import { FastifyInstance } from 'fastify';
import { PromptController } from './controller.js';
import { PromptService } from './service.js';
import { PromptRepository } from './repository.js';
import { AIGateway } from '../ai-provider/gateway.js';
import { AIProviderRepository } from '../ai-provider/repository.js';
import { supabase } from '@/config/supabase.js';

export async function promptRoutes(fastify: FastifyInstance) {
  const repository = new PromptRepository(supabase);
  
  const providerRepo = new AIProviderRepository(supabase);
  const gateway = new AIGateway(providerRepo);

  const service = new PromptService(repository, gateway);
  const controller = new PromptController(service);

  // CRUD & Registry
  fastify.get('/', (req, rep) => controller.getConfigs(req, rep));
  fastify.post('/', (req, rep) =>
    controller.createTemplate(
      req as import('fastify').FastifyRequest<{ Body: import('./dto.js').CreatePromptTemplateDto }>,
      rep
    )
  );
  fastify.get('/:id', (req, rep) =>
    controller.getTemplateById(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );

  // Version management
  fastify.post('/:id/versions', (req, rep) =>
    controller.createVersion(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: import('./dto.js').CreatePromptVersionDto }>,
      rep
    )
  );
  fastify.get('/:id/versions', (req, rep) =>
    controller.getVersions(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );

  // Approval workflow
  fastify.post('/:id/approve', (req, rep) =>
    controller.approveTemplate(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );
  fastify.post('/:id/review', (req, rep) =>
    controller.reviewTemplate(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );
  fastify.post('/:id/deprecate', (req, rep) =>
    controller.deprecateTemplate(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );
  fastify.post('/:id/rollback', (req, rep) =>
    controller.rollbackTemplate(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: { versionId: string } }>,
      rep
    )
  );

  // Rendering & Execution
  fastify.post('/:id/render', (req, rep) =>
    controller.renderPrompt(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: import('./dto.js').RenderPromptDto }>,
      rep
    )
  );
  fastify.post('/preview', (req, rep) =>
    controller.previewPrompt(
      req as import('fastify').FastifyRequest<{ Body: import('./dto.js').PreviewPromptDto }>,
      rep
    )
  );
  fastify.post('/:id/execute', (req, rep) =>
    controller.executePrompt(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: import('./dto.js').RenderPromptDto }>,
      rep
    )
  );

  // Monitoring
  fastify.get('/history', (req, rep) => controller.getHistory(req, rep));
}
export default promptRoutes;
