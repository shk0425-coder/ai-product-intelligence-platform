import { FastifyInstance, FastifyPluginOptions, FastifyRequest } from 'fastify';
import { ProductionRepository } from './repository.js';
import { ClosedLoopProductionService } from './service.js';
import { ClosedLoopProductionController } from './controller.js';
import { authMiddleware } from '@/middleware/auth.middleware.js';
import {
  runProductionSchema,
  retryProductionSchema,
  automationIdParamSchema,
  automationWorkspaceParamSchema,
} from './schema.js';
import { ValidationError } from '@/common/errors/index.js';
import { z } from 'zod';

const validateBody =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.body);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.body = result.data;
  };

const validateParams =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.params);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.params = result.data;
  };

export default async function closedLoopProductionRoutes(
  fastify: FastifyInstance,
  _options: FastifyPluginOptions,
): Promise<void> {
  const repository = new ProductionRepository(fastify.supabase);
  const service = new ClosedLoopProductionService(repository);
  const controller = new ClosedLoopProductionController(service);

  // Apply authentication globally
  fastify.addHook('preHandler', authMiddleware);

  // POST /run
  fastify.post('/run', {
    preValidation: validateBody(runProductionSchema),
    handler: controller.run,
  });

  // POST /retry
  fastify.post('/retry', {
    preValidation: validateBody(retryProductionSchema),
    handler: controller.retry,
  });

  // GET /status/:automationId
  fastify.get('/status/:automationId', {
    preValidation: validateParams(automationIdParamSchema),
    handler: controller.findStatus,
  });

  // GET /history/:workspaceId
  fastify.get('/history/:workspaceId', {
    preValidation: validateParams(automationWorkspaceParamSchema),
    handler: controller.findHistory,
  });
}
