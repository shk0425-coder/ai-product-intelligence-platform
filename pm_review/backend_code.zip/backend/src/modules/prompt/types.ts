export type PromptStatus = 'DRAFT' | 'REVIEW' | 'APPROVED' | 'DEPRECATED';

export interface PromptTemplateEntity {
  id: string;
  workspace_id: string;
  category: string;
  name: string;
  description?: string;
  latest_version: number;
  current_version_id?: string;
  status: PromptStatus;
  model_capability: string;
  default_provider: string;
  default_model: string;
  temperature: number;
  top_p: number;
  max_tokens: number;
  response_schema?: Record<string, unknown>;
  variables: string[]; // Variable names allowed
  tags: string[];
  created_by?: string;
  updated_by?: string;
  approved_by?: string;
  approved_at?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface PromptVersionEntity {
  id: string;
  template_id: string;
  version: number;
  system_prompt: string;
  user_prompt: string;
  change_summary?: string;
  variables: string[];
  checksum: string;
  created_by?: string;
  created_at: string;
}

export interface PromptExecutionHistoryEntity {
  id: string;
  workspace_id: string;
  template_id: string;
  version_id: string;
  provider: string;
  model: string;
  rendered_hash: string;
  execution_ms: number;
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  estimated_cost: number;
  cache_hit: boolean;
  success: boolean;
  error_message?: string;
  created_at: string;
}

export interface PromptAuditLogEntity {
  id: string;
  workspace_id: string;
  template_id: string;
  action: string;
  actor?: string;
  before?: Record<string, unknown>;
  after?: Record<string, unknown>;
  created_at: string;
}

export interface ContextProvider {
  readonly name: string;
  provide(workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>>;
}

export interface VariableParserResult {
  name: string;
  defaultValue?: string;
  isNullable: boolean;
}
