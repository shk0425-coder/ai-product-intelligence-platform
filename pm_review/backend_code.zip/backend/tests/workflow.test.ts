import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import crypto from 'crypto';
import { createApp } from '../src/app.js';
import { WorkflowGraphValidator } from '../src/modules/workflow/graph-validator.js';
import { WorkflowStateMachine } from '../src/modules/workflow/state-machine.js';
import { WorkflowContextManager } from '../src/modules/workflow/context-manager.js';
import { WorkflowConditionEvaluator } from '../src/modules/workflow/condition.js';
import { StepRetryPolicy } from '../src/modules/workflow/retry-policy.js';
import { CancellationToken } from '../src/modules/workflow/cancellation.js';
import { WorkflowPreviewer } from '../src/modules/workflow/preview.js';
import { WorkflowHistoryCollector, WorkflowAuditLogger } from '../src/modules/workflow/history.js';
import { WorkflowRepository } from '../src/modules/workflow/repository.js';
import { WorkflowService } from '../src/modules/workflow/service.js';
import { PromptRepository } from '../src/modules/prompt/repository.js';
import { PromptService } from '../src/modules/prompt/service.js';
import { AIGateway } from '../src/modules/ai-provider/gateway.js';
import { AIProviderRepository } from '../src/modules/ai-provider/repository.js';
import { ProviderRegistry } from '../src/modules/ai-provider/provider-registry.js';
import { GeneralAIProvider } from '../src/modules/ai-provider/provider-registry.js';
import { AIProviderRequest, GenerateResponse, ModelMetadata } from '../src/modules/ai-provider/types.js';
import { WorkflowGraph, WorkflowDefinitionEntity, WorkflowVersionEntity, WorkflowStatus } from '../src/modules/workflow/types.js';
import { ValidationError } from '../src/common/errors/index.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeResolver = () => Promise.resolve({ data: null, error: null });

  const queryMockObj = {
    insert: vi.fn().mockImplementation((payload) => {
      return {
        select: vi.fn().mockImplementation(() => {
          return {
            single: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'insert', payload)),
          };
        }),
      };
    }),
    update: vi.fn().mockImplementation((payload) => {
      return {
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            select: vi.fn().mockImplementation(() => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', { col, val, payload })),
              };
            }),
          };
        }),
      };
    }),
    select: vi.fn().mockImplementation((cols) => {
      const chain = {
        is: vi.fn().mockImplementation((col, val) => {
          return {
            order: vi.fn().mockImplementation((col2, val2) => {
              return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_all_workflows'));
            }),
          };
        }),
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            is: vi.fn().mockImplementation((col2, val2) => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'select_workflow_by_id', { col, val })),
              };
            }),
            order: vi.fn().mockImplementation((col2, val2) => {
              return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_versions', { col, val }));
            }),
            maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'select_by_id_simple', { col, val })),
          };
        }),
        order: vi.fn().mockImplementation((col, val) => {
          return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_ordered_general'));
        }),
      };
      const promiseObj = Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_all_general'));
      Object.assign(promiseObj, chain);
      return promiseObj;
    }),
    _table: '',
  };

  (globalThis as any).__mockSupabase = {
    from: vi.fn().mockImplementation((table) => {
      queryMockObj._table = table;
      return queryMockObj;
    }),
  };
});

export const setResolver = (fn: any) => {
  (globalThis as any).__activeResolver = fn;
};

vi.mock('@supabase/supabase-js', async (importOriginal) => {
  const actual = await importOriginal() as any;
  return {
    ...actual,
    createClient: (url: string, key: string, options: any) => {
      if ((globalThis as any).__mockSupabase) {
        return (globalThis as any).__mockSupabase;
      }
      return actual.createClient(url, key, options);
    },
  };
});

// Mock Provider Adapter
class MockAdapter {
  async generate(request: AIProviderRequest, metadata: ModelMetadata): Promise<GenerateResponse> {
    return {
      content: `AI output for: ${request.prompt}`,
      finishReason: 'STOP',
      usage: { promptTokens: 100, completionTokens: 50, totalTokens: 150 },
      provider: 'GEMINI',
      model: metadata.model,
      cost: 0.005,
    };
  }

  async generateStream(request: AIProviderRequest, _metadata: ModelMetadata): Promise<AsyncIterable<string>> {
    const text = `AI Stream`;
    const chunks = text.split(' ');
    return {
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) {
          yield chunk + ' ';
        }
      },
    };
  }
}

describe('AI Workflow Engine & Multi-Agent Orchestrator (Integration Tests)', () => {
  let app: any;
  let repository: WorkflowRepository;
  let service: WorkflowService;
  let promptService: PromptService;

  const testToken = jwt.sign({ orgId: 'test-workspace-owner-123' }, 'test-jwt-secret');
  const workspaceId = '11111111-1111-1111-1111-111111111111';

  const mockMeta: ModelMetadata = {
    provider: 'GEMINI',
    model: 'gemini-1.5-pro',
    version: 'v1.5',
    contextWindow: 100000,
    maxOutputTokens: 2048,
    supportsStreaming: true,
    supportsVision: true,
    supportsText: true,
    supportsImageGeneration: false,
    supportsImageEditing: false,
    supportsEmbedding: true,
    supportsStructuredOutput: true,
    supportsFunctionCalling: true,
    inputCost: 0.00125,
    outputCost: 0.00375,
    enabled: true,
  };

  // 1. Correct DAG definition
  const validGraph: WorkflowGraph = {
    nodes: [
      { id: 'start', type: 'Start', name: 'StartNode' },
      { id: 'step1', type: 'Agent', name: 'WriterAgent', promptTemplateId: '55555555-5555-5555-5555-555555555555' },
      { id: 'end', type: 'End', name: 'EndNode' },
    ],
    edges: [
      { from: 'start', to: 'step1' },
      { from: 'step1', to: 'end' },
    ],
  };

  // 2. Cycle graph definition (Invalid)
  const cyclicGraph: WorkflowGraph = {
    nodes: [
      { id: 'start', type: 'Start', name: 'Start' },
      { id: 'step1', type: 'Agent', name: 'Agent1', promptTemplateId: '55555555-5555-5555-5555-555555555555' },
      { id: 'step2', type: 'Agent', name: 'Agent2', promptTemplateId: '55555555-5555-5555-5555-555555555555' },
      { id: 'end', type: 'End', name: 'End' },
    ],
    edges: [
      { from: 'start', to: 'step1' },
      { from: 'step1', to: 'step2' },
      { from: 'step2', to: 'step1' }, // Cycle
      { from: 'step2', to: 'end' },
    ],
  };

  // 3. Orphan node graph definition (Invalid)
  const orphanGraph: WorkflowGraph = {
    nodes: [
      { id: 'start', type: 'Start', name: 'Start' },
      { id: 'step1', type: 'Agent', name: 'Agent1', promptTemplateId: '55555555-5555-5555-5555-555555555555' },
      { id: 'step2', type: 'Agent', name: 'OrphanAgent', promptTemplateId: '55555555-5555-5555-5555-555555555555' },
      { id: 'end', type: 'End', name: 'End' },
    ],
    edges: [
      { from: 'start', to: 'step1' },
      { from: 'step1', to: 'end' },
      // step2 is disjoint
    ],
  };

  const sampleWorkflow: WorkflowDefinitionEntity = {
    id: 'workflow-uuid-1',
    workspace_id: workspaceId,
    name: 'Marketing Strategy Flow',
    description: 'Runs parallel agent pipelines',
    latest_version: 1,
    current_version_id: 'ver-uuid-1',
    status: 'APPROVED',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const sampleVersion: WorkflowVersionEntity = {
    id: 'ver-uuid-1',
    workflow_id: 'workflow-uuid-1',
    version: 1,
    graph: validGraph,
    checksum: 'mock-checksum',
    created_at: new Date().toISOString(),
  };

  beforeAll(async () => {
    app = await createApp();

    ProviderRegistry.clear();
    const provider = new GeneralAIProvider('GEMINI', 'gemini-1.5-pro', mockMeta, 100, 50000, new MockAdapter());
    ProviderRegistry.register(provider);

    const providerRepo = new AIProviderRepository((globalThis as any).__mockSupabase as any);
    const gateway = new AIGateway(providerRepo);

    const promptRepo = new PromptRepository((globalThis as any).__mockSupabase as any);
    promptService = new PromptService(promptRepo, gateway);

    repository = new WorkflowRepository((globalThis as any).__mockSupabase as any);
    service = new WorkflowService(repository, promptService);
  });

  beforeEach(() => {
    WorkflowHistoryCollector.clear();
    WorkflowAuditLogger.clear();
  });

  // 1. Graph Validator Tests
  describe('WorkflowGraphValidator tests', () => {
    it('should pass validation on correct linear graph structure', () => {
      expect(() => WorkflowGraphValidator.validate(validGraph)).not.toThrow();
    });

    it('should throw ValidationError if cyclic connections exist in graph', () => {
      expect(() => WorkflowGraphValidator.validate(cyclicGraph)).toThrow(ValidationError);
    });

    it('should throw ValidationError if disjoint orphan nodes exist in graph', () => {
      expect(() => WorkflowGraphValidator.validate(orphanGraph)).toThrow(ValidationError);
    });
  });

  // 2. State Machine Tests
  describe('WorkflowStateMachine tests', () => {
    it('should successfully transition PENDING to RUNNING state', () => {
      const state = WorkflowStateMachine.transition('PENDING', 'RUNNING');
      expect(state).toBe('RUNNING');
    });

    it('should throw ValidationError on transition from TERMINAL SUCCESS state', () => {
      expect(() => WorkflowStateMachine.transition('SUCCESS', 'RUNNING')).toThrow(ValidationError);
    });
  });

  // 3. Context Manager Tests
  describe('WorkflowContextManager tests', () => {
    it('should copy and merge contexts immutably', () => {
      const original = { workspaceName: 'OrgA', count: 1 };
      const merged = WorkflowContextManager.merge(original, { count: 2, newKey: 'added' });

      expect(merged.workspaceName).toBe('OrgA');
      expect(merged.count).toBe(2);
      expect(merged.newKey).toBe('added');
      // Ensure original is untouched
      expect(original.count).toBe(1);
    });
  });

  // 4. Conditional Branches Tests
  describe('WorkflowConditionEvaluator tests', () => {
    it('should evaluate conditional expression to true on equal matching', () => {
      const result = WorkflowConditionEvaluator.evaluate('context.score === 100', { score: 100 });
      expect(result).toBe(true);
    });

    it('should evaluate conditional expression to true on numerical bounds comparison', () => {
      const result = WorkflowConditionEvaluator.evaluate('context.rating > 4.5', { rating: 4.8 });
      expect(result).toBe(true);
    });

    it('should evaluate conditional expression to false on mis-matching ratings', () => {
      const result = WorkflowConditionEvaluator.evaluate('context.rating < 3.0', { rating: 4.5 });
      expect(result).toBe(false);
    });
  });

  // 5. Retry Policy Tests
  describe('StepRetryPolicy tests', () => {
    it('should calculate exponential backoff delay correctly', () => {
      const delay = StepRetryPolicy.getDelayMs(2, 1000); // 1000 * 2^2 = 4000
      expect(delay).toBe(4000);
    });

    it('should check if step can be retried based on retry limits', () => {
      expect(StepRetryPolicy.shouldRetry(1, 3)).toBe(true);
      expect(StepRetryPolicy.shouldRetry(3, 3)).toBe(false);
    });
  });

  // 6. Preview Engine Tests
  describe('WorkflowPreviewer tests', () => {
    it('should return simulated groupings and estimated cost values', () => {
      const preview = WorkflowPreviewer.preview(validGraph);
      expect(preview.executionOrder).toEqual(['start', 'step1', 'end']);
      expect(preview.parallelGroups).toBeDefined();
    });
  });

  // 7. WorkflowService Operations & Lifecycles
  describe('WorkflowService CRUD & approval lifecycles', () => {
    it('should create workflow definitions and version 1 record', async () => {
      setResolver((table: string, action: string, payload: any) => {
        if (table === 'workflow_definitions') {
          const base = {
            id: 'workflow-uuid-1',
            latest_version: 1,
            status: 'DRAFT',
            workspace_id: workspaceId,
            name: 'Strategy Flow',
          };
          const resolved = action === 'update' ? { ...base, ...payload.payload } : { ...base, ...payload };
          return Promise.resolve({ data: resolved, error: null });
        }
        if (table === 'workflow_versions') {
          return Promise.resolve({ data: { ...payload, id: 'version-uuid-1' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const wf = await service.createWorkflow({
        workspaceId,
        name: 'Strategy Flow',
        graph: validGraph,
      });

      expect(wf.latest_version).toBe(1);
      expect(wf.status).toBe('DRAFT');
    });

    it('should auto-increment version number on new version creation', async () => {
      setResolver((table: string, action: string, payload: any) => {
        if (table === 'workflow_definitions' && action === 'select_workflow_by_id') {
          return Promise.resolve({ data: sampleWorkflow, error: null });
        }
        if (table === 'workflow_versions' && action === 'insert') {
          return Promise.resolve({ data: { ...payload, id: 'ver-2' }, error: null });
        }
        if (table === 'workflow_definitions' && action === 'update') {
          return Promise.resolve({ data: { ...sampleWorkflow, latest_version: 2, status: 'DRAFT' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const nextVer = await service.createVersion('workflow-uuid-1', {
        graph: validGraph,
        changeSummary: 'Change graph connections',
      });

      expect(nextVer.version).toBe(2);
    });

    it('should transit status to APPROVED when approve is called', async () => {
      setResolver((table: string, action: string, payload: any) => {
        if (table === 'workflow_definitions' && action === 'select_workflow_by_id') {
          return Promise.resolve({ data: sampleWorkflow, error: null });
        }
        if (table === 'workflow_definitions' && action === 'update') {
          return Promise.resolve({ data: { ...sampleWorkflow, status: 'APPROVED' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const approved = await service.approveWorkflow('workflow-uuid-1', 'admin-user');
      expect(approved.status).toBe('APPROVED');
    });
  });

  // 8. Execution API Tests
  describe('REST API endpoints mapping', () => {
    it('should return 200 and list workflows on GET /api/v1/workflows', async () => {
      setResolver(() => Promise.resolve({ data: [sampleWorkflow], error: null }));

      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/workflows',
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data[0].name).toBe('Marketing Strategy Flow');
    });

    it('should return 200 and return preview details on POST /api/v1/workflows/preview', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/workflows/preview',
        headers: { authorization: `Bearer ${testToken}` },
        payload: {
          workspaceId,
          graph: validGraph,
          input: { key: 'value' },
        },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data.executionOrder).toEqual(['start', 'step1', 'end']);
    });
  });
});
