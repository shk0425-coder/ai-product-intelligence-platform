export interface IWorker {
  execute(jobId: string, payload: Record<string, unknown>): Promise<void>;
}

export class WorkerRegistry {
  private static readonly workers = new Map<string, IWorker>();

  static register(type: string, worker: IWorker): void {
    this.workers.set(type.toUpperCase(), worker);
  }

  static getWorker(type: string): IWorker | undefined {
    return this.workers.get(type.toUpperCase());
  }

  static clear(): void {
    this.workers.clear();
  }
}
