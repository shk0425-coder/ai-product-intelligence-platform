export interface PerformanceMetricsDto {
  impressions: number;
  clicks: number;
  conversionCount: number;
  conversionRate: number;
  ctr: number;
  adCost: number;
  profit: number;
  marginRate: number;
  roi: number;
}

export interface PerformanceSourceDto {
  marketplaceCode: string;
  marketplaceName: string;
  collectionJobId?: string | null;
  sourceVersion: number;
  collectedAt: string;
  rawPayloadHash: string;
}

export interface CreatePerformanceDto {
  workspaceId: string;
  productId: string;
  analysisRunId: string;
  strategyId?: string | null;
  creativeId?: string | null;
  periodStart: string;
  periodEnd: string;
  salesCount: number;
  salesAmount: number;
  refundCount: number;
  reviewCount: number;
  reviewScore: number;
  favoriteCount: number;
  metrics: PerformanceMetricsDto;
  source: PerformanceSourceDto;
}

export interface UpdatePerformanceDto {
  strategyId?: string | null;
  creativeId?: string | null;
  salesCount: number;
  salesAmount: number;
  refundCount: number;
  reviewCount: number;
  reviewScore: number;
  favoriteCount: number;
  metrics: PerformanceMetricsDto;
  source: PerformanceSourceDto;
}

export interface PerformanceResponseDto {
  performanceId: string;
  workspaceId: string;
  productId: string;
  analysisRunId: string;
  strategyId: string | null;
  creativeId: string | null;
  periodStart: string;
  periodEnd: string;
  salesCount: number;
  salesAmount: number;
  refundCount: number;
  reviewCount: number;
  reviewScore: number;
  favoriteCount: number;
  version: number;
  lastCollectedAt: string;
  createdAt: string;
  updatedAt: string;
  metrics: PerformanceMetricsDto | null;
  source: PerformanceSourceDto | null;
}
