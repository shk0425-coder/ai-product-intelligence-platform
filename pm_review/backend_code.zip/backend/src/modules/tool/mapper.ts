import { ToolDefinitionEntity, ToolVersionEntity, ApprovalRequestEntity } from './types.js';
import { ToolDefinitionDto, ToolVersionDto, ApprovalRequestDto } from './dto.js';

export class ToolMapper {
  static toDefinitionDto(entity: ToolDefinitionEntity): ToolDefinitionDto {
    return {
      id: entity.id,
      workspaceId: entity.workspace_id,
      name: entity.name,
      description: entity.description,
      category: entity.category,
      latestVersion: entity.latest_version,
      currentVersionId: entity.current_version_id,
      status: entity.status,
      createdAt: entity.created_at,
      updatedAt: entity.updated_at,
    };
  }

  static toDefinitionDtoList(entities: ToolDefinitionEntity[]): ToolDefinitionDto[] {
    return entities.map((e) => this.toDefinitionDto(e));
  }

  static toVersionDto(entity: ToolVersionEntity): ToolVersionDto {
    return {
      id: entity.id,
      toolId: entity.tool_id,
      version: entity.version,
      manifest: entity.manifest,
      inputSchema: entity.input_schema,
      outputSchema: entity.output_schema,
      permission: entity.permission,
      timeoutMs: entity.timeout_ms,
      retryLimit: entity.retry_limit,
      checksum: entity.checksum,
      createdAt: entity.created_at,
    };
  }

  static toVersionDtoList(entities: ToolVersionEntity[]): ToolVersionDto[] {
    return entities.map((e) => this.toVersionDto(e));
  }

  static toApprovalDto(entity: ApprovalRequestEntity): ApprovalRequestDto {
    return {
      id: entity.id,
      workspaceId: entity.workspace_id,
      workflowExecutionId: entity.workflow_execution_id,
      workflowStepExecutionId: entity.workflow_step_execution_id,
      title: entity.title,
      description: entity.description,
      payload: entity.payload,
      status: entity.status,
      timeoutAt: entity.timeout_at,
      requestedBy: entity.requested_by,
      approvedBy: entity.approved_by,
      approvedAt: entity.approved_at,
      rejectedBy: entity.rejected_by,
      rejectedAt: entity.rejected_at,
      createdAt: entity.created_at,
    };
  }

  static toApprovalDtoList(entities: ApprovalRequestEntity[]): ApprovalRequestDto[] {
    return entities.map((e) => this.toApprovalDto(e));
  }
}
export default ToolMapper;
