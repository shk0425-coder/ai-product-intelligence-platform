import { JobQueueRepository } from './repository.js';
import { LeaseManager } from './lease-manager.js';
import { WorkerFactory } from './worker-factory.js';
import { JobExecutor } from './job-executor.js';
import { JobQueueEntity } from './types.js';

export class JobDispatcher {
  private pollingInterval: number = 5000;
  private intervalId: NodeJS.Timeout | null = null;
  private isPollingActive: boolean = false;

  constructor(
    private readonly repository: JobQueueRepository,
    private readonly leaseOwnerId: string
  ) {}

  setPollingInterval(ms: number): void {
    this.pollingInterval = ms;
    if (this.isPollingActive) {
      this.stopPolling();
      this.startPolling();
    }
  }

  startPolling(): void {
    if (this.isPollingActive) return;
    this.isPollingActive = true;

    const tick = async () => {
      try {
        await this.pollAndDispatch();
      } catch (_err) {
        // Log poll error silently or delegate to logger
      }
      if (this.isPollingActive) {
        this.intervalId = setTimeout(tick, this.pollingInterval);
      }
    };

    this.intervalId = setTimeout(tick, this.pollingInterval);
  }

  stopPolling(): void {
    this.isPollingActive = false;
    if (this.intervalId) {
      clearTimeout(this.intervalId);
      this.intervalId = null;
    }
  }

  async pollAndDispatch(): Promise<JobQueueEntity | null> {
    const supabase = (this.repository as unknown as { supabase: import('@supabase/supabase-js').SupabaseClient }).supabase;
    const now = new Date().toISOString();

    // Scan for high priority eligible job
    const { data: jobs, error } = await supabase
      .from('job_queue')
      .select('*')
      .or(`status.eq.PENDING,status.eq.FAILED,lease_until.lt.${now}`)
      .lte('scheduled_at', now)
      .eq('cancel_requested', false)
      .order('priority', { ascending: false })
      .order('scheduled_at', { ascending: true })
      .limit(1);

    if (error || !jobs || jobs.length === 0) return null;
    const job = jobs[0] as JobQueueEntity;

    // Attempt to acquire lease atomically
    const leaseManager = new LeaseManager(this.repository, this.leaseOwnerId);
    const acquired = await leaseManager.acquire(job.id);
    if (!acquired) {
      // Lease acquisition race condition lost
      return null;
    }

    // Dynamic Worker dispatch (Switch-case free OCP factory)
    try {
      const worker = WorkerFactory.getWorker(acquired.job_type);
      const executor = new JobExecutor(this.repository, leaseManager);

      // Async execution out of polling loop thread
      executor.executeJob(acquired, worker).catch(() => {});
      return acquired;
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      // Failed to find worker instance: Route to dead letter directly
      await this.repository.updateJob(acquired.id, {
        status: 'FAILED',
        error_message: errMsg,
      });
      return acquired;
    }
  }
}
