import { vi, describe, it, expect, beforeAll } from 'vitest';

const { mockQueryBuilder, setResolver, mockSupabase } = vi.hoisted(() => {
  const qb: any = {
    select: vi.fn(),
    insert: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
    eq: vi.fn(),
    is: vi.fn(),
    in: vi.fn(),
    order: vi.fn(),
    limit: vi.fn(),
    maybeSingle: vi.fn(),
    single: vi.fn(),
  };

  const methods = [
    'select',
    'insert',
    'update',
    'delete',
    'eq',
    'is',
    'in',
    'order',
    'limit',
    'maybeSingle',
    'single',
  ];
  for (const m of methods) {
    qb[m].mockImplementation(() => qb);
  }

  let resolver = () => Promise.resolve({ data: null, count: 0, error: null });
  qb.then = (onfulfilled: any) => resolver().then(onfulfilled);

  const supabaseMock = {
    from: vi.fn().mockReturnValue(qb),
  };

  return {
    mockQueryBuilder: qb,
    setResolver: (newResolver: any) => {
      resolver = newResolver;
    },
    mockSupabase: supabaseMock,
  };
});

vi.mock('@/config/supabase.js', () => {
  return {
    supabase: mockSupabase,
  };
});

import { createApp } from '@/app.js';
import jwt from 'jsonwebtoken';
import { env } from '@/config/env.js';
import { FeatureExtractor } from '../src/modules/closed-loop-learning/feature-extractor.js';
import { PatternDetector } from '../src/modules/closed-loop-learning/pattern-detector.js';
import { KnowledgeScorer } from '../src/modules/closed-loop-learning/knowledge-scorer.js';
import { VectorGenerator } from '../src/modules/closed-loop-learning/vector-generator.js';

const generateTestToken = (userId: string, email: string) => {
  return jwt.sign({ userId, email, role: 'USER' }, env.JWT_SECRET, { expiresIn: '1h' });
};

describe('Closed-loop Learning Engine Module Tests', () => {
  let app: any;
  const mockUserId = '11111111-1111-1111-1111-111111111111';
  const testToken = generateTestToken(mockUserId, 'test@example.com');

  const intelligenceId = '22222222-2222-2222-2222-222222222222';
  const knowledgeId = '33333333-3333-3333-3333-333333333333';
  const vectorId = '44444444-4444-4444-4444-444444444444';
  const productId = '55555555-5555-5555-5555-555555555555';

  beforeAll(async () => {
    app = await createApp();
  });

  describe('Pure Calculation Engines Verification', () => {
    const mockIntel = {
      strengthSummary: '만족도 우수',
      impactScore: 50.0,
      confidenceScore: 100.0,
      detectedRules: [
        { ruleId: 'RULE_CONV_BOTTLENECK_CRITICAL', category: 'Conversion', severity: 5, message: 'low conversion' },
        { ruleId: 'RULE_CTR_LEAKAGE', category: 'CTR', severity: 3, message: 'low CTR' },
      ],
      recommendations: [
        { category: 'Conversion', recommendation: 'improve layout', expectedImpact: 100 },
      ],
    };

    it('should extract correct feature set elements', () => {
      const features = FeatureExtractor.extract(mockIntel);
      expect(features.strengths).toContain('만족도 우수');
      expect(features.bottlenecks[0]).toContain('Conversion issue');
      expect(features.weaknesses[0]).toContain('CTR issue');
    });

    it('should detect patterns and generate SHA-256 hashes', () => {
      const patterns = PatternDetector.detect(mockIntel);
      expect(patterns.length).toBe(2); // Conversion, CTR
      expect(patterns[0].patternHash).toBeDefined();
      expect(patterns[0].patternHash.length).toBe(64); // SHA-256 hex length
    });

    it('should generate structured vector data with valid checksum', () => {
      const features = FeatureExtractor.extract(mockIntel);
      const patterns = PatternDetector.detect(mockIntel);
      const result = VectorGenerator.generate(features, patterns, mockIntel);

      expect(result.featureCount).toBe(5); // strengths(1) + weaknesses(1) + bottlenecks(1) + improvements(1) + risks(1)
      expect(result.checksum.length).toBe(64);
    });

    it('should calculate knowledge score according to weighted sum formula', () => {
      // 5 features (coverage 1.0) + 3 patterns (coverage 1.0) + confidence 100
      // Expected: 1.0 * 30 + 1.0 * 30 + 100 * 0.4 = 100.00
      const score = KnowledgeScorer.calculate(5, 3, 100);
      expect(score).toBe(100.0);

      // 0 features + 0 patterns + confidence 50
      // Expected: 0 + 0 + 50 * 0.4 = 20.0
      expect(KnowledgeScorer.calculate(0, 0, 50)).toBe(20.0);
    });
  });

  describe('API Integrations / Authentication & Security Check', () => {
    it('should deny generate request if token is missing', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/learning/generate',
        payload: { intelligenceId },
      });
      expect(response.statusCode).toBe(401);
    });

    it('should return 403 Forbidden when requester does not own intelligence report', async () => {
      setResolver(() => {
        // verifyIntelligenceOwner -> false
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/learning/generate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { intelligenceId },
      });

      expect(response.statusCode).toBe(403);
    });
  });

  describe('POST /api/v1/learning/generate (Success & Conflict cases)', () => {
    it('should successfully build learning knowledge and vector records', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyIntelligenceOwner
        if (callCount === 1) {
          return Promise.resolve({
            data: { feedback_scores: { product_performance: { workspaces: { org_id: mockUserId } } } },
            error: null,
          });
        }
        // 2. Fetch Intelligence
        if (callCount === 2) {
          return Promise.resolve({
            data: {
              id: intelligenceId,
              feedback_score_id: 'score-id',
              confidence_score: 100.0,
              impact_score: 50.0,
              strength_summary: '만족도 우수',
              detected_rules: [
                { ruleId: 'RULE_CONV_BOTTLENECK_CRITICAL', category: 'Conversion', severity: 5, message: 'low conversion' },
              ],
              recommendations: [
                { category: 'Conversion', recommendation: 'improve layout', expectedImpact: 100 },
              ],
            },
            error: null,
          });
        }
        // 3. Prevent duplicate check: exists(intelligenceId, 1) -> count is 0
        if (callCount === 3) {
          return Promise.resolve({ count: 0, error: null });
        }
        // 4. Fetch Feedback Score
        if (callCount === 4) {
          return Promise.resolve({ data: { id: 'score-id', performance_id: 'perf-id' }, error: null });
        }
        // 5. Fetch Performance
        if (callCount === 5) {
          return Promise.resolve({ data: { id: 'perf-id' }, error: null });
        }
        // 6. Fetch Metrics
        if (callCount === 6) {
          return Promise.resolve({ data: { id: 'perf-id' }, error: null });
        }
        // 7. createKnowledge
        if (callCount === 7) {
          return Promise.resolve({
            data: {
              id: knowledgeId,
              intelligence_id: intelligenceId,
              knowledge_version: 1,
              feature_summary: 'summary',
              success_pattern: 'success',
              failure_pattern: 'failure',
              improvement_pattern: 'improve',
              knowledge_score: 80.0,
              confidence_score: 100.0,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            },
            error: null,
          });
        }
        // 8. createVector
        if (callCount === 8) {
          return Promise.resolve({
            data: {
              id: vectorId,
              knowledge_id: knowledgeId,
              vector_version: 'v1',
              vector_data: { test: true },
              feature_count: 3,
              checksum: 'hash-code',
              created_at: new Date().toISOString(),
            },
            error: null,
          });
        }
        // 9. createPattern
        if (callCount === 9) {
          return Promise.resolve({ data: { id: 'pattern-id' }, error: null });
        }
        // 10. createAudit
        if (callCount === 10) {
          return Promise.resolve({ data: { id: 'audit-id' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/learning/generate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { intelligenceId },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.success).toBe(true);
      expect(body.data.knowledgeId).toBe(knowledgeId);
      expect(body.data.knowledgeVersion).toBe(1);
      expect(body.data.vector.checksum).toBe('hash-code');
    });

    it('should return 409 Conflict if knowledge version 1 already exists', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyIntelligenceOwner
        if (callCount === 1) {
          return Promise.resolve({
            data: { feedback_scores: { product_performance: { workspaces: { org_id: mockUserId } } } },
            error: null,
          });
        }
        // 2. Fetch Intelligence
        if (callCount === 2) return Promise.resolve({ data: { id: intelligenceId }, error: null });
        // 3. exists() -> returns count > 0 (1)
        return Promise.resolve({ count: 1, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/learning/generate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { intelligenceId },
      });

      expect(response.statusCode).toBe(409);
    });
  });

  describe('POST /api/v1/learning/regenerate', () => {
    it('should increment version count and add new record', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyIntelligenceOwner
        if (callCount === 1) {
          return Promise.resolve({
            data: { feedback_scores: { product_performance: { workspaces: { org_id: mockUserId } } } },
            error: null,
          });
        }
        // 2. Fetch Intelligence
        if (callCount === 2) return Promise.resolve({ data: { id: intelligenceId, feedback_score_id: 'score-id' }, error: null });
        // 3. Get existing list to resolve version (returns list with version 1)
        if (callCount === 3) return Promise.resolve({ data: [{ knowledge_version: 1 }], error: null });
        // 4. Fetch Score
        if (callCount === 4) return Promise.resolve({ data: { id: 'score-id' }, error: null });
        // 5. Fetch Performance
        if (callCount === 5) return Promise.resolve({ data: null, error: null });
        // 6. Fetch Metrics
        if (callCount === 6) return Promise.resolve({ data: null, error: null });
        // 7. createKnowledge (inserts version 2)
        if (callCount === 7) {
          return Promise.resolve({
            data: {
              id: knowledgeId,
              intelligence_id: intelligenceId,
              knowledge_version: 2, // version incremented
              feature_summary: 'summary-2',
              success_pattern: 'success',
              failure_pattern: 'failure',
              improvement_pattern: 'improve',
              knowledge_score: 90.0,
              confidence_score: 100.0,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            },
            error: null,
          });
        }
        // 8. createVector
        if (callCount === 8) return Promise.resolve({ data: { id: vectorId, knowledge_id: knowledgeId, vector_version: 'v1' }, error: null });
        // 9. createAudit
        if (callCount === 9) return Promise.resolve({ data: { id: 'audit-id' }, error: null });
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/learning/regenerate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { intelligenceId },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.knowledgeVersion).toBe(2);
    });
  });

  describe('GET /api/v1/learning/latest/:productId', () => {
    it('should fetch latest knowledge record successfully', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyProductOwner
        if (callCount === 1) return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        // 2. findLatest
        if (callCount === 2) {
          return Promise.resolve({
            data: {
              id: knowledgeId,
              intelligence_id: intelligenceId,
              knowledge_version: 2,
              knowledge_score: 85.0,
            },
            error: null,
          });
        }
        // 3. findVectorByKnowledge
        return Promise.resolve({
          data: {
            id: vectorId,
            knowledge_id: knowledgeId,
            vector_version: 'v1',
            checksum: 'some-hash',
          },
          error: null,
        });
      });

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/learning/latest/${productId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.knowledgeId).toBe(knowledgeId);
      expect(body.data.vector.checksum).toBe('some-hash');
    });
  });
});
