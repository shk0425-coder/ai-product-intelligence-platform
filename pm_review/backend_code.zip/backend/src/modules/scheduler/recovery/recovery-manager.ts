import { SnapshotManager, SchedulerSnapshot } from './snapshot-manager.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export class RecoveryManager {
  static async recover(lastSnapshot: SchedulerSnapshot): Promise<boolean> {
    const success = await SnapshotManager.restoreSnapshot(lastSnapshot);
    if (success) {
      MetricsRegistry.counter('scheduler_recovery_total', 1);

      eventBus.publish({
        eventId: crypto.randomUUID(),
        eventType: 'SchedulerRecovered',
        timestamp: new Date().toISOString(),
        workspaceId: 'default-workspace',
        data: { timestamp: lastSnapshot.timestamp, type: 'SnapshotRestore' },
      }).catch(() => {});

      return true;
    }
    return false;
  }
}
export default RecoveryManager;
