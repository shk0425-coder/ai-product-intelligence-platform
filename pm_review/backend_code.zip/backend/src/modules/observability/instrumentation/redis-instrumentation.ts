import { TraceManager, Span } from '../tracing/trace-manager.js';
import { MetricsRegistry } from '../metrics/registry.js';
import { RedisMetricsCollector } from '../metrics/collector/redis-collector.js';

export class RedisInstrumentation {
  static startCommand(cmdName: string): Span {
    const span = TraceManager.startSpan(`Redis ${cmdName}`);
    span.setAttribute('redis.command', cmdName);
    return span;
  }

  static endCommand(span: Span, cmdName: string, durationMs: number, success = true): void {
    span.setStatus(success ? 'OK' : 'ERROR');
    span.end();

    MetricsRegistry.counter('redis_commands_total', 1, { status: success ? 'success' : 'failure' });
    MetricsRegistry.histogram('redis_command_duration_seconds', durationMs / 1000, { endpoint: cmdName });

    if (!success) {
      MetricsRegistry.counter('redis_command_failures_total', 1);
    }
  }

  static recordCircuitStateChange(state: 'CLOSED' | 'HALF_OPEN' | 'OPEN'): void {
    RedisMetricsCollector.recordCircuitState(state);
  }

  static recordCircuitBreakerEvent(event: 'recovery' | 'failure'): void {
    RedisMetricsCollector.recordCircuitEvent(event);
  }
}
