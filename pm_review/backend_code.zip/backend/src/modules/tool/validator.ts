import { ValidationError } from '../../common/errors/index.js';

export class ToolSchemaValidator {
  static validate(schema: Record<string, unknown>, data: Record<string, unknown>): void {
    if (!schema || Object.keys(schema).length === 0) return;

    // Check if type matches
    const expectedType = schema.type;
    if (expectedType === 'object') {
      const properties = (schema.properties || {}) as Record<string, unknown>;
      const required = (schema.required || []) as string[];

      // 1. Check required properties
      for (const reqKey of required) {
        if (data[reqKey] === undefined) {
          throw new ValidationError(`Validation failed: missing required property "${reqKey}"`);
        }
      }

      // 2. Validate property types recursively
      for (const [key, value] of Object.entries(data)) {
        const propSchema = properties[key];
        if (!propSchema) {
          // If additionalProperties is false, throw error
          if (schema.additionalProperties === false) {
            throw new ValidationError(`Validation failed: property "${key}" is not allowed by schema`);
          }
          continue;
        }

        this.validateProperty(key, propSchema as Record<string, unknown>, value);
      }
    }
  }

  private static validateProperty(key: string, schema: Record<string, unknown>, value: unknown): void {
    const expected = schema.type;

    if (expected === 'string' && typeof value !== 'string') {
      throw new ValidationError(`Validation failed: property "${key}" must be a string`);
    }
    if (expected === 'number' && typeof value !== 'number') {
      throw new ValidationError(`Validation failed: property "${key}" must be a number`);
    }
    if (expected === 'boolean' && typeof value !== 'boolean') {
      throw new ValidationError(`Validation failed: property "${key}" must be a boolean`);
    }
    if (expected === 'array') {
      if (!Array.isArray(value)) {
        throw new ValidationError(`Validation failed: property "${key}" must be an array`);
      }
      if (schema.items) {
        value.forEach((item, index) => {
          this.validateProperty(`${key}[${index}]`, schema.items as Record<string, unknown>, item);
        });
      }
    }
    if (expected === 'object') {
      if (typeof value !== 'object' || value === null || Array.isArray(value)) {
        throw new ValidationError(`Validation failed: property "${key}" must be an object`);
      }
      this.validate(schema, value as Record<string, unknown>);
    }
  }
}
export default ToolSchemaValidator;
