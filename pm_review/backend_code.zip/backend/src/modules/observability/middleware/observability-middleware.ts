import { FastifyRequest, FastifyReply } from 'fastify';
import { AsyncContextManager } from '../context/context-manager.js';
import { HttpInstrumentation } from '../instrumentation/http-instrumentation.js';
import { PerformanceProfiler } from '../diagnostics/profiler.js';
import { Span } from '../tracing/trace-manager.js';
import crypto from 'crypto';

interface ObservabilityRequest {
  routerPath?: string;
  url: string;
  method: string;
  observabilitySpan?: Span;
  observabilityStartTime?: number;
}

export async function observabilityMiddleware(req: FastifyRequest, rep: FastifyReply) {
  // 1. Correlation & Trace IDs generation
  const correlationId = (req.headers['x-correlation-id'] as string) || crypto.randomUUID();
  const traceId = (req.headers['x-trace-id'] as string) || crypto.randomUUID();

  // Bind correlation ID response header
  rep.header('x-correlation-id', correlationId);

  const context = {
    traceId,
    correlationId,
    workspaceId: (req.headers['x-workspace-id'] as string) || 'default-workspace',
  };

  // Start HTTP instrumentation inside Context Scope
  return new Promise<void>((resolve) => {
    AsyncContextManager.run(context, () => {
      const reqWithObs = req as unknown as ObservabilityRequest;
      const endpoint = reqWithObs.routerPath || reqWithObs.url;
      const method = reqWithObs.method;
      
      const span = HttpInstrumentation.startRequest(endpoint, method);
      const startTime = Date.now();

      // Attach context objects to request context
      reqWithObs.observabilitySpan = span;
      reqWithObs.observabilityStartTime = startTime;

      resolve();
    });
  });
}

export async function observabilityResponseMiddleware(req: FastifyRequest, rep: FastifyReply) {
  const reqWithObs = req as unknown as ObservabilityRequest;
  const span = reqWithObs.observabilitySpan;
  const startTime = reqWithObs.observabilityStartTime;

  if (span && startTime) {
    const durationMs = Date.now() - startTime;
    const endpoint = reqWithObs.routerPath || reqWithObs.url;
    const method = reqWithObs.method;
    const statusCode = rep.statusCode;

    HttpInstrumentation.endRequest(span, endpoint, method, statusCode, durationMs);
    PerformanceProfiler.recordLatency(endpoint, durationMs);
  }
}

export async function observabilityErrorMiddleware(req: FastifyRequest, _rep: FastifyReply, error: Error) {
  const reqWithObs = req as unknown as ObservabilityRequest;
  const span = reqWithObs.observabilitySpan;
  if (span) {
    const endpoint = reqWithObs.routerPath || reqWithObs.url;
    HttpInstrumentation.recordError(span, endpoint, error);
  }
}
