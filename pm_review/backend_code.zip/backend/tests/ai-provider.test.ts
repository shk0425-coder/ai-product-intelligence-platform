import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import { createApp } from '../src/app.js';
import { ProviderRegistry } from '../src/modules/ai-provider/provider-registry.js';
import { ProviderFactory } from '../src/modules/ai-provider/provider-factory.js';
import { ProviderSelector } from '../src/modules/ai-provider/provider-selector.js';
import { ProviderResolver } from '../src/modules/ai-provider/provider-resolver.js';
import { PricingEngine } from '../src/modules/ai-provider/pricing-engine.js';
import { ResponseNormalizer } from '../src/modules/ai-provider/response-normalizer.js';
import { ResponseValidator } from '../src/modules/ai-provider/response-validator.js';
import { RateLimiter } from '../src/modules/ai-provider/rate-limiter.js';
import { CircuitBreaker } from '../src/modules/ai-provider/circuit-breaker.js';
import { ResponseCache } from '../src/modules/ai-provider/response-cache.js';
import { ProviderHealthChecker } from '../src/modules/ai-provider/provider-health.js';
import { ProviderMetricsCollector } from '../src/modules/ai-provider/provider-metrics.js';
import { AIProviderRepository } from '../src/modules/ai-provider/repository.js';
import { AIProviderService } from '../src/modules/ai-provider/service.js';
import { AIGateway } from '../src/modules/ai-provider/gateway.js';
import { AIProviderHooks } from '../src/modules/ai-provider/hooks.js';
import { AIProvider, AIProviderRequest, ModelMetadata, GenerateResponse, ProviderHealthStatus } from '../src/modules/ai-provider/types.js';
import {
  ProviderNotFoundError,
  ProviderUnavailableError,
  ProviderCapabilityError,
  ProviderTimeoutError,
  ProviderAuthenticationError,
  ProviderValidationError,
  CircuitBreakerOpenError,
  RateLimitExceededError,
  FallbackFailedError,
  ResponseValidationError,
  StructuredOutputValidationError,
  InvalidTokenUsageError,
  InvalidFinishReasonError,
} from '../src/common/errors/index.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeResolver = () => Promise.resolve({ data: null, error: null });

  const queryMockObj = {
    insert: vi.fn().mockImplementation((payload) => {
      return {
        select: vi.fn().mockImplementation(() => {
          return {
            single: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'insert', payload)),
          };
        }),
      };
    }),
    update: vi.fn().mockImplementation((payload) => {
      return {
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            eq: vi.fn().mockImplementation((col2, val2) => {
              return {
                select: vi.fn().mockImplementation(() => {
                  return {
                    maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', { col, val, col2, val2, payload })),
                  };
                }),
              };
            }),
            select: vi.fn().mockImplementation(() => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', { col, val, payload })),
              };
            }),
          };
        }),
      };
    }),
    select: vi.fn().mockImplementation((cols) => {
      const chain = {
        order: vi.fn().mockImplementation((col, val) => {
          return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_configs'));
        }),
      };
      // For general select without order
      const promiseObj = Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_healths'));
      Object.assign(promiseObj, chain);
      return promiseObj;
    }),
    _table: '',
  };

  (globalThis as any).__mockSupabase = {
    from: vi.fn().mockImplementation((table) => {
      queryMockObj._table = table;
      return queryMockObj;
    }),
  };
});

export const setResolver = (fn: any) => {
  (globalThis as any).__activeResolver = fn;
};

vi.mock('@supabase/supabase-js', async (importOriginal) => {
  const actual = await importOriginal() as any;
  return {
    ...actual,
    createClient: (url: string, key: string, options: any) => {
      if ((globalThis as any).__mockSupabase) {
        return (globalThis as any).__mockSupabase;
      }
      return actual.createClient(url, key, options);
    },
  };
});

// Mock dummy Provider for registration testing
class DummyProvider implements AIProvider {
  public readonly rpm = 100;
  public readonly tpm = 50000;
  constructor(
    public readonly providerId: string,
    public readonly modelId: string,
    public readonly metadata: ModelMetadata
  ) {}

  async generate(request: AIProviderRequest): Promise<GenerateResponse> {
    if (request.prompt === 'simulate-timeout') {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    if (request.prompt === 'simulate-auth-error') {
      throw new ProviderAuthenticationError('Simulated invalid token');
    }
    if (request.prompt === 'simulate-validation-error') {
      throw new ProviderValidationError('Simulated validation error');
    }
    if (request.prompt === 'simulate-capability-error') {
      throw new ProviderCapabilityError('Simulated capability error');
    }
    if (request.prompt === 'simulate-unhandled-error') {
      throw new Error('Unhandled network error');
    }

    return {
      content: `Response from ${this.providerId}:${this.modelId} for ${request.prompt}`,
      finishReason: 'STOP',
      usage: { promptTokens: 10, completionTokens: 10, totalTokens: 20 },
      provider: this.providerId,
      model: this.modelId,
      cost: 0.05,
    };
  }

  async generateStream(request: AIProviderRequest): Promise<AsyncIterable<string>> {
    const text = `Stream response from ${this.providerId}`;
    const chunks = text.split(' ');
    return {
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) {
          yield chunk + ' ';
        }
      },
    };
  }

  async healthCheck(): Promise<ProviderHealthStatus> {
    return 'HEALTHY';
  }
}

describe('AI Provider Gateway & Model Abstraction Layer (50 Scenarios)', () => {
  let app: any;
  let repository: AIProviderRepository;
  let service: AIProviderService;
  let gateway: AIGateway;

  const testToken = jwt.sign({ orgId: 'test-workspace-owner-123' }, 'test-jwt-secret');
  const workspaceId = '11111111-1111-1111-1111-111111111111';

  const mockMeta: ModelMetadata = {
    provider: 'GEMINI',
    model: 'gemini-1.5-pro',
    version: 'v1.5',
    contextWindow: 100000,
    maxOutputTokens: 2048,
    supportsStreaming: true,
    supportsVision: true,
    supportsText: true, // Capability Matching support
    supportsImageGeneration: false,
    supportsImageEditing: false,
    supportsEmbedding: true,
    supportsStructuredOutput: true,
    supportsFunctionCalling: true,
    inputCost: 0.00125,
    outputCost: 0.00375,
    enabled: true,
  };

  const sampleConfig: AIProviderConfigEntity = {
    id: 'config-id-1',
    provider: 'GEMINI',
    model: 'gemini-1.5-pro',
    version: 'v1.5',
    priority: 80,
    metadata: mockMeta,
    enabled: true,
    rpm: 100,
    tpm: 50000,
    retry_count: 2,
    timeout_seconds: 30,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const sampleHealth: AIProviderHealthEntity = {
    id: 'health-id-1',
    provider: 'GEMINI',
    model: 'gemini-1.5-pro',
    status: 'HEALTHY',
    failure_count: 0,
    last_checked_at: new Date().toISOString(),
    created_at: new Date().toISOString(),
  };

  beforeAll(async () => {
    app = await createApp();
    repository = new AIProviderRepository((globalThis as any).__mockSupabase as any);
    service = new AIProviderService(repository);
    gateway = new AIGateway(repository);
  });

  beforeEach(() => {
    ProviderRegistry.clear();
    RateLimiter.clear();
    CircuitBreaker.clear();
    ResponseCache.clear();
    ProviderMetricsCollector.clear();
  });

  // Registry & Factory Tests (Scenarios 1-5)
  it('Scenario 1: should register a provider successfully via self registration', () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);
    const resolved = ProviderRegistry.getProvider('GEMINI', 'gemini-1.5-pro');
    expect(resolved).toBe(provider);
  });

  it('Scenario 2: should retrieve all registered providers', () => {
    const provider1 = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    const provider2 = new DummyProvider('OPENAI', 'gpt-4', { ...mockMeta, provider: 'OPENAI', model: 'gpt-4' });
    ProviderRegistry.register(provider1);
    ProviderRegistry.register(provider2);
    const all = ProviderRegistry.getAll();
    expect(all.length).toBe(2);
  });

  it('Scenario 3: should throw ProviderNotFoundError in Factory if provider not registered', () => {
    expect(() => ProviderFactory.create('CLAUDE', 'claude-3-opus')).toThrow(ProviderNotFoundError);
  });

  it('Scenario 4: should create provider instance via factory on matched key', () => {
    const provider = new DummyProvider('CLAUDE', 'claude-3-opus', mockMeta);
    ProviderRegistry.register(provider);
    const resolved = ProviderFactory.create('CLAUDE', 'claude-3-opus');
    expect(resolved).toBe(provider);
  });

  it('Scenario 5: should clear registry completely', () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);
    ProviderRegistry.clear();
    expect(ProviderRegistry.getAll().length).toBe(0);
  });

  // Selector Tests (Scenarios 6-12)
  it('Scenario 6: should select healthy provider matching text capabilities', () => {
    const selected = ProviderSelector.select([sampleConfig], [sampleHealth], [], ['TEXT'], workspaceId);
    expect(selected?.provider).toBe('GEMINI');
  });

  it('Scenario 7: should return null if no provider has the required capabilities', () => {
    const selected = ProviderSelector.select([sampleConfig], [sampleHealth], [], ['IMAGE_GENERATION'], workspaceId);
    expect(selected).toBeNull();
  });

  it('Scenario 8: should override default selector if workspaceOverride matches enabled provider', () => {
    const override = { provider: 'GEMINI', model: 'gemini-1.5-pro' };
    const selected = ProviderSelector.select([sampleConfig], [sampleHealth], [], ['TEXT'], workspaceId, override);
    expect(selected?.provider).toBe('GEMINI');
  });

  it('Scenario 9: should ignore workspace override if targeted provider is disabled', () => {
    const disabledConfig = { ...sampleConfig, enabled: false };
    const override = { provider: 'GEMINI', model: 'gemini-1.5-pro' };
    const selected = ProviderSelector.select([disabledConfig], [sampleHealth], [], ['TEXT'], workspaceId, override);
    expect(selected).toBeNull();
  });

  it('Scenario 10: should sort selectors prioritising HEALTHY over UNAVAILABLE', () => {
    const config1 = { ...sampleConfig, priority: 90, model: 'model-a' };
    const config2 = { ...sampleConfig, priority: 50, model: 'model-b' };
    const health1: AIProviderHealthEntity = { ...sampleHealth, model: 'model-a', status: 'UNAVAILABLE' };
    const health2: AIProviderHealthEntity = { ...sampleHealth, model: 'model-b', status: 'HEALTHY' };

    const selected = ProviderSelector.select([config1, config2], [health1, health2], [], ['TEXT'], workspaceId);
    expect(selected?.model).toBe('model-b'); // model-b is healthy despite lower priority
  });

  it('Scenario 11: should fallback to DEGRADED provider if no HEALTHY provider is available', () => {
    const config1 = { ...sampleConfig, model: 'model-a' };
    const health1: AIProviderHealthEntity = { ...sampleHealth, model: 'model-a', status: 'DEGRADED' };

    const selected = ProviderSelector.select([config1], [health1], [], ['TEXT'], workspaceId);
    expect(selected?.model).toBe('model-a');
  });

  it('Scenario 12: should ignore capability match case-insensitively', () => {
    const config = { ...sampleConfig, metadata: { ...mockMeta, supportsVision: true } };
    const selected = ProviderSelector.select([config], [sampleHealth], [], ['VISION'], workspaceId);
    expect(selected?.provider).toBe('GEMINI');
  });

  // Resolver Tests (Scenarios 13-17)
  it('Scenario 13: should resolve valid provider using ProviderResolver', () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);
    const resolved = ProviderResolver.resolve([sampleConfig], [sampleHealth], [], ['TEXT'], workspaceId);
    expect(resolved).toBe(provider);
  });

  it('Scenario 14: should throw ProviderUnavailableError if status is UNAVAILABLE in health map', () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);
    const unavailableHealth = { ...sampleHealth, status: 'UNAVAILABLE' as ProviderHealthStatus };
    expect(() =>
      ProviderResolver.resolve([sampleConfig], [unavailableHealth], [], ['TEXT'], workspaceId)
    ).toThrow(ProviderUnavailableError);
  });

  it('Scenario 15: should respect priority during resolution', () => {
    const providerA = new DummyProvider('GEMINI', 'model-a', { ...mockMeta, model: 'model-a' });
    const providerB = new DummyProvider('GEMINI', 'model-b', { ...mockMeta, model: 'model-b' });
    ProviderRegistry.register(providerA);
    ProviderRegistry.register(providerB);

    const configA = { ...sampleConfig, model: 'model-a', priority: 50 };
    const configB = { ...sampleConfig, model: 'model-b', priority: 95 };

    const resolved = ProviderResolver.resolve([configA, configB], [sampleHealth], [], ['TEXT'], workspaceId);
    expect(resolved.modelId).toBe('model-b');
  });

  it('Scenario 16: should throw ProviderNotFoundError in resolver if no capabilities match', () => {
    expect(() =>
      ProviderResolver.resolve([sampleConfig], [sampleHealth], [], ['IMAGE_GENERATION'], workspaceId)
    ).toThrow(ProviderNotFoundError);
  });

  it('Scenario 17: should resolve using workspace override parameter', () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);
    const resolved = ProviderResolver.resolve(
      [sampleConfig],
      [sampleHealth],
      [],
      ['TEXT'],
      workspaceId,
      { provider: 'GEMINI', model: 'gemini-1.5-pro' }
    );
    expect(resolved.providerId).toBe('GEMINI');
  });

  // Response Normalizer & Pricing Engine Tests (Scenarios 18-22)
  it('Scenario 18: should normalize response metadata objects successfully', () => {
    const rawUsage = { promptTokens: 100, completionTokens: 50, totalTokens: 150 };
    const normalized = ResponseNormalizer.normalize('test content', 'gemini', 'gemini-1.5-pro', 'stop', rawUsage, 0.05);
    
    expect(normalized.provider).toBe('GEMINI');
    expect(normalized.finishReason).toBe('STOP');
    expect(normalized.cost).toBe(0.05);
  });

  it('Scenario 19: should compute estimated cost using input/output pricing parameters', () => {
    const metadata: ModelMetadata = {
      ...mockMeta,
      inputCost: 0.015,  // $0.015 per 1k tokens
      outputCost: 0.06,  // $0.06 per 1k tokens
    };
    const cost = PricingEngine.calculateCost(1000, 2000, metadata);
    // 1000 tokens input = $0.015. 2000 tokens output = $0.12. Total = $0.135
    expect(cost).toBeCloseTo(0.135, 4);
  });

  it('Scenario 20: should return 0 cost if token parameters are negative', () => {
    const cost = PricingEngine.calculateCost(-10, 50, mockMeta);
    expect(cost).toBe(0);
  });

  it('Scenario 21: should handle NaN and Infinity gracefully inside pricing engine', () => {
    const cost = PricingEngine.calculateCost(NaN, Infinity, mockMeta);
    expect(cost).toBe(0);
  });

  it('Scenario 22: should fall back to sum of prompt and completion tokens if totalTokens is invalid', () => {
    const normalized = ResponseNormalizer.normalize(
      'content',
      'openai',
      'gpt-4',
      'stop',
      { promptTokens: 10, completionTokens: 20, totalTokens: -1 }
    );
    expect(normalized.usage.totalTokens).toBe(30);
  });

  // Response Validator Tests (Scenarios 23-30)
  it('Scenario 23: should pass validation for structurally valid response objects', () => {
    const validResponse: GenerateResponse = {
      content: 'hello',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.02,
    };
    expect(() => ResponseValidator.validate(validResponse)).not.toThrow();
  });

  it('Scenario 24: should throw ResponseValidationError if content is empty', () => {
    const invalidResponse: GenerateResponse = {
      content: '',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.02,
    };
    expect(() => ResponseValidator.validate(invalidResponse)).toThrow(ResponseValidationError);
  });

  it('Scenario 25: should throw InvalidFinishReasonError if finish reason is unsupported', () => {
    const invalidResponse: GenerateResponse = {
      content: 'hello',
      finishReason: 'UNKNOWN_REASON' as any,
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.02,
    };
    expect(() => ResponseValidator.validate(invalidResponse)).toThrow(InvalidFinishReasonError);
  });

  it('Scenario 26: should throw InvalidTokenUsageError if promptTokens is negative', () => {
    const invalidResponse: GenerateResponse = {
      content: 'hello',
      finishReason: 'STOP',
      usage: { promptTokens: -5, completionTokens: 5, totalTokens: 0 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.02,
    };
    expect(() => ResponseValidator.validate(invalidResponse)).toThrow(InvalidTokenUsageError);
  });

  it('Scenario 27: should throw InvalidTokenUsageError if sum of prompt and completion does not match total', () => {
    const invalidResponse: GenerateResponse = {
      content: 'hello',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 25 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.02,
    };
    expect(() => ResponseValidator.validate(invalidResponse)).toThrow(InvalidTokenUsageError);
  });

  it('Scenario 28: should throw ResponseValidationError if cost is negative', () => {
    const invalidResponse: GenerateResponse = {
      content: 'hello',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: -0.01,
    };
    expect(() => ResponseValidator.validate(invalidResponse)).toThrow(ResponseValidationError);
  });

  it('Scenario 29: should pass structured output schema check when required keys exist in JSON content', () => {
    const response: GenerateResponse = {
      content: '{"name": "test", "age": 20}',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.02,
    };
    const schema = {
      type: 'object',
      required: ['name', 'age'],
    };
    expect(() => ResponseValidator.validate(response, schema)).not.toThrow();
  });

  it('Scenario 30: should throw StructuredOutputValidationError if required keys are missing in structured output', () => {
    const response: GenerateResponse = {
      content: '{"name": "test"}', // missing age
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.02,
    };
    const schema = {
      type: 'object',
      required: ['name', 'age'],
    };
    expect(() => ResponseValidator.validate(response, schema)).toThrow(StructuredOutputValidationError);
  });

  // Rate Limiter & Circuit Breaker Tests (Scenarios 31-36)
  it('Scenario 31: should allow requests within RPM limits', () => {
    expect(() => RateLimiter.checkLimit('GEMINI', 'gemini-1.5-pro', 5, 1000, 10)).not.toThrow();
  });

  it('Scenario 32: should throw RateLimitExceededError when RPM limit is hit', () => {
    for (let i = 0; i < 5; i++) {
      RateLimiter.checkLimit('OPENAI', 'gpt-4', 5, 10000, 10);
    }
    expect(() => RateLimiter.checkLimit('OPENAI', 'gpt-4', 5, 10000, 10)).toThrow(RateLimitExceededError);
  });

  it('Scenario 33: should throw RateLimitExceededError when TPM limit is exceeded', () => {
    RateLimiter.checkLimit('CLAUDE', 'claude-3', 10, 100, 90);
    expect(() => RateLimiter.checkLimit('CLAUDE', 'claude-3', 10, 100, 20)).toThrow(RateLimitExceededError);
  });

  it('Scenario 34: should record failure and trip Circuit Breaker to OPEN state after 5 consecutive failures', () => {
    for (let i = 0; i < 5; i++) {
      CircuitBreaker.recordFailure('GEMINI', 'gemini-1.5-pro');
    }
    expect(() => CircuitBreaker.checkCall('GEMINI', 'gemini-1.5-pro')).toThrow(CircuitBreakerOpenError);
  });

  it('Scenario 35: should transit from OPEN to HALF_OPEN after cooldown interval expires', async () => {
    CircuitBreaker.setCooldown(10); // set short cooldown (10ms)
    for (let i = 0; i < 5; i++) {
      CircuitBreaker.recordFailure('OPENAI', 'gpt-4');
    }
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(CircuitBreaker.getState('OPENAI', 'gpt-4')).toBe('HALF_OPEN');
  });

  it('Scenario 36: should reset failure count to 0 and transit to CLOSED on success in HALF_OPEN', () => {
    CircuitBreaker.setCooldown(10);
    for (let i = 0; i < 5; i++) {
      CircuitBreaker.recordFailure('OPENAI', 'gpt-4');
    }
    CircuitBreaker.recordSuccess('OPENAI', 'gpt-4');
    expect(CircuitBreaker.getState('OPENAI', 'gpt-4')).toBe('CLOSED');
  });

  // Response Caching Tests (Scenarios 37-40)
  it('Scenario 37: should write and read from response cache successfully', () => {
    const cachedResponse: GenerateResponse = {
      content: 'cached content',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.01,
    };
    ResponseCache.set('my-prompt', workspaceId, cachedResponse);
    const hit = ResponseCache.get('my-prompt', workspaceId);
    expect(hit?.content).toBe('cached content');
  });

  it('Scenario 38: should return null if response cache TTL has expired', async () => {
    const cachedResponse: GenerateResponse = {
      content: 'expired content',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.01,
    };
    ResponseCache.set('my-prompt-expired', workspaceId, cachedResponse, 2); // 2ms TTL
    await new Promise((resolve) => setTimeout(resolve, 5));
    const hit = ResponseCache.get('my-prompt-expired', workspaceId);
    expect(hit).toBeNull();
  });

  it('Scenario 39: should support deleting individual cache entries', () => {
    const cachedResponse: GenerateResponse = {
      content: 'some content',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.01,
    };
    ResponseCache.set('delete-prompt', workspaceId, cachedResponse);
    ResponseCache.delete('delete-prompt', workspaceId);
    expect(ResponseCache.get('delete-prompt', workspaceId)).toBeNull();
  });

  it('Scenario 40: should clear entire cache list', () => {
    const cachedResponse: GenerateResponse = {
      content: 'content',
      finishReason: 'STOP',
      usage: { promptTokens: 5, completionTokens: 5, totalTokens: 10 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.01,
    };
    ResponseCache.set('prompt-1', workspaceId, cachedResponse);
    ResponseCache.set('prompt-2', workspaceId, cachedResponse);
    ResponseCache.clear();
    expect(ResponseCache.get('prompt-1', workspaceId)).toBeNull();
    expect(ResponseCache.get('prompt-2', workspaceId)).toBeNull();
  });

  // Gateway Orchestration & Chunk Wrapper Tests (Scenarios 41-45)
  it('Scenario 41: should return cached response if hit inside gateway', async () => {
    const cachedResponse: GenerateResponse = {
      content: 'gateway-cached',
      finishReason: 'STOP',
      usage: { promptTokens: 10, completionTokens: 10, totalTokens: 20 },
      provider: 'GEMINI',
      model: 'gemini-1.5-pro',
      cost: 0.05,
    };
    ResponseCache.set('cached-prompt', workspaceId, cachedResponse);

    const res = await gateway.generate({ prompt: 'cached-prompt', workspaceId });
    expect(res.content).toBe('gateway-cached');
  });

  it('Scenario 42: should wrap non-streaming provider into chunked async iterator', async () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', { ...mockMeta, supportsStreaming: false });
    ProviderRegistry.register(provider);

    setResolver(() => Promise.resolve({ data: [sampleConfig], error: null }));

    const stream = await gateway.generateStream({ prompt: 'stream-me', workspaceId }, { provider: 'GEMINI', model: 'gemini-1.5-pro' });
    const chunks: string[] = [];
    for await (const chunk of stream) {
      chunks.push(chunk);
    }
    expect(chunks.join('')).toContain('gemini-1.5-pro');
  });

  it('Scenario 43: should throw FallbackFailedError on Gateway generate call when retry limit is exceeded', async () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);

    setResolver((table) => {
      if (table === 'ai_provider_configs') {
        return Promise.resolve({ data: [sampleConfig], error: null });
      }
      return Promise.resolve({ data: null, error: null });
    });

    await expect(
      gateway.generate({ prompt: 'simulate-unhandled-error', workspaceId })
    ).rejects.toThrow(FallbackFailedError);
  });

  it('Scenario 44: should throw ValidationError immediately without retry', async () => {
    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);

    setResolver(() => Promise.resolve({ data: [sampleConfig], error: null }));

    await expect(
      gateway.generate({ prompt: 'simulate-validation-error', workspaceId })
    ).rejects.toThrow(ProviderValidationError);
  });

  it('Scenario 45: should trigger domain hooks for Selected and Called tracking', async () => {
    const selectSpy = vi.spyOn(AIProviderHooks, 'onProviderSelected');
    const callSpy = vi.spyOn(AIProviderHooks, 'onProviderCalled');

    const provider = new DummyProvider('GEMINI', 'gemini-1.5-pro', mockMeta);
    ProviderRegistry.register(provider);

    setResolver(() => Promise.resolve({ data: [sampleConfig], error: null }));

    await gateway.generate({ prompt: 'hook-prompt', workspaceId });
    expect(selectSpy).toHaveBeenCalled();
  });

  // REST API Endpoints Tests (Scenarios 46-50)
  it('Scenario 46: should return 200 and list configs on GET /api/v1/providers', async () => {
    setResolver(() => Promise.resolve({ data: [sampleConfig], error: null }));

    const response = await app.inject({
      method: 'GET',
      url: '/api/v1/providers',
      headers: { authorization: `Bearer ${testToken}` },
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.payload);
    expect(body.data[0].provider).toBe('GEMINI');
  });

  it('Scenario 47: should return 200 and list models on GET /api/v1/providers/models', async () => {
    setResolver(() => Promise.resolve({ data: [sampleConfig], error: null }));

    const response = await app.inject({
      method: 'GET',
      url: '/api/v1/providers/models',
      headers: { authorization: `Bearer ${testToken}` },
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.payload);
    expect(body.data[0].model).toBe('gemini-1.5-pro');
  });

  it('Scenario 48: should return 200 and health list on GET /api/v1/providers/health', async () => {
    setResolver((table) => {
      if (table === 'ai_provider_health') {
        return Promise.resolve({ data: [sampleHealth], error: null });
      }
      return Promise.resolve({ data: [], error: null });
    });

    const response = await app.inject({
      method: 'GET',
      url: '/api/v1/providers/health',
      headers: { authorization: `Bearer ${testToken}` },
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.payload);
    expect(body.data[0].status).toBe('HEALTHY');
  });

  it('Scenario 49: should trigger batch health check and return 200 on POST /api/v1/providers/health-check', async () => {
    setResolver(() => Promise.resolve({ data: [sampleConfig], error: null }));

    const response = await app.inject({
      method: 'POST',
      url: '/api/v1/providers/health-check',
      headers: { authorization: `Bearer ${testToken}` },
    });

    expect(response.statusCode).toBe(200);
  });

  it('Scenario 50: should update provider config priority via PATCH /api/v1/providers/configs/:provider/:model', async () => {
    setResolver((table, action, payload) => {
      if (action === 'update') {
        return Promise.resolve({ data: { ...sampleConfig, priority: 99 }, error: null });
      }
      return Promise.resolve({ data: null, error: null });
    });

    const response = await app.inject({
      method: 'PATCH',
      url: '/api/v1/providers/configs/gemini/gemini-1.5-pro',
      headers: { authorization: `Bearer ${testToken}` },
      payload: { priority: 99 },
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.payload);
    expect(body.data.priority).toBe(99);
  });
});
