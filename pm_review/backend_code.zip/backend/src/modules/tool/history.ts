import { ToolExecutionHistoryEntity, ApprovalAuditLogEntity } from './types.js';

export class ToolExecutionHistoryCollector {
  private static readonly historyBuffer: ToolExecutionHistoryEntity[] = [];

  static record(entity: ToolExecutionHistoryEntity): void {
    this.historyBuffer.push(entity);
    if (this.historyBuffer.length > 500) {
      this.historyBuffer.shift();
    }
  }

  static getHistory(): ToolExecutionHistoryEntity[] {
    return [...this.historyBuffer];
  }

  static clear(): void {
    this.historyBuffer.length = 0;
  }
}

export class ApprovalAuditCollector {
  private static readonly auditBuffer: ApprovalAuditLogEntity[] = [];

  static record(entity: ApprovalAuditLogEntity): void {
    this.auditBuffer.push(entity);
    if (this.auditBuffer.length > 500) {
      this.auditBuffer.shift();
    }
  }

  static getAudits(): ApprovalAuditLogEntity[] {
    return [...this.auditBuffer];
  }

  static clear(): void {
    this.auditBuffer.length = 0;
  }
}
export default ToolExecutionHistoryCollector;
