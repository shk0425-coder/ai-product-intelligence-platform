import { SupabaseClient } from '@supabase/supabase-js';
import { ToolDefinitionEntity, ToolVersionEntity, ToolExecutionHistoryEntity, ApprovalRequestEntity, ApprovalAuditLogEntity } from './types.js';

export class ToolRepository {
  constructor(private readonly supabase: SupabaseClient) {}

  async findTools(): Promise<ToolDefinitionEntity[]> {
    const { data, error } = await this.supabase
      .from('tool_definitions')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) return [];
    return (data || []) as ToolDefinitionEntity[];
  }

  async findToolById(id: string): Promise<ToolDefinitionEntity | null> {
    const { data, error } = await this.supabase
      .from('tool_definitions')
      .select('*')
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) return null;
    return data as ToolDefinitionEntity;
  }

  async createTool(entity: Omit<ToolDefinitionEntity, 'id' | 'created_at' | 'updated_at'>): Promise<ToolDefinitionEntity | null> {
    const { data, error } = await this.supabase
      .from('tool_definitions')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as ToolDefinitionEntity;
  }

  async updateTool(id: string, payload: Partial<ToolDefinitionEntity>): Promise<ToolDefinitionEntity | null> {
    const { data, error } = await this.supabase
      .from('tool_definitions')
      .update({
        ...payload,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select('*')
      .maybeSingle();

    if (error) return null;
    return data as ToolDefinitionEntity;
  }

  async createVersion(entity: Omit<ToolVersionEntity, 'id' | 'created_at'>): Promise<ToolVersionEntity | null> {
    const { data, error } = await this.supabase
      .from('tool_versions')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as ToolVersionEntity;
  }

  async findVersionById(id: string): Promise<ToolVersionEntity | null> {
    const { data, error } = await this.supabase
      .from('tool_versions')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) return null;
    return data as ToolVersionEntity;
  }

  async findVersionsByToolId(toolId: string): Promise<ToolVersionEntity[]> {
    const { data, error } = await this.supabase
      .from('tool_versions')
      .select('*')
      .eq('tool_id', toolId)
      .order('version', { ascending: false });

    if (error) return [];
    return (data || []) as ToolVersionEntity[];
  }

  async createExecutionHistory(entity: Omit<ToolExecutionHistoryEntity, 'id' | 'created_at'>): Promise<ToolExecutionHistoryEntity | null> {
    const { data, error } = await this.supabase
      .from('tool_execution_history')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as ToolExecutionHistoryEntity;
  }

  async findExecutionHistories(): Promise<ToolExecutionHistoryEntity[]> {
    const { data, error } = await this.supabase
      .from('tool_execution_history')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) return [];
    return (data || []) as ToolExecutionHistoryEntity[];
  }

  async createApprovalRequest(entity: Omit<ApprovalRequestEntity, 'id' | 'created_at'>): Promise<ApprovalRequestEntity | null> {
    const { data, error } = await this.supabase
      .from('approval_requests')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as ApprovalRequestEntity;
  }

  async findApprovalById(id: string): Promise<ApprovalRequestEntity | null> {
    const { data, error } = await this.supabase
      .from('approval_requests')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) return null;
    return data as ApprovalRequestEntity;
  }

  async updateApproval(id: string, payload: Partial<ApprovalRequestEntity>): Promise<ApprovalRequestEntity | null> {
    const { data, error } = await this.supabase
      .from('approval_requests')
      .update(payload)
      .eq('id', id)
      .select('*')
      .maybeSingle();

    if (error) return null;
    return data as ApprovalRequestEntity;
  }

  async findApprovals(): Promise<ApprovalRequestEntity[]> {
    const { data, error } = await this.supabase
      .from('approval_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) return [];
    return (data || []) as ApprovalRequestEntity[];
  }

  async createApprovalAudit(entity: Omit<ApprovalAuditLogEntity, 'id' | 'created_at'>): Promise<ApprovalAuditLogEntity | null> {
    const { data, error } = await this.supabase
      .from('approval_audit_logs')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as ApprovalAuditLogEntity;
  }
}
export default ToolRepository;
