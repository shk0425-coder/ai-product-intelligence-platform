import { MetricsRegistry } from '../../observability/metrics/registry.js';

export type BreakerState = 'Closed' | 'Open' | 'HalfOpen';

export class CircuitBreaker {
  private static state: BreakerState = 'Closed';
  private static failureCount = 0;
  private static threshold = 3; // Trigger Open on 3 consecutive failures
  private static lastStateChange = Date.now();

  static getState(): BreakerState {
    return this.state;
  }

  static recordSuccess(): void {
    this.failureCount = 0;
    if (this.state === 'HalfOpen') {
      this.transitionTo('Closed');
    }
  }

  static recordFailure(): void {
    this.failureCount++;
    if (this.failureCount >= this.threshold && this.state !== 'Open') {
      this.transitionTo('Open');
    }
  }

  private static transitionTo(newState: BreakerState): void {
    this.state = newState;
    this.lastStateChange = Date.now();

    MetricsRegistry.counter('circuit_breaker_open_total', newState === 'Open' ? 1 : 0);
    MetricsRegistry.gauge('circuit_breaker_state', newState === 'Open' ? 1 : newState === 'HalfOpen' ? 0.5 : 0);
  }

  static attemptRemediation(): boolean {
    if (this.state === 'Open') {
      const now = Date.now();
      // Emulate 100ms cooldown for test fast-failover
      if (now - this.lastStateChange > 100) {
        this.transitionTo('HalfOpen');
        return true; // Allow attempt
      }
      return false; // Remain blocked
    }
    return true; // Closed or HalfOpen permits attempts
  }

  static clear(): void {
    this.state = 'Closed';
    this.failureCount = 0;
    this.lastStateChange = Date.now();
  }
}
export default CircuitBreaker;
