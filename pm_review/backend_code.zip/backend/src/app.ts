import Fastify, { FastifyInstance } from 'fastify';
import sensible from '@fastify/sensible';
import { loggerConfig } from '@/config/logger.js';
import { errorHandler } from '@/middleware/error-handler.js';
import { API_PREFIX } from '@/common/constants/index.js';
import { authMiddleware } from '@/middleware/auth.middleware.js';
import { successResponse } from '@/common/responses/index.js';

// Import Plugins
import corsPlugin from '@/plugins/cors.js';
import loggerPlugin from '@/plugins/logger.js';
import supabasePlugin from '@/plugins/supabase.js';

// Import Routes
import healthRoutes from '@/routes/v1/health.js';
import authRoutes from '@/modules/auth/route.js';
import workspaceRoutes from '@/modules/workspace/route.js';
import marketRoutes from '@/modules/market/route.js';
import reviewRoutes from '@/modules/review/route.js';
import aiRoutes from '@/modules/ai/route.js';
import performanceRoutes from '@/modules/performance/route.js';
import feedbackRoutes from '@/modules/feedback/route.js';
import feedbackIntelligenceRoutes from '@/modules/feedback-intelligence/route.js';
import closedLoopLearningRoutes from '@/modules/closed-loop-learning/route.js';
import closedLoopProductionRoutes from '@/modules/production-automation/route.js';
import { jobQueueRoutes } from '@/modules/job-queue/index.js';
import { aiProviderRoutes } from '@/modules/ai-provider/index.js';
import { promptRoutes } from '@/modules/prompt/index.js';
import { workflowRoutes } from '@/modules/workflow/index.js';
import { toolRoutes, approvalRoutes } from '@/modules/tool/index.js';
import { systemRoutes } from '@/modules/infrastructure/index.js';
import { validateWeights } from '@/modules/feedback/weights.js';
import { monitoringRoutes, observabilityMiddleware, observabilityResponseMiddleware } from '@/modules/observability/index.js';
import { schedulerRoutes } from '@/modules/scheduler/index.js';
import { resilienceRoutes } from '@/modules/resilience/index.js';
import { operationsRoutes, capabilityRoutes } from '@/modules/operations/index.js';

export const createApp = async (): Promise<FastifyInstance> => {
  // Run boot-blocking validation on feedback weights sum
  validateWeights();

  const app = Fastify({
    logger: loggerConfig,
    disableRequestLogging: true, // Custom request logging is handled in loggerPlugin
  });

  // Register Observability Hooks
  app.addHook('onRequest', observabilityMiddleware);
  app.addHook('onResponse', observabilityResponseMiddleware);

  // Register Fastify Sensible for HTTP errors and utility responses
  await app.register(sensible);

  // Register Plugins
  await app.register(corsPlugin);
  await app.register(loggerPlugin);
  await app.register(supabasePlugin);

  // Register Global Error Handler
  app.setErrorHandler(errorHandler);

  // Register API Routes
  await app.register(healthRoutes, { prefix: API_PREFIX });
  await app.register(authRoutes, { prefix: `${API_PREFIX}/auth` });
  await app.register(workspaceRoutes, { prefix: `${API_PREFIX}/workspaces` });
  await app.register(marketRoutes, { prefix: `${API_PREFIX}/markets` });
  await app.register(reviewRoutes, { prefix: `${API_PREFIX}/reviews` });
  // Register AI Review Analysis Routes (analyze, query results)
  await app.register(aiRoutes, { prefix: `${API_PREFIX}/reviews` });
  // Register Performance Domain Routes
  await app.register(performanceRoutes, { prefix: `${API_PREFIX}/performance` });
  // Register Feedback Domain Routes
  await app.register(feedbackRoutes, { prefix: `${API_PREFIX}/feedback` });
  // Register Feedback Intelligence Domain Routes
  await app.register(feedbackIntelligenceRoutes, { prefix: `${API_PREFIX}/feedback-intelligence` });
  // Register Closed-loop Learning Domain Routes
  await app.register(closedLoopLearningRoutes, { prefix: `${API_PREFIX}/learning` });
  // Register Production Automation Domain Routes
  await app.register(closedLoopProductionRoutes, { prefix: `${API_PREFIX}/production` });
  await app.register(jobQueueRoutes, { prefix: `${API_PREFIX}/jobs` });
  await app.register(aiProviderRoutes, { prefix: `${API_PREFIX}/providers` });
  await app.register(promptRoutes, { prefix: `${API_PREFIX}/prompts` });
  await app.register(workflowRoutes, { prefix: `${API_PREFIX}/workflows` });
  await app.register(toolRoutes, { prefix: `${API_PREFIX}/tools` });
  await app.register(approvalRoutes, { prefix: `${API_PREFIX}/approvals` });
  await app.register(systemRoutes, { prefix: `${API_PREFIX}/system` });
  await app.register(monitoringRoutes, { prefix: `${API_PREFIX}/monitoring` });
  await app.register(schedulerRoutes, { prefix: `${API_PREFIX}/scheduler` });
  await app.register(resilienceRoutes, { prefix: `${API_PREFIX}/resilience` });
  await app.register(operationsRoutes, { prefix: `${API_PREFIX}/operations` });
  await app.register(capabilityRoutes, { prefix: `${API_PREFIX}/system` });

  // Test Protected Route for Verification
  app.get(`${API_PREFIX}/protected`, { preHandler: authMiddleware }, async (request, _reply) => {
    return successResponse({ user: request.user });
  });

  return app;
};
export default createApp;
