import { pino } from 'pino';
import { ProductionEventPayload, IProductionHooks } from './types.js';

const logger = pino();

export const ProductionHooks: IProductionHooks = {
  async onProductionAutomationStarted(payload: ProductionEventPayload): Promise<void> {
    logger.info(
      {
        automationId: payload.automationId,
        workspaceId: payload.workspaceId,
        status: payload.status,
      },
      'Domain Hook [ProductionAutomationStarted] triggered',
    );
  },

  async onPlannerStarted(payload: { automationId: string; timestamp: string }): Promise<void> {
    logger.info(
      {
        automationId: payload.automationId,
        timestamp: payload.timestamp,
      },
      'Domain Hook [PlannerStarted] triggered',
    );
  },

  async onPlannerCompleted(payload: {
    automationId: string;
    strategyId: string;
    timestamp: string;
  }): Promise<void> {
    logger.info(
      {
        automationId: payload.automationId,
        strategyId: payload.strategyId,
        timestamp: payload.timestamp,
      },
      'Domain Hook [PlannerCompleted] triggered',
    );
  },

  async onProductionCompleted(payload: ProductionEventPayload): Promise<void> {
    logger.info(
      {
        automationId: payload.automationId,
        workspaceId: payload.workspaceId,
        status: payload.status,
      },
      'Domain Hook [ProductionCompleted] triggered',
    );
  },
};
export default ProductionHooks;
