export interface EnqueueJobDto {
  workspaceId: string;
  jobType: string;
  payload: Record<string, unknown>;
  priority?: number;
  scheduledAt?: string;
}

export interface JobActionDto {
  jobId: string;
}

export interface JobQueueDto {
  jobId: string;
  workspaceId: string;
  jobType: string;
  priority: number;
  payload: Record<string, unknown>;
  payloadVersion: string;
  status: 'PENDING' | 'QUEUED' | 'RUNNING' | 'SUCCESS' | 'FAILED';
  retryCount: number;
  maxRetry: number;
  leaseOwner?: string | null;
  leaseUntil?: string | null;
  heartbeatAt?: string | null;
  cancelRequested: boolean;
  scheduledAt: string;
  startedAt?: string | null;
  completedAt?: string | null;
  errorMessage?: string | null;
  createdAt: string;
  updatedAt: string;
}
