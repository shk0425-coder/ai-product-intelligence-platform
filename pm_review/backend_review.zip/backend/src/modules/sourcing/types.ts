export interface SourcingPlaceholder {}
