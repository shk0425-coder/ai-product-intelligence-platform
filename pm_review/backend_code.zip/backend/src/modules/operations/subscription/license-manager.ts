export type LicenseTier = 'Starter' | 'Pro' | 'Enterprise';

export class LicenseManager {
  private static tier: LicenseTier = 'Starter';

  static getTier(): LicenseTier {
    return this.tier;
  }

  static setTier(newTier: LicenseTier): void {
    this.tier = newTier;
  }

  static isFeatureAllowed(featureName: string): boolean {
    if (this.tier === 'Enterprise') {
      return true; // All features unlocked
    }

    if (this.tier === 'Pro') {
      return featureName !== 'advanced_disaster_recovery'; // Pro blocks DR
    }

    // Starter tier blocks both premium analysis and DR
    return featureName !== 'ai_advanced_analysis' && featureName !== 'advanced_disaster_recovery';
  }

  static clear(): void {
    this.tier = 'Starter';
  }
}
export default LicenseManager;
