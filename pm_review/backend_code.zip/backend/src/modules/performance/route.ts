import { FastifyInstance, FastifyPluginOptions, FastifyRequest } from 'fastify';
import { PerformanceRepository } from './repository.js';
import { PerformanceService } from './service.js';
import { PerformanceController } from './controller.js';
import { authMiddleware } from '@/middleware/auth.middleware.js';
import {
  createPerformanceSchema,
  updatePerformanceSchema,
  performanceIdParamSchema,
  performanceProductParamSchema,
  performanceAnalysisParamSchema,
  performanceHistoryQuerySchema,
  performanceQuerySchema,
} from './schema.js';
import { ValidationError } from '@/common/errors/index.js';
import { z } from 'zod';

const validateBody =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.body);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.body = result.data;
  };

const validateParams =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.params);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.params = result.data;
  };

const validateQuery =
  <T extends z.ZodTypeAny>(schema: T) =>
  async (request: FastifyRequest) => {
    const result = schema.safeParse(request.query);
    if (!result.success) {
      const message = result.error.errors
        .map((e) => `${e.path.join('.')}: ${e.message}`)
        .join(', ');
      throw new ValidationError(message);
    }
    request.query = result.data;
  };

export default async function performanceRoutes(
  fastify: FastifyInstance,
  _options: FastifyPluginOptions,
): Promise<void> {
  const repository = new PerformanceRepository(fastify.supabase);
  const service = new PerformanceService(repository);
  const controller = new PerformanceController(service);

  // Apply authorization middleware globally to this router group
  fastify.addHook('preHandler', authMiddleware);

  // POST / - Create or Upsert
  fastify.post('/', {
    preValidation: validateBody(createPerformanceSchema),
    handler: controller.upsert,
  });

  // PUT /:id - Update
  fastify.put('/:id', {
    preValidation: [
      validateParams(performanceIdParamSchema),
      validateBody(updatePerformanceSchema),
    ],
    handler: controller.update,
  });

  // GET /:id - Single record lookup
  fastify.get('/:id', {
    preValidation: validateParams(performanceIdParamSchema),
    handler: controller.findById,
  });

  // GET /product/:productId - Pagination list by product
  fastify.get('/product/:productId', {
    preValidation: [
      validateParams(performanceProductParamSchema),
      validateQuery(performanceQuerySchema),
    ],
    handler: controller.findByProduct,
  });

  // GET /analysis/:analysisRunId - Lookup by Analysis Run ID
  fastify.get('/analysis/:analysisRunId', {
    preValidation: validateParams(performanceAnalysisParamSchema),
    handler: controller.findByAnalysis,
  });

  // GET /history/:productId - Period filtering and pagination lookup
  fastify.get('/history/:productId', {
    preValidation: [
      validateParams(performanceProductParamSchema),
      validateQuery(performanceHistoryQuerySchema),
    ],
    handler: controller.findByPeriod,
  });

  // GET /latest/:productId - Retrieve latest snapshot
  fastify.get('/latest/:productId', {
    preValidation: validateParams(performanceProductParamSchema),
    handler: controller.findLatest,
  });

  // DELETE /:id - Soft Delete
  fastify.delete('/:id', {
    preValidation: validateParams(performanceIdParamSchema),
    handler: controller.delete,
  });
}
