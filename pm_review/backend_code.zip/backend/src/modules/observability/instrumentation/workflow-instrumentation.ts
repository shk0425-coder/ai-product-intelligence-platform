import { TraceManager, Span } from '../tracing/trace-manager.js';
import { WorkflowMetricsCollector } from '../metrics/collector/workflow-collector.js';

export class WorkflowInstrumentation {
  static startWorkflow(workflowName: string, workspaceId: string): Span {
    const span = TraceManager.startSpan(`Workflow ${workflowName}`);
    span.setAttribute('workflow.name', workflowName);
    span.setAttribute('workspace_id', workspaceId);

    WorkflowMetricsCollector.recordWorkflowStart(workflowName, workspaceId);
    return span;
  }

  static endWorkflow(span: Span, workflowName: string, durationMs: number, workspaceId: string, success = true): void {
    span.setStatus(success ? 'OK' : 'ERROR');
    span.end();

    if (success) {
      WorkflowMetricsCollector.recordWorkflowCompletion(workflowName, durationMs, workspaceId);
    } else {
      WorkflowMetricsCollector.recordWorkflowFailure(workflowName, workspaceId);
    }
  }
}
