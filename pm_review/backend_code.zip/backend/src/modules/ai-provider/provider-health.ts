import { ProviderHealthStatus } from './types.js';

export class ProviderHealthChecker {
  private static intervalId: NodeJS.Timeout | null = null;
  private static isChecking = false;

  static async runBatchCheck(repository: import('./repository.js').AIProviderRepository): Promise<void> {
    if (this.isChecking) return;
    this.isChecking = true;

    try {
      const configs = await repository.findConfigs();
      for (const config of configs) {
        // Simple ping simulation or calling provider.healthCheck()
        let status: ProviderHealthStatus = 'HEALTHY';
        if (!config.enabled) {
          status = 'UNAVAILABLE';
        }
        
        await repository.updateHealth(config.provider, config.model, {
          status,
          failure_count: 0,
          last_checked_at: new Date().toISOString(),
        });
      }
    } catch (_err) {
      // Suppress daemon exceptions
    } finally {
      this.isChecking = false;
    }
  }

  static startDaemon(repository: import('./repository.js').AIProviderRepository, intervalMs: number = 60000): void {
    if (this.intervalId) return;
    this.intervalId = setInterval(() => this.runBatchCheck(repository), intervalMs);
  }

  static stopDaemon(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }
}
