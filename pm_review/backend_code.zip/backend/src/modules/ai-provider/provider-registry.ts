import { AIProvider, AIProviderRequest, GenerateResponse, ModelMetadata, ProviderHealthStatus } from './types.js';
import {
  GeminiProviderAdapter,
  OpenAIProviderAdapter,
  ClaudeProviderAdapter,
  LocalLLMProviderAdapter,
} from './provider-adapter.js';

export class GeneralAIProvider implements AIProvider {
  constructor(
    public readonly providerId: string,
    public readonly modelId: string,
    public readonly metadata: ModelMetadata,
    public readonly rpm: number = 60,
    public readonly tpm: number = 40000,
    private readonly adapter: import('./types.js').AIProviderAdapter
  ) {}

  async generate(request: AIProviderRequest): Promise<GenerateResponse> {
    return this.adapter.generate(request, this.metadata);
  }

  async generateStream(request: AIProviderRequest): Promise<AsyncIterable<string>> {
    return this.adapter.generateStream(request, this.metadata);
  }

  async healthCheck(): Promise<ProviderHealthStatus> {
    return 'HEALTHY';
  }
}

export class ProviderRegistry {
  private static readonly providers = new Map<string, AIProvider>();

  static register(provider: AIProvider): void {
    const key = `${provider.providerId}:${provider.modelId}`.toUpperCase();
    this.providers.set(key, provider);
  }

  static getProvider(providerId: string, modelId: string): AIProvider | undefined {
    const key = `${providerId}:${modelId}`.toUpperCase();
    return this.providers.get(key);
  }

  static getAll(): AIProvider[] {
    return Array.from(this.providers.values());
  }

  static clear(): void {
    this.providers.clear();
  }
}

// Self-registration on startup
const dummyMeta: ModelMetadata = {
  provider: 'GEMINI',
  model: 'gemini-1.5-pro',
  version: 'v1.5',
  contextWindow: 100000,
  maxOutputTokens: 2048,
  supportsStreaming: true,
  supportsVision: true,
  supportsText: true,
  supportsImageGeneration: false,
  supportsImageEditing: false,
  supportsEmbedding: true,
  supportsStructuredOutput: true,
  supportsFunctionCalling: true,
  inputCost: 0.00125,
  outputCost: 0.00375,
  enabled: true,
};

ProviderRegistry.register(
  new GeneralAIProvider('GEMINI', 'gemini-1.5-pro', dummyMeta, 100, 50000, new GeminiProviderAdapter())
);
ProviderRegistry.register(
  new GeneralAIProvider(
    'OPENAI',
    'gpt-4',
    { ...dummyMeta, provider: 'OPENAI', model: 'gpt-4' },
    120,
    60000,
    new OpenAIProviderAdapter()
  )
);
ProviderRegistry.register(
  new GeneralAIProvider(
    'CLAUDE',
    'claude-3-opus',
    { ...dummyMeta, provider: 'CLAUDE', model: 'claude-3-opus' },
    80,
    40000,
    new ClaudeProviderAdapter()
  )
);
ProviderRegistry.register(
  new GeneralAIProvider(
    'LOCAL_LLM',
    'local-llama',
    { ...dummyMeta, provider: 'LOCAL_LLM', model: 'local-llama', supportsStreaming: false },
    9999,
    999999,
    new LocalLLMProviderAdapter()
  )
);
