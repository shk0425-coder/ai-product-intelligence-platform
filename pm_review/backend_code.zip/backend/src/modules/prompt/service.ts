import crypto from 'crypto';
import { PromptRepository } from './repository.js';
import { AIGateway } from '../ai-provider/gateway.js';
import { GenerateResponse } from '../ai-provider/types.js';
import { CreatePromptTemplateDto, CreatePromptVersionDto, RenderPromptDto, PreviewPromptDto, RenderPromptResponseDto } from './dto.js';
import { PromptTemplateEntity, PromptVersionEntity } from './types.js';
import { PromptRenderer } from './renderer.js';
import { PromptPreviewer } from './preview.js';
import { PromptRegistry } from './registry.js';
import { promptCache } from './cache.js';
import { PromptHistoryCollector } from './history.js';
import { PromptHooks } from './hooks.js';
import { VariableParser } from './variable-parser.js';
import { ValidationError } from '../../common/errors/index.js';

export class PromptService {
  private readonly gateway: AIGateway;

  constructor(
    private readonly repository: PromptRepository,
    gatewayInstance: AIGateway
  ) {
    this.gateway = gatewayInstance;
  }

  async getTemplates(): Promise<PromptTemplateEntity[]> {
    return this.repository.findTemplates();
  }

  async getTemplateById(id: string): Promise<PromptTemplateEntity> {
    const template = await this.repository.findTemplateById(id);
    if (!template) {
      throw new ValidationError(`Prompt template not found for id: ${id}`);
    }
    return template;
  }

  async createTemplate(dto: CreatePromptTemplateDto): Promise<PromptTemplateEntity> {
    // 1. Create Template Entity
    const templatePayload: Omit<PromptTemplateEntity, 'id' | 'created_at' | 'updated_at'> = {
      workspace_id: dto.workspaceId,
      category: dto.category,
      name: dto.name,
      description: dto.description,
      latest_version: 1,
      status: 'DRAFT',
      model_capability: dto.modelCapability || 'TEXT',
      default_provider: dto.defaultProvider || 'GEMINI',
      default_model: dto.defaultModel || 'gemini-1.5-pro',
      temperature: dto.temperature !== undefined ? dto.temperature : 0.7,
      top_p: dto.topP !== undefined ? dto.topP : 0.9,
      max_tokens: dto.maxTokens !== undefined ? dto.maxTokens : 2048,
      response_schema: dto.responseSchema,
      variables: [],
      tags: dto.tags || [],
    };

    const template = await this.repository.createTemplate(templatePayload);
    if (!template) {
      throw new ValidationError('Failed to create prompt template');
    }

    // 2. Parse Variables from prompts
    const parsedSys = VariableParser.parse(dto.systemPrompt);
    const parsedUser = VariableParser.parse(dto.userPrompt);
    const uniqueVars = Array.from(new Set([...parsedSys, ...parsedUser].map((v) => v.name)));

    // 3. Create Version 1
    const checksum = crypto.createHash('sha256').update(dto.systemPrompt + dto.userPrompt).digest('hex');
    const versionPayload: Omit<PromptVersionEntity, 'id' | 'created_at'> = {
      template_id: template.id,
      version: 1,
      system_prompt: dto.systemPrompt,
      user_prompt: dto.userPrompt,
      change_summary: 'Initial creation',
      variables: uniqueVars,
      checksum,
    };

    const version = await this.repository.createVersion(versionPayload);
    if (!version) {
      throw new ValidationError('Failed to create initial prompt version');
    }

    // Link template to version
    const updated = await this.repository.updateTemplate(template.id, {
      current_version_id: version.id,
      variables: uniqueVars,
    });

    const finalTemplate = updated || template;

    // Cache lookup registry
    PromptRegistry.cacheTemplate(finalTemplate);
    PromptRegistry.cacheVersion(version);

    await PromptHooks.onPromptCreated(finalTemplate.id, finalTemplate.workspace_id);
    await PromptHooks.onVersionGenerated(finalTemplate.id, version.id, 1);

    // Log Audit trail
    await this.repository.createAuditLog({
      workspace_id: finalTemplate.workspace_id,
      template_id: finalTemplate.id,
      action: 'CREATE',
      after: finalTemplate as unknown as Record<string, unknown>,
    });

    return finalTemplate;
  }

  async createVersion(templateId: string, dto: CreatePromptVersionDto): Promise<PromptVersionEntity> {
    const template = await this.getTemplateById(templateId);

    const nextVer = template.latest_version + 1;
    const parsedSys = VariableParser.parse(dto.systemPrompt);
    const parsedUser = VariableParser.parse(dto.userPrompt);
    const uniqueVars = Array.from(new Set([...parsedSys, ...parsedUser].map((v) => v.name)));

    const checksum = crypto.createHash('sha256').update(dto.systemPrompt + dto.userPrompt).digest('hex');
    const versionPayload: Omit<PromptVersionEntity, 'id' | 'created_at'> = {
      template_id: templateId,
      version: nextVer,
      system_prompt: dto.systemPrompt,
      user_prompt: dto.userPrompt,
      change_summary: dto.changeSummary,
      variables: uniqueVars,
      checksum,
    };

    const version = await this.repository.createVersion(versionPayload);
    if (!version) {
      throw new ValidationError('Failed to create version');
    }

    // Automatically transition back to DRAFT state on template content modify
    const updated = await this.repository.updateTemplate(templateId, {
      latest_version: nextVer,
      current_version_id: version.id,
      status: 'DRAFT',
      variables: uniqueVars,
    });

    PromptRegistry.cacheTemplate(updated || template);
    PromptRegistry.cacheVersion(version);

    await PromptHooks.onVersionGenerated(templateId, version.id, nextVer);

    await this.repository.createAuditLog({
      workspace_id: template.workspace_id,
      template_id: templateId,
      action: 'VERSION_UP',
      before: template as unknown as Record<string, unknown>,
      after: (updated || template) as unknown as Record<string, unknown>,
    });

    return version;
  }

  async approveTemplate(id: string, approvedBy: string): Promise<PromptTemplateEntity> {
    const template = await this.getTemplateById(id);
    const updated = await this.repository.updateTemplate(id, {
      status: 'APPROVED',
      approved_by: approvedBy,
      approved_at: new Date().toISOString(),
    });

    if (!updated) {
      throw new ValidationError('Failed to approve template');
    }

    PromptRegistry.cacheTemplate(updated);
    await PromptHooks.onPromptApproved(id, approvedBy);

    await this.repository.createAuditLog({
      workspace_id: template.workspace_id,
      template_id: id,
      action: 'APPROVE',
      before: template as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async reviewTemplate(id: string): Promise<PromptTemplateEntity> {
    const template = await this.getTemplateById(id);
    const updated = await this.repository.updateTemplate(id, {
      status: 'REVIEW',
    });

    if (!updated) {
      throw new ValidationError('Failed to transit to REVIEW');
    }

    PromptRegistry.cacheTemplate(updated);

    await this.repository.createAuditLog({
      workspace_id: template.workspace_id,
      template_id: id,
      action: 'REVIEW',
      before: template as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async deprecateTemplate(id: string): Promise<PromptTemplateEntity> {
    const template = await this.getTemplateById(id);
    const updated = await this.repository.updateTemplate(id, {
      status: 'DEPRECATED',
    });

    if (!updated) {
      throw new ValidationError('Failed to deprecate template');
    }

    PromptRegistry.cacheTemplate(updated);

    await this.repository.createAuditLog({
      workspace_id: template.workspace_id,
      template_id: id,
      action: 'DEPRECATE',
      before: template as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async rollbackTemplateVersion(id: string, versionId: string): Promise<PromptTemplateEntity> {
    const template = await this.getTemplateById(id);
    const version = await this.repository.findVersionById(versionId);
    if (!version || version.template_id !== id) {
      throw new ValidationError(`Version not found or mismatch for versionId: ${versionId}`);
    }

    const updated = await this.repository.updateTemplate(id, {
      current_version_id: version.id,
      variables: version.variables,
      status: 'DRAFT', // Transition back to DRAFT state on rollbacks
    });

    if (!updated) {
      throw new ValidationError('Failed to rollback template');
    }

    PromptRegistry.cacheTemplate(updated);

    await this.repository.createAuditLog({
      workspace_id: template.workspace_id,
      template_id: id,
      action: 'ROLLBACK',
      before: template as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async render(templateId: string, dto: RenderPromptDto): Promise<RenderPromptResponseDto> {
    const template = await this.getTemplateById(templateId);
    if (!template.current_version_id) {
      throw new ValidationError('Template does not have a current version configured');
    }

    const version = await this.repository.findVersionById(template.current_version_id);
    if (!version) {
      throw new ValidationError('Current version details not found');
    }

    const model = dto.model || template.default_model;

    // 1. Check Prompt Render Cache
    const testContext = {}; // simple context simulation in cache check
    const cacheKey = promptCache.generateKey(template.id, version.id, dto.variables, testContext, model);
    const cached = promptCache.get(cacheKey);

    if (cached) {
      const parsed = JSON.parse(cached);
      return {
        renderedSystemPrompt: parsed.systemPrompt,
        renderedUserPrompt: parsed.userPrompt,
        checksum: parsed.checksum,
        estimatedTokens: parsed.estimatedTokens,
        cacheHit: true,
      };
    }

    // 2. Render actual text
    const result = await PromptRenderer.render(template, version, dto.variables, model);

    // Save in cache
    promptCache.set(cacheKey, JSON.stringify(result));

    return {
      renderedSystemPrompt: result.systemPrompt,
      renderedUserPrompt: result.userPrompt,
      checksum: result.checksum,
      estimatedTokens: result.estimatedTokens,
      cacheHit: false,
    };
  }

  async preview(dto: PreviewPromptDto): Promise<Record<string, unknown>> {
    const template = await this.getTemplateById(dto.templateId);
    const version = await this.repository.findVersionById(dto.versionId);
    if (!version || version.template_id !== dto.templateId) {
      throw new ValidationError('Version not found or mismatch');
    }

    const model = dto.model || template.default_model;
    const previewResult = await PromptPreviewer.preview(template, version, dto.variables, model);

    return {
      renderedSystemPrompt: previewResult.systemPrompt,
      renderedUserPrompt: previewResult.userPrompt,
      checksum: previewResult.checksum,
      estimatedTokens: previewResult.estimatedTokens,
      variables: previewResult.variables,
      cacheKey: previewResult.cacheKey,
    };
  }

  async execute(templateId: string, dto: RenderPromptDto): Promise<GenerateResponse> {
    const startTime = Date.now();
    const template = await this.getTemplateById(templateId);

    // 1. Render prompt parameters
    const rendered = await this.render(templateId, dto);

    const provider = dto.provider || template.default_provider;
    const model = dto.model || template.default_model;

    try {
      // 2. Direct execution through AIGateway interface
      const response = await this.gateway.generate({
        prompt: rendered.renderedUserPrompt,
        systemInstruction: rendered.renderedSystemPrompt,
        workspaceId: dto.workspaceId,
        temperature: template.temperature,
        maxTokens: template.max_tokens,
        responseSchema: template.response_schema || undefined,
      });

      const latency = Date.now() - startTime;

      // 3. Record Execution history
      const historyPayload = {
        workspace_id: dto.workspaceId,
        template_id: templateId,
        version_id: template.current_version_id || '',
        provider,
        model,
        rendered_hash: rendered.checksum,
        execution_ms: latency,
        prompt_tokens: response.usage.promptTokens,
        completion_tokens: response.usage.completionTokens,
        total_tokens: response.usage.totalTokens,
        estimated_cost: response.cost,
        cache_hit: rendered.cacheHit,
        success: true,
      };

      await this.repository.createHistory(historyPayload);
      PromptHistoryCollector.record(historyPayload);

      await PromptHooks.onPromptExecuted(templateId, template.current_version_id || '', latency, true);

      return response;
    } catch (err: unknown) {
      const latency = Date.now() - startTime;
      const errMsg = err instanceof Error ? err.message : String(err);

      const historyPayload = {
        workspace_id: dto.workspaceId,
        template_id: templateId,
        version_id: template.current_version_id || '',
        provider,
        model,
        rendered_hash: rendered.checksum,
        execution_ms: latency,
        prompt_tokens: 0,
        completion_tokens: 0,
        total_tokens: 0,
        estimated_cost: 0.0,
        cache_hit: rendered.cacheHit,
        success: false,
        error_message: errMsg,
      };

      await this.repository.createHistory(historyPayload);
      PromptHistoryCollector.record(historyPayload);

      await PromptHooks.onPromptExecuted(templateId, template.current_version_id || '', latency, false);

      throw err;
    }
  }

  async getVersions(templateId: string): Promise<PromptVersionEntity[]> {
    return this.repository.findVersionsByTemplateId(templateId);
  }

  async getHistory(): Promise<unknown[]> {
    return this.repository.findHistories ? this.repository.findHistories() : PromptHistoryCollector.getHistory();
  }
}
export default PromptService;
