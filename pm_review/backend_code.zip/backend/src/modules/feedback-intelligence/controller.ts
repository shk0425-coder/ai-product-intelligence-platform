import { FastifyReply, FastifyRequest } from 'fastify';
import { FeedbackIntelligenceService } from './service.js';
import {
  AnalyzeFeedbackInput,
  ReanalyzeFeedbackInput,
  FeedbackIdParamInput,
  FeedbackIntelProductParamInput,
} from './schema.js';
import { successResponse } from '@/common/responses/index.js';

export class FeedbackIntelligenceController {
  constructor(private readonly service: FeedbackIntelligenceService) {}

  analyze = async (
    request: FastifyRequest<{ Body: AnalyzeFeedbackInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.analyze(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Feedback intelligence report generated successfully'));
  };

  reanalyze = async (
    request: FastifyRequest<{ Body: ReanalyzeFeedbackInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.reanalyze(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Feedback intelligence report regenerated successfully'));
  };

  findByFeedback = async (
    request: FastifyRequest<{ Params: FeedbackIdParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findByFeedback(request.params.feedbackId, userId);
    return reply.status(200).send(successResponse(result));
  };

  findHistory = async (
    request: FastifyRequest<{ Params: FeedbackIntelProductParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findHistory(request.params.productId, userId);
    return reply.status(200).send(successResponse(result));
  };

  findLatest = async (
    request: FastifyRequest<{ Params: FeedbackIntelProductParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findLatest(request.params.productId, userId);
    return reply.status(200).send(successResponse(result));
  };
}
export default FeedbackIntelligenceController;
