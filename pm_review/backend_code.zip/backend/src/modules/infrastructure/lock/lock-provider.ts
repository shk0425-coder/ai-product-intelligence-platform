export interface DistributedLockProvider {
  acquire(lockKey: string, ttlMs: number): Promise<string | null>; // Returns Owner Token if success
  release(lockKey: string, ownerToken: string): Promise<boolean>;
  extend(lockKey: string, ownerToken: string, ttlMs: number): Promise<boolean>;
}
