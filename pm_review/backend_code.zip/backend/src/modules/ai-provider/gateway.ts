import { AIProviderRequest, GenerateResponse } from './types.js';
import { ProviderResolver } from './provider-resolver.js';
import { RateLimiter } from './rate-limiter.js';
import { CircuitBreaker } from './circuit-breaker.js';
import { ResponseCache } from './response-cache.js';
import { ResponseNormalizer } from './response-normalizer.js';
import { ResponseValidator } from './response-validator.js';
import { PricingEngine } from './pricing-engine.js';
import { ProviderMetricsCollector } from './provider-metrics.js';
import { AIProviderHooks } from './hooks.js';
import {
  ProviderValidationError,
  ProviderAuthenticationError,
  ProviderCapabilityError,
  ProviderTimeoutError,
  FallbackFailedError,
} from '../../common/errors/index.js';

export class AIGateway {
  constructor(private readonly repository: import('./repository.js').AIProviderRepository) {}

  async generate(request: AIProviderRequest, workspaceOverride?: { provider: string; model: string }): Promise<GenerateResponse> {
    // 1. Response Cache lookup (Streaming은 제외)
    const cached = ResponseCache.get(request.prompt, request.workspaceId);
    if (cached) {
      ProviderMetricsCollector.record({
        provider: cached.provider,
        model: cached.model,
        status: 'SUCCESS',
        latency_ms: 0,
        prompt_tokens: cached.usage.promptTokens,
        completion_tokens: cached.usage.completionTokens,
        total_tokens: cached.usage.totalTokens,
        estimated_cost: cached.cost,
        cache_hit: true,
      });
      return { ...cached, cost: cached.cost }; // return cached copy
    }

    const configs = await this.repository.findConfigs();
    const healths = await this.repository.findHealths();
    const metrics = ProviderMetricsCollector.getMetrics();

    let retryCount = 0;
    const maxRetry = 2; // Spec: Retry up to 2 times

    while (retryCount <= maxRetry) {
      let providerInstance;
      try {
        // Resolve Provider using Selector routing rules
        providerInstance = ProviderResolver.resolve(
          configs,
          healths,
          metrics,
          request.capabilities || [],
          request.workspaceId,
          workspaceOverride
        );
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : String(err);
        throw new FallbackFailedError(`Failed to resolve eligible provider: ${msg}`);
      }

      const providerId = providerInstance.providerId;
      const modelId = providerInstance.modelId;
      await AIProviderHooks.onProviderSelected(providerId, modelId, request.workspaceId);

      try {
        // 2. Circuit Breaker & Rate Limiter Check
        CircuitBreaker.checkCall(providerId, modelId);
        
        const estTokens = Math.floor(request.prompt.length / 4) + 500;
        RateLimiter.checkLimit(providerId, modelId, providerInstance.rpm, providerInstance.tpm, estTokens);

        const startTime = Date.now();
        await AIProviderHooks.onProviderCalled(providerId, modelId, request.prompt.length);

        // 3. Execution with Timeout
        const timeoutMs = request.timeoutMs || providerInstance.metadata.maxOutputTokens * 10 || 30000;
        const generatePromise = providerInstance.generate(request);
        
        const timeoutPromise = new Promise<never>((_, reject) =>
          setTimeout(() => reject(new ProviderTimeoutError(`Request timed out after ${timeoutMs}ms`)), timeoutMs)
        );

        const rawResponse = await Promise.race([generatePromise, timeoutPromise]);
        const latency = Date.now() - startTime;
        await AIProviderHooks.onProviderSucceeded(providerId, modelId, latency);

        // 4. Cost calculation & Normalization
        const cost = PricingEngine.calculateCost(
          rawResponse.usage.promptTokens,
          rawResponse.usage.completionTokens,
          providerInstance.metadata
        );

        const normalized = ResponseNormalizer.normalize(
          rawResponse.content,
          providerId,
          modelId,
          rawResponse.finishReason,
          rawResponse.usage,
          cost
        );

        // 5. Response Validation
        ResponseValidator.validate(normalized, request.responseSchema);

        // Record metrics & cache hit
        CircuitBreaker.recordSuccess(providerId, modelId);
        ProviderMetricsCollector.record({
          provider: providerId,
          model: modelId,
          status: 'SUCCESS',
          latency_ms: latency,
          prompt_tokens: normalized.usage.promptTokens,
          completion_tokens: normalized.usage.completionTokens,
          total_tokens: normalized.usage.totalTokens,
          estimated_cost: cost,
          cache_hit: false,
        });

        // Set response cache
        ResponseCache.set(request.prompt, request.workspaceId, normalized);

        return normalized;
      } catch (err: unknown) {
        // Failure record for circuit breaker
        CircuitBreaker.recordFailure(providerId, modelId);
        const errMsg = err instanceof Error ? err.message : String(err);
        await AIProviderHooks.onProviderFailed(providerId, modelId, errMsg);
        if (CircuitBreaker.getState(providerId, modelId) === 'OPEN') {
          await AIProviderHooks.onCircuitOpened(providerId, modelId);
        }

        ProviderMetricsCollector.record({
          provider: providerId,
          model: modelId,
          status: 'FAILED',
          latency_ms: 0,
          prompt_tokens: 0,
          completion_tokens: 0,
          total_tokens: 0,
          estimated_cost: 0,
          cache_hit: false,
        });

        // Non-retryable Errors check
        if (
          err instanceof ProviderValidationError ||
          err instanceof ProviderAuthenticationError ||
          err instanceof ProviderCapabilityError
        ) {
          throw err; // Stop and bubble immediately
        }

        retryCount++;
        if (retryCount > maxRetry) {
          throw new FallbackFailedError(`Execution failed on all retry attempts. Last error: ${errMsg}`);
        }
        await AIProviderHooks.onFallbackActivated(providerId, 'FALLBACK_MODEL');
        // Delay for exponential backoff before retry
        await new Promise((resolve) => setTimeout(resolve, Math.pow(2, retryCount) * 100));
      }
    }

    throw new FallbackFailedError('Gateway processing failed without returning response');
  }

  async generateStream(
    request: AIProviderRequest,
    workspaceOverride?: { provider: string; model: string }
  ): Promise<AsyncIterable<string>> {
    const configs = await this.repository.findConfigs();
    const healths = await this.repository.findHealths();
    const metrics = ProviderMetricsCollector.getMetrics();

    let providerInstance;
    try {
      providerInstance = ProviderResolver.resolve(
        configs,
        healths,
        metrics,
        request.capabilities || [],
        request.workspaceId,
        workspaceOverride
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new FallbackFailedError(`Failed to resolve provider for stream: ${msg}`);
    }

    const providerId = providerInstance.providerId;
    const modelId = providerInstance.modelId;

    CircuitBreaker.checkCall(providerId, modelId);

    // If streaming capability is unsupported, use Chunk Wrapper to stream regular generate content
    if (!providerInstance.metadata.supportsStreaming) {
      const regularResponse = await this.generate(request, workspaceOverride);
      const chunks = regularResponse.content.split(/(?<=\s)/); // Split keeping spaces
      
      return {
        async *[Symbol.asyncIterator]() {
          for (const chunk of chunks) {
            yield chunk;
          }
        },
      };
    }

    try {
      return await providerInstance.generateStream(request);
    } catch (err: unknown) {
      CircuitBreaker.recordFailure(providerId, modelId);
      throw err;
    }
  }
}
export default AIGateway;
