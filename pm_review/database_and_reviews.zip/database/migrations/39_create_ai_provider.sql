-- 39_create_ai_provider.sql
-- AI Provider Gateway & Model Abstraction Layer tables

BEGIN;

-- 1. ai_provider_configs
CREATE TABLE IF NOT EXISTS public.ai_provider_configs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    version VARCHAR(50) NOT NULL,
    priority INTEGER NOT NULL DEFAULT 10,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    enabled BOOLEAN NOT NULL DEFAULT true,
    rpm INTEGER NOT NULL DEFAULT 60,
    tpm INTEGER NOT NULL DEFAULT 40000,
    retry_count INTEGER NOT NULL DEFAULT 2,
    timeout_seconds INTEGER NOT NULL DEFAULT 30,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_ai_provider_configs PRIMARY KEY (id),
    CONSTRAINT uq_provider_model UNIQUE (provider, model)
);

COMMENT ON TABLE public.ai_provider_configs IS 'AI Provider 및 모델 설정값과 가중치 정보';

-- 2. ai_provider_metrics
CREATE TABLE IF NOT EXISTS public.ai_provider_metrics (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL, -- SUCCESS, FAILED
    latency_ms INTEGER NOT NULL DEFAULT 0,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    estimated_cost NUMERIC(10, 6) NOT NULL DEFAULT 0.0,
    cache_hit BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_ai_provider_metrics PRIMARY KEY (id)
);

COMMENT ON TABLE public.ai_provider_metrics IS 'AI API 호출 통계 및 비용 측정 정보';

-- 3. ai_provider_health
CREATE TABLE IF NOT EXISTS public.ai_provider_health (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'HEALTHY', -- HEALTHY, DEGRADED, UNAVAILABLE
    failure_count INTEGER NOT NULL DEFAULT 0,
    last_checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_ai_provider_health PRIMARY KEY (id),
    CONSTRAINT uq_health_provider_model UNIQUE (provider, model)
);

COMMENT ON TABLE public.ai_provider_health IS 'AI Provider 모델별 실시간 헬스 체크 상태 보관 테이블';

-- Performance Index
CREATE INDEX IF NOT EXISTS idx_ai_provider_configs_enabled ON public.ai_provider_configs(enabled, priority DESC);
CREATE INDEX IF NOT EXISTS idx_ai_provider_metrics_provider_model ON public.ai_provider_metrics(provider, model);
CREATE INDEX IF NOT EXISTS idx_ai_provider_health_status ON public.ai_provider_health(status);

COMMIT;
