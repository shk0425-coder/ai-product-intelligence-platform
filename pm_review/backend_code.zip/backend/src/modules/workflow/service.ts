import crypto from 'crypto';
import { WorkflowRepository } from './repository.js';
import { PromptService } from '../prompt/service.js';
import { CreateWorkflowDto, CreateWorkflowVersionDto, ExecuteWorkflowDto, PreviewWorkflowDto, PreviewWorkflowResponseDto } from './dto.js';
import { WorkflowDefinitionEntity, WorkflowVersionEntity, WorkflowExecutionEntity } from './types.js';
import { WorkflowValidator } from './validator.js';
import { WorkflowPreviewer } from './preview.js';
import { WorkflowRegistry } from './registry.js';
import { WorkflowExecutor } from './executor.js';
import { WorkflowStepEngine } from './step-engine.js';
import { CancellationToken } from './cancellation.js';
import { WorkflowHistoryCollector } from './history.js';
import { WorkflowHooks } from './hooks.js';
import { ValidationError } from '../../common/errors/index.js';

export class WorkflowService {
  private readonly activeTokens = new Map<string, CancellationToken>();
  private readonly executor: WorkflowExecutor;

  constructor(
    private readonly repository: WorkflowRepository,
    promptService: PromptService
  ) {
    const stepEngine = new WorkflowStepEngine(promptService);
    this.executor = new WorkflowExecutor(stepEngine);
  }

  async getWorkflows(): Promise<WorkflowDefinitionEntity[]> {
    return this.repository.findWorkflows();
  }

  async getWorkflowById(id: string): Promise<WorkflowDefinitionEntity> {
    const wf = await this.repository.findWorkflowById(id);
    if (!wf) {
      throw new ValidationError(`Workflow not found for id: ${id}`);
    }
    return wf;
  }

  async createWorkflow(dto: CreateWorkflowDto): Promise<WorkflowDefinitionEntity> {
    const graphString = JSON.stringify(dto.graph);
    const checksum = crypto.createHash('sha256').update(graphString).digest('hex');

    // 1. Create Definition Master
    const defPayload: Omit<WorkflowDefinitionEntity, 'id' | 'created_at' | 'updated_at'> = {
      workspace_id: dto.workspaceId,
      name: dto.name,
      description: dto.description,
      latest_version: 1,
      status: 'DRAFT',
    };

    const wf = await this.repository.createWorkflow(defPayload);
    if (!wf) {
      throw new ValidationError('Failed to create workflow definition');
    }

    // 2. Create Version 1
    const verPayload: Omit<WorkflowVersionEntity, 'id' | 'created_at'> = {
      workflow_id: wf.id,
      version: 1,
      graph: dto.graph,
      checksum,
      change_summary: 'Initial creation',
    };

    const version = await this.repository.createVersion(verPayload);
    if (!version) {
      throw new ValidationError('Failed to create initial workflow version');
    }

    // Link master to current version id
    const updated = await this.repository.updateWorkflow(wf.id, {
      current_version_id: version.id,
    });

    const finalWf = updated || wf;

    WorkflowRegistry.cacheWorkflow(finalWf);
    WorkflowRegistry.cacheVersion(version);

    await WorkflowHooks.onWorkflowCreated(finalWf.id, finalWf.workspace_id);
    await WorkflowHooks.onVersionCreated(finalWf.id, version.id, 1);

    // Audit Log
    await this.repository.createAuditLog({
      workspace_id: finalWf.workspace_id,
      workflow_id: finalWf.id,
      action: 'CREATE',
      after: finalWf as unknown as Record<string, unknown>,
    });

    return finalWf;
  }

  async createVersion(workflowId: string, dto: CreateWorkflowVersionDto): Promise<WorkflowVersionEntity> {
    const wf = await this.getWorkflowById(workflowId);

    const nextVer = wf.latest_version + 1;
    const graphString = JSON.stringify(dto.graph);
    const checksum = crypto.createHash('sha256').update(graphString).digest('hex');

    const verPayload: Omit<WorkflowVersionEntity, 'id' | 'created_at'> = {
      workflow_id: workflowId,
      version: nextVer,
      graph: dto.graph,
      checksum,
      change_summary: dto.changeSummary,
    };

    const version = await this.repository.createVersion(verPayload);
    if (!version) {
      throw new ValidationError('Failed to create version');
    }

    // Reset master to DRAFT on modifications
    const updated = await this.repository.updateWorkflow(workflowId, {
      latest_version: nextVer,
      current_version_id: version.id,
      status: 'DRAFT',
    });

    WorkflowRegistry.cacheWorkflow(updated || wf);
    WorkflowRegistry.cacheVersion(version);

    await WorkflowHooks.onVersionCreated(workflowId, version.id, nextVer);

    await this.repository.createAuditLog({
      workspace_id: wf.workspace_id,
      workflow_id: workflowId,
      action: 'VERSION_UP',
      before: wf as unknown as Record<string, unknown>,
      after: (updated || wf) as unknown as Record<string, unknown>,
    });

    return version;
  }

  async approveWorkflow(id: string, approvedBy: string): Promise<WorkflowDefinitionEntity> {
    const wf = await this.getWorkflowById(id);
    const updated = await this.repository.updateWorkflow(id, {
      status: 'APPROVED',
      approved_by: approvedBy,
      approved_at: new Date().toISOString(),
    });

    if (!updated) {
      throw new ValidationError('Failed to approve workflow');
    }

    WorkflowRegistry.cacheWorkflow(updated);

    await this.repository.createAuditLog({
      workspace_id: wf.workspace_id,
      workflow_id: id,
      action: 'APPROVE',
      before: wf as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async reviewWorkflow(id: string): Promise<WorkflowDefinitionEntity> {
    const wf = await this.getWorkflowById(id);
    const updated = await this.repository.updateWorkflow(id, {
      status: 'REVIEW',
    });

    if (!updated) {
      throw new ValidationError('Failed to transition to REVIEW');
    }

    WorkflowRegistry.cacheWorkflow(updated);

    await this.repository.createAuditLog({
      workspace_id: wf.workspace_id,
      workflow_id: id,
      action: 'REVIEW',
      before: wf as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async deprecateWorkflow(id: string): Promise<WorkflowDefinitionEntity> {
    const wf = await this.getWorkflowById(id);
    const updated = await this.repository.updateWorkflow(id, {
      status: 'DEPRECATED',
    });

    if (!updated) {
      throw new ValidationError('Failed to deprecate workflow');
    }

    WorkflowRegistry.cacheWorkflow(updated);

    await this.repository.createAuditLog({
      workspace_id: wf.workspace_id,
      workflow_id: id,
      action: 'DEPRECATE',
      before: wf as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async rollbackWorkflowVersion(id: string, versionId: string): Promise<WorkflowDefinitionEntity> {
    const wf = await this.getWorkflowById(id);
    const version = await this.repository.findVersionById(versionId);
    if (!version || version.workflow_id !== id) {
      throw new ValidationError(`Version not found or mismatch: ${versionId}`);
    }

    const updated = await this.repository.updateWorkflow(id, {
      current_version_id: version.id,
      status: 'DRAFT', // rollbacks reset to DRAFT
    });

    if (!updated) {
      throw new ValidationError('Failed to rollback workflow version');
    }

    WorkflowRegistry.cacheWorkflow(updated);

    await this.repository.createAuditLog({
      workspace_id: wf.workspace_id,
      workflow_id: id,
      action: 'ROLLBACK',
      before: wf as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async execute(workflowId: string, dto: ExecuteWorkflowDto): Promise<WorkflowExecutionEntity> {
    const wf = await this.getWorkflowById(workflowId);
    if (!wf.current_version_id) {
      throw new ValidationError('Workflow does not have current active version configured');
    }

    const version = await this.repository.findVersionById(wf.current_version_id);
    if (!version) {
      throw new ValidationError('Active version graph definition not found');
    }

    // 1. Validation check (fails execution if not APPROVED or cycles exist)
    WorkflowValidator.validate(wf, version);

    // 2. Initialize execution
    const executionKey = `exec-${Date.now()}-${crypto.randomUUID().slice(0, 8)}`;
    const initExecution = await this.repository.createExecution({
      workspace_id: dto.workspaceId,
      workflow_id: workflowId,
      version_id: version.id,
      status: 'PENDING',
      execution_key: executionKey,
      input: dto.input,
      output: {},
      snapshot: {},
      duration_ms: 0,
      estimated_cost: 0.0,
    });

    if (!initExecution) {
      throw new ValidationError('Failed to write workflow execution log');
    }

    const cancellationToken = new CancellationToken();
    this.activeTokens.set(initExecution.id, cancellationToken);

    // Update execution start
    await this.repository.updateExecution(initExecution.id, {
      status: 'RUNNING',
      started_at: new Date().toISOString(),
    });

    const startTime = Date.now();

    // 3. Trigger Async Execution Loop
    this.executor.execute({
      executionId: initExecution.id,
      workspaceId: dto.workspaceId,
      graph: version.graph,
      initialContext: dto.input,
      cancellationToken,
      onStepCompleted: async (stepId, status, output, cost, snapshot) => {
        // Record step executions in parallel threads safely
        await this.repository.createStepExecution({
          execution_id: initExecution.id,
          step_id: stepId,
          status,
          input: dto.input,
          output,
          estimated_cost: cost,
          execution_ms: 0, // default step timing placeholder
          retry_count: 0,
        });

        // Save progress snapshot
        await this.repository.updateExecution(initExecution.id, {
          snapshot,
        });
      },
      onWorkflowFinished: async (status, outputContext, totalCost, errorMsg) => {
        const duration = Date.now() - startTime;

        const finalUpdatePayload: Partial<WorkflowExecutionEntity> = {
          status,
          output: outputContext,
          duration_ms: duration,
          estimated_cost: totalCost,
          finished_at: new Date().toISOString(),
          error_message: errorMsg,
        };

        const finalExec = await this.repository.updateExecution(initExecution.id, finalUpdatePayload);
        
        if (finalExec) {
          WorkflowHistoryCollector.record(finalExec);
          await this.repository.createAuditLog({
            workspace_id: dto.workspaceId,
            workflow_id: workflowId,
            action: `FINISH_${status}`,
            after: finalExec as unknown as Record<string, unknown>,
          });
        }
        
        this.activeTokens.delete(initExecution.id);
      },
    }).catch(async (err) => {
      // Catch overall execution errors
      const duration = Date.now() - startTime;
      await this.repository.updateExecution(initExecution.id, {
        status: 'FAILED',
        finished_at: new Date().toISOString(),
        duration_ms: duration,
        error_message: err.message || String(err),
      });
      this.activeTokens.delete(initExecution.id);
    });

    // Immediately return the initial execution ticket details
    const currentTicket = await this.repository.findExecutionById(initExecution.id);
    return currentTicket || initExecution;
  }

  async cancelExecution(executionId: string): Promise<void> {
    const token = this.activeTokens.get(executionId);
    if (token) {
      token.cancel('User cancellation requested');
      
      const exec = await this.repository.findExecutionById(executionId);
      if (exec) {
        await this.repository.createAuditLog({
          workspace_id: exec.workspace_id,
          workflow_id: exec.workflow_id,
          action: 'CANCEL',
          before: exec as unknown as Record<string, unknown>,
        });
      }
    }
  }

  async preview(dto: PreviewWorkflowDto): Promise<PreviewWorkflowResponseDto> {
    return WorkflowPreviewer.preview(dto.graph);
  }

  async getVersions(workflowId: string): Promise<WorkflowVersionEntity[]> {
    return this.repository.findVersionsByWorkflowId(workflowId);
  }

  async getHistory(): Promise<WorkflowExecutionEntity[]> {
    return this.repository.findExecutions ? this.repository.findExecutions() : WorkflowHistoryCollector.getHistory();
  }
}
export default WorkflowService;
