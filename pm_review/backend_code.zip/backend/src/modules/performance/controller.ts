import { FastifyReply, FastifyRequest } from 'fastify';
import { PerformanceService } from './service.js';
import {
  CreatePerformanceInput,
  UpdatePerformanceInput,
  PerformanceIdParamInput,
  PerformanceProductParamInput,
  PerformanceAnalysisParamInput,
  PerformanceHistoryQueryInput,
  PerformanceQueryInput,
} from './schema.js';
import { successResponse } from '@/common/responses/index.js';

export class PerformanceController {
  constructor(private readonly performanceService: PerformanceService) {}

  upsert = async (
    request: FastifyRequest<{ Body: CreatePerformanceInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.performanceService.upsert(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Performance record upserted successfully'));
  };

  update = async (
    request: FastifyRequest<{ Params: PerformanceIdParamInput; Body: UpdatePerformanceInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.performanceService.update(request.params.id, request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Performance record updated successfully'));
  };

  findById = async (
    request: FastifyRequest<{ Params: PerformanceIdParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.performanceService.findById(request.params.id, userId);
    return reply.status(200).send(successResponse(result));
  };

  findByProduct = async (
    request: FastifyRequest<{
      Params: PerformanceProductParamInput;
      Querystring: PerformanceQueryInput;
    }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.performanceService.findByProduct(
      request.params.productId,
      request.query,
      userId,
    );
    return reply.status(200).send(successResponse(result));
  };

  findByAnalysis = async (
    request: FastifyRequest<{ Params: PerformanceAnalysisParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.performanceService.findByAnalysis(
      request.params.analysisRunId,
      userId,
    );
    return reply.status(200).send(successResponse(result));
  };

  findByPeriod = async (
    request: FastifyRequest<{
      Params: PerformanceProductParamInput;
      Querystring: PerformanceHistoryQueryInput;
    }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const { startDate, endDate, ...options } = request.query;
    const result = await this.performanceService.findByPeriod(
      request.params.productId,
      startDate || '',
      endDate || '',
      options,
      userId,
    );
    return reply.status(200).send(successResponse(result));
  };

  findLatest = async (
    request: FastifyRequest<{ Params: PerformanceProductParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.performanceService.findLatest(request.params.productId, userId);
    return reply.status(200).send(successResponse(result));
  };

  delete = async (
    request: FastifyRequest<{ Params: PerformanceIdParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    await this.performanceService.delete(request.params.id, userId);
    return reply.status(200).send(successResponse(null, 'Performance deleted successfully'));
  };
}
