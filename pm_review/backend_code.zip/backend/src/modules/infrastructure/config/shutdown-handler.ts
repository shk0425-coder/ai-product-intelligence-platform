import { eventBus } from '../event/event-bus.js';
import { lockProvider } from '../lock/redis-lock.js';

export class GracefulShutdownHandler {
  private static isShuttingDown = false;

  static async initiate(_signal: string): Promise<void> {
    if (this.isShuttingDown) return;
    this.isShuttingDown = true;

    // 1. Terminate new incoming events
    eventBus.shutdown();

    // 2. Wait for inflight handler tasks (up to 10 seconds)
    const allCompleted = await eventBus.waitInFlight(10000);

    // 3. Release Locks and Clean resources
    lockProvider.clearAll();
    eventBus.clearHandlers();
    eventBus.clearIdempotencyCache();

    // 4. Record output logging
    if (allCompleted) {
      // Completed gracefully
    } else {
      // Shutdown timed out, forcing shutdown
    }
  }
}
