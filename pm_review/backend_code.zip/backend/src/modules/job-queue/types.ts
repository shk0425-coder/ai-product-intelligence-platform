export interface JobQueueEntity {
  id: string;
  workspace_id: string;
  job_type: string;
  priority: number;
  payload: Record<string, unknown>;
  payload_version: string;
  status: 'PENDING' | 'QUEUED' | 'RUNNING' | 'SUCCESS' | 'FAILED';
  retry_count: number;
  max_retry: number;
  lease_owner: string | null;
  lease_until: string | null;
  heartbeat_at: string | null;
  cancel_requested: boolean;
  schedule_type: 'IMMEDIATE' | 'DELAYED' | 'FUTURE';
  scheduled_at: string;
  started_at: string | null;
  completed_at: string | null;
  error_message: string | null;
  created_at: string;
  updated_at: string;
}

export interface JobExecutionLogEntity {
  id: string;
  job_id: string;
  worker: string;
  status: 'SUCCESS' | 'FAILED';
  duration_ms: number;
  error_message: string | null;
  created_at: string;
}

export interface JobDeadLetterEntity {
  id: string;
  job_id: string;
  payload: Record<string, unknown>;
  reason: string;
  retry_count: number;
  failed_at: string;
  created_at: string;
}
