import crypto from 'crypto';
import { PROMPT_CACHE_TTL_MS } from './constants.js';

export interface PromptCacheInterface {
  get(key: string): string | null;
  set(key: string, value: string, ttlMs?: number): void;
  delete(key: string): void;
  clear(): void;
  generateKey(templateId: string, versionId: string, variables: Record<string, unknown>, context: Record<string, unknown>, model: string): string;
}

export class InMemoryPromptCache implements PromptCacheInterface {
  private readonly store = new Map<string, { value: string; expiresAt: number }>();

  get(key: string): string | null {
    const entry = this.store.get(key);
    if (!entry) return null;

    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return entry.value;
  }

  set(key: string, value: string, ttlMs: number = PROMPT_CACHE_TTL_MS): void {
    this.store.set(key, {
      value,
      expiresAt: Date.now() + ttlMs,
    });
  }

  delete(key: string): void {
    this.store.delete(key);
  }

  clear(): void {
    this.store.clear();
  }

  generateKey(
    templateId: string,
    versionId: string,
    variables: Record<string, unknown>,
    context: Record<string, unknown>,
    model: string
  ): string {
    const sortedVars = JSON.stringify(variables, Object.keys(variables).sort());
    const sortedContext = JSON.stringify(context, Object.keys(context).sort());
    const composite = `${templateId}:${versionId}:${sortedVars}:${sortedContext}:${model}`;
    return crypto.createHash('sha256').update(composite).digest('hex');
  }
}

// Singleton instantiation
export const promptCache: PromptCacheInterface = new InMemoryPromptCache();
export default promptCache;
