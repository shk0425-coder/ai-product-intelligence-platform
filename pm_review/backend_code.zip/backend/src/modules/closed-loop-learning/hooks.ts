import { pino } from 'pino';
import { LearningEventPayload, ILearningHooks } from './types.js';
import { LearningVectorDto } from './dto.js';

const logger = pino();

export const LearningHooks: ILearningHooks = {
  async onLearningKnowledgeCreated(payload: LearningEventPayload): Promise<void> {
    logger.info(
      {
        knowledgeId: payload.knowledge.knowledgeId,
        intelligenceId: payload.knowledge.intelligenceId,
        actorId: payload.actorId,
        knowledgeScore: payload.knowledge.knowledgeScore,
      },
      'Domain Hook [LearningKnowledgeCreated] triggered',
    );
    // Future integration point for Sprint 5-5 Product Strategy auto-reinforcement
  },

  async onLearningKnowledgeUpdated(payload: LearningEventPayload): Promise<void> {
    logger.info(
      {
        knowledgeId: payload.knowledge.knowledgeId,
        intelligenceId: payload.knowledge.intelligenceId,
        actorId: payload.actorId,
      },
      'Domain Hook [LearningKnowledgeUpdated] triggered',
    );
  },

  async onLearningVectorGenerated(payload: {
    vector: LearningVectorDto;
    actorId: string;
  }): Promise<void> {
    logger.info(
      {
        vectorId: payload.vector.vectorId,
        knowledgeId: payload.vector.knowledgeId,
        actorId: payload.actorId,
        checksum: payload.vector.checksum,
      },
      'Domain Hook [LearningVectorGenerated] triggered',
    );
    // Future integration point for Sprint 5-5
  },
};
export default LearningHooks;
