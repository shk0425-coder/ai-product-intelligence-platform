import { MetricsRegistry } from '../registry.js';

export class RedisMetricsCollector {
  private static connections = 0;
  private static status: 'UP' | 'DOWN' = 'UP';
  private static stateMap: Record<string, number> = {
    CLOSED: 0,
    HALF_OPEN: 1,
    OPEN: 2,
  };

  static setConnectionCount(count: number): void {
    this.connections = count;
    MetricsRegistry.gauge('redis_connections', count);
  }

  static setStatus(status: 'UP' | 'DOWN'): void {
    this.status = status;
    MetricsRegistry.gauge('redis_status', status === 'UP' ? 1 : 0);
  }

  static recordCircuitState(state: 'CLOSED' | 'HALF_OPEN' | 'OPEN'): void {
    const val = this.stateMap[state] ?? 0;
    MetricsRegistry.gauge('current_circuit_state', val);

    if (state === 'OPEN') {
      MetricsRegistry.counter('circuit_open_total', 1);
    } else if (state === 'HALF_OPEN') {
      MetricsRegistry.counter('circuit_half_open_total', 1);
    } else if (state === 'CLOSED') {
      MetricsRegistry.counter('circuit_closed_total', 1);
    }
  }

  static recordCircuitEvent(event: 'recovery' | 'failure'): void {
    if (event === 'recovery') {
      MetricsRegistry.counter('circuit_recovery_total', 1);
    } else if (event === 'failure') {
      MetricsRegistry.counter('circuit_failure_total', 1);
    }
  }
}
