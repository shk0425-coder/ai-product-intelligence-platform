export const DEFAULT_AI_PROVIDER = 'GEMINI';
export const DEFAULT_AI_MODEL = 'gemini-1.5-pro';

export const DEFAULT_RETRY_COUNT = 2;
export const DEFAULT_TIMEOUT_MS = 30000; // 30 seconds

export const HEALTH_CHECK_INTERVAL_MS = 60000; // 60 seconds
export const CACHE_TTL_MS = 600000; // 10 minutes (10 * 60 * 1000)

export const FINISH_REASONS = ['STOP', 'LENGTH', 'TOOL_CALL', 'CONTENT_FILTER', 'ERROR'] as const;

export const CAPABILITIES_LIST = [
  'TEXT',
  'CHAT',
  'VISION',
  'IMAGE_GENERATION',
  'IMAGE_EDITING',
  'EMBEDDING',
  'STRUCTURED_OUTPUT',
  'FUNCTION_CALLING',
] as const;
