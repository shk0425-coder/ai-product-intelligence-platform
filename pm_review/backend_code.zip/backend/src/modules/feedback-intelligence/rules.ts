export interface FeedbackRule {
  id: string;
  category: 'Sales' | 'Review' | 'Conversion' | 'CTR' | 'ROI' | 'Profit' | 'Favorite' | 'Refund';
  priority: number; // Lower is higher priority (e.g. 1 is top)
  severity: number; // 1 (Minor) ~ 5 (Critical)
  condition: (score: number, metrics: Record<string, unknown> | null | undefined) => boolean;
  message: string;
  recommendation: string;
}

export const FEEDBACK_RULES: FeedbackRule[] = [
  {
    id: 'RULE_SALES_CRITICAL_DROP',
    category: 'Sales',
    priority: 1,
    severity: 5,
    condition: (score) => score < 40.0,
    message: '판매량 및 매출 기여도가 극도로 낮아 즉각적인 마케팅 액션이 요구됩니다.',
    recommendation:
      '시즌성 프로모션 진행 및 단기 타겟 할인 쿠폰 발행으로 초반 구매 모멘텀을 형성하십시오.',
  },
  {
    id: 'RULE_CONV_BOTTLENECK_CRITICAL',
    category: 'Conversion',
    priority: 2,
    severity: 5,
    condition: (score) => score < 50.0,
    message: '구매 전환율이 저조하여 잠재적 구매자 이탈 병목이 발생하고 있습니다.',
    recommendation:
      '상세페이지 상단에 직관적인 핵심 소구점(결핍 해결책) 배치 및 혜택 요약을 보완하십시오.',
  },
  {
    id: 'RULE_REFUND_PENALTY_WARN',
    category: 'Refund',
    priority: 3,
    severity: 4,
    condition: (_, metrics) => (metrics ? Number(metrics.refund_count || 0) > 10 : false),
    message:
      '환불 건수가 임계 기준치(10건)를 초과하여 비즈니스 페널티 및 만족도 감점이 누적되고 있습니다.',
    recommendation:
      'CS 문의 내역과 반품 사유를 매칭 분석하여 상세페이지의 제품 설명 과장 여부나 포장 상태를 점검하십시오.',
  },
  {
    id: 'RULE_CTR_LEAKAGE',
    category: 'CTR',
    priority: 4,
    severity: 3,
    condition: (score) => score < 60.0,
    message: '노출 수 대비 클릭율(CTR)이 저조하여 대표 이미지 소구력이 약화된 상태입니다.',
    recommendation:
      '클릭율을 개선하기 위해 메인 대표 썸네일에 고해상도의 차별적 사용성컷을 배치하고 테스트해 보십시오.',
  },
  {
    id: 'RULE_ROI_EFFICIENCY_DROP',
    category: 'ROI',
    priority: 5,
    severity: 3,
    condition: (score) => score < 50.0,
    message: '광고비 대비 매출액(ROI/ROAS) 효율이 저하되어 광고비 누수가 우려됩니다.',
    recommendation:
      '타겟 세그먼트 정밀화 및 저효율 키워드 단가를 하향 조정하여 노출 비용 낭비를 절감하십시오.',
  },
  {
    id: 'RULE_PROFIT_MARGIN_WARN',
    category: 'Profit',
    priority: 6,
    severity: 4,
    condition: (score) => score < 40.0,
    message: '순이익 마진 스코어가 낮아 마진 구조 개선이 시급합니다.',
    recommendation:
      '배송 조건 재협상, 패키지 간소화 또는 원가 절감을 시도하여 개별 상품의 공헌 마진을 높이십시오.',
  },
  {
    id: 'RULE_REVIEW_SATISFACTION_BAD',
    category: 'Review',
    priority: 7,
    severity: 4,
    condition: (score) => score < 70.0,
    message: '리뷰 평점 지표가 낮아 부정 피드백 및 스토어 신뢰도 하락세가 관찰됩니다.',
    recommendation:
      '평점 3점 이하의 불만족 사유를 정형화하여 제품 매뉴얼 보강 혹은 패키지 정비에 반영하십시오.',
  },
  {
    id: 'RULE_FAVORITE_ENGAGEMENT_LOW',
    category: 'Favorite',
    priority: 8,
    severity: 2,
    condition: (score) => score < 50.0,
    message: '찜하기 및 인게이지먼트 수치가 저조하여 락인(Lock-in) 고객 유치가 미흡합니다.',
    recommendation:
      '알림받기 동의 시 추가 쿠폰 제공 등을 유도하여 단골 고객층 모수를 확보해 두십시오.',
  },
];
