import { RateLimitExceededError } from '../../common/errors/index.js';

export class RateLimiter {
  private static readonly rpmRegistry = new Map<string, number[]>();
  private static readonly tpmRegistry = new Map<string, { timestamp: number; tokens: number }[]>();

  static checkLimit(provider: string, model: string, rpmLimit: number, tpmLimit: number, requestedTokens: number = 500): void {
    const key = `${provider}:${model}`.toUpperCase();
    const now = Date.now();
    const oneMinuteAgo = now - 60000;

    // 1. RPM Limit check
    let requestTimes = this.rpmRegistry.get(key) || [];
    requestTimes = requestTimes.filter((t) => t > oneMinuteAgo);
    
    if (requestTimes.length >= rpmLimit) {
      throw new RateLimitExceededError(`RPM limit of ${rpmLimit} exceeded for provider ${provider}:${model}`);
    }

    // 2. TPM Limit check
    let tokenRecords = this.tpmRegistry.get(key) || [];
    tokenRecords = tokenRecords.filter((r) => r.timestamp > oneMinuteAgo);

    const totalTokensInMinute = tokenRecords.reduce((sum, r) => sum + r.tokens, 0);
    if (totalTokensInMinute + requestedTokens > tpmLimit) {
      throw new RateLimitExceededError(`TPM limit of ${tpmLimit} exceeded for provider ${provider}:${model}`);
    }

    // Record request
    requestTimes.push(now);
    tokenRecords.push({ timestamp: now, tokens: requestedTokens });

    this.rpmRegistry.set(key, requestTimes);
    this.tpmRegistry.set(key, tokenRecords);
  }

  static clear(): void {
    this.rpmRegistry.clear();
    this.tpmRegistry.clear();
  }
}
export default RateLimiter;
