-- 36_create_learning_knowledge.sql
-- Closed-loop Learning Domain tables

BEGIN;

-- 1. learning_knowledge
CREATE TABLE IF NOT EXISTS public.learning_knowledge (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    intelligence_id UUID NOT NULL,
    knowledge_version INTEGER NOT NULL DEFAULT 1,
    feature_summary TEXT NOT NULL DEFAULT '',
    success_pattern TEXT NOT NULL DEFAULT '',
    failure_pattern TEXT NOT NULL DEFAULT '',
    improvement_pattern TEXT NOT NULL DEFAULT '',
    knowledge_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    confidence_score NUMERIC(6, 3) NOT NULL DEFAULT 100.000,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_learning_knowledge PRIMARY KEY (id),
    CONSTRAINT uq_learning_knowledge_intel_version UNIQUE (intelligence_id, knowledge_version),
    CONSTRAINT fk_learning_knowledge_intel FOREIGN KEY (intelligence_id) REFERENCES public.feedback_intelligence(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.learning_knowledge IS '피드백 인텔리전스 기반 결정론적 지식 자산 테이블';
COMMENT ON COLUMN public.learning_knowledge.id IS '학습 지식 식별 UUID';
COMMENT ON COLUMN public.learning_knowledge.intelligence_id IS '부모 피드백 인텔리전스 UUID';
COMMENT ON COLUMN public.learning_knowledge.knowledge_version IS '동일 인텔리전스 분석 차수 버전';

-- 2. learning_vectors
CREATE TABLE IF NOT EXISTS public.learning_vectors (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    knowledge_id UUID NOT NULL,
    vector_version VARCHAR(20) NOT NULL DEFAULT 'v1',
    vector_data JSONB NOT NULL DEFAULT '{}'::jsonb,
    feature_count INTEGER NOT NULL DEFAULT 0,
    checksum VARCHAR(128) NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_learning_vectors PRIMARY KEY (id),
    CONSTRAINT uq_learning_vectors_knowledge_version UNIQUE (knowledge_id, vector_version),
    CONSTRAINT fk_learning_vectors_knowledge FOREIGN KEY (knowledge_id) REFERENCES public.learning_knowledge(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.learning_vectors IS 'AI 프롬프트 주입용 구조화 피처 벡터 테이블';

-- 3. learning_patterns
CREATE TABLE IF NOT EXISTS public.learning_patterns (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    knowledge_id UUID NOT NULL,
    category VARCHAR(50) NOT NULL,
    severity INTEGER NOT NULL DEFAULT 0,
    frequency INTEGER NOT NULL DEFAULT 0,
    pattern_hash VARCHAR(128) NOT NULL DEFAULT '',
    pattern_data JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_learning_patterns PRIMARY KEY (id),
    CONSTRAINT fk_learning_patterns_knowledge FOREIGN KEY (knowledge_id) REFERENCES public.learning_knowledge(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.learning_patterns IS '인텔리전스 피칭에 따른 수집된 행태 패턴 분류 테이블';

-- 4. learning_audit_logs
CREATE TABLE IF NOT EXISTS public.learning_audit_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    knowledge_id UUID NOT NULL,
    action VARCHAR(20) NOT NULL,
    actor_id UUID NOT NULL,
    knowledge_version INTEGER NOT NULL,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

    CONSTRAINT pk_learning_audit_logs PRIMARY KEY (id),
    CONSTRAINT fk_learning_audit_knowledge FOREIGN KEY (knowledge_id) REFERENCES public.learning_knowledge(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.learning_audit_logs IS '학습 지식 관리 행위 감사 로그 테이블';

-- Indexes for performance optimization
CREATE INDEX IF NOT EXISTS idx_learning_knowledge ON public.learning_knowledge(intelligence_id);
CREATE INDEX IF NOT EXISTS idx_learning_vector ON public.learning_vectors(knowledge_id);
CREATE INDEX IF NOT EXISTS idx_learning_pattern ON public.learning_patterns(knowledge_id);
CREATE INDEX IF NOT EXISTS idx_learning_created ON public.learning_knowledge(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_learning_score ON public.learning_knowledge(knowledge_score DESC);

COMMIT;
