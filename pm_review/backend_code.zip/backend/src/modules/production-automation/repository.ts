import { SupabaseClient } from '@supabase/supabase-js';
import {
  ProductionAutomationEntity,
  ProductionPromptLogEntity,
  ProductionExecutionLogEntity,
  IProductionRepository,
} from './types.js';

export class ProductionRepository implements IProductionRepository {
  constructor(private readonly supabase: SupabaseClient) {}

  async createAutomation(
    payload: Partial<ProductionAutomationEntity>,
  ): Promise<ProductionAutomationEntity> {
    const { data, error } = await this.supabase
      .from('production_automations')
      .insert(payload)
      .select('*')
      .single();

    if (error) throw error;
    return data as ProductionAutomationEntity;
  }

  async updateAutomation(
    id: string,
    payload: Partial<ProductionAutomationEntity>,
  ): Promise<ProductionAutomationEntity> {
    const { data, error } = await this.supabase
      .from('production_automations')
      .update(payload)
      .eq('id', id)
      .select('*')
      .single();

    if (error) throw error;
    return data as ProductionAutomationEntity;
  }

  async findAutomation(id: string): Promise<ProductionAutomationEntity | null> {
    const { data, error } = await this.supabase
      .from('production_automations')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error || !data) return null;
    return data as ProductionAutomationEntity;
  }

  async findHistory(workspaceId: string): Promise<ProductionAutomationEntity[]> {
    const { data, error } = await this.supabase
      .from('production_automations')
      .select('*')
      .eq('workspace_id', workspaceId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];
    return data as ProductionAutomationEntity[];
  }

  async createPromptLog(
    payload: Partial<ProductionPromptLogEntity>,
  ): Promise<ProductionPromptLogEntity> {
    const { data, error } = await this.supabase
      .from('production_prompt_logs')
      .insert(payload)
      .select('*')
      .single();

    if (error) throw error;
    return data as ProductionPromptLogEntity;
  }

  async createExecutionLog(
    payload: Partial<ProductionExecutionLogEntity>,
  ): Promise<ProductionExecutionLogEntity> {
    const { data, error } = await this.supabase
      .from('production_execution_logs')
      .insert(payload)
      .select('*')
      .single();

    if (error) throw error;
    return data as ProductionExecutionLogEntity;
  }

  async findExecutionLogs(automationId: string): Promise<ProductionExecutionLogEntity[]> {
    const { data, error } = await this.supabase
      .from('production_execution_logs')
      .select('*')
      .eq('automation_id', automationId)
      .order('created_at', { ascending: true });

    if (error || !data) return [];
    return data as ProductionExecutionLogEntity[];
  }

  // Ownership verification helpers
  async verifyWorkspaceOwnership(workspaceId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('workspaces')
      .select('id, org_id')
      .eq('id', workspaceId)
      .is('deleted_at', null)
      .maybeSingle();

    if (error || !data) return false;
    return data.org_id === userId;
  }

  async verifyKnowledgeOwnership(knowledgeId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('learning_knowledge')
      .select(
        `
        id,
        feedback_intelligence!inner(
          feedback_scores!inner(
            product_performance!inner(
              workspaces!inner(org_id)
            )
          )
        )
      `,
      )
      .eq('id', knowledgeId)
      .maybeSingle();

    if (error || !data) return false;
    const knowledge = data as unknown as {
      feedback_intelligence: {
        feedback_scores: { product_performance: { workspaces: { org_id: string } } };
      };
    };
    return (
      knowledge.feedback_intelligence?.feedback_scores?.product_performance?.workspaces?.org_id ===
      userId
    );
  }

  async verifyAutomationOwnership(automationId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('production_automations')
      .select(
        `
        id,
        workspaces!inner(org_id)
      `,
      )
      .eq('id', automationId)
      .maybeSingle();

    if (error || !data) return false;
    const automation = data as unknown as { workspaces: { org_id: string } };
    return automation.workspaces?.org_id === userId;
  }
}
export default ProductionRepository;
