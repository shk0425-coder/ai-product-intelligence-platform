import { z } from 'zod';

export const toolManifestSchema = z.object({
  name: z.string().min(1),
  category: z.string().min(1),
  version: z.number().int().min(1),
  timeoutMs: z.number().int().min(0).optional(),
  retryLimit: z.number().int().min(0).optional(),
  cacheTtlMs: z.number().int().min(0).optional(),
});

export const createToolSchema = z.object({
  workspaceId: z.string().uuid(),
  name: z.string().min(1),
  description: z.string().optional(),
  category: z.string().min(1),
  manifest: toolManifestSchema,
  inputSchema: z.record(z.any()),
  outputSchema: z.record(z.any()),
  permission: z.array(z.string()),
});

export const createToolVersionSchema = z.object({
  manifest: toolManifestSchema,
  inputSchema: z.record(z.any()),
  outputSchema: z.record(z.any()),
  permission: z.array(z.string()),
});

export const executeToolSchema = z.object({
  workspaceId: z.string().uuid(),
  request: z.record(z.any()),
  workflowExecutionId: z.string().uuid().optional(),
  workflowStepExecutionId: z.string().uuid().optional(),
});

export const createApprovalSchema = z.object({
  workspaceId: z.string().uuid(),
  workflowExecutionId: z.string().uuid(),
  workflowStepExecutionId: z.string().uuid(),
  title: z.string().min(1),
  description: z.string().optional(),
  payload: z.record(z.any()),
});
