import { describe, it, expect, vi, beforeEach, beforeAll, afterEach } from 'vitest';
import { createApp } from '../src/app.js';
import { ResilienceLifecycleManager } from '../src/modules/resilience/lifecycle/lifecycle-manager.js';
import { RunbookRepository, RunbookDependencyManager, RunbookEngine } from '../src/modules/resilience/runbook/runbook-engine.js';
import { RecoveryStateMachine } from '../src/modules/resilience/state/recovery-state-machine.js';
import { IncidentManager } from '../src/modules/resilience/incident/incident-manager.js';
import { CircuitBreaker } from '../src/modules/resilience/breaker/circuit-breaker.js';
import { RecoveryBudgetManager } from '../src/modules/resilience/budget/recovery-budget-manager.js';
import { PriorityRecoveryQueue } from '../src/modules/resilience/queue/priority-recovery-queue.js';
import { EventReplayManager } from '../src/modules/resilience/replay/event-replay-manager.js';
import { PluginSandbox } from '../src/modules/resilience/plugins/plugin-sandbox.js';
import { RecoveryWorkflow } from '../src/modules/resilience/workflow/recovery-workflow.js';
import { SimulationEngine } from '../src/modules/resilience/simulation/simulation-engine.js';
import { AuditTrail } from '../src/modules/resilience/audit/audit-trail.js';
import { BackupManager } from '../src/modules/resilience/backup/backup-manager.js';
import { SelfHealingEngine } from '../src/modules/resilience/engine/self-healing-engine.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeSystemResolver = () => Promise.resolve({ data: null, error: null });
  (globalThis as any).__mockSupabaseForSystem = {
    from: vi.fn().mockImplementation(() => ({
      select: vi.fn().mockImplementation(() => Promise.resolve({ data: [], error: null })),
    })),
  };
});

describe('Production Resilience Platform (Integration & Unit Tests)', () => {
  let app: any;
  const testToken = jwt.sign({ orgId: 'test-org-456' }, 'test-jwt-secret');

  beforeAll(async () => {
    app = await createApp();
  });

  beforeEach(async () => {
    process.env.RESILIENCE_ENABLED = 'true';
    process.env.SELF_HEALING_ENABLED = 'true';
    await ResilienceLifecycleManager.start();
  });

  afterEach(async () => {
    await ResilienceLifecycleManager.stop();
  });

  // 1. Runbook Versioning & Dependencies
  describe('Runbook Engine & Version Control', () => {
    it('should register multiple versions, rollback, and validate execution dependencies', async () => {
      // 1. Register Runbooks
      RunbookRepository.register({
        id: 'runbook-A',
        name: 'ParentRunbook',
        version: 1,
        approvalPolicy: 'AUTO',
        dependencies: [],
        steps: ['step A1'],
      });

      RunbookRepository.register({
        id: 'runbook-B',
        name: 'ChildRunbook',
        version: 1,
        approvalPolicy: 'AUTO',
        dependencies: ['runbook-A'],
        steps: ['step B1'],
      });

      RunbookDependencyManager.register('runbook-B', 'runbook-A');

      const execId = 'exec-rb-1';

      // 2. Child cannot execute before parent completes
      const blocked = await RunbookEngine.execute('runbook-B', execId);
      expect(blocked).toBe(false);

      // 3. Parent runs successfully
      const parentSuccess = await RunbookEngine.execute('runbook-A', execId);
      expect(parentSuccess).toBe(true);

      // 4. Now child runs successfully
      const childSuccess = await RunbookEngine.execute('runbook-B', execId);
      expect(childSuccess).toBe(true);

      // 5. Rollback
      const rbSuccess = await RunbookEngine.rollback('runbook-A', execId, 1);
      expect(rbSuccess).toBe(true);
    });
  });

  // 2. Recovery State Machine Transitions
  describe('Recovery State Machine & Transitions', () => {
    it('should transition through valid flow and throw error on invalid leaps', async () => {
      const execId = 'exec-sm-1';
      
      // Valid transition Detected -> Classified
      await RecoveryStateMachine.transitionTo(execId, 'Detected', 'Classified');
      const history = RecoveryStateMachine.getHistory(execId);
      expect(history.length).toBe(1);
      expect(history[0].state).toBe('Classified');

      // Invalid transition Classified -> RollbackCompleted (should fail)
      await expect(
        RecoveryStateMachine.transitionTo(execId, 'Classified', 'RollbackCompleted')
      ).rejects.toThrow('Illegal state transition');
    });
  });

  // 3. Circuit Breaker & Recovery Budgets
  describe('Circuit Breaker and Budget Controls', () => {
    it('should open breaker on failures, and fail recovery when budget is exhausted', async () => {
      // 1. Budget check
      RecoveryBudgetManager.setLimit(1);
      expect(RecoveryBudgetManager.consume()).toBe(true);
      expect(RecoveryBudgetManager.consume()).toBe(false); // Budget exceeded

      // 2. Circuit Breaker check
      CircuitBreaker.recordFailure();
      CircuitBreaker.recordFailure();
      CircuitBreaker.recordFailure(); // Reaches 3 failures threshold

      expect(CircuitBreaker.getState()).toBe('Open');
      expect(CircuitBreaker.attemptRemediation()).toBe(false); // Cooldown block
    });
  });

  // 4. Priority Recovery Queue
  describe('Priority Recovery Queue', () => {
    it('should sort tasks based on P0~P3 weights', () => {
      let runCount = 0;
      const t1 = { id: 't1', name: 'TaskLow', priority: 'P3' as const, action: async () => { runCount++; } };
      const t2 = { id: 't2', name: 'TaskCritical', priority: 'P0' as const, action: async () => { runCount++; } };

      PriorityRecoveryQueue.push(t1);
      PriorityRecoveryQueue.push(t2);

      const first = PriorityRecoveryQueue.pop();
      expect(first?.id).toBe('t2'); // P0 pops first
    });
  });

  // 5. Recovery Simulation Engine
  describe('Recovery Simulation Engine', () => {
    it('should predict success probability and output reports without executing actual plugins', async () => {
      const result = await SimulationEngine.runSimulation('reconnect_redis');
      expect(result.dryRun).toBe(true);
      expect(result.successProbability).toBe(95);
      expect(result.report).toContain('reconnect_redis');
    });
  });

  // 6. Event Replay Store (Exactly Once)
  describe('Event Replay Store', () => {
    it('should replay registered event and block duplicate replays', async () => {
      const event = {
        eventId: 'evt-replay-1',
        eventType: 'IncidentCreated',
        timestamp: Date.now(),
        data: {},
      };
      await EventReplayManager.recordEvent(event);

      // First replay succeeds
      expect(await EventReplayManager.replay('evt-replay-1')).toBe(true);
      // Second replay gets blocked (Exactly Once Replay protection)
      expect(await EventReplayManager.replay('evt-replay-1')).toBe(false);
    });
  });

  // 7. Plugin Sandbox
  describe('Plugin Sandbox resource limits', () => {
    it('should enforce memory limits and execute within sandbox', async () => {
      const resultNormal = await PluginSandbox.runInSandbox(
        async () => {},
        { cpuLimitPercentage: 50, memoryLimitMb: 256, timeoutMs: 100 }
      );
      expect(resultNormal.success).toBe(true);

      const resultExceeded = await PluginSandbox.runInSandbox(
        async () => {},
        { cpuLimitPercentage: 0, memoryLimitMb: 0, timeoutMs: 100 } // Out of resources
      );
      expect(resultExceeded.success).toBe(false);
      expect(resultExceeded.error).toBe('Resource budget constraint violated');
    });
  });

  // 8. Recovery SLA & Incident Timeline
  describe('Incident SLA calculation', () => {
    it('should calculate classification delay and resolution MTTR', async () => {
      const inc = await IncidentManager.createIncident('redis-conn', 'High');
      
      // Simulate delays
      await new Promise((resolve) => setTimeout(resolve, 50));
      await IncidentManager.classifyIncident(inc.id, 'Redis DB out of memory');
      
      await new Promise((resolve) => setTimeout(resolve, 50));
      await IncidentManager.resolveIncident(inc.id);

      const updated = IncidentManager.findById(inc.id);
      expect(updated?.state).toBe('Resolved');
      expect(updated?.timeline.length).toBe(3);
    });
  });

  // 9. API Manual Approval & Observability Dashboards
  describe('Resilience Dashboard APIs and manual approvals', () => {
    it('should transition WaitingApproval to Recovering via manual approve API', async () => {
      const execId = 'exec-approve-1';
      // Setup initial state
      (RecoveryStateMachine as any).history.set(execId, [{ state: 'WaitingApproval', timestamp: Date.now() }]);

      const responseApprove = await app.inject({
        method: 'POST',
        url: '/api/v1/resilience/approval/approve',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { executionId: execId },
      });
      expect(responseApprove.statusCode).toBe(200);

      const history = RecoveryStateMachine.getHistory(execId);
      expect(history[history.length - 1].state).toBe('Recovering');

      // Verify dashboard retrieval
      const responseDash = await app.inject({
        method: 'GET',
        url: '/api/v1/resilience/dashboard',
        headers: { authorization: `Bearer ${testToken}` },
      });
      expect(responseDash.statusCode).toBe(200);
      const dashBody = JSON.parse(responseDash.payload);
      expect(dashBody.data.currentHealth).toBeDefined();
    });
  });
});
