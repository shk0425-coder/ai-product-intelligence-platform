import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import { createApp } from '../src/app.js';
import { cacheManager } from '../src/modules/infrastructure/cache/cache-manager.js';
import { CacheKeyBuilder } from '../src/modules/infrastructure/cache/cache-key-builder.js';
import { CacheSerializer } from '../src/modules/infrastructure/cache/serializer.js';
import { SingleFlight } from '../src/modules/infrastructure/cache/single-flight.js';
import { eventBus } from '../src/modules/infrastructure/event/event-bus.js';
import { DeadLetterQueue } from '../src/modules/infrastructure/event/dead-letter-queue.js';
import { lockProvider } from '../src/modules/infrastructure/lock/redis-lock.js';
import { GracefulShutdownHandler } from '../src/modules/infrastructure/config/shutdown-handler.js';
import { MetricsCollector } from '../src/modules/infrastructure/monitoring/metrics-service.js';
import { RedisPoolManager } from '../src/modules/infrastructure/config/connection-pool.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeSystemResolver = () => Promise.resolve({ data: null, error: null });

  (globalThis as any).__mockSupabaseForSystem = {
    from: vi.fn().mockImplementation((table) => {
      return {
        select: vi.fn().mockImplementation(() => Promise.resolve({ data: [], error: null })),
      };
    }),
  };
});

vi.mock('@supabase/supabase-js', async (importOriginal) => {
  const actual = await importOriginal() as any;
  return {
    ...actual,
    createClient: (url: string, key: string, options: any) => {
      if ((globalThis as any).__mockSupabaseForSystem) {
        return (globalThis as any).__mockSupabaseForSystem;
      }
      return actual.createClient(url, key, options);
    },
  };
});

describe('Distributed Redis Infrastructure & Event Bus (Integration Tests)', () => {
  let app: any;
  const testToken = jwt.sign({ orgId: 'test-org-123' }, 'test-jwt-secret');
  const workspaceId = 'test-workspace-777';

  beforeAll(async () => {
    app = await createApp();
  });

  beforeEach(() => {
    MetricsCollector.clear();
    DeadLetterQueue.clear();
    lockProvider.clearAll();
    eventBus.clearHandlers();
    eventBus.clearIdempotencyCache();
    SingleFlight.clear();
    RedisPoolManager.resetAll();
    cacheManager.getRedisProvider().setOnlineStatus(true);
  });

  // 1. Custom Serialization Tests
  describe('Cache Serialization Policy', () => {
    it('should serialize BigInt, Date and Buffer types safely and reconstruct them during deserialization', () => {
      const payload: Record<string, any> = {
        big: BigInt(9007199254740991),
        time: new Date('2026-06-28T12:00:00.000Z'),
        buf: Buffer.from('Antigravity Platform'),
        normal: 'JTBD',
      };

      // Add circular reference emulation
      const circular: any = {};
      circular.self = circular;
      payload.circular = circular;

      const serialized = CacheSerializer.serialize(payload);
      expect(serialized).toContain('__BIGINT__');
      expect(serialized).toContain('__DATE__');
      expect(serialized).toContain('__BUFFER__');
      expect(serialized).toContain('__CIRCULAR__');

      const restored = CacheSerializer.deserialize(serialized);
      expect(restored.big).toBe(BigInt(9007199254740991));
      expect(restored.time).toBeInstanceOf(Date);
      expect(restored.time.toISOString()).toBe('2026-06-28T12:00:00.000Z');
      expect(Buffer.isBuffer(restored.buf)).toBe(true);
      expect(restored.buf.toString()).toBe('Antigravity Platform');
      expect(restored.circular.self).toBe('[Circular]');
    });
  });

  // 2. Redis Key Versioning Tests
  describe('Redis Key Versioning', () => {
    it('should prefix all generated cache keys with v1 version namespace', () => {
      const key = CacheKeyBuilder.build('prompt', workspaceId, '1.0.0', 'creative', { text: 'test' });
      expect(key.startsWith('v1:prompt:')).toBe(true);
    });
  });

  // 3. Event Versioning & Ordering Tests
  describe('Event Versioning & Sequential Ordering', () => {
    it('should route events by matching event_version and maintain backward compatibility', async () => {
      let v1Called = 0;
      let v2Called = 0;

      eventBus.subscribe('WorkflowStarted', async () => { v1Called++; }, 1);
      eventBus.subscribe('WorkflowStarted', async () => { v2Called++; }, 2);

      const eventV2 = {
        eventId: 'evt-v2',
        eventType: 'WorkflowStarted' as const,
        timestamp: new Date().toISOString(),
        workspaceId,
        event_version: 2,
        data: { workflowId: 'wf-99' },
      };

      await eventBus.publish(eventV2);
      expect(v1Called).toBe(0);
      expect(v2Called).toBe(1);
    });

    it('should drop out-of-order sequence events and serialize same workflowId FIFO events in order', async () => {
      const sequenceRecords: number[] = [];
      eventBus.subscribe('WorkflowStarted', async (evt) => {
        sequenceRecords.push(evt.eventSequenceNumber || 0);
      });

      const baseEvent = {
        eventType: 'WorkflowStarted' as const,
        timestamp: new Date().toISOString(),
        workspaceId,
        data: { workflowId: 'workflow-ordered-123' },
      };

      // 1. Valid Seq 1
      await eventBus.publish({ ...baseEvent, eventId: 'evt-1', eventSequenceNumber: 1 });
      // 2. Out-of-order Seq 1 (duplicate) - should be dropped
      await eventBus.publish({ ...baseEvent, eventId: 'evt-2', eventSequenceNumber: 1 });
      // 3. Out-of-order Seq 0 (older) - should be dropped
      await eventBus.publish({ ...baseEvent, eventId: 'evt-3', eventSequenceNumber: 0 });
      // 4. Valid Seq 3
      await eventBus.publish({ ...baseEvent, eventId: 'evt-4', eventSequenceNumber: 3 });

      expect(sequenceRecords).toEqual([1, 3]);
    });
  });

  // 4. Poison Message & DLQ Status Tests
  describe('DLQ Poison Message Isolation', () => {
    it('should quarantine recurrent failures as POISON and prevent automatic execution', async () => {
      const eventPayload = {
        eventId: 'evt-poison-1',
        eventType: 'WorkflowFailed' as const,
        timestamp: new Date().toISOString(),
        workspaceId,
        data: { workflowId: 'wf-failing', error: 'Database timeout' },
      };

      // Push failing task into DLQ
      await DeadLetterQueue.push(eventPayload, 'Initial crash', 3);

      const entries = await DeadLetterQueue.getEntries();
      expect(entries[0].status).toBe('POISON');

      // Attempt manual replay three times to trigger absolute lockout
      const dummyHandler = async () => { throw new Error('Crash again'); };
      await DeadLetterQueue.replay('evt-poison-1', dummyHandler);
      await DeadLetterQueue.replay('evt-poison-1', dummyHandler);
      await DeadLetterQueue.replay('evt-poison-1', dummyHandler);

      // Replay attempts must lock at max 3
      const finalReplay = await DeadLetterQueue.replay('evt-poison-1', dummyHandler);
      expect(finalReplay).toBe(false); // Refused automatic replay

      // Test manual ignore and archive status
      await DeadLetterQueue.ignore('evt-poison-1');
      expect(entries[0].status).toBe('IGNORED');

      await DeadLetterQueue.archive('evt-poison-1');
      expect(entries[0].status).toBe('ARCHIVED');
    });
  });

  // 5. Connection Pool and Cache Warm-up Tests
  describe('Connection Pool Management & Cache Warm-up', () => {
    it('should split cache, pubsub and lock pools and track connection stats', async () => {
      const cacheConn = await RedisPoolManager.cachePool.acquireConnection();
      expect(cacheConn.startsWith('cache_conn_')).toBe(true);

      const stats = RedisPoolManager.getSummary();
      expect(stats.cache.activeConnections).toBe(1);
      expect(stats.pubsub.activeConnections).toBe(0);

      await RedisPoolManager.cachePool.releaseConnection(cacheConn);
      expect(RedisPoolManager.cachePool.getStats().activeConnections).toBe(0);
    });

    it('should warmup namespaces background loading and report completion metrics', async () => {
      await cacheManager.warmup(['prompt', 'workflow']);
      expect(cacheManager.getWarmupProgress()).toBe(100);

      const val = await cacheManager.get('v1:prompt:warmup_init');
      expect(val).toEqual({ initialized: true });
    });
  });

  // 6. Single Flight Tests
  describe('Single Flight (Stampede protection)', () => {
    it('should aggregate duplicate cache miss calculations and call resolve 1 time', async () => {
      let callCount = 0;
      const fn = async () => {
        callCount++;
        await new Promise((resolve) => setTimeout(resolve, 50));
        return { count: callCount };
      };

      const promises = Array.from({ length: 5 }).map(() =>
        SingleFlight.do('pricing-key', fn)
      );

      const results = await Promise.all(promises);
      expect(callCount).toBe(1);
      results.forEach((res) => {
        expect(res).toEqual({ count: 1 });
      });
    });
  });

  // 7. Lock Owner & Circuit Breaker & Graceful Shutdown Checks
  describe('Graceful Shutdown triggers and Monitoring API', () => {
    it('should reject new events during shutdown', async () => {
      await GracefulShutdownHandler.initiate('SIGTERM');

      const payload = {
        eventId: 'evt-uuid-shutdown',
        eventType: 'WorkflowStarted' as const,
        timestamp: new Date().toISOString(),
        workspaceId,
        data: { workflowId: 'wf-1' },
      };

      await expect(eventBus.publish(payload)).rejects.toThrow('EventBus is shutting down');
    });

    it('should return metrics and pool stats from GET /api/v1/system/metrics', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/system/metrics',
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data.pools.cache).toBeDefined();
    });
  });
});
