import { FeedbackIntelligenceEntity } from './types.js';
import { FeedbackIntelligenceDto } from './dto.js';

export class FeedbackIntelligenceMapper {
  static toResponseDto(entity: FeedbackIntelligenceEntity): FeedbackIntelligenceDto {
    return {
      intelligenceId: entity.id,
      feedbackScoreId: entity.feedback_score_id,
      analysisVersion: entity.analysis_version,
      ruleVersion: entity.rule_version,
      strengthSummary: entity.strength_summary,
      weaknessSummary: entity.weakness_summary,
      bottleneckSummary: entity.bottleneck_summary,
      improvementSummary: entity.improvement_summary,
      rootCauses: entity.root_causes,
      recommendations: entity.recommendations,
      detectedRules: entity.detected_rules,
      impactScore: Number(entity.impact_score),
      confidenceScore: Number(entity.confidence_score),
      executionTimeMs: entity.execution_time_ms,
      analyzedAt: entity.analyzed_at,
      createdAt: entity.created_at,
    };
  }

  static toResponseDtoList(entities: FeedbackIntelligenceEntity[]): FeedbackIntelligenceDto[] {
    return entities.map((entity) => this.toResponseDto(entity));
  }
}
export default FeedbackIntelligenceMapper;
