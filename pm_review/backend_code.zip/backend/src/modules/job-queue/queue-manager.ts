import { JobQueueRepository } from './repository.js';
import { JobQueueEntity } from './types.js';
import { EnqueueJobDto } from './dto.js';
import { QUEUE_CONSTANTS } from './constants.js';
import { JobScheduler } from './scheduler.js';
import { JobQueueHooks } from './hooks.js';
import { JobNotFoundError, JobConflictError } from '@/common/errors/index.js';

export class QueueManager {
  constructor(private readonly repository: JobQueueRepository) {}

  async enqueue(dto: EnqueueJobDto): Promise<JobQueueEntity> {
    const { workspaceId, jobType, payload, priority = QUEUE_CONSTANTS.DEFAULT_PRIORITY, scheduledAt } = dto;

    const sched = JobScheduler.determineScheduleType(scheduledAt);

    const job = await this.repository.createJob({
      workspace_id: workspaceId,
      job_type: jobType.toUpperCase(),
      payload,
      priority,
      payload_version: QUEUE_CONSTANTS.DEFAULT_PAYLOAD_VERSION,
      status: 'PENDING',
      schedule_type: sched.scheduleType,
      scheduled_at: sched.scheduledAt,
      retry_count: 0,
      max_retry: QUEUE_CONSTANTS.DEFAULT_MAX_RETRY,
      cancel_requested: false,
    });

    await JobQueueHooks.onJobQueued(job);
    return job;
  }

  async cancel(jobId: string): Promise<JobQueueEntity> {
    const job = await this.repository.findJob(jobId);
    if (!job) {
      throw new JobNotFoundError(`Job with ID ${jobId} not found`);
    }

    if (job.status === 'SUCCESS' || job.status === 'FAILED') {
      throw new JobConflictError(`Job ${jobId} is already in a final state: ${job.status}`);
    }

    // Set cancel_requested flag. The running worker will observe this gracefully.
    return this.repository.updateJob(jobId, {
      cancel_requested: true,
      status: 'FAILED',
      error_message: 'Job cancelled by user request',
      completed_at: new Date().toISOString(),
    });
  }

  async changePriority(jobId: string, newPriority: number): Promise<JobQueueEntity> {
    const job = await this.repository.findJob(jobId);
    if (!job) {
      throw new JobNotFoundError(`Job with ID ${jobId} not found`);
    }

    return this.repository.updateJob(jobId, {
      priority: newPriority,
    });
  }
}
