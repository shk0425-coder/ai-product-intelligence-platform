import { AlertRule, AlertRuleRepository } from './rule-repository.js';
import { AlertDeduplicator } from './deduplicator.js';
import { MetricsAggregator } from '../metrics/aggregator.js';

export interface AlertChannel {
  name: string;
  send(message: string): Promise<boolean>;
}

export class ConsoleAlertChannel implements AlertChannel {
  name = 'Console';
  async send(message: string): Promise<boolean> {
    console.warn(`[ALERT] ${message}`);
    return true;
  }
}

export class SlackAlertChannel implements AlertChannel {
  name = 'Slack';
  private sentMessages: string[] = [];

  async send(message: string): Promise<boolean> {
    this.sentMessages.push(message);
    // Emulated Slack Webhook dispatch.
    return true;
  }

  getSentMessages(): string[] {
    return this.sentMessages;
  }

  clear(): void {
    this.sentMessages = [];
  }
}

export class AlertEngine {
  private static channels: AlertChannel[] = [new ConsoleAlertChannel()];
  private static evaluationInterval: NodeJS.Timeout | null = null;

  static setChannels(channels: AlertChannel[]): void {
    this.channels = channels;
  }

  static addChannel(channel: AlertChannel): void {
    this.channels.push(channel);
  }

  static init(): void {
    const enabled = process.env.OBS_ALERT_ENABLED !== 'false';
    if (!enabled) return;

    this.evaluationInterval = setInterval(() => {
      this.evaluateRules();
    }, 10000); // Check rules every 10s

    if (this.evaluationInterval.unref) {
      this.evaluationInterval.unref();
    }
  }

  static async evaluateRules(): Promise<void> {
    const rules = AlertRuleRepository.getEnabledRules();
    for (const rule of rules) {
      // Fetch latest aggregation for this metric
      const agg = MetricsAggregator.getAggregated(rule.metricName, rule.windowMinutes);
      if (!agg) continue;

      const value = agg.avg; // Evaluate average value over window
      let triggered = false;

      if (rule.operator === 'GT' && value > rule.threshold) triggered = true;
      if (rule.operator === 'LT' && value < rule.threshold) triggered = true;
      if (rule.operator === 'EQ' && value === rule.threshold) triggered = true;

      if (triggered) {
        const msg = `Rule "${rule.name}" triggered: ${rule.metricName} average is ${value.toFixed(2)} (Threshold: ${rule.operator} ${rule.threshold})`;
        await this.triggerAlert(rule, value, msg);
      } else {
        // Attempt automatic recovery
        const recoveredInstance = AlertDeduplicator.resolve(rule.id);
        if (recoveredInstance) {
          const msg = `[RESOLVED] Rule "${rule.name}" has returned to normal. Value: ${value.toFixed(2)}`;
          for (const channel of this.channels) {
            await channel.send(msg);
          }
        }
      }
    }
  }

  static async triggerAlert(rule: AlertRule, value: number, msg: string): Promise<void> {
    const enabled = process.env.OBS_ALERT_ENABLED !== 'false';
    if (!enabled) return;

    const { dispatch, instance } = AlertDeduplicator.shouldDispatch(rule, value, msg);
    if (!dispatch || !instance) return;

    // Send asynchronously across channels
    const finalMsg = `[${instance.severity}] ${instance.message} (Fired ${instance.count} times)`;
    for (const channel of this.channels) {
      try {
        await channel.send(finalMsg);
      } catch {
        // Resilience: alert dispatcher failure should not crash system
      }
    }
  }

  static shutdown(): void {
    if (this.evaluationInterval) {
      clearInterval(this.evaluationInterval);
      this.evaluationInterval = null;
    }
  }
}
