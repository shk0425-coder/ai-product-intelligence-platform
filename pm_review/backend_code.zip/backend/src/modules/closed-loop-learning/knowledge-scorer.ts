export const KnowledgeScorer = {
  calculate(featureCount: number, patternCount: number, intelligenceConfidence: number): number {
    // 1. Calculate Feature Coverage out of 1.0 (5 features target)
    const featureCoverage = Math.min(1.0, featureCount / 5.0);

    // 2. Calculate Pattern Coverage out of 1.0 (3 patterns target)
    const patternCoverage = Math.min(1.0, patternCount / 3.0);

    // 3. Overall Weighted sum: (Coverage weights contribute 30 points each, confidence accounts for 40 points)
    const overall = featureCoverage * 30.0 + patternCoverage * 30.0 + intelligenceConfidence * 0.4;

    // Clamp score strictly between 0.000 and 100.000
    return Math.min(100.0, Math.max(0.0, overall));
  },
};
export default KnowledgeScorer;
