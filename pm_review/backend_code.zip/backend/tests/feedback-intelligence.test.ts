import { vi, describe, it, expect, beforeAll } from 'vitest';

const { mockQueryBuilder, setResolver, mockSupabase } = vi.hoisted(() => {
  const qb: any = {
    select: vi.fn(),
    insert: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
    eq: vi.fn(),
    is: vi.fn(),
    order: vi.fn(),
    limit: vi.fn(),
    maybeSingle: vi.fn(),
    single: vi.fn(),
  };

  const methods = ['select', 'insert', 'update', 'delete', 'eq', 'is', 'order', 'limit', 'maybeSingle', 'single'];
  for (const m of methods) {
    qb[m].mockImplementation(() => qb);
  }

  let resolver = () => Promise.resolve({ data: null, count: 0, error: null });
  qb.then = (onfulfilled: any) => resolver().then(onfulfilled);

  const supabaseMock = {
    from: vi.fn().mockReturnValue(qb),
  };

  return {
    mockQueryBuilder: qb,
    setResolver: (newResolver: any) => {
      resolver = newResolver;
    },
    mockSupabase: supabaseMock,
  };
});

vi.mock('@/config/supabase.js', () => {
  return {
    supabase: mockSupabase,
  };
});

import { createApp } from '@/app.js';
import jwt from 'jsonwebtoken';
import { env } from '@/config/env.js';
import { FeedbackRuleEngine } from '../src/modules/feedback-intelligence/rule-engine.js';
import { ImpactCalculator } from '../src/modules/feedback-intelligence/impact-calculator.js';
import { ConfidenceCalculator } from '../src/modules/feedback-intelligence/confidence-calculator.js';

const generateTestToken = (userId: string, email: string) => {
  return jwt.sign({ userId, email, role: 'USER' }, env.JWT_SECRET, { expiresIn: '1h' });
};

describe('Feedback Intelligence Module Tests', () => {
  let app: any;
  const mockUserId = '11111111-1111-1111-1111-111111111111';
  const otherUserId = '22222222-2222-2222-2222-222222222222';
  const testToken = generateTestToken(mockUserId, 'test@example.com');

  const feedbackScoreId = '33333333-3333-3333-3333-333333333333';
  const productId = '44444444-4444-4444-4444-444444444444';
  const intelligenceId = '55555555-5555-5555-5555-555555555555';

  beforeAll(async () => {
    app = await createApp();
  });

  describe('Pure Engines Verification', () => {
    it('should correctly match rule conditions on score drop', () => {
      const matched = FeedbackRuleEngine.matchRules({
        salesScore: 30.0, // Matches RULE_SALES_CRITICAL_DROP (Sales score < 40)
        reviewScore: 90.0,
        conversionScore: 80.0,
        ctrScore: 70.0,
        roiScore: 70.0,
        profitScore: 70.0,
        favoriteScore: 70.0,
        refundPenalty: 0.0,
        metrics: { refund_count: 2 },
      });

      expect(matched.length).toBe(1);
      expect(matched[0].id).toBe('RULE_SALES_CRITICAL_DROP');
    });

    it('should calculate impact score proportional to severity', () => {
      const mockRules: any[] = [
        { severity: 5 },
        { severity: 4 },
      ];
      // Sum of severity = 9 -> 9 * 10 = 90.0
      expect(ImpactCalculator.calculate(mockRules)).toBe(90.0);
    });

    it('should calculate confidence score based on data completeness', () => {
      // 1 missing field -> 100 - 15 = 85
      const perfPayload = { sales_count: 100, review_score: 4.5, conversion_score: 12.0, favorite_count: 50 }; // refund_count missing
      const metricsPayload = { ctr: 3.0, roi: 500.0, profit: 100000 };
      expect(ConfidenceCalculator.calculate(perfPayload, metricsPayload)).toBe(85.0);
    });
  });

  describe('API Integrations / Authentication Checks', () => {
    it('should reject analyze requests without authentication', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback-intelligence/analyze',
        payload: { feedbackScoreId },
      });
      expect(response.statusCode).toBe(401);
    });

    it('should block analyze requests when requester does not own feedback score', async () => {
      setResolver(() => {
        // verifyFeedbackOwner -> false
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback-intelligence/analyze',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { feedbackScoreId },
      });

      expect(response.statusCode).toBe(403);
    });
  });

  describe('POST /api/v1/feedback-intelligence/analyze', () => {
    it('should successfully analyze and create feedback intelligence report', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyFeedbackOwner -> true
        if (callCount === 1) {
          return Promise.resolve({ data: { product_performance: { workspaces: { org_id: mockUserId } } }, error: null });
        }
        // 2. Fetch Feedback Score
        if (callCount === 2) {
          return Promise.resolve({
            data: {
              id: feedbackScoreId,
              performance_id: 'perf-id',
              sales_score: 30, // Trigger Sales drop
              review_score: 95,
              conversion_score: 80,
              engagement_score: 80,
              profitability_score: 85,
              refund_penalty: 0,
              overall_score: 75,
            },
            error: null,
          });
        }
        // 3. Fetch Parent Performance Snapshot
        if (callCount === 3) {
          return Promise.resolve({
            data: {
              id: 'perf-id',
              sales_count: 300,
              review_score: 4.8,
              conversion_score: 12.0,
              favorite_count: 50,
              refund_count: 0,
            },
            error: null,
          });
        }
        // 4. Fetch Metrics Snapshot
        if (callCount === 4) {
          return Promise.resolve({
            data: {
              performance_id: 'perf-id',
              ctr: 3.5,
              roi: 400.0,
              profit: 2000000.0,
            },
            error: null,
          });
        }
        // 5. Find existing intelligence -> null
        if (callCount === 5) {
          return Promise.resolve({ data: null, error: null });
        }
        // 6. Create Intelligence Entity (Insert)
        if (callCount === 6) {
          return Promise.resolve({
            data: {
              id: intelligenceId,
              feedback_score_id: feedbackScoreId,
              analysis_version: 1,
              rule_version: 'v1',
              strength_summary: '우수 강점 요인 검출',
              weakness_summary: '우려 요인 검출',
              bottleneck_summary: '병목 현상 식별',
              improvement_summary: '개선안 마련',
              root_causes: ['Sales drop issue'],
              recommendations: [{ priority: 1, category: 'Sales', recommendation: 'Promotional discount', expectedImpact: 100 }],
              detected_rules: [{ ruleId: 'RULE_SALES_CRITICAL_DROP', category: 'Sales', severity: 5, message: 'Sales drop' }],
              impact_score: 50.0,
              confidence_score: 100.0,
              execution_time_ms: 10,
              analyzed_at: new Date().toISOString(),
              created_at: new Date().toISOString(),
            },
            error: null,
          });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback-intelligence/analyze',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { feedbackScoreId },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.success).toBe(true);
      expect(body.data.intelligenceId).toBe(intelligenceId);
      expect(body.data.analysisVersion).toBe(1);
      expect(body.data.rootCauses.length).toBe(1);
    });

    it('should throw 409 Conflict if analysis already exists', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyFeedbackOwner
        if (callCount === 1) return Promise.resolve({ data: { product_performance: { workspaces: { org_id: mockUserId } } }, error: null });
        // 2. Fetch Feedback Score
        if (callCount === 2) return Promise.resolve({ data: { id: feedbackScoreId, performance_id: 'perf-id' }, error: null });
        // 3. Fetch Parent Performance
        if (callCount === 3) return Promise.resolve({ data: { id: 'perf-id' }, error: null });
        // 4. Fetch Metrics
        if (callCount === 4) return Promise.resolve({ data: { performance_id: 'perf-id' }, error: null });
        // 5. Existing intelligence report -> returns existing record
        return Promise.resolve({ data: { id: intelligenceId, analysis_version: 1 }, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback-intelligence/analyze',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { feedbackScoreId },
      });

      expect(response.statusCode).toBe(409);
    });
  });

  describe('POST /api/v1/feedback-intelligence/reanalyze', () => {
    it('should regenerate intelligence report and increment analysis version', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyFeedbackOwner
        if (callCount === 1) return Promise.resolve({ data: { product_performance: { workspaces: { org_id: mockUserId } } }, error: null });
        // 2. Fetch Feedback Score
        if (callCount === 2) return Promise.resolve({ data: { id: feedbackScoreId, performance_id: 'perf-id' }, error: null });
        // 3. Fetch Performance
        if (callCount === 3) return Promise.resolve({ data: { id: 'perf-id' }, error: null });
        // 4. Fetch Metrics
        if (callCount === 4) return Promise.resolve({ data: { performance_id: 'perf-id' }, error: null });
        // 5. Fetch existing intelligence -> returns version 1
        if (callCount === 5) return Promise.resolve({ data: { id: intelligenceId, analysis_version: 1 }, error: null });
        // 6. Update intelligence report
        return Promise.resolve({
          data: {
            id: intelligenceId,
            feedback_score_id: feedbackScoreId,
            analysis_version: 2, // version incremented
            rule_version: 'v1',
            impact_score: 80.0,
            confidence_score: 100.0,
            analyzed_at: new Date().toISOString(),
            created_at: new Date().toISOString(),
          },
          error: null,
        });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback-intelligence/reanalyze',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { feedbackScoreId },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.analysisVersion).toBe(2);
    });
  });

  describe('GET /api/v1/feedback-intelligence/latest/:productId', () => {
    it('should return latest intelligence report for a product', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyProductOwner
        if (callCount === 1) return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        // 2. findLatest
        return Promise.resolve({
          data: {
            id: intelligenceId,
            feedback_score_id: feedbackScoreId,
            analysis_version: 1,
            impact_score: 40.0,
            confidence_score: 100.0,
          },
          error: null,
        });
      });

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/feedback-intelligence/latest/${productId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.intelligenceId).toBe(intelligenceId);
      expect(body.data.impactScore).toBe(40.0);
    });
  });
});
