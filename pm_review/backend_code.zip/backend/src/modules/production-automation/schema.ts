import { z } from 'zod';

export const runProductionSchema = z.object({
  workspaceId: z.string().uuid('Workspace ID must be a valid UUID'),
  knowledgeId: z.string().uuid('Knowledge ID must be a valid UUID'),
  userRequest: z.string().min(1, 'User request must not be empty'),
  bestPractice: z.string().trim().optional(),
});

export const retryProductionSchema = z.object({
  automationId: z.string().uuid('Automation ID must be a valid UUID'),
});

export const automationIdParamSchema = z.object({
  automationId: z.string().uuid('Invalid automation ID format'),
});

export const automationWorkspaceParamSchema = z.object({
  workspaceId: z.string().uuid('Invalid workspace ID format'),
});

export type RunProductionInput = z.infer<typeof runProductionSchema>;
export type RetryProductionInput = z.infer<typeof retryProductionSchema>;
export type AutomationIdParamInput = z.infer<typeof automationIdParamSchema>;
export type AutomationWorkspaceParamInput = z.infer<typeof automationWorkspaceParamSchema>;
