import { ToolManifest, ToolStatus, ApprovalStatus } from './types.js';

export interface CreateToolDto {
  workspaceId: string;
  name: string;
  description?: string;
  category: string;
  manifest: ToolManifest;
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown>;
  permission: string[];
}

export interface CreateToolVersionDto {
  manifest: ToolManifest;
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown>;
  permission: string[];
}

export interface ExecuteToolDto {
  workspaceId: string;
  request: Record<string, unknown>;
  workflowExecutionId?: string;
  workflowStepExecutionId?: string;
}

export interface CreateApprovalDto {
  workspaceId: string;
  workflowExecutionId: string;
  workflowStepExecutionId: string;
  title: string;
  description?: string;
  payload: Record<string, unknown>;
}

export interface ToolDefinitionDto {
  id: string;
  workspaceId: string;
  name: string;
  description?: string;
  category: string;
  latestVersion: number;
  currentVersionId?: string;
  status: ToolStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ToolVersionDto {
  id: string;
  toolId: string;
  version: number;
  manifest: ToolManifest;
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown>;
  permission: string[];
  timeoutMs: number;
  retryLimit: number;
  checksum: string;
  createdAt: string;
}

export interface ApprovalRequestDto {
  id: string;
  workspaceId: string;
  workflowExecutionId: string;
  workflowStepExecutionId: string;
  title: string;
  description?: string;
  payload: Record<string, unknown>;
  status: ApprovalStatus;
  timeoutAt?: string;
  requestedBy?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  createdAt: string;
}
