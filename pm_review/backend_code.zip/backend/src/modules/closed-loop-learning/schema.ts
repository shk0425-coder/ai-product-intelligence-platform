import { z } from 'zod';

export const generateLearningSchema = z.object({
  intelligenceId: z.string().uuid('Intelligence ID must be a valid UUID'),
  vectorVersion: z.string().trim().max(20).default('v1'),
});

export const regenerateLearningSchema = z.object({
  intelligenceId: z.string().uuid('Intelligence ID must be a valid UUID'),
  vectorVersion: z.string().trim().max(20).default('v1'),
});

export const learningIdParamSchema = z.object({
  knowledgeId: z.string().uuid('Invalid knowledge ID format'),
});

export const learningProductParamSchema = z.object({
  productId: z.string().uuid('Invalid product ID format'),
});

export type GenerateLearningInput = z.infer<typeof generateLearningSchema>;
export type RegenerateLearningInput = z.infer<typeof regenerateLearningSchema>;
export type LearningIdParamInput = z.infer<typeof learningIdParamSchema>;
export type LearningProductParamInput = z.infer<typeof learningProductParamSchema>;
