import { RunbookRepository, RunbookDependencyManager, RunbookEngine } from '../runbook/runbook-engine.js';
import { RecoveryStateMachine } from '../state/recovery-state-machine.js';
import { IncidentManager } from '../incident/incident-manager.js';
import { CircuitBreaker } from '../breaker/circuit-breaker.js';
import { RecoveryBudgetManager } from '../budget/recovery-budget-manager.js';
import { PriorityRecoveryQueue } from '../queue/priority-recovery-queue.js';
import { EventReplayManager } from '../replay/event-replay-manager.js';
import { RecoveryWorkflow } from '../workflow/recovery-workflow.js';
import { SimulationEngine } from '../simulation/simulation-engine.js';
import { AuditTrail } from '../audit/audit-trail.js';
import { BackupManager } from '../backup/backup-manager.js';

export class ResilienceLifecycleManager {
  static async start(): Promise<void> {
    const enabled = process.env.RESILIENCE_ENABLED !== 'false';
    if (!enabled) return;

    // Load default rules and settings
    RunbookRepository.clear();
    RunbookDependencyManager.clear();
    RunbookEngine.clear();
    RecoveryStateMachine.clear();
    IncidentManager.clear();
    CircuitBreaker.clear();
    RecoveryBudgetManager.clear();
    PriorityRecoveryQueue.clear();
    EventReplayManager.clear();
    RecoveryWorkflow.clear();
    SimulationEngine.clear();
    AuditTrail.clear();
    BackupManager.clear();

    // Register Default Runbooks for operational platform
    RunbookRepository.register({
      id: 'reconnect_redis',
      name: 'Reconnect Redis',
      version: 1,
      approvalPolicy: 'AUTO',
      dependencies: [],
      steps: ['Ping Redis', 'Recreate connection pool'],
    });

    RunbookRepository.register({
      id: 'restart_worker',
      name: 'Restart Worker Process',
      version: 1,
      approvalPolicy: 'AUTO',
      dependencies: [],
      steps: ['Kill process', 'Spawn child node process'],
    });

    RunbookRepository.register({
      id: 'manual_remediation',
      name: 'Manual Critical Remediation',
      version: 1,
      approvalPolicy: 'MANUAL',
      dependencies: [],
      steps: ['Alert Slack', 'Wait admin response'],
    });
  }

  static async stop(): Promise<void> {
    RunbookRepository.clear();
    RunbookDependencyManager.clear();
    RunbookEngine.clear();
    RecoveryStateMachine.clear();
    IncidentManager.clear();
    CircuitBreaker.clear();
    RecoveryBudgetManager.clear();
    PriorityRecoveryQueue.clear();
    EventReplayManager.clear();
    RecoveryWorkflow.clear();
    SimulationEngine.clear();
    AuditTrail.clear();
    BackupManager.clear();
  }
}
export default ResilienceLifecycleManager;
