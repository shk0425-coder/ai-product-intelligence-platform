import { z } from 'zod';

export const analyzeFeedbackSchema = z.object({
  feedbackScoreId: z.string().uuid('Feedback Score ID must be a valid UUID'),
  ruleVersion: z.string().trim().max(20).default('v1'),
});

export const reanalyzeFeedbackSchema = z.object({
  feedbackScoreId: z.string().uuid('Feedback Score ID must be a valid UUID'),
  ruleVersion: z.string().trim().max(20).default('v1'),
});

export const feedbackIdParamSchema = z.object({
  feedbackId: z.string().uuid('Invalid feedback score ID format'),
});

export const feedbackIntelProductParamSchema = z.object({
  productId: z.string().uuid('Invalid product ID format'),
});

export type AnalyzeFeedbackInput = z.infer<typeof analyzeFeedbackSchema>;
export type ReanalyzeFeedbackInput = z.infer<typeof reanalyzeFeedbackSchema>;
export type FeedbackIdParamInput = z.infer<typeof feedbackIdParamSchema>;
export type FeedbackIntelProductParamInput = z.infer<typeof feedbackIntelProductParamSchema>;
