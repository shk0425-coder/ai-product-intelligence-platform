import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import crypto from 'crypto';
import { createApp } from '../src/app.js';
import { ToolSchemaValidator } from '../src/modules/tool/validator.js';
import { ToolPermissionChecker } from '../src/modules/tool/permission.js';
import { ToolSandbox } from '../src/modules/tool/sandbox.js';
import { ApprovalStateMachine } from '../src/modules/tool/approval-state-machine.js';
import { WorkflowResumeManager } from '../src/modules/tool/resume-manager.js';
import { ToolInMemoryCache, ToolCacheKeyGenerator } from '../src/modules/tool/cache.js';
import { ToolRepository } from '../src/modules/tool/repository.js';
import { ToolService } from '../src/modules/tool/service.js';
import { ToolManifest, ToolDefinitionEntity, ToolVersionEntity, ApprovalRequestEntity } from '../src/modules/tool/types.js';
import { ValidationError } from '../src/common/errors/index.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeToolResolver = () => Promise.resolve({ data: null, error: null });

  const queryMockObj = {
    insert: vi.fn().mockImplementation((payload) => {
      return {
        select: vi.fn().mockImplementation(() => {
          return {
            single: vi.fn().mockImplementation(() => (globalThis as any).__activeToolResolver(queryMockObj._table, 'insert', payload)),
          };
        }),
      };
    }),
    update: vi.fn().mockImplementation((payload) => {
      return {
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            select: vi.fn().mockImplementation(() => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeToolResolver(queryMockObj._table, 'update', { col, val, payload })),
              };
            }),
          };
        }),
      };
    }),
    select: vi.fn().mockImplementation((cols) => {
      const chain = {
        is: vi.fn().mockImplementation((col, val) => {
          return {
            order: vi.fn().mockImplementation((col2, val2) => {
              return Promise.resolve((globalThis as any).__activeToolResolver(queryMockObj._table, 'select_all_tools'));
            }),
          };
        }),
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            is: vi.fn().mockImplementation((col2, val2) => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeToolResolver(queryMockObj._table, 'select_tool_by_id', { col, val })),
              };
            }),
            order: vi.fn().mockImplementation((col2, val2) => {
              return Promise.resolve((globalThis as any).__activeToolResolver(queryMockObj._table, 'select_versions', { col, val }));
            }),
            maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeToolResolver(queryMockObj._table, 'select_by_id_simple', { col, val })),
          };
        }),
        order: vi.fn().mockImplementation((col, val) => {
          return Promise.resolve((globalThis as any).__activeToolResolver(queryMockObj._table, 'select_ordered_general'));
        }),
      };
      const promiseObj = Promise.resolve((globalThis as any).__activeToolResolver(queryMockObj._table, 'select_all_general'));
      Object.assign(promiseObj, chain);
      return promiseObj;
    }),
    _table: '',
  };

  (globalThis as any).__mockSupabaseForTool = {
    from: vi.fn().mockImplementation((table) => {
      queryMockObj._table = table;
      return queryMockObj;
    }),
  };
});

export const setToolResolver = (fn: any) => {
  (globalThis as any).__activeToolResolver = fn;
};

vi.mock('@supabase/supabase-js', async (importOriginal) => {
  const actual = await importOriginal() as any;
  return {
    ...actual,
    createClient: (url: string, key: string, options: any) => {
      if ((globalThis as any).__mockSupabaseForTool) {
        return (globalThis as any).__mockSupabaseForTool;
      }
      return actual.createClient(url, key, options);
    },
  };
});

describe('Human Approval & Tool Calling Engine (Integration Tests)', () => {
  let app: any;
  let repository: ToolRepository;
  let service: ToolService;

  const testToken = jwt.sign({ orgId: 'test-workspace-owner-123' }, 'test-jwt-secret');
  const workspaceId = '11111111-1111-1111-1111-111111111111';

  const mockManifest: ToolManifest = {
    name: 'Search Product Pricing',
    category: 'search',
    version: 1,
    timeoutMs: 3000,
    retryLimit: 2,
    cacheTtlMs: 600000,
  };

  const mockInputSchema = {
    type: 'object',
    required: ['query'],
    properties: {
      query: { type: 'string' },
      limit: { type: 'number' },
    },
    additionalProperties: false,
  };

  const mockOutputSchema = {
    type: 'object',
    required: ['results'],
    properties: {
      results: { type: 'array' },
      query: { type: 'string' },
    },
  };

  const sampleTool: ToolDefinitionEntity = {
    id: 'tool-uuid-1',
    workspace_id: workspaceId,
    name: 'Search Product Pricing',
    category: 'search',
    latest_version: 1,
    current_version_id: 'tool-ver-1',
    status: 'APPROVED',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const sampleVersion: ToolVersionEntity = {
    id: 'tool-ver-1',
    tool_id: 'tool-uuid-1',
    version: 1,
    manifest: mockManifest,
    input_schema: mockInputSchema,
    output_schema: mockOutputSchema,
    permission: ['EXECUTE'],
    timeout_ms: 3000,
    retry_limit: 2,
    checksum: 'mock-checksum',
    created_at: new Date().toISOString(),
  };

  const sampleApproval: ApprovalRequestEntity = {
    id: 'app-uuid-1',
    workspace_id: workspaceId,
    workflow_execution_id: 'wf-exec-1',
    workflow_step_execution_id: 'step-exec-1',
    title: 'Confirm Creative Budget',
    description: 'Requires human approval to proceed with budget allocation',
    payload: { budget: 1500 },
    status: 'PENDING',
    created_at: new Date().toISOString(),
  };

  beforeAll(async () => {
    app = await createApp();
    repository = new ToolRepository((globalThis as any).__mockSupabaseForTool as any);
    service = new ToolService(repository);
  });

  // 1. JSON Schema Validator Tests
  describe('ToolSchemaValidator validation checks', () => {
    it('should validate inputs successfully on correct data types matches schema', () => {
      expect(() =>
        ToolSchemaValidator.validate(mockInputSchema, { query: 'hoodie', limit: 10 })
      ).not.toThrow();
    });

    it('should throw ValidationError if required property is missing', () => {
      expect(() =>
        ToolSchemaValidator.validate(mockInputSchema, { limit: 10 })
      ).toThrow(ValidationError);
    });

    it('should throw ValidationError if type matches mismatch', () => {
      expect(() =>
        ToolSchemaValidator.validate(mockInputSchema, { query: 12345 })
      ).toThrow(ValidationError);
    });
  });

  // 2. Permission Checker Tests
  describe('ToolPermissionChecker checks', () => {
    it('should pass if required permissions are subset of granted privileges', () => {
      expect(() =>
        ToolPermissionChecker.verify(['EXECUTE'], ['READ', 'EXECUTE'])
      ).not.toThrow();
    });

    it('should throw ValidationError if required permission is missing', () => {
      expect(() =>
        ToolPermissionChecker.verify(['EXECUTE', 'WRITE'], ['EXECUTE'])
      ).toThrow(ValidationError);
    });
  });

  // 3. Sandbox Exception & Timeout Checks
  describe('ToolSandbox checks', () => {
    it('should catch exceptions and return unsuccessful sandbox status', async () => {
      const res = await ToolSandbox.run(async () => {
        throw new Error('Sandbox network error occurred');
      }, 3000);

      expect(res.success).toBe(false);
      expect(res.errorMessage).toContain('Sandbox network error');
    });

    it('should enforce execution timeout correctly', async () => {
      const res = await ToolSandbox.run(async () => {
        await new Promise((resolve) => setTimeout(resolve, 500));
        return { value: 'late' };
      }, 50);

      expect(res.success).toBe(false);
      expect(res.errorMessage).toContain('timed out');
    });
  });

  // 4. SHA-256 Cache Checks
  describe('Tool Cache Checks', () => {
    it('should hit cache when request is identical within TTL', () => {
      const cache = new ToolInMemoryCache();
      const key = ToolCacheKeyGenerator.generate('ver-1', { query: 'jeans' }, workspaceId, 'search');
      
      const payload = { cached: true };
      cache.set(key, payload, 60000); // 60s TTL

      const hit = cache.get(key);
      expect(hit).toEqual(payload);
    });

    it('should return null when cache expires', async () => {
      const cache = new ToolInMemoryCache();
      const key = ToolCacheKeyGenerator.generate('ver-1', { query: 'jeans' }, workspaceId, 'search');
      
      cache.set(key, { data: 'old' }, 5); // 5ms TTL
      await new Promise((resolve) => setTimeout(resolve, 10));

      expect(cache.get(key)).toBeNull();
    });
  });

  // 5. Approval State Machine Checks
  describe('ApprovalStateMachine transitions', () => {
    it('should successfully transition PENDING to APPROVED', () => {
      const state = ApprovalStateMachine.transition('PENDING', 'APPROVED');
      expect(state).toBe('APPROVED');
    });

    it('should throw ValidationError on illegal transitions', () => {
      expect(() => ApprovalStateMachine.transition('REJECTED', 'APPROVED')).toThrow(ValidationError);
    });
  });

  // 6. Workflow Resume Snapshot restore mocks
  describe('Workflow Resume triggers', () => {
    it('should call registered handler upon resumeExecution', async () => {
      const mockHandler = {
        resume: vi.fn().mockImplementation(() => Promise.resolve()),
      };

      WorkflowResumeManager.registerHandler(mockHandler);
      await WorkflowResumeManager.resumeExecution('wf-1', 'step-1', { budget: 2000 });

      expect(mockHandler.resume).toHaveBeenCalledWith('wf-1', 'step-1', { budget: 2000 });
    });
  });

  // 7. REST API mapping
  describe('REST API routing mapping', () => {
    it('should return list of tools on GET /api/v1/tools', async () => {
      setToolResolver(() => Promise.resolve({ data: [sampleTool], error: null }));

      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/tools',
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data[0].name).toBe('Search Product Pricing');
    });

    it('should return list of approvals on GET /api/v1/approvals', async () => {
      setToolResolver(() => Promise.resolve({ data: [sampleApproval], error: null }));

      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/approvals',
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data[0].title).toBe('Confirm Creative Budget');
    });
  });
});
