export interface RecoveryTask {
  id: string;
  name: string;
  priority: 'P0' | 'P1' | 'P2' | 'P3';
  action: () => Promise<void>;
}

export class PriorityRecoveryQueue {
  private static readonly queue: RecoveryTask[] = [];
  private static readonly priorityWeights: Record<string, number> = {
    P0: 4,
    P1: 3,
    P2: 2,
    P3: 1,
  };

  static push(task: RecoveryTask): void {
    this.queue.push(task);
    // Sort descending by priority weight
    this.queue.sort((a, b) => this.priorityWeights[b.priority] - this.priorityWeights[a.priority]);
  }

  static pop(): RecoveryTask | undefined {
    return this.queue.shift();
  }

  static getLength(): number {
    return this.queue.length;
  }

  static clear(): void {
    this.queue.length = 0;
  }
}
export default PriorityRecoveryQueue;
