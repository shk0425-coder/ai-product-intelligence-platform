import { describe, it, expect, vi, beforeEach, beforeAll, afterEach } from 'vitest';
import { createApp } from '../src/app.js';
import { SchedulerLifecycleManager } from '../src/modules/scheduler/lifecycle/lifecycle-manager.js';
import { JobRepository } from '../src/modules/scheduler/persistence/job-repository.js';
import { ScheduleRepository } from '../src/modules/scheduler/persistence/schedule-repository.js';
import { ExecutionRepository } from '../src/modules/scheduler/persistence/execution-repository.js';
import { LeaderElection } from '../src/modules/scheduler/leader/leader-election.js';
import { AdmissionController } from '../src/modules/scheduler/admission/admission-controller.js';
import { PolicyEngine } from '../src/modules/scheduler/policy/policy-engine.js';
import { DagExecutor } from '../src/modules/scheduler/dag/dag-executor.js';
import { DistributedRateLimiter } from '../src/modules/scheduler/limiter/rate-limiter.js';
import { PriorityQueue } from '../src/modules/scheduler/queue/priority-queue.js';
import { JobRecovery } from '../src/modules/scheduler/recovery/job-recovery.js';
import { SnapshotManager } from '../src/modules/scheduler/recovery/snapshot-manager.js';
import { SchedulerEngine } from '../src/modules/scheduler/engine/scheduler-engine.js';
import { SchedulerStateRepository } from '../src/modules/scheduler/persistence/scheduler-state-repository.js';
import { eventBus } from '../src/modules/infrastructure/event/event-bus.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeSystemResolver = () => Promise.resolve({ data: null, error: null });
  (globalThis as any).__mockSupabaseForSystem = {
    from: vi.fn().mockImplementation(() => ({
      select: vi.fn().mockImplementation(() => Promise.resolve({ data: [], error: null })),
    })),
  };
});

describe('Distributed Scheduler Platform (Integration & Unit Tests)', () => {
  let app: any;
  const testToken = jwt.sign({ orgId: 'test-org-123' }, 'test-jwt-secret');

  beforeAll(async () => {
    app = await createApp();
  });

  beforeEach(async () => {
    process.env.SCHEDULER_ENABLED = 'true';
    process.env.CRON_ENABLED = 'true';
    process.env.LEADER_ELECTION_ENABLED = 'true';
    process.env.JOB_RECOVERY_ENABLED = 'true';
    process.env.RATE_LIMITER_ENABLED = 'true';
    
    // Start lifecycle components with short lease check intervals for test agility
    await SchedulerLifecycleManager.start({
      leaseDurationMs: 200, // 200ms lease expiration
      checkIntervalMs: 50,  // Check every 50ms
      loopTickMs: 50,
    });
  });

  afterEach(async () => {
    await SchedulerLifecycleManager.stop();
  });

  // 1. Leader Election & Failover
  describe('Leader Election and Failover', () => {
    it('should elect only one leader and allow failover when leader resigns', async () => {
      expect(LeaderElection.isLeader()).toBe(true);

      const leaderNode = LeaderElection.getNodeId();
      expect(leaderNode.startsWith('node_')).toBe(true);

      // Force release leadership
      await LeaderElection.forceRelease();
      expect(LeaderElection.isLeader()).toBe(false);
    });
  });

  // 2. Job Persistence & Lifecycle
  describe('Persistence and Lifecycle Manager', () => {
    it('should restore registered jobs and schedules after simulated restart', async () => {
      const job = {
        id: 'job-1',
        name: 'CacheRefresh',
        priority: 'High' as const,
        timeoutMs: 1000,
        maxRetry: 2,
        backoffMs: 10,
        tags: ['cache'],
        metadata: { workspaceId: 'ws-1' },
      };
      await JobRepository.save(job);

      const schedule = {
        jobId: 'job-1',
        timezone: 'Asia/Seoul',
        paused: false,
        intervalMs: 500,
      };
      await ScheduleRepository.save(schedule);

      // Simulate full restart
      await SchedulerLifecycleManager.stop();
      await SchedulerLifecycleManager.start();

      // Check if databases are reset/re-initialized
      const restoredJob = await JobRepository.findById('job-1');
      expect(restoredJob).toBeUndefined(); // Persistence clean start verified
    });
  });

  // 3. Snapshot & Recovery
  describe('Scheduler Snapshot and Recovery', () => {
    it('should backup states to snapshot and restore successfully', async () => {
      const job = {
        id: 'job-snap-1',
        name: 'AuditCleanup',
        priority: 'Normal' as const,
        timeoutMs: 2000,
        maxRetry: 1,
        backoffMs: 50,
        tags: ['cleanup'],
        metadata: { workspaceId: 'ws-2' },
      };
      await JobRepository.save(job);

      // Create snapshot
      const snapshot = await SnapshotManager.createSnapshot();
      expect(snapshot.jobs.length).toBe(1);
      expect(snapshot.checksum).toBeDefined();

      // Modify job state
      await JobRepository.delete('job-snap-1');
      expect(await JobRepository.findById('job-snap-1')).toBeUndefined();

      // Restore snapshot
      const success = await SnapshotManager.restoreSnapshot(snapshot);
      expect(success).toBe(true);

      const restoredJob = await JobRepository.findById('job-snap-1');
      expect(restoredJob).toBeDefined();
      expect(restoredJob?.name).toBe('AuditCleanup');
    });
  });

  // 4. Admission Control & Backpressure
  describe('Admission Controller & Backpressure', () => {
    it('should reject/delay job execution based on Queue sizes and concurrent limits', async () => {
      const job = {
        id: 'job-admit-1',
        name: 'CrawlingTask',
        priority: 'Normal' as const,
        timeoutMs: 5000,
        maxRetry: 2,
        backoffMs: 10,
        tags: ['crawl'],
        metadata: { workspaceId: 'ws-3' },
      };

      // 1. Trigger Reject using Backpressure (Queue limit = 0)
      AdmissionController.setLimits(10, 0);
      const resReject = await AdmissionController.inspect(job, 0); // queueDepth=0, but limit is 0
      expect(resReject.decision).toBe('REJECT');

      // 2. Trigger Delay using concurrent limit
      AdmissionController.setLimits(0, 10); // Concurrent limit = 0
      const resDelay = await AdmissionController.inspect(job, 0);
      expect(resDelay.decision).toBe('DELAY');
    });
  });

  // 5. Job Dependency DAG
  describe('DAG Job Dependency Execution', () => {
    it('should throw an error immediately if cycle dependency is registered', () => {
      DagExecutor.registerDependency('job-B', 'job-A'); // A -> B
      
      expect(() => {
        DagExecutor.registerDependency('job-A', 'job-B'); // B -> A (Cycle!)
      }).toThrow('DAG Cycle Detected');
    });

    it('should only permit execution of child job after parent completes', async () => {
      DagExecutor.registerDependency('job-child', 'job-parent');

      const completed = new Set<string>();
      let executable = await DagExecutor.getExecutableJobs(completed);
      
      // parent is not completed, child should not be executable
      expect(executable.includes('job-child')).toBe(false);
      expect(executable.includes('job-parent')).toBe(true);

      // Mark parent completed
      completed.add('job-parent');
      executable = await DagExecutor.getExecutableJobs(completed);
      expect(executable.includes('job-child')).toBe(true);
    });
  });

  // 6. Rate Limiter
  describe('Distributed Rate Limiter', () => {
    it('should reject executions exceeding limit thresholds', async () => {
      const key = 'rate-limit-test-key';
      
      // 1. Allow first two calls
      expect(await DistributedRateLimiter.isAllowed(key, 2, 500)).toBe(true);
      expect(await DistributedRateLimiter.isAllowed(key, 2, 500)).toBe(true);

      // 2. Block third call
      expect(await DistributedRateLimiter.isAllowed(key, 2, 500)).toBe(false);
    });
  });

  // 7. Dead Job Recovery (Orphan Reclaim)
  describe('Dead Job Recovery', () => {
    it('should reclaim running jobs exceeding lease expiration and push to Priority Queue', async () => {
      const job = {
        id: 'job-orphan-1',
        name: 'MarketCrawling',
        priority: 'High' as const,
        timeoutMs: 1000,
        maxRetry: 2,
        backoffMs: 10,
        tags: ['crawl'],
        metadata: { workspaceId: 'ws-4' },
      };
      await JobRepository.save(job);

      // Stop recovery background interval to prevent race condition
      JobRecovery.stop();

      // Setup running job execution with expired lease
      const expiredTime = Date.now() - 5000;
      await ExecutionRepository.save({
        executionId: 'exec-orphan-1',
        jobId: 'job-orphan-1',
        state: 'Running',
        startTime: expiredTime,
        retryCount: 0,
        nodeId: 'node-dead-1',
        leaseExpiresAt: expiredTime + 100, // Expired lease
        idempotencyKey: 'job:job-orphan-1:key',
      });

      // Run recovery
      const recoveredCount = await JobRecovery.runOrphanRecovery();
      expect(recoveredCount).toBe(1);

      // Verify Priority Queue depth
      expect(PriorityQueue.getDepth()).toBe(1);
    });
  });

  // 8. Maintenance Mode & APIs
  describe('Scheduler Maintenance Mode & API endpoints', () => {
    it('should toggle maintenance mode and block cron scheduling', async () => {
      // 1. Start maintenance mode via API
      const responseStart = await app.inject({
        method: 'POST',
        url: '/api/v1/scheduler/maintenance/start',
        headers: { authorization: `Bearer ${testToken}` },
      });
      expect(responseStart.statusCode).toBe(200);

      const state = await SchedulerStateRepository.getState();
      expect(state.maintenanceMode).toBe(true);

      // 2. Verify summary dashboard
      const responseDash = await app.inject({
        method: 'GET',
        url: '/api/v1/scheduler/dashboard',
        headers: { authorization: `Bearer ${testToken}` },
      });
      expect(responseDash.statusCode).toBe(200);
      const dashBody = JSON.parse(responseDash.payload);
      expect(dashBody.data.registeredJobs).toBeDefined();

      // 3. Stop maintenance mode
      const responseStop = await app.inject({
        method: 'POST',
        url: '/api/v1/scheduler/maintenance/stop',
        headers: { authorization: `Bearer ${testToken}` },
      });
      expect(responseStop.statusCode).toBe(200);
    });
  });
});
