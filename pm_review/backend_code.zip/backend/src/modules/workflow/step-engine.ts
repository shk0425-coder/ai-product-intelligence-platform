import { WorkflowNode, ExecutionStatus } from './types.js';
import { PromptService } from '../prompt/service.js';
import { ValidationError } from '../../common/errors/index.js';

export interface StepExecuteResult {
  status: ExecutionStatus;
  output: Record<string, unknown>;
  estimatedCost: number;
  errorMessage?: string;
}

export class WorkflowStepEngine {
  constructor(private readonly promptService: PromptService) {}

  async execute(
    node: WorkflowNode,
    workspaceId: string,
    inputContext: Record<string, unknown>
  ): Promise<StepExecuteResult> {
    if (node.type === 'Start') {
      return {
        status: 'SUCCESS',
        output: inputContext,
        estimatedCost: 0,
      };
    }
    if (node.type === 'End') {
      return {
        status: 'SUCCESS',
        output: inputContext,
        estimatedCost: 0,
      };
    }

    if (node.type === 'Agent') {
      if (!node.promptTemplateId) {
        throw new ValidationError(`Agent Node "${node.name}" is missing promptTemplateId`);
      }

      try {
        // Direct decoupling execution through PromptService
        const response = await this.promptService.execute(node.promptTemplateId, {
          workspaceId,
          variables: inputContext,
        });

        // Map output context
        const outputVal = typeof response.content === 'string' ? response.content : JSON.stringify(response.content);
        
        return {
          status: 'SUCCESS',
          output: {
            [`${node.id}_output`]: outputVal,
            // Merge last agent content output directly as default answer context if needed
            last_agent_output: outputVal,
          },
          estimatedCost: response.cost || 0.0,
        };
      } catch (err: unknown) {
        return {
          status: 'FAILED',
          output: {},
          estimatedCost: 0,
          errorMessage: err instanceof Error ? err.message : String(err),
        };
      }
    }

    // Default fallthrough for nodes like Merge or Parallel container hooks
    return {
      status: 'SUCCESS',
      output: {},
      estimatedCost: 0,
    };
  }
}
export default WorkflowStepEngine;
