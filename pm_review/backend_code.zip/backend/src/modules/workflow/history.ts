import { WorkflowExecutionEntity, WorkflowAuditLogEntity } from './types.js';

export class WorkflowHistoryCollector {
  private static readonly executionBuffer: WorkflowExecutionEntity[] = [];

  static record(execution: WorkflowExecutionEntity): void {
    this.executionBuffer.push(execution);
    if (this.executionBuffer.length > 500) {
      this.executionBuffer.shift();
    }
  }

  static getHistory(): WorkflowExecutionEntity[] {
    return [...this.executionBuffer];
  }

  static clear(): void {
    this.executionBuffer.length = 0;
  }
}

export class WorkflowAuditLogger {
  private static readonly auditBuffer: WorkflowAuditLogEntity[] = [];

  static record(audit: WorkflowAuditLogEntity): void {
    this.auditBuffer.push(audit);
    if (this.auditBuffer.length > 500) {
      this.auditBuffer.shift();
    }
  }

  static getAudits(): WorkflowAuditLogEntity[] {
    return [...this.auditBuffer];
  }

  static clear(): void {
    this.auditBuffer.length = 0;
  }
}
