import { WorkflowGraph, WorkflowNode, ExecutionStatus } from './types.js';
import { WorkflowStepEngine } from './step-engine.js';
import { WorkflowStateMachine } from './state-machine.js';
import { WorkflowContextManager } from './context-manager.js';
import { WorkflowSnapshotManager } from './snapshot-manager.js';
import { StepRetryPolicy } from './retry-policy.js';
import { CancellationToken } from './cancellation.js';
import { WorkflowConditionEvaluator } from './condition.js';
import { ValidationError } from '../../common/errors/index.js';

export interface WorkflowExecuteInput {
  executionId: string;
  workspaceId: string;
  graph: WorkflowGraph;
  initialContext: Record<string, unknown>;
  cancellationToken: CancellationToken;
  onStepCompleted: (stepId: string, status: ExecutionStatus, output: Record<string, unknown>, cost: number, snapshot: Record<string, unknown>) => Promise<void>;
  onWorkflowFinished: (status: ExecutionStatus, outputContext: Record<string, unknown>, totalCost: number, errorMsg?: string) => Promise<void>;
}

export class WorkflowExecutor {
  constructor(private readonly stepEngine: WorkflowStepEngine) {}

  async execute(input: WorkflowExecuteInput): Promise<void> {
    let currentStatus: ExecutionStatus = 'PENDING';
    let currentContext = WorkflowContextManager.create(input.initialContext);
    let totalCost = 0.0;

    const nodes = input.graph.nodes || [];
    const edges = input.graph.edges || [];

    // Adjacency and edges configurations
    const adjMap = new Map<string, string[]>();
    const nodeMap = new Map<string, WorkflowNode>();
    for (const node of nodes) {
      nodeMap.set(node.id, node);
      adjMap.set(node.id, []);
    }
    for (const edge of edges) {
      adjMap.get(edge.from)?.push(edge.to);
    }

    const startNode = nodes.find((n) => n.type === 'Start');
    if (!startNode) {
      throw new ValidationError('Start node not found in DAG');
    }

    // Transit to RUNNING status
    currentStatus = WorkflowStateMachine.transition(currentStatus, 'RUNNING');

    // Run active queue traversal (Dynamic Path BFS based on condition resolution)
    const queue: string[] = [startNode.id];
    const completedSteps: string[] = [];
    const stateProgress: Record<string, unknown> = {};

    try {
      while (queue.length > 0) {
        input.cancellationToken.throwIfCancelled();

        // Process level (Parallel execution)
        const size = queue.length;
        const currentBatch = queue.splice(0, size);

        // Run batch steps in Parallel
        const stepPromises = currentBatch.map(async (nodeId) => {
          const node = nodeMap.get(nodeId)!;
          
          let stepStatus: ExecutionStatus = 'RUNNING';
          let retryCount = 0;
          let stepResult: import('./step-engine.js').StepExecuteResult | undefined;

          // Step Execution Retry Loop
          while (true) {
            input.cancellationToken.throwIfCancelled();

            // Check Step Timeout
            const timeoutPromise = new Promise<never>((_, reject) => {
              if (node.timeoutMs && node.timeoutMs > 0) {
                setTimeout(() => reject(new Error(`Step execution timeout: ${node.name}`)), node.timeoutMs);
              }
            });

            try {
              // Stateless deep copy context transfer
              const stepInputContext = WorkflowContextManager.create(currentContext);
              
              // Exec step
              stepResult = await Promise.race([
                this.stepEngine.execute(node, input.workspaceId, stepInputContext),
                timeoutPromise,
              ]);

              if (stepResult && stepResult.status === 'SUCCESS') {
                stepStatus = 'SUCCESS';
                break;
              } else {
                throw new Error(stepResult?.errorMessage || 'Step failed execution');
              }
            } catch (err: unknown) {
              const errMsg = err instanceof Error ? err.message : String(err);
              if (errMsg.includes('timeout')) {
                stepStatus = 'TIMEOUT';
                break;
              }

              if (StepRetryPolicy.shouldRetry(retryCount, node.maxRetry)) {
                const delay = StepRetryPolicy.getDelayMs(retryCount, node.retryIntervalMs);
                retryCount++;
                await new Promise((resolve) => setTimeout(resolve, delay));
              } else {
                stepStatus = 'FAILED';
                stepResult = { status: 'FAILED', output: {}, estimatedCost: 0, errorMessage: errMsg };
                break;
              }
            }
          }

          return { nodeId, node, status: stepStatus, result: stepResult };
        });

        const batchResults = await Promise.all(stepPromises);

        // Process step outputs and transition next edges
        for (const res of batchResults) {
          const result = res.result || { status: 'FAILED', output: {}, estimatedCost: 0, errorMessage: 'No result returned' };
          totalCost += result.estimatedCost || 0.0;

          if (res.status === 'TIMEOUT') {
            currentStatus = 'TIMEOUT';
            throw new Error(`Execution timed out during Step: ${res.node.name}`);
          }
          if (res.status === 'FAILED') {
            currentStatus = 'FAILED';
            throw new Error(result.errorMessage || `Step failed: ${res.node.name}`);
          }

          // Merge Immutable Context safely
          currentContext = WorkflowContextManager.merge(currentContext, result.output);
          completedSteps.push(res.nodeId);
          stateProgress[res.nodeId] = 'COMPLETED';

          const snapshot = WorkflowSnapshotManager.createSnapshot(completedSteps, currentContext, stateProgress);
          await input.onStepCompleted(res.nodeId, res.status, result.output, result.estimatedCost, snapshot);

          // Resolve next conditional branches or normal edges
          const nextTargets = adjMap.get(res.nodeId) || [];
          for (const nextId of nextTargets) {
            const nextNode = nodeMap.get(nextId)!;

            if (nextNode.type === 'Condition') {
              const evalRes = WorkflowConditionEvaluator.evaluate(nextNode.conditionExpression || '', currentContext);
              // Condition nodes pass context down to targets
              if (evalRes) {
                // If condition matches, enqueue the next node connected to this Condition node
                const condTargets = adjMap.get(nextId) || [];
                queue.push(...condTargets);
              }
            } else {
              queue.push(nextId);
            }
          }
        }
      }

      currentStatus = WorkflowStateMachine.transition(currentStatus, 'SUCCESS');
      await input.onWorkflowFinished(currentStatus, currentContext, totalCost);
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      
      if (input.cancellationToken.isCancelled() || errMsg.includes('cancelled')) {
        currentStatus = 'CANCELLED';
      } else if (currentStatus !== 'TIMEOUT' && currentStatus !== 'FAILED') {
        currentStatus = 'FAILED';
      }

      await input.onWorkflowFinished(currentStatus, currentContext, totalCost, errMsg);
    }
  }
}
export default WorkflowExecutor;
