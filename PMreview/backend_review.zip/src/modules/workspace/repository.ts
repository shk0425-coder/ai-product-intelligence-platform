export class WorkspaceRepository {}
