import { BaseRepository } from '@/repositories/implementations/base.repository.js';
import {
  ProductPerformance,
  IPerformanceRepository,
  PerformanceMetrics,
  PerformanceSource,
  PerformanceAuditLog,
} from './types.js';
import { PaginationOptions, PaginatedResult } from '@/repositories/interfaces/base.repository.js';
import { DatabaseError } from '@/common/errors/index.js';
import { SupabaseClient } from '@supabase/supabase-js';

export class PerformanceRepository
  extends BaseRepository<ProductPerformance>
  implements IPerformanceRepository
{
  constructor(supabase: SupabaseClient) {
    super(supabase, 'product_performance', 'id');
  }

  async upsert(
    performanceData: Partial<ProductPerformance>,
    metricsData: Partial<PerformanceMetrics>,
    sourceData: Partial<PerformanceSource>,
    actorId: string,
  ): Promise<ProductPerformance> {
    const { data, error } = await this.supabase.rpc('upsert_performance_foundation', {
      p_workspace_id: performanceData.workspace_id,
      p_product_id: performanceData.product_id,
      p_analysis_run_id: performanceData.analysis_run_id,
      p_strategy_id: performanceData.strategy_id || null,
      p_creative_id: performanceData.creative_id || null,
      p_period_start: performanceData.period_start,
      p_period_end: performanceData.period_end,
      p_sales_count: performanceData.sales_count || 0,
      p_sales_amount: performanceData.sales_amount || 0.0,
      p_refund_count: performanceData.refund_count || 0,
      p_review_count: performanceData.review_count || 0,
      p_review_score: performanceData.review_score || 0.0,
      p_favorite_count: performanceData.favorite_count || 0,
      p_created_by: actorId,
      p_metrics: {
        impressions: metricsData.impressions || 0,
        clicks: metricsData.clicks || 0,
        conversionCount: metricsData.conversion_count || 0,
        conversionRate: metricsData.conversion_rate || 0.0,
        ctr: metricsData.ctr || 0.0,
        adCost: metricsData.ad_cost || 0.0,
        profit: metricsData.profit || 0.0,
        marginRate: metricsData.margin_rate || 0.0,
        roi: metricsData.roi || 0.0,
      },
      p_source: {
        marketplaceCode: sourceData.marketplace_code,
        marketplaceName: sourceData.marketplace_name,
        collectionJobId: sourceData.collection_job_id || null,
        sourceVersion: sourceData.source_version || 1,
        collectedAt: sourceData.collected_at,
        rawPayloadHash: sourceData.raw_payload_hash,
      },
    });

    if (error) {
      throw new DatabaseError(error.message);
    }
    return data as ProductPerformance;
  }

  async findLatest(productId: string): Promise<ProductPerformance | null> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select('*')
      .eq('product_id', productId)
      .is('deleted_at', null)
      .order('period_end', { ascending: false })
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) {
      throw new DatabaseError(error.message);
    }
    return data as ProductPerformance | null;
  }

  async findByProduct(
    productId: string,
    options: PaginationOptions,
  ): Promise<PaginatedResult<ProductPerformance>> {
    const { page, limit, sort, order } = options;
    const from = (page - 1) * limit;
    const to = from + limit - 1;

    const { data, count, error } = await this.supabase
      .from(this.tableName)
      .select('*', { count: 'exact' })
      .eq('product_id', productId)
      .is('deleted_at', null)
      .order(sort, { ascending: order === 'asc' })
      .range(from, to);

    if (error) {
      throw new DatabaseError(error.message);
    }

    return {
      data: (data ?? []) as ProductPerformance[],
      total: count ?? 0,
      page,
      limit,
    };
  }

  async findByAnalysis(analysisRunId: string): Promise<ProductPerformance[]> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select('*')
      .eq('analysis_run_id', analysisRunId)
      .is('deleted_at', null)
      .order('period_start', { ascending: false });

    if (error) {
      throw new DatabaseError(error.message);
    }
    return (data ?? []) as ProductPerformance[];
  }

  async findByPeriod(
    productId: string,
    startDate: string,
    endDate: string,
    options: PaginationOptions,
  ): Promise<PaginatedResult<ProductPerformance>> {
    const { page, limit, sort, order } = options;
    const from = (page - 1) * limit;
    const to = from + limit - 1;

    let query = this.supabase
      .from(this.tableName)
      .select('*', { count: 'exact' })
      .eq('product_id', productId)
      .is('deleted_at', null);

    if (startDate) {
      query = query.gte('period_start', startDate);
    }
    if (endDate) {
      query = query.lte('period_end', endDate);
    }

    const { data, count, error } = await query
      .order(sort, { ascending: order === 'asc' })
      .range(from, to);

    if (error) {
      throw new DatabaseError(error.message);
    }

    return {
      data: (data ?? []) as ProductPerformance[],
      total: count ?? 0,
      page,
      limit,
    };
  }

  async findMetrics(performanceId: string): Promise<PerformanceMetrics | null> {
    const { data, error } = await this.supabase
      .from('performance_metrics')
      .select('*')
      .eq('performance_id', performanceId)
      .maybeSingle();

    if (error) {
      throw new DatabaseError(error.message);
    }
    return data as PerformanceMetrics | null;
  }

  async findSource(performanceId: string): Promise<PerformanceSource | null> {
    const { data, error } = await this.supabase
      .from('performance_sources')
      .select('*')
      .eq('performance_id', performanceId)
      .maybeSingle();

    if (error) {
      throw new DatabaseError(error.message);
    }
    return data as PerformanceSource | null;
  }

  async createAudit(auditLog: Partial<PerformanceAuditLog>): Promise<PerformanceAuditLog> {
    const { data, error } = await this.supabase
      .from('performance_audit_logs')
      .insert(auditLog as Record<string, unknown>)
      .select('*')
      .single();

    if (error) {
      throw new DatabaseError(error.message);
    }
    return data as PerformanceAuditLog;
  }

  async verifyWorkspaceOwner(workspaceId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('workspaces')
      .select('org_id')
      .eq('workspace_id', workspaceId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const workspace = data as { org_id: string };
    return workspace.org_id === userId;
  }

  async verifyProductOwner(productId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('products')
      .select(
        `
        product_id,
        workspaces!inner(org_id)
      `,
      )
      .eq('product_id', productId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const product = data as unknown as { workspaces: { org_id: string } };
    return product.workspaces?.org_id === userId;
  }

  async verifyRunOwner(runId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('analysis_runs')
      .select(
        `
        run_id,
        products!inner(
          workspaces!inner(org_id)
        )
      `,
      )
      .eq('run_id', runId)
      .maybeSingle();
    if (error || !data) return false;
    const run = data as unknown as { products: { workspaces: { org_id: string } } };
    return run.products?.workspaces?.org_id === userId;
  }

  async verifyPerformanceOwner(performanceId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select(
        `
        id,
        workspaces!inner(org_id)
      `,
      )
      .eq('id', performanceId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const performance = data as unknown as { workspaces: { org_id: string } };
    return performance.workspaces?.org_id === userId;
  }
}
