import { JobDefinition } from '../persistence/job-repository.js';
import { ExecutionRepository, JobExecution } from '../persistence/execution-repository.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import { EventType } from '../../infrastructure/event/event-registry.js';
import { Logger } from '../../observability/logging/logger.js';
import crypto from 'crypto';

export class SchedulerExecutor {
  static async execute(job: JobDefinition, handler: () => Promise<void>, nodeId: string): Promise<boolean> {
    const executionId = `exec_${crypto.randomUUID().slice(0, 8)}`;
    const idempotencyKey = `job:${job.id}:key`;
    const startTime = Date.now();

    const execRecord: JobExecution = {
      executionId,
      jobId: job.id,
      state: 'Running',
      startTime,
      retryCount: 0,
      nodeId,
      leaseExpiresAt: startTime + job.timeoutMs,
      idempotencyKey,
    };

    await ExecutionRepository.save(execRecord);
    this.publishStateEvent('JobStarted', execRecord, job.metadata);

    MetricsRegistry.counter('scheduler_execution_delay_seconds', 0); // No startup delay

    let attempts = 0;
    while (attempts <= job.maxRetry) {
      try {
        // Enforce job timeout constraint
        const timeoutPromise = new Promise<void>((_, reject) =>
          setTimeout(() => reject(new Error('Job execution timeout')), job.timeoutMs)
        );
        const taskPromise = handler();

        await Promise.race([taskPromise, timeoutPromise]);

        // 1. Success execution
        const endTime = Date.now();
        execRecord.state = 'Success';
        execRecord.endTime = endTime;
        execRecord.durationMs = endTime - startTime;
        execRecord.retryCount = attempts;
        await ExecutionRepository.save(execRecord);

        this.publishStateEvent('JobCompleted', execRecord, job.metadata);
        
        MetricsRegistry.counter('scheduler_jobs_completed_total', 1, { queue: job.name });
        MetricsRegistry.histogram('scheduler_job_duration_seconds', execRecord.durationMs / 1000, { queue: job.name });

        return true;
      } catch (err) {
        attempts++;
        if (attempts > job.maxRetry) {
          // 2. Fatal failure execution
          const endTime = Date.now();
          execRecord.state = (err as Error).message === 'Job execution timeout' ? 'Timeout' : 'Failed';
          execRecord.endTime = endTime;
          execRecord.durationMs = endTime - startTime;
          execRecord.retryCount = attempts - 1;
          execRecord.error = (err as Error).message;
          await ExecutionRepository.save(execRecord);

          this.publishStateEvent('JobFailed', execRecord, job.metadata);

          MetricsRegistry.counter('scheduler_jobs_failed_total', 1, { queue: job.name });
          
          Logger.error({
            message: `Job ${job.name} execution failed permanently: ${execRecord.error}`,
            module: 'SCHEDULER',
            action: 'ExecutionFailure',
            errorCode: 'SCHEDULER_JOB_FAIL',
          });

          return false;
        }

        // 3. Retry with Exponential Backoff
        execRecord.state = 'Retrying';
        await ExecutionRepository.save(execRecord);
        this.publishStateEvent('JobRetried', execRecord, job.metadata);
        MetricsRegistry.counter('scheduler_retry_total', 1, { queue: job.name });

        const delay = Math.pow(2, attempts) * job.backoffMs;
        MetricsRegistry.histogram('scheduler_retry_delay_seconds', delay / 1000);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }

    return false;
  }

  private static publishStateEvent(eventType: EventType, exec: JobExecution, metadata: Record<string, unknown>): void {
    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType,
      timestamp: new Date().toISOString(),
      workspaceId: (metadata.workspaceId as string) || 'default-workspace',
      data: {
        jobId: exec.jobId,
        executionId: exec.executionId,
        state: exec.state,
        retryCount: exec.retryCount,
        error: exec.error,
      },
    }).catch(() => {});
  }
}
export default SchedulerExecutor;
