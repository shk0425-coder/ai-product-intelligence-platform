export class WorkflowContextManager {
  static create(initialInput: Record<string, unknown>): Record<string, unknown> {
    // Return structured deep clone
    return JSON.parse(JSON.stringify(initialInput));
  }

  static merge(current: Record<string, unknown>, addition: Record<string, unknown>): Record<string, unknown> {
    const clone = this.create(current);
    return {
      ...clone,
      ...this.create(addition),
    };
  }
}
export default WorkflowContextManager;
