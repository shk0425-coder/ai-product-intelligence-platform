export class AuthRepository {}
