import { WorkflowDefinitionEntity, WorkflowVersionEntity } from './types.js';

export class WorkflowRegistry {
  private static readonly workflowCache = new Map<string, WorkflowDefinitionEntity>();
  private static readonly versionCache = new Map<string, WorkflowVersionEntity>();

  static cacheWorkflow(workflow: WorkflowDefinitionEntity): void {
    this.workflowCache.set(workflow.id, workflow);
  }

  static getWorkflow(workflowId: string): WorkflowDefinitionEntity | null {
    return this.workflowCache.get(workflowId) || null;
  }

  static cacheVersion(version: WorkflowVersionEntity): void {
    this.versionCache.set(version.id, version);
  }

  static getVersion(versionId: string): WorkflowVersionEntity | null {
    return this.versionCache.get(versionId) || null;
  }

  static clear(): void {
    this.workflowCache.clear();
    this.versionCache.clear();
  }
}
export default WorkflowRegistry;
