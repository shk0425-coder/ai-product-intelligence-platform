import { CacheProvider } from './provider.js';

export interface CachePolicy {
  applyGet(key: string, provider: CacheProvider, ttlMs: number): Promise<void>;
  applySet(key: string, value: Record<string, unknown>, provider: CacheProvider, ttlMs: number): Promise<void>;
}

export class AbsoluteTtlPolicy implements CachePolicy {
  async applyGet(_key: string, _provider: CacheProvider, _ttlMs: number): Promise<void> {
    // Absolute TTL does not extend TTL on read access
  }

  async applySet(key: string, value: Record<string, unknown>, provider: CacheProvider, ttlMs: number): Promise<void> {
    await provider.set(key, value, ttlMs);
  }
}

export class SlidingTtlPolicy implements CachePolicy {
  async applyGet(key: string, provider: CacheProvider, ttlMs: number): Promise<void> {
    const exists = await provider.exists(key);
    if (exists) {
      await provider.expire(key, ttlMs);
    }
  }

  async applySet(key: string, value: Record<string, unknown>, provider: CacheProvider, ttlMs: number): Promise<void> {
    await provider.set(key, value, ttlMs);
  }
}

export class CachePolicyEngine {
  private static policy: CachePolicy = new AbsoluteTtlPolicy();

  static setPolicy(newPolicy: CachePolicy): void {
    this.policy = newPolicy;
  }

  static getPolicy(): CachePolicy {
    return this.policy;
  }
}
