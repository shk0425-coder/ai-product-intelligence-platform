import { ContextProvider } from './types.js';

export class WorkspaceContextProvider implements ContextProvider {
  readonly name = 'Workspace';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const wsName = variables['workspaceName'] || 'Default Workspace';
    return {
      workspace_context: `Workspace: ${wsName}`,
    };
  }
}

export class UserContextProvider implements ContextProvider {
  readonly name = 'User';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const userName = variables['userName'] || 'Anonymous User';
    return {
      user_context: `User: ${userName}`,
    };
  }
}

export class ProductContextProvider implements ContextProvider {
  readonly name = 'Product';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const productName = variables['productName'] || 'N/A';
    const productPrice = variables['productPrice'] || 'N/A';
    return {
      product_context: `Product Name: ${productName}, Price: ${productPrice}`,
    };
  }
}

export class ReviewContextProvider implements ContextProvider {
  readonly name = 'Review';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const totalReviews = variables['totalReviews'] || 0;
    const score = variables['reviewScore'] || 0.0;
    return {
      review_context: `Total Reviews: ${totalReviews}, Average Score: ${score}`,
    };
  }
}

export class JTBDContextProvider implements ContextProvider {
  readonly name = 'JTBD';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const jtbdNeeds = variables['jtbdNeeds'] || 'None';
    return {
      jtbd_context: `Customer Job-to-be-done Needs: ${jtbdNeeds}`,
    };
  }
}

export class MarketContextProvider implements ContextProvider {
  readonly name = 'Market';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const trend = variables['marketTrend'] || 'Stable';
    return {
      market_context: `Market Trend: ${trend}`,
    };
  }
}

export class HistoryContextProvider implements ContextProvider {
  readonly name = 'History';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const lastAction = variables['lastExecutionAction'] || 'None';
    return {
      history_context: `Last Action execution history: ${lastAction}`,
    };
  }
}

export class CustomContextProvider implements ContextProvider {
  readonly name = 'Custom';
  async provide(_workspaceId: string, variables: Record<string, unknown>): Promise<Record<string, unknown>> {
    const customData = variables['customContextData'] || '{}';
    return {
      custom_context: `Custom Context Data: ${JSON.stringify(customData)}`,
    };
  }
}
