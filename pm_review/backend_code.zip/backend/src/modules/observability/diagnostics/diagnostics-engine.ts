import os from 'os';
import { MetricsAggregator } from '../metrics/aggregator.js';

export interface DiagnosticsReport {
  timestamp: string;
  verdict: 'HEALTHY' | 'DEGRADED' | 'UNHEALTHY';
  findings: string[];
  recommendations: string[];
  metrics: {
    eventLoopDelayMs: number;
    heapUsagePercentage: number;
    cpuLoadAverage: number;
    activeHandles: number;
    openSockets: number;
  };
}

export class DiagnosticsEngine {
  // Emulate Heap snapshot trigger count
  private static snapshotCount = 0;

  static triggerHeapSnapshot(): string {
    this.snapshotCount++;
    return `Snapshot_${this.snapshotCount}_triggered_${Date.now()}.heapsnapshot`;
  }

  static getRuntimeDiagnostics() {
    const memory = process.memoryUsage();
    const heapUsed = memory.heapUsed;
    const heapTotal = memory.heapTotal;
    const heapUsagePct = (heapUsed / heapTotal) * 100;

    const proc = process as unknown as { _getActiveHandles?: () => unknown[]; _getActiveRequests?: () => unknown[] };
    return {
      eventLoopDelayMs: 2.5, // Emulated event loop delay in ms
      heapUsagePercentage: heapUsagePct,
      cpuLoadAverage: os.loadavg()[0],
      activeHandles: proc._getActiveHandles ? proc._getActiveHandles().length : 12,
      openSockets: proc._getActiveRequests ? proc._getActiveRequests().length : 4,
      fileDescriptorCount: 15,
      threadPoolSize: 4,
      gcPauseTimeMs: 12,
    };
  }

  static async analyze(): Promise<DiagnosticsReport> {
    const findings: string[] = [];
    const recommendations: string[] = [];
    let verdict: 'HEALTHY' | 'DEGRADED' | 'UNHEALTHY' = 'HEALTHY';

    const diag = this.getRuntimeDiagnostics();

    // 1. Event Loop Delay analysis
    if (diag.eventLoopDelayMs > 100) {
      verdict = 'DEGRADED';
      findings.push('High Event Loop Delay detected (> 100ms)');
      recommendations.push('Investigate synchronous heavy operations on main thread');
    }

    // 2. Heap Usage analysis
    if (diag.heapUsagePercentage > 85) {
      verdict = 'UNHEALTHY';
      findings.push(`Critical Heap usage: ${diag.heapUsagePercentage.toFixed(1)}%`);
      recommendations.push('Trigger heapsnapshot and check for memory leaks');
    }

    // 3. System Cache/Miss Rate analysis (using aggregated values)
    const hitsAgg = MetricsAggregator.getAggregated('cache_hits_total', 1);
    const missAgg = MetricsAggregator.getAggregated('cache_misses_total', 1);
    if (hitsAgg && missAgg) {
      const total = hitsAgg.sum + missAgg.sum;
      if (total > 0) {
        const missRatio = missAgg.sum / total;
        if (missRatio > 0.8) {
          findings.push(`Cache miss ratio is extremely high: ${(missRatio * 100).toFixed(1)}%`);
          recommendations.push('Increase cache key TTL or review cache warm-up logic');
        }
      }
    }

    // 4. Redis failures analysis
    const redisFailures = MetricsAggregator.getAggregated('redis_command_failures_total', 1);
    if (redisFailures && redisFailures.sum > 5) {
      verdict = 'UNHEALTHY';
      findings.push('Frequent Redis command failures in the last minute');
      recommendations.push('Check Redis connection pool capacity and server memory limits');
    }

    return {
      timestamp: new Date().toISOString(),
      verdict,
      findings,
      recommendations,
      metrics: {
        eventLoopDelayMs: diag.eventLoopDelayMs,
        heapUsagePercentage: diag.heapUsagePercentage,
        cpuLoadAverage: diag.cpuLoadAverage,
        activeHandles: diag.activeHandles,
        openSockets: diag.openSockets,
      },
    };
  }
}
