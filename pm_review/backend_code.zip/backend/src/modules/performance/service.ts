import { IPerformanceRepository, PerformanceMetrics, PerformanceSource } from './types.js';
import { SupabaseClient } from '@supabase/supabase-js';

import { CreatePerformanceDto, UpdatePerformanceDto, PerformanceResponseDto } from './dto.js';
import { PerformanceMapper } from './mapper.js';
import { PerformanceHooks } from './hooks.js';
import { PaginationOptions, PaginatedResult } from '@/repositories/interfaces/base.repository.js';
import {
  PerformanceNotFoundError,
  WorkspaceForbiddenError,
  InvalidDateRangeError,
  PerformanceValidationError,
  ValidationError,
} from '@/common/errors/index.js';

export class PerformanceService {
  constructor(private readonly performanceRepository: IPerformanceRepository) {}

  async upsert(dto: CreatePerformanceDto, userId: string): Promise<PerformanceResponseDto> {
    // 1. Authorization checks (using SQLInner joins to verify ownership)
    const isWorkspaceOwner = await this.performanceRepository.verifyWorkspaceOwner(
      dto.workspaceId,
      userId,
    );
    if (!isWorkspaceOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this workspace');
    }

    const isProductOwner = await this.performanceRepository.verifyProductOwner(
      dto.productId,
      userId,
    );
    if (!isProductOwner) {
      throw new WorkspaceForbiddenError(
        'You do not own the workspace associated with this product',
      );
    }

    const isRunOwner = await this.performanceRepository.verifyRunOwner(dto.analysisRunId, userId);
    if (!isRunOwner) {
      throw new WorkspaceForbiddenError(
        'You do not own the workspace associated with this analysis run',
      );
    }

    // 2. Strict Domain Validations
    if (new Date(dto.periodStart) > new Date(dto.periodEnd)) {
      throw new InvalidDateRangeError();
    }

    if (dto.refundCount > dto.salesCount) {
      throw new PerformanceValidationError('refundCount must be less than or equal to salesCount');
    }

    // 3. Database atomic upsert (runs PL/pgSQL RPC which executes transacted upserts for all 3 tables & logs audit)
    const performance = await this.performanceRepository.upsert(
      {
        workspace_id: dto.workspaceId,
        product_id: dto.productId,
        analysis_run_id: dto.analysisRunId,
        strategy_id: dto.strategyId,
        creative_id: dto.creativeId,
        period_start: dto.periodStart,
        period_end: dto.periodEnd,
        sales_count: dto.salesCount,
        sales_amount: dto.salesAmount,
        refund_count: dto.refundCount,
        review_count: dto.reviewCount,
        review_score: dto.reviewScore,
        favorite_count: dto.favoriteCount,
      },
      {
        impressions: dto.metrics.impressions,
        clicks: dto.metrics.clicks,
        conversion_count: dto.metrics.conversionCount,
        conversion_rate: dto.metrics.conversionRate,
        ctr: dto.metrics.ctr,
        ad_cost: dto.metrics.adCost,
        profit: dto.metrics.profit,
        margin_rate: dto.metrics.marginRate,
        roi: dto.metrics.roi,
      } as PerformanceMetrics,
      {
        marketplace_code: dto.source.marketplaceCode,
        marketplace_name: dto.source.marketplaceName,
        collection_job_id: dto.source.collectionJobId,
        source_version: dto.source.sourceVersion,
        collected_at: dto.source.collectedAt,
        raw_payload_hash: dto.source.rawPayloadHash,
      } as PerformanceSource,
      userId,
    );

    // 4. Load nested records for DTO mapping
    const metrics = await this.performanceRepository.findMetrics(performance.id);
    const source = await this.performanceRepository.findSource(performance.id);

    // 5. Trigger Domain Hooks
    const hookPayload = {
      performance,
      actorId: userId,
      timestamp: new Date().toISOString(),
    };
    if (performance.version === 1) {
      await PerformanceHooks.onPerformanceCreated(hookPayload);
    } else {
      await PerformanceHooks.onPerformanceUpdated(hookPayload);
    }

    return PerformanceMapper.toResponseDto(performance, metrics, source);
  }

  async update(
    id: string,
    dto: UpdatePerformanceDto,
    userId: string,
  ): Promise<PerformanceResponseDto> {
    // 1. Verify existence & ownership
    const isOwner = await this.performanceRepository.verifyPerformanceOwner(id, userId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to modify this performance record',
      );
    }

    const existing = await this.performanceRepository.findById(id);
    if (!existing) {
      throw new PerformanceNotFoundError();
    }

    // 2. Domain validations
    if (dto.refundCount > dto.salesCount) {
      throw new PerformanceValidationError('refundCount must be less than or equal to salesCount');
    }

    const previousMetrics = await this.performanceRepository.findMetrics(id);
    const previousSource = await this.performanceRepository.findSource(id);

    const nextVersion = existing.version + 1;

    // 3. Atomically update parent and sub-records inside Repository/DB Context
    const updated = await this.performanceRepository.update(id, {
      strategy_id: dto.strategyId,
      creative_id: dto.creativeId,
      sales_count: dto.salesCount,
      sales_amount: dto.salesAmount,
      refund_count: dto.refundCount,
      review_count: dto.reviewCount,
      review_score: dto.reviewScore,
      favorite_count: dto.favoriteCount,
      version: nextVersion,
      updated_by: userId,
      updated_at: new Date().toISOString(),
    });

    // Update child records using cascade or direct updates
    // In our repository pattern, we replace metrics and sources snapshots
    const clientHolder = this.performanceRepository as unknown as { supabase: SupabaseClient };
    const metricsRepo = clientHolder.supabase.from('performance_metrics');
    const sourceRepo = clientHolder.supabase.from('performance_sources');

    await metricsRepo.delete().eq('performance_id', id);
    const { data: updatedMetrics } = await metricsRepo
      .insert({
        performance_id: id,
        impressions: dto.metrics.impressions,
        clicks: dto.metrics.clicks,
        conversion_count: dto.metrics.conversionCount,
        conversion_rate: dto.metrics.conversionRate,
        ctr: dto.metrics.ctr,
        ad_cost: dto.metrics.adCost,
        profit: dto.metrics.profit,
        margin_rate: dto.metrics.marginRate,
        roi: dto.metrics.roi,
      })
      .select('*')
      .single();

    await sourceRepo.delete().eq('performance_id', id);
    const { data: updatedSource } = await sourceRepo
      .insert({
        performance_id: id,
        marketplace_code: dto.source.marketplaceCode,
        marketplace_name: dto.source.marketplaceName,
        collection_job_id: dto.source.collectionJobId || null,
        source_version: dto.source.sourceVersion,
        collected_at: dto.source.collectedAt,
        raw_payload_hash: dto.source.rawPayloadHash,
      })
      .select('*')
      .single();

    // 4. Create Audit Log for UPDATE
    await this.performanceRepository.createAudit({
      performance_id: id,
      action: 'UPDATE',
      actor_id: userId,
      version: nextVersion,
      metadata: {
        previous: {
          performance: existing,
          metrics: previousMetrics,
          source: previousSource,
        },
        current: {
          performance: updated,
          metrics: updatedMetrics,
          source: updatedSource,
        },
      },
    });

    // 5. Trigger Domain Hooks
    await PerformanceHooks.onPerformanceUpdated({
      performance: updated,
      actorId: userId,
      timestamp: new Date().toISOString(),
    });

    return PerformanceMapper.toResponseDto(updated, updatedMetrics, updatedSource);
  }

  async findById(id: string, userId: string): Promise<PerformanceResponseDto> {
    const isOwner = await this.performanceRepository.verifyPerformanceOwner(id, userId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this performance record',
      );
    }

    const performance = await this.performanceRepository.findById(id);
    if (!performance) {
      throw new PerformanceNotFoundError();
    }

    const metrics = await this.performanceRepository.findMetrics(id);
    const source = await this.performanceRepository.findSource(id);

    return PerformanceMapper.toResponseDto(performance, metrics, source);
  }

  async findByProduct(
    productId: string,
    options: PaginationOptions,
    userId: string,
  ): Promise<PaginatedResult<PerformanceResponseDto>> {
    const isOwner = await this.performanceRepository.verifyProductOwner(productId, userId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product');
    }

    const paginated = await this.performanceRepository.findByProduct(productId, options);
    const dtos = await Promise.all(
      paginated.data.map(async (perf) => {
        const metrics = await this.performanceRepository.findMetrics(perf.id);
        const source = await this.performanceRepository.findSource(perf.id);
        return PerformanceMapper.toResponseDto(perf, metrics, source);
      }),
    );

    return {
      data: dtos,
      total: paginated.total,
      page: paginated.page,
      limit: paginated.limit,
    };
  }

  async findByAnalysis(analysisRunId: string, userId: string): Promise<PerformanceResponseDto[]> {
    const isOwner = await this.performanceRepository.verifyRunOwner(analysisRunId, userId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this analysis run');
    }

    const performances = await this.performanceRepository.findByAnalysis(analysisRunId);
    return Promise.all(
      performances.map(async (perf) => {
        const metrics = await this.performanceRepository.findMetrics(perf.id);
        const source = await this.performanceRepository.findSource(perf.id);
        return PerformanceMapper.toResponseDto(perf, metrics, source);
      }),
    );
  }

  async findByPeriod(
    productId: string,
    startDate: string,
    endDate: string,
    options: PaginationOptions,
    userId: string,
  ): Promise<PaginatedResult<PerformanceResponseDto>> {
    const isOwner = await this.performanceRepository.verifyProductOwner(productId, userId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product');
    }

    if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
      throw new ValidationError('startDate must be less than or equal to endDate');
    }

    const paginated = await this.performanceRepository.findByPeriod(
      productId,
      startDate,
      endDate,
      options,
    );
    const dtos = await Promise.all(
      paginated.data.map(async (perf) => {
        const metrics = await this.performanceRepository.findMetrics(perf.id);
        const source = await this.performanceRepository.findSource(perf.id);
        return PerformanceMapper.toResponseDto(perf, metrics, source);
      }),
    );

    return {
      data: dtos,
      total: paginated.total,
      page: paginated.page,
      limit: paginated.limit,
    };
  }

  async findLatest(productId: string, userId: string): Promise<PerformanceResponseDto> {
    const isOwner = await this.performanceRepository.verifyProductOwner(productId, userId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this product');
    }

    const performance = await this.performanceRepository.findLatest(productId);
    if (!performance) {
      throw new PerformanceNotFoundError('Latest performance record not found for this product');
    }

    const metrics = await this.performanceRepository.findMetrics(performance.id);
    const source = await this.performanceRepository.findSource(performance.id);

    return PerformanceMapper.toResponseDto(performance, metrics, source);
  }

  async delete(id: string, userId: string): Promise<void> {
    const isOwner = await this.performanceRepository.verifyPerformanceOwner(id, userId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to delete this performance record',
      );
    }

    const existing = await this.performanceRepository.findById(id);
    if (!existing) {
      throw new PerformanceNotFoundError();
    }

    const previousMetrics = await this.performanceRepository.findMetrics(id);
    const previousSource = await this.performanceRepository.findSource(id);

    // 1. Soft Delete update in Database
    const nextVersion = existing.version + 1;
    const deletedTime = new Date().toISOString();

    // update parent
    const updated = await this.performanceRepository.update(id, {
      deleted_at: deletedTime,
      deleted_by: userId,
      version: nextVersion,
      updated_at: deletedTime,
    });

    // 2. Create Audit Log for DELETE
    await this.performanceRepository.createAudit({
      performance_id: id,
      action: 'DELETE',
      actor_id: userId,
      version: nextVersion,
      metadata: {
        previous: {
          performance: existing,
          metrics: previousMetrics,
          source: previousSource,
        },
        current: {
          performance: updated,
          metrics: previousMetrics,
          source: previousSource,
        },
      },
    });

    // 3. Trigger Domain Hook
    await PerformanceHooks.onPerformanceDeleted({
      performance: updated,
      actorId: userId,
      timestamp: deletedTime,
    });
  }
}
