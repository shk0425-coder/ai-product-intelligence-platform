export class CancellationToken {
  private cancelled = false;
  private reason?: string;

  cancel(reason?: string): void {
    this.cancelled = true;
    this.reason = reason;
  }

  isCancelled(): boolean {
    return this.cancelled;
  }

  getReason(): string | undefined {
    return this.reason;
  }

  throwIfCancelled(): void {
    if (this.cancelled) {
      throw new Error(`Execution cancelled: ${this.reason || 'No reason provided'}`);
    }
  }
}
export default CancellationToken;
