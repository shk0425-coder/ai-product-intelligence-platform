import { SupabaseClient } from '@supabase/supabase-js';
import { WorkflowDefinitionEntity, WorkflowVersionEntity, WorkflowExecutionEntity, WorkflowStepExecutionEntity, WorkflowAuditLogEntity } from './types.js';

export class WorkflowRepository {
  constructor(private readonly supabase: SupabaseClient) {}

  async findWorkflows(): Promise<WorkflowDefinitionEntity[]> {
    const { data, error } = await this.supabase
      .from('workflow_definitions')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) return [];
    return (data || []) as WorkflowDefinitionEntity[];
  }

  async findWorkflowById(id: string): Promise<WorkflowDefinitionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_definitions')
      .select('*')
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) return null;
    return data as WorkflowDefinitionEntity;
  }

  async createWorkflow(entity: Omit<WorkflowDefinitionEntity, 'id' | 'created_at' | 'updated_at'>): Promise<WorkflowDefinitionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_definitions')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as WorkflowDefinitionEntity;
  }

  async updateWorkflow(id: string, payload: Partial<WorkflowDefinitionEntity>): Promise<WorkflowDefinitionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_definitions')
      .update({
        ...payload,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select('*')
      .maybeSingle();

    if (error) return null;
    return data as WorkflowDefinitionEntity;
  }

  async createVersion(entity: Omit<WorkflowVersionEntity, 'id' | 'created_at'>): Promise<WorkflowVersionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_versions')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as WorkflowVersionEntity;
  }

  async findVersionsByWorkflowId(workflowId: string): Promise<WorkflowVersionEntity[]> {
    const { data, error } = await this.supabase
      .from('workflow_versions')
      .select('*')
      .eq('workflow_id', workflowId)
      .order('version', { ascending: false });

    if (error) return [];
    return (data || []) as WorkflowVersionEntity[];
  }

  async findVersionById(id: string): Promise<WorkflowVersionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_versions')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) return null;
    return data as WorkflowVersionEntity;
  }

  async createExecution(entity: Omit<WorkflowExecutionEntity, 'id' | 'created_at'>): Promise<WorkflowExecutionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_executions')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as WorkflowExecutionEntity;
  }

  async updateExecution(id: string, payload: Partial<WorkflowExecutionEntity>): Promise<WorkflowExecutionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_executions')
      .update(payload)
      .eq('id', id)
      .select('*')
      .maybeSingle();

    if (error) return null;
    return data as WorkflowExecutionEntity;
  }

  async findExecutions(): Promise<WorkflowExecutionEntity[]> {
    const { data, error } = await this.supabase
      .from('workflow_executions')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) return [];
    return (data || []) as WorkflowExecutionEntity[];
  }

  async findExecutionById(id: string): Promise<WorkflowExecutionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_executions')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) return null;
    return data as WorkflowExecutionEntity;
  }

  async createStepExecution(entity: Omit<WorkflowStepExecutionEntity, 'id' | 'created_at'>): Promise<WorkflowStepExecutionEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_step_executions')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as WorkflowStepExecutionEntity;
  }

  async createAuditLog(entity: Omit<WorkflowAuditLogEntity, 'id' | 'created_at'>): Promise<WorkflowAuditLogEntity | null> {
    const { data, error } = await this.supabase
      .from('workflow_audit_logs')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as WorkflowAuditLogEntity;
  }
}
export default WorkflowRepository;
