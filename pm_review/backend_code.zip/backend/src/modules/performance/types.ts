import {
  IBaseRepository,
  PaginationOptions,
  PaginatedResult,
} from '@/repositories/interfaces/base.repository.js';

export interface ProductPerformance {
  id: string; // UUID Primary Key
  workspace_id: string; // UUID FK
  product_id: string; // UUID FK
  analysis_run_id: string; // UUID FK
  strategy_id: string | null; // UUID FK
  creative_id: string | null; // UUID FK
  period_start: string; // DATE (YYYY-MM-DD)
  period_end: string; // DATE (YYYY-MM-DD)
  sales_count: number; // INTEGER
  sales_amount: number; // NUMERIC(15,2)
  refund_count: number; // INTEGER
  review_count: number; // INTEGER
  review_score: number; // NUMERIC(2,1)
  favorite_count: number; // INTEGER
  version: number; // INTEGER
  last_collected_at: string; // TIMESTAMPTZ
  created_at: string; // TIMESTAMPTZ
  updated_at: string; // TIMESTAMPTZ
  deleted_at: string | null; // TIMESTAMPTZ Soft delete
  created_by: string; // UUID FK
  updated_by: string | null; // UUID FK
  deleted_by: string | null; // UUID FK
}

export interface PerformanceMetrics {
  id: string; // UUID PK
  performance_id: string; // UUID FK
  impressions: number; // INTEGER
  clicks: number; // INTEGER
  conversion_count: number; // INTEGER
  conversion_rate: number; // NUMERIC(5,2)
  ctr: number; // NUMERIC(5,2)
  ad_cost: number; // NUMERIC(15,2)
  profit: number; // NUMERIC(15,2)
  margin_rate: number; // NUMERIC(5,2)
  roi: number; // NUMERIC(8,2)
  created_at: string; // TIMESTAMPTZ
  updated_at: string; // TIMESTAMPTZ
}

export interface PerformanceSource {
  id: string; // UUID PK
  performance_id: string; // UUID FK
  marketplace_code: string; // VARCHAR(50)
  marketplace_name: string; // VARCHAR(100)
  collection_job_id: string | null; // UUID
  source_version: number; // INTEGER
  collected_at: string; // TIMESTAMPTZ
  raw_payload_hash: string; // VARCHAR(128)
  created_at: string; // TIMESTAMPTZ
}

export interface PerformanceAuditLog {
  id: string; // UUID PK
  performance_id: string; // UUID FK
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'UPSERT'; // VARCHAR(20)
  actor_id: string; // UUID FK
  version: number; // INTEGER
  changed_at: string; // TIMESTAMPTZ
  metadata: Record<string, unknown>; // JSONB
}

export interface IPerformanceRepository extends IBaseRepository<ProductPerformance> {
  upsert(
    performanceData: Partial<ProductPerformance>,
    metricsData: Partial<PerformanceMetrics>,
    sourceData: Partial<PerformanceSource>,
    actorId: string,
  ): Promise<ProductPerformance>;

  findLatest(productId: string): Promise<ProductPerformance | null>;

  findByProduct(
    productId: string,
    options: PaginationOptions,
  ): Promise<PaginatedResult<ProductPerformance>>;

  findByAnalysis(analysisRunId: string): Promise<ProductPerformance[]>;

  findByPeriod(
    productId: string,
    startDate: string,
    endDate: string,
    options: PaginationOptions,
  ): Promise<PaginatedResult<ProductPerformance>>;

  findMetrics(performanceId: string): Promise<PerformanceMetrics | null>;

  findSource(performanceId: string): Promise<PerformanceSource | null>;

  createAudit(auditLog: Partial<PerformanceAuditLog>): Promise<PerformanceAuditLog>;

  verifyWorkspaceOwner(workspaceId: string, userId: string): Promise<boolean>;
  verifyProductOwner(productId: string, userId: string): Promise<boolean>;
  verifyRunOwner(runId: string, userId: string): Promise<boolean>;
  verifyPerformanceOwner(performanceId: string, userId: string): Promise<boolean>;
}
