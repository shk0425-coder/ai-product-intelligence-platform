import { PromptStatus } from './types.js';

export interface CreatePromptTemplateDto {
  workspaceId: string;
  category: string;
  name: string;
  description?: string;
  systemPrompt: string;
  userPrompt: string;
  modelCapability?: string;
  defaultProvider?: string;
  defaultModel?: string;
  temperature?: number;
  topP?: number;
  maxTokens?: number;
  responseSchema?: Record<string, unknown>;
  tags?: string[];
}

export interface CreatePromptVersionDto {
  systemPrompt: string;
  userPrompt: string;
  changeSummary?: string;
}

export interface RenderPromptDto {
  workspaceId: string;
  variables: Record<string, unknown>;
  provider?: string;
  model?: string;
}

export interface PreviewPromptDto {
  workspaceId: string;
  templateId: string;
  versionId: string;
  variables: Record<string, unknown>;
  model?: string;
}

export interface PromptTemplateDto {
  id: string;
  workspaceId: string;
  category: string;
  name: string;
  description?: string;
  latestVersion: number;
  currentVersionId?: string;
  status: PromptStatus;
  modelCapability: string;
  defaultProvider: string;
  defaultModel: string;
  temperature: number;
  topP: number;
  maxTokens: number;
  responseSchema?: Record<string, unknown>;
  variables: string[];
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PromptVersionDto {
  id: string;
  templateId: string;
  version: number;
  systemPrompt: string;
  userPrompt: string;
  changeSummary?: string;
  variables: string[];
  checksum: string;
  createdAt: string;
}

export interface RenderPromptResponseDto {
  renderedSystemPrompt: string;
  renderedUserPrompt: string;
  checksum: string;
  estimatedTokens: number;
  cacheHit: boolean;
}
