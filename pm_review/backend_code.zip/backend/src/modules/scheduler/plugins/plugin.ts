export interface SchedulerPlugin {
  name: string;
  register(): Promise<void>;
  initialize(): Promise<void>;
  start(): Promise<void>;
  stop(): Promise<void>;
  shutdown(): Promise<void>;
}

export abstract class BaseSchedulerPlugin implements SchedulerPlugin {
  abstract name: string;
  async register(): Promise<void> {}
  async initialize(): Promise<void> {}
  async start(): Promise<void> {}
  async stop(): Promise<void> {}
  async shutdown(): Promise<void> {}
}
