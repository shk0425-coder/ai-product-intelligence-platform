import { ExecutionRepository } from '../persistence/execution-repository.js';
import { JobRepository } from '../persistence/job-repository.js';
import { PriorityQueue } from '../queue/priority-queue.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import { Logger } from '../../observability/logging/logger.js';
import crypto from 'crypto';

export class JobRecovery {
  private static recoveryInterval: NodeJS.Timeout | null = null;
  private static checkPeriodMs = 5000; // Check every 5s

  static init(checkPeriodMs = 5000): void {
    this.checkPeriodMs = checkPeriodMs;
    const enabled = process.env.JOB_RECOVERY_ENABLED !== 'false';
    if (!enabled) return;

    this.recoveryInterval = setInterval(async () => {
      try {
        await this.runOrphanRecovery();
      } catch {
        // Enforce resilience
      }
    }, this.checkPeriodMs);

    if (this.recoveryInterval.unref) {
      this.recoveryInterval.unref();
    }
  }

  static async runOrphanRecovery(): Promise<number> {
    const now = Date.now();
    const orphans = await ExecutionRepository.findOrphanJobs(now);

    let recoveredCount = 0;
    for (const orphan of orphans) {
      const job = await JobRepository.findById(orphan.jobId);
      if (!job) continue;

      // Reset execution state to Failed to terminate this run before retry
      orphan.state = 'Failed';
      orphan.leaseExpiresAt = undefined;
      orphan.endTime = now;
      orphan.error = 'Lease timeout exceeded (Orphan job)';
      await ExecutionRepository.save(orphan);

      // Re-push job to Priority Queue
      const success = await PriorityQueue.push(job, orphan.idempotencyKey);
      if (success) {
        recoveredCount++;
        MetricsRegistry.counter('recovered_jobs_total', 1, { queue: job.name });

        Logger.warn({
          message: `Orphan job recovered: ${job.name} (Execution ID: ${orphan.executionId})`,
          module: 'SCHEDULER',
          action: 'JobRecovery',
        });

        eventBus.publish({
          eventId: crypto.randomUUID(),
          eventType: 'SchedulerRecovered',
          timestamp: new Date().toISOString(),
          workspaceId: (job.metadata.workspaceId as string) || 'default-workspace',
          data: { jobId: job.id, executionId: orphan.executionId, type: 'OrphanRecovery' },
        }).catch(() => {});
      }
    }

    return recoveredCount;
  }

  static stop(): void {
    if (this.recoveryInterval) {
      clearInterval(this.recoveryInterval);
      this.recoveryInterval = null;
    }
  }
}
export default JobRecovery;
