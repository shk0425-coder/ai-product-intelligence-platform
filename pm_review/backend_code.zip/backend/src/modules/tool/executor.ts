export interface ToolAdapter {
  execute(request: Record<string, unknown>): Promise<Record<string, unknown>>;
}

export class HttpToolAdapter implements ToolAdapter {
  async execute(request: Record<string, unknown>): Promise<Record<string, unknown>> {
    // Simulated external HTTP request
    const url = request.url || 'https://api.external.com/data';
    const method = request.method || 'GET';

    return {
      status: 200,
      headers: { 'content-type': 'application/json' },
      body: {
        message: `HTTP Mock ${method} request to ${url} succeeded`,
        receivedPayload: request.payload || {},
      },
    };
  }
}

export class SearchToolAdapter implements ToolAdapter {
  async execute(request: Record<string, unknown>): Promise<Record<string, unknown>> {
    const query = request.query || '';
    return {
      query,
      results: [
        { title: `Search result 1 for ${query}`, snippet: 'Relevant excerpt description...' },
        { title: `Search result 2 for ${query}`, snippet: 'Alternative snippet reference...' },
      ],
    };
  }
}

export class ToolExecutor {
  static getAdapter(category: string): ToolAdapter {
    if (category === 'search') {
      return new SearchToolAdapter();
    }
    // Default fallback to HTTP Tool Adapter
    return new HttpToolAdapter();
  }

  static async run(category: string, request: Record<string, unknown>): Promise<Record<string, unknown>> {
    const adapter = this.getAdapter(category);
    return adapter.execute(request);
  }
}
export default ToolExecutor;
