import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export interface WorkflowStep {
  name: string;
  action: () => Promise<void>;
  rollback?: () => Promise<void>;
}

export class RecoveryWorkflow {
  private static readonly workflows = new Map<string, WorkflowStep[]>();

  static register(workflowId: string, steps: WorkflowStep[]): void {
    this.workflows.set(workflowId, steps);
  }

  static async executeWorkflow(workflowId: string): Promise<boolean> {
    const steps = this.workflows.get(workflowId);
    if (!steps) return false;

    const completedSteps: string[] = [];

    for (const step of steps) {
      try {
        await step.action();
        completedSteps.push(step.name);
      } catch (err) {
        // Run compensation rollback in reverse order
        MetricsRegistry.counter('rollback_total', 1, { step: step.name });
        
        for (let i = completedSteps.length - 1; i >= 0; i--) {
          const compStep = steps.find(s => s.name === completedSteps[i]);
          if (compStep && compStep.rollback) {
            await compStep.rollback();
          }
        }

        eventBus.publish({
          eventId: crypto.randomUUID(),
          eventType: 'RollbackCompleted',
          timestamp: new Date().toISOString(),
          workspaceId: 'default-workspace',
          data: { workflowId, failedStep: step.name, error: (err as Error).message },
        }).catch(() => {});

        return false;
      }
    }

    MetricsRegistry.counter('recovery_validation_total', 1);
    
    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'RecoveryValidated',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { workflowId, stepsCompleted: completedSteps.length },
    }).catch(() => {});

    return true;
  }

  static clear(): void {
    this.workflows.clear();
  }
}
export default RecoveryWorkflow;
