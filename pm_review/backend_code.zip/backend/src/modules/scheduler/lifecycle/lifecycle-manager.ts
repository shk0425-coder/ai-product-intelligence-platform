import { LeaderElection } from '../leader/leader-election.js';
import { SchedulerEngine } from '../engine/scheduler-engine.js';
import { SchedulerDispatcher } from '../engine/dispatcher.js';
import { PluginManager } from '../plugins/plugin-manager.js';
import { JobRecovery } from '../recovery/job-recovery.js';
import { SchedulerStateRepository } from '../persistence/scheduler-state-repository.js';
import { JobRepository } from '../persistence/job-repository.js';
import { ScheduleRepository } from '../persistence/schedule-repository.js';
import { ExecutionRepository } from '../persistence/execution-repository.js';
import { SnapshotManager } from '../recovery/snapshot-manager.js';
import { PriorityQueue } from '../queue/priority-queue.js';
import { DagExecutor } from '../dag/dag-executor.js';
import { DistributedRateLimiter } from '../limiter/rate-limiter.js';

export class SchedulerLifecycleManager {
  static async start(config?: {
    leaseDurationMs?: number;
    checkIntervalMs?: number;
    loopTickMs?: number;
  }): Promise<void> {
    const isSchedulerEnabled = process.env.SCHEDULER_ENABLED !== 'false';
    if (!isSchedulerEnabled) return;

    // 1. Initialize DB state and configs
    await SchedulerStateRepository.saveState({ maintenanceMode: false });

    // 2. Leader Election startup
    LeaderElection.init(config?.leaseDurationMs, config?.checkIntervalMs);

    // 3. Initialize Engine scheduler and Dispatcher loops
    SchedulerEngine.start(config?.loopTickMs);
    SchedulerDispatcher.start(config?.loopTickMs);

    // 4. Job Recovery process startup
    JobRecovery.init(config?.checkIntervalMs);

    // 5. Plugin system initialization
    await PluginManager.loadAll();
    await PluginManager.startAll();
  }

  static async stop(): Promise<void> {
    // 1. Plugin system termination
    await PluginManager.stopAll();
    await PluginManager.shutdownAll();

    // 2. Leader Election release
    await LeaderElection.forceRelease();
    LeaderElection.stopElectionLoop();

    // 3. Engine scheduler loops termination
    SchedulerEngine.stop();
    SchedulerDispatcher.stop();
    JobRecovery.stop();

    // 4. Persistence/Cache registries cleanup
    SchedulerStateRepository.clear();
    JobRepository.clear();
    ScheduleRepository.clear();
    ExecutionRepository.clear();
    SnapshotManager.clear();
    PriorityQueue.clear();
    DagExecutor.clear();
    DistributedRateLimiter.clear();
  }
}
export default SchedulerLifecycleManager;
