-- 41_create_workflow_engine.sql
-- Workflow Engine & Orchestrator Tables

BEGIN;

-- 1. workflow_definitions
CREATE TABLE IF NOT EXISTS public.workflow_definitions (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    latest_version INTEGER NOT NULL DEFAULT 1,
    current_version_id UUID, -- nullable initially until first version is created
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT', -- DRAFT, REVIEW, APPROVED, DEPRECATED
    created_by UUID,
    updated_by UUID,
    approved_by UUID,
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,

    CONSTRAINT pk_workflow_definitions PRIMARY KEY (id),
    CONSTRAINT fk_workflows_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.workflow_definitions IS 'Workflow 정의 마스터 정보 및 승인 메타데이터';

-- 2. workflow_versions
CREATE TABLE IF NOT EXISTS public.workflow_versions (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL,
    version INTEGER NOT NULL,
    graph JSONB NOT NULL DEFAULT '{}'::jsonb,
    checksum VARCHAR(64) NOT NULL,
    change_summary TEXT,
    created_by UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_workflow_versions PRIMARY KEY (id),
    CONSTRAINT fk_workflow_versions_master FOREIGN KEY (workflow_id) REFERENCES public.workflow_definitions(id) ON DELETE CASCADE,
    CONSTRAINT uq_workflow_version UNIQUE (workflow_id, version)
);

COMMENT ON TABLE public.workflow_versions IS 'Workflow 버전 관리 및 DAG 그래프 정의 명세';

-- Add cyclic foreign key constraint for active current version safely
ALTER TABLE public.workflow_definitions
    ADD CONSTRAINT fk_workflows_current_version
    FOREIGN KEY (current_version_id) REFERENCES public.workflow_versions(id) ON DELETE SET NULL;

-- 3. workflow_executions
CREATE TABLE IF NOT EXISTS public.workflow_executions (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    workflow_id UUID NOT NULL,
    version_id UUID NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, RUNNING, WAITING, SUCCESS, FAILED, CANCELLED, TIMEOUT
    execution_key VARCHAR(100) NOT NULL,
    input JSONB NOT NULL DEFAULT '{}'::jsonb,
    output JSONB NOT NULL DEFAULT '{}'::jsonb,
    snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    estimated_cost NUMERIC(10, 6) NOT NULL DEFAULT 0.000000,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_workflow_executions PRIMARY KEY (id),
    CONSTRAINT fk_workflow_exec_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT fk_workflow_exec_master FOREIGN KEY (workflow_id) REFERENCES public.workflow_definitions(id) ON DELETE CASCADE,
    CONSTRAINT fk_workflow_exec_version FOREIGN KEY (version_id) REFERENCES public.workflow_versions(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.workflow_executions IS 'Workflow 실행 단위 스냅샷 및 비용 감사 로그';

-- 4. workflow_step_executions
CREATE TABLE IF NOT EXISTS public.workflow_step_executions (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    execution_id UUID NOT NULL,
    step_id VARCHAR(100) NOT NULL,
    agent_name VARCHAR(100),
    prompt_version_id UUID,
    provider VARCHAR(50),
    model VARCHAR(100),
    retry_count INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, RUNNING, SUCCESS, FAILED, CANCELLED, TIMEOUT
    input JSONB NOT NULL DEFAULT '{}'::jsonb,
    output JSONB NOT NULL DEFAULT '{}'::jsonb,
    estimated_cost NUMERIC(10, 6) NOT NULL DEFAULT 0.000000,
    execution_ms INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_workflow_step_executions PRIMARY KEY (id),
    CONSTRAINT fk_step_exec_parent FOREIGN KEY (execution_id) REFERENCES public.workflow_executions(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.workflow_step_executions IS 'Workflow 내 개별 Step 단위 실행 상태';

-- 5. workflow_audit_logs
CREATE TABLE IF NOT EXISTS public.workflow_audit_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    workflow_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL,
    actor UUID,
    before JSONB,
    after JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_workflow_audit_logs PRIMARY KEY (id),
    CONSTRAINT fk_workflow_audit_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT fk_workflow_audit_master FOREIGN KEY (workflow_id) REFERENCES public.workflow_definitions(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.workflow_audit_logs IS 'Workflow 생명주기 관리 감사 이력';

-- Indexes
CREATE INDEX IF NOT EXISTS idx_workflows_workspace ON public.workflow_definitions(workspace_id);
CREATE INDEX IF NOT EXISTS idx_workflow_versions_master ON public.workflow_versions(workflow_id);
CREATE INDEX IF NOT EXISTS idx_workflow_exec_master_version ON public.workflow_executions(workflow_id, version_id);
CREATE INDEX IF NOT EXISTS idx_step_exec_parent ON public.workflow_step_executions(execution_id);
CREATE INDEX IF NOT EXISTS idx_workflow_audit_master ON public.workflow_audit_logs(workflow_id);

COMMIT;
