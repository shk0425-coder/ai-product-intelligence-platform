export type ToolStatus = 'DRAFT' | 'REVIEW' | 'APPROVED' | 'DEPRECATED';
export type ApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'TIMEOUT' | 'CANCELLED' | 'RESUMED';

export interface ToolManifest {
  name: string;
  category: string;
  version: number;
  timeoutMs?: number;
  retryLimit?: number;
  cacheTtlMs?: number;
}

export interface ToolDefinitionEntity {
  id: string;
  workspace_id: string;
  name: string;
  description?: string;
  category: string;
  latest_version: number;
  current_version_id?: string;
  status: ToolStatus;
  created_by?: string;
  updated_by?: string;
  approved_by?: string;
  approved_at?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface ToolVersionEntity {
  id: string;
  tool_id: string;
  version: number;
  manifest: ToolManifest;
  input_schema: Record<string, unknown>;
  output_schema: Record<string, unknown>;
  permission: string[]; // READ, WRITE, EXECUTE, ADMIN
  timeout_ms: number;
  retry_limit: number;
  checksum: string;
  created_by?: string;
  created_at: string;
}

export interface ToolExecutionHistoryEntity {
  id: string;
  workspace_id: string;
  workflow_execution_id?: string;
  workflow_step_execution_id?: string;
  tool_version_id: string;
  execution_key: string;
  request: Record<string, unknown>;
  response: Record<string, unknown>;
  execution_ms: number;
  cache_hit: boolean;
  success: boolean;
  error_message?: string;
  created_at: string;
}

export interface ApprovalRequestEntity {
  id: string;
  workspace_id: string;
  workflow_execution_id: string;
  workflow_step_execution_id: string;
  title: string;
  description?: string;
  payload: Record<string, unknown>;
  status: ApprovalStatus;
  timeout_at?: string;
  requested_by?: string;
  approved_by?: string;
  approved_at?: string;
  rejected_by?: string;
  rejected_at?: string;
  created_at: string;
}

export interface ApprovalAuditLogEntity {
  id: string;
  approval_id: string;
  action: string;
  actor?: string;
  before?: Record<string, unknown>;
  after?: Record<string, unknown>;
  created_at: string;
}
