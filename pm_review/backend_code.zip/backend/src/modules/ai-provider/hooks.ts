export class AIProviderHooks {
  static async onProviderSelected(_providerId: string, _modelId: string, _workspaceId: string): Promise<void> {
    // Hooks trigger when resolver resolves provider
  }

  static async onProviderCalled(_providerId: string, _modelId: string, _promptLength: number): Promise<void> {
    // Hooks trigger when gateway calls provider
  }

  static async onProviderSucceeded(_providerId: string, _modelId: string, _latencyMs: number): Promise<void> {
    // Hooks trigger when call succeeds
  }

  static async onProviderFailed(_providerId: string, _modelId: string, _errorMsg: string): Promise<void> {
    // Hooks trigger when call fails
  }

  static async onFallbackActivated(_fromProvider: string, _toProvider: string): Promise<void> {
    // Hooks trigger when fallback rolling routing activates
  }

  static async onCircuitOpened(_providerId: string, _modelId: string): Promise<void> {
    // Hooks trigger when circuit breaker trips to OPEN
  }
}
export default AIProviderHooks;
