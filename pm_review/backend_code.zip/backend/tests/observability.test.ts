import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import { createApp } from '../src/app.js';
import { AsyncContextManager } from '../src/modules/observability/context/context-manager.js';
import { Logger } from '../src/modules/observability/logging/logger.js';
import { FileSink, OltpSink } from '../src/modules/observability/logging/sink.js';
import { TraceManager, Span } from '../src/modules/observability/tracing/trace-manager.js';
import { OltpTracingExporter } from '../src/modules/observability/tracing/exporter.js';
import { MetricsRegistry } from '../src/modules/observability/metrics/registry.js';
import { MetricsAggregator } from '../src/modules/observability/metrics/aggregator.js';
import { PrometheusProvider, MetricsProviderFactory } from '../src/modules/observability/metrics/metrics-provider.js';
import { AlertRuleRepository } from '../src/modules/observability/alerts/rule-repository.js';
import { AlertDeduplicator } from '../src/modules/observability/alerts/deduplicator.js';
import { AlertEngine, SlackAlertChannel } from '../src/modules/observability/alerts/engine.js';
import { PerformanceProfiler } from '../src/modules/observability/diagnostics/profiler.js';
import { DiagnosticsEngine } from '../src/modules/observability/diagnostics/diagnostics-engine.js';
import { HealthDashboard } from '../src/modules/observability/dashboard/health.js';
import { EventBusInstrumentation } from '../src/modules/observability/instrumentation/eventbus-instrumentation.js';
import { cacheManager } from '../src/modules/infrastructure/cache/cache-manager.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeSystemResolver = () => Promise.resolve({ data: null, error: null });
  (globalThis as any).__mockSupabaseForSystem = {
    from: vi.fn().mockImplementation(() => ({
      select: vi.fn().mockImplementation(() => Promise.resolve({ data: [], error: null })),
    })),
  };
});

describe('Observability, Monitoring & Diagnostics Platform (Integration Tests)', () => {
  let app: any;
  const testToken = jwt.sign({ orgId: 'test-org-123' }, 'test-jwt-secret');
  const fileSink = new FileSink();
  const oltpSink = new OltpSink();
  const tracingExporter = new OltpTracingExporter();
  const prometheusProvider = new PrometheusProvider();

  beforeAll(async () => {
    app = await createApp();
  });

  beforeEach(() => {
    // Reset environments and configurations
    process.env.OBS_LOGGING_ENABLED = 'true';
    process.env.OBS_METRICS_ENABLED = 'true';
    process.env.OBS_TRACING_ENABLED = 'true';
    process.env.OBS_ALERT_ENABLED = 'true';
    
    fileSink.clear();
    tracingExporter.clear();
    prometheusProvider.clear();
    MetricsAggregator.clear();
    AlertRuleRepository.clear();
    AlertDeduplicator.clear();
    PerformanceProfiler.clear();
    HealthDashboard.invalidateCache();
    TraceManager.clearActiveSpans();

    Logger.setSinks([fileSink, oltpSink]);
    TraceManager.setExporter(tracingExporter);
    MetricsProviderFactory.setProvider(prometheusProvider);
  });

  // 1. Structured Logging & Masking
  describe('Structured Logging & PII Masking', () => {
    it('should format logs in JSON, append tracing IDs and mask sensitive fields', () => {
      AsyncContextManager.run({ traceId: 't-123', correlationId: 'c-456' }, () => {
        Logger.info({
          message: 'User request initiated with apiKey key_999 and password secret_pwd',
          module: 'AUTH',
          action: 'Login',
        });
      });

      const logs = fileSink.getLogs();
      expect(logs.length).toBe(1);
      expect(logs[0].level).toBe('INFO');
      expect(logs[0].trace_id).toBe('t-123');
      expect(logs[0].correlation_id).toBe('c-456');
      expect(logs[0].message).toContain('apiKey [MASKED]');
      expect(logs[0].message).toContain('password [MASKED]');
    });

    it('should suppress logs if OBS_LOGGING_ENABLED is false', () => {
      process.env.OBS_LOGGING_ENABLED = 'false';
      Logger.info({ message: 'Ignore this' });
      expect(fileSink.getLogs().length).toBe(0);
    });
  });

  // 2. Distributed Tracing & Sampling
  describe('Distributed Tracing & Sampling', () => {
    it('should link parent-child spans and propagate correlation IDs', () => {
      AsyncContextManager.run({ correlationId: 'corr-99' }, () => {
        const parentSpan = TraceManager.startSpan('ParentHTTP');
        expect(parentSpan.traceId).toBeDefined();

        const childSpan = TraceManager.startSpan('ChildDB');
        expect(childSpan.parentSpanId).toBe(parentSpan.spanId);
        expect(childSpan.traceId).toBe(parentSpan.traceId);

        childSpan.end();
        parentSpan.end();
      });

      const spans = tracingExporter.getExportedSpans();
      expect(spans.length).toBe(2);
      expect(spans[0].name).toBe('ChildDB');
      expect(spans[1].name).toBe('ParentHTTP');
      expect(spans[0].traceId).toBe(spans[1].traceId);
    });

    it('should enforce Ratio Sampling in TraceManager', () => {
      TraceManager.setSamplingPolicy('RATIO', 0.0); // 0% sampling rate
      const span = TraceManager.startSpan('NoSample');
      span.end();
      expect(tracingExporter.getExportedSpans().length).toBe(0);

      TraceManager.setSamplingPolicy('RATIO', 1.0); // 100% sampling rate
      const span2 = TraceManager.startSpan('SampleIt');
      span2.end();
      expect(tracingExporter.getExportedSpans().length).toBe(1);
    });

    it('should fire leak callbacks on unclosed spans', async () => {
      let leakFired = false;
      TraceManager.init((span) => {
        if (span.name === 'LeakedSpan') leakFired = true;
      }, 10);
      // Set short leak duration for testing
      (TraceManager as any).leakDetectionTimeoutMs = 50;

      TraceManager.startSpan('LeakedSpan');
      await new Promise((resolve) => setTimeout(resolve, 150));

      expect(leakFired).toBe(true);
      TraceManager.stopLeakDetection();
    });
  });

  // 3. Metrics Naming & Aggregation
  describe('Metric Naming Conventions & Aggregation', () => {
    it('should throw an error on violating metric naming conventions', () => {
      expect(() => MetricsRegistry.counter('invalid_name', 1)).toThrow('Metric Naming Violation');
      expect(() => MetricsRegistry.histogram('invalid_name', 1)).toThrow('Metric Naming Violation');
      expect(() => MetricsRegistry.summary('invalid_name', 1)).toThrow('Metric Naming Violation');
    });

    it('should enforce 10 whitelist standard labels and drop unknown labels', () => {
      MetricsRegistry.counter('http_requests_total', 1, {
        workspace_id: 'ws-123',
        endpoint: '/users',
        unknown_label: 'drop-me',
      } as any);

      const raw = prometheusProvider.getRawMetrics();
      const val = raw['http_requests_total'].values[0];
      expect(val.labels?.workspace_id).toBe('ws-123');
      expect(val.labels?.endpoint).toBe('/users');
      expect(val.labels?.unknown_label).toBeUndefined();
    });

    it('should aggregate rolling windows and compress downsampled raw metrics', () => {
      MetricsAggregator.record('http_latency', 10);
      MetricsAggregator.record('http_latency', 20);
      MetricsAggregator.record('http_latency', 30);

      // Trigger manual aggregation
      (MetricsAggregator as any).aggregateWindows();
      const result = MetricsAggregator.getAggregated('http_latency', 1); // 1 minute window
      expect(result).toBeDefined();
      expect(result?.avg).toBe(20);
      expect(result?.max).toBe(30);
      expect(result?.min).toBe(10);
    });
  });

  // 4. Alert Engine & Protection (Storms, Deduplication)
  describe('Alert Engine Storm Protection & Deduplication', () => {
    it('should deduplicate and coalesce alerts during cooldown periods', async () => {
      const rule = {
        id: 'cpu-high',
        name: 'CPU High Alert',
        metricName: 'cpu_usage',
        operator: 'GT' as const,
        threshold: 80,
        windowMinutes: 1,
        cooldownMinutes: 5,
        severity: 'WARNING' as const,
        priority: 'HIGH' as const,
        enabled: true,
        tags: ['system'],
      };
      AlertRuleRepository.register(rule);

      const slackChannel = new SlackAlertChannel();
      AlertEngine.setChannels([slackChannel]);

      // Fire alert 5 times consecutively
      await AlertEngine.triggerAlert(rule, 90, 'CPU is 90%');
      await AlertEngine.triggerAlert(rule, 92, 'CPU is 92%');
      await AlertEngine.triggerAlert(rule, 95, 'CPU is 95%');

      // Due to cooldown and deduplication, only 1 alert must be sent to Slack channel
      expect(slackChannel.getSentMessages().length).toBe(1);
      expect(slackChannel.getSentMessages()[0]).toContain('Fired 1 times');
    });

    it('should trigger severity escalation on recurrent alerts', async () => {
      const rule = {
        id: 'memory-high',
        name: 'Memory High Alert',
        metricName: 'memory_usage',
        operator: 'GT' as const,
        threshold: 80,
        windowMinutes: 1,
        cooldownMinutes: 0, // No cooldown to let alerts accumulate
        severity: 'WARNING' as const,
        priority: 'HIGH' as const,
        enabled: true,
        tags: ['system'],
      };
      AlertRuleRepository.register(rule);

      const slackChannel = new SlackAlertChannel();
      AlertEngine.setChannels([slackChannel]);

      // Fire alert 5 times consecutively to trigger escalation
      for (let i = 0; i < 5; i++) {
        AlertDeduplicator.shouldDispatch(rule, 90, 'Memory high');
      }

      const { instance } = AlertDeduplicator.shouldDispatch(rule, 90, 'Memory high');
      expect(instance?.severity).toBe('CRITICAL');
      expect(instance?.message).toContain('[ESCALATED]');
    });
  });

  // 5. Performance Profiler & Runtime Diagnostics
  describe('Performance Profiler & Diagnostics', () => {
    it('should calculate P50, P90, P99 latency percentiles and top slow endpoints', () => {
      for (let i = 1; i <= 100; i++) {
        PerformanceProfiler.recordLatency('/api/data', i); // 1ms to 100ms
      }

      const stats = PerformanceProfiler.getStats('/api/data');
      expect(stats?.p50).toBe(50);
      expect(stats?.p90).toBe(90);
      expect(stats?.p99).toBe(99);
      expect(stats?.max).toBe(100);
      expect(stats?.avg).toBe(50.5);

      const topSlow = PerformanceProfiler.getTopSlowEndpoints();
      expect(topSlow[0].endpoint).toBe('/api/data');
    });

    it('should run diagnostics analyze report', async () => {
      const report = await DiagnosticsEngine.analyze();
      expect(report.verdict).toBeDefined();
      expect(report.metrics.heapUsagePercentage).toBeGreaterThan(0);
    });
  });

  // 6. EventBus Distributed Tracing propagation
  describe('EventBus Tracing Integration', () => {
    it('should carry and restore trace headers across event bus messages', () => {
      const context = {
        traceId: 'trace-eb-111',
        spanId: 'span-eb-222',
        correlationId: 'corr-eb-333',
        workspaceId: 'ws-eb-444',
      };

      let headers: Record<string, unknown> = {};
      AsyncContextManager.run(context, () => {
        headers = EventBusInstrumentation.injectContext();
      });

      expect(headers['x-trace-id']).toBe('trace-eb-111');
      expect(headers['x-span-id']).toBe('span-eb-222');

      // Consumer side restoration
      const restoreContext = EventBusInstrumentation.extractContext(headers);
      expect(restoreContext.traceId).toBe('trace-eb-111');
      expect(restoreContext.correlationId).toBe('corr-eb-333');
    });
  });

  // 7. Fastify Middleware & APIs
  describe('Monitoring APIs & Middleware Integration', () => {
    it('should route requests through Observability Middleware and return metrics', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/monitoring/summary',
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data.system.uptime).toBeDefined();
      expect(body.data.runtime.cpu).toBeDefined();
    });

    it('should return health dashboard statistics', async () => {
      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/monitoring/health',
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data.overall).toBeDefined();
    });
  });
});
