import { MetricsRegistry } from '../../observability/metrics/registry.js';

export class RecoveryLockManager {
  private static readonly locks = new Map<string, { owner: string; expiresAt: number }>();

  static async acquireLock(key: string, owner: string, leaseMs: number): Promise<boolean> {
    const now = Date.now();
    const existing = this.locks.get(key);

    if (existing && existing.expiresAt > now) {
      MetricsRegistry.counter('recovery_lock_wait_total', 1, { key });
      return false; // Lock is currently held and active
    }

    this.locks.set(key, { owner, expiresAt: now + leaseMs });
    return true;
  }

  static async renewLease(key: string, owner: string, leaseMs: number): Promise<boolean> {
    const now = Date.now();
    const existing = this.locks.get(key);

    if (!existing || existing.owner !== owner || existing.expiresAt <= now) {
      return false; // Cannot renew expired or unowned lock
    }

    existing.expiresAt = now + leaseMs;
    this.locks.set(key, existing);
    return true;
  }

  static async releaseLock(key: string, owner: string): Promise<boolean> {
    const existing = this.locks.get(key);
    if (!existing || existing.owner !== owner) {
      return false; // Unauthorized release
    }

    this.locks.delete(key);
    return true;
  }

  static clear(): void {
    this.locks.clear();
  }
}
export default RecoveryLockManager;
