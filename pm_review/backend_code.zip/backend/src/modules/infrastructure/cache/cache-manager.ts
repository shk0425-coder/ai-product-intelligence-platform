import { MemoryCacheProvider } from './memory-provider.js';
import { RedisCacheProvider } from './redis-provider.js';
import { RedisCircuitBreaker, CircuitState } from './circuit-breaker.js';
import { CachePolicyEngine } from './cache-policy.js';
import { MetricsCollector } from '../monitoring/metrics-service.js';

export class CacheManager {
  private readonly memoryProvider = new MemoryCacheProvider();
  private readonly redisProvider = new RedisCacheProvider();
  private readonly circuitBreaker: RedisCircuitBreaker;
  private currentFallbackMode = false;
  private warmupProgress = 0; // percentage

  constructor() {
    this.circuitBreaker = new RedisCircuitBreaker((oldState, newState) => {
      this.handleCircuitStateChange(oldState, newState);
    });
  }

  getWarmupProgress(): number {
    return this.warmupProgress;
  }

  async warmup(namespaces: string[]): Promise<void> {
    this.warmupProgress = 0;
    if (namespaces.length === 0) {
      this.warmupProgress = 100;
      return;
    }

    let completed = 0;
    for (const ns of namespaces) {
      // Emulate background loading of default keys for namespaces
      await this.set(`v1:${ns}:warmup_init`, { initialized: true }, 600000);
      completed++;
      this.warmupProgress = Math.floor((completed / namespaces.length) * 100);
    }
  }

  private handleCircuitStateChange(oldState: CircuitState, newState: CircuitState): void {
    if (newState === 'OPEN') {
      this.currentFallbackMode = true;
    } else if (newState === 'CLOSED') {
      this.currentFallbackMode = false;
      // Auto-trigger warmup upon Redis recovery
      this.warmup(['system', 'prompt', 'workflow']).catch(() => {});
    }
  }

  getRedisProvider(): RedisCacheProvider {
    return this.redisProvider;
  }

  getMemoryProvider(): MemoryCacheProvider {
    return this.memoryProvider;
  }

  isFallbackActive(): boolean {
    return this.currentFallbackMode;
  }

  private async executeWithFallback<T>(
    opName: string,
    redisOp: (provider: RedisCacheProvider) => Promise<T>,
    memoryOp: (provider: MemoryCacheProvider) => Promise<T>
  ): Promise<T> {
    const state = this.circuitBreaker.getState();

    if (state === 'OPEN') {
      MetricsCollector.recordCacheMiss('memory', 'system', 'unknown');
      return memoryOp(this.memoryProvider);
    }

    try {
      const res = await redisOp(this.redisProvider);
      this.circuitBreaker.recordSuccess();
      return res;
    } catch (_err) {
      this.circuitBreaker.recordFailure();
      // Auto fallback immediately to Memory Cache on fail
      MetricsCollector.recordCacheMiss('memory', 'system', 'unknown');
      return memoryOp(this.memoryProvider);
    }
  }

  async get(key: string, namespace = 'system', workspaceId = 'unknown'): Promise<Record<string, unknown> | null> {
    const policy = CachePolicyEngine.getPolicy();
    const activeProvider = this.isFallbackActive() ? 'memory' : 'redis';

    const result = await this.executeWithFallback(
      'get',
      async (p) => {
        await policy.applyGet(key, p, 600000);
        return p.get(key);
      },
      async (p) => {
        await policy.applyGet(key, p, 600000);
        return p.get(key);
      }
    );

    if (result) {
      MetricsCollector.recordCacheHit(activeProvider, namespace, workspaceId);
    } else {
      MetricsCollector.recordCacheMiss(activeProvider, namespace, workspaceId);
    }
    return result;
  }

  async set(key: string, value: Record<string, unknown>, ttlMs = 600000): Promise<void> {
    const policy = CachePolicyEngine.getPolicy();
    await this.executeWithFallback(
      'set',
      (p) => policy.applySet(key, value, p, ttlMs),
      (p) => policy.applySet(key, value, p, ttlMs)
    );
  }

  async delete(key: string): Promise<void> {
    await this.executeWithFallback(
      'delete',
      (p) => p.delete(key),
      (p) => p.delete(key)
    );
  }

  async exists(key: string): Promise<boolean> {
    return this.executeWithFallback(
      'exists',
      (p) => p.exists(key),
      (p) => p.exists(key)
    );
  }

  async expire(key: string, ttlMs: number): Promise<boolean> {
    return this.executeWithFallback(
      'expire',
      (p) => p.expire(key, ttlMs),
      (p) => p.expire(key, ttlMs)
    );
  }

  async ttl(key: string): Promise<number> {
    return this.executeWithFallback(
      'ttl',
      (p) => p.ttl(key),
      (p) => p.ttl(key)
    );
  }

  async increment(key: string): Promise<number> {
    return this.executeWithFallback(
      'increment',
      (p) => p.increment(key),
      (p) => p.increment(key)
    );
  }

  async decrement(key: string): Promise<number> {
    return this.executeWithFallback(
      'decrement',
      (p) => p.decrement(key),
      (p) => p.decrement(key)
    );
  }

  async clearNamespace(namespace: string): Promise<void> {
    await this.executeWithFallback(
      'clearNamespace',
      (p) => p.clearNamespace(namespace),
      (p) => p.clearNamespace(namespace)
    );
  }
}

// Singleton Cache Manager for unified application layer usage
export const cacheManager = new CacheManager();
export default cacheManager;
