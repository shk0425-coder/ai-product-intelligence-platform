-- 40_create_prompt_registry.sql
-- Prompt Registry & Version Management tables

BEGIN;

-- 1. prompt_templates
CREATE TABLE IF NOT EXISTS public.prompt_templates (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    category VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    latest_version INTEGER NOT NULL DEFAULT 1,
    current_version_id UUID, -- nullable initially until first version is created
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT', -- DRAFT, REVIEW, APPROVED, DEPRECATED
    model_capability VARCHAR(50) NOT NULL DEFAULT 'TEXT',
    default_provider VARCHAR(50) NOT NULL DEFAULT 'GEMINI',
    default_model VARCHAR(100) NOT NULL DEFAULT 'gemini-1.5-pro',
    temperature NUMERIC(3, 2) NOT NULL DEFAULT 0.7,
    top_p NUMERIC(3, 2) NOT NULL DEFAULT 0.9,
    max_tokens INTEGER NOT NULL DEFAULT 2048,
    response_schema JSONB,
    variables JSONB NOT NULL DEFAULT '[]'::jsonb,
    tags JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_by UUID,
    updated_by UUID,
    approved_by UUID,
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,

    CONSTRAINT pk_prompt_templates PRIMARY KEY (id),
    CONSTRAINT fk_prompt_templates_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.prompt_templates IS 'Prompt 템플릿 마스터 정보 및 메타데이터';

-- 2. prompt_versions
CREATE TABLE IF NOT EXISTS public.prompt_versions (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    template_id UUID NOT NULL,
    version INTEGER NOT NULL,
    system_prompt TEXT NOT NULL,
    user_prompt TEXT NOT NULL,
    change_summary TEXT,
    variables JSONB NOT NULL DEFAULT '[]'::jsonb,
    checksum VARCHAR(64) NOT NULL,
    created_by UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_prompt_versions PRIMARY KEY (id),
    CONSTRAINT fk_prompt_versions_template FOREIGN KEY (template_id) REFERENCES public.prompt_templates(id) ON DELETE CASCADE,
    CONSTRAINT uq_template_version UNIQUE (template_id, version)
);

COMMENT ON TABLE public.prompt_versions IS 'Prompt 수정 이력 및 버전별 프롬프트 본문';

-- Add cyclic foreign key constraint for template active version safely
ALTER TABLE public.prompt_templates 
    ADD CONSTRAINT fk_prompt_templates_current_version 
    FOREIGN KEY (current_version_id) REFERENCES public.prompt_versions(id) ON DELETE SET NULL;

-- 3. prompt_execution_history
CREATE TABLE IF NOT EXISTS public.prompt_execution_history (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    template_id UUID NOT NULL,
    version_id UUID NOT NULL,
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    rendered_hash VARCHAR(64) NOT NULL,
    execution_ms INTEGER NOT NULL DEFAULT 0,
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER NOT NULL DEFAULT 0,
    estimated_cost NUMERIC(10, 6) NOT NULL DEFAULT 0.000000,
    cache_hit BOOLEAN NOT NULL DEFAULT false,
    success BOOLEAN NOT NULL DEFAULT true,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_prompt_execution_history PRIMARY KEY (id),
    CONSTRAINT fk_prompt_history_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT fk_prompt_history_template FOREIGN KEY (template_id) REFERENCES public.prompt_templates(id) ON DELETE CASCADE,
    CONSTRAINT fk_prompt_history_version FOREIGN KEY (version_id) REFERENCES public.prompt_versions(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.prompt_execution_history IS '프롬프트 실행 단위 토큰/비용/성공 감사 로그';

-- 4. prompt_audit_logs
CREATE TABLE IF NOT EXISTS public.prompt_audit_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    template_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL,
    actor UUID,
    before JSONB,
    after JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_prompt_audit_logs PRIMARY KEY (id),
    CONSTRAINT fk_prompt_audit_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT fk_prompt_audit_template FOREIGN KEY (template_id) REFERENCES public.prompt_templates(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.prompt_audit_logs IS '프롬프트 라이프사이클(승인/반려/수정 등) 감사 트레일';

-- Performance Index
CREATE INDEX IF NOT EXISTS idx_prompt_templates_workspace ON public.prompt_templates(workspace_id);
CREATE INDEX IF NOT EXISTS idx_prompt_versions_template ON public.prompt_versions(template_id);
CREATE INDEX IF NOT EXISTS idx_prompt_history_template_version ON public.prompt_execution_history(template_id, version_id);
CREATE INDEX IF NOT EXISTS idx_prompt_audit_template ON public.prompt_audit_logs(template_id);

COMMIT;
