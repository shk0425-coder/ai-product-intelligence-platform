export class PromptHooks {
  static async onPromptCreated(_templateId: string, _workspaceId: string): Promise<void> {
    // Hooks trigger when prompt template is created
  }

  static async onVersionGenerated(_templateId: string, _versionId: string, _version: number): Promise<void> {
    // Hooks trigger when version is incremented
  }

  static async onPromptApproved(_templateId: string, _approvedBy: string): Promise<void> {
    // Hooks trigger when template state transits to APPROVED
  }

  static async onPromptExecuted(_templateId: string, _versionId: string, _latencyMs: number, _success: boolean): Promise<void> {
    // Hooks trigger when prompt is run via AIGateway
  }

  static async onPromptAuditLogged(_templateId: string, _action: string): Promise<void> {
    // Hooks trigger when audit logs are generated
  }
}
export default PromptHooks;
