import { JobQueueRepository } from './repository.js';
import { LeaseManager } from './lease-manager.js';
import { IWorker } from './worker-registry.js';
import { JobQueueEntity } from './types.js';
import { QUEUE_CONSTANTS } from './constants.js';
import { DeadLetterManager } from './dead-letter.js';
import { JobQueueHooks } from './hooks.js';

export class JobExecutor {
  constructor(
    private readonly repository: JobQueueRepository,
    private readonly leaseManager: LeaseManager
  ) {}

  async executeJob(job: JobQueueEntity, worker: IWorker): Promise<void> {
    const startTime = Date.now();
    let heartbeatInterval: NodeJS.Timeout | null = null;

    // Start background heartbeat
    heartbeatInterval = setInterval(async () => {
      // Check cancellation request first
      const freshJob = await this.repository.findJob(job.id);
      if (freshJob?.cancel_requested) {
        // Stop execution
        if (heartbeatInterval) clearInterval(heartbeatInterval);
        return;
      }

      const active = await this.leaseManager.heartbeat(job.id);
      if (!active) {
        // Heartbeat updated failed (e.g. lease stolen or connection lost)
        if (heartbeatInterval) clearInterval(heartbeatInterval);
      } else {
        await JobQueueHooks.onHeartbeatUpdated(job.id, new Date().toISOString());
      }
    }, QUEUE_CONSTANTS.DEFAULT_HEARTBEAT_INTERVAL_MS);

    try {
      // Check early cancellation
      const checkCancel = await this.repository.findJob(job.id);
      if (checkCancel?.cancel_requested) {
        throw new Error('Job execution cancelled by client');
      }

      await JobQueueHooks.onJobStarted(job);

      // Invoke pure worker execute
      await worker.execute(job.id, job.payload);

      // Clean heartbeat
      if (heartbeatInterval) clearInterval(heartbeatInterval);

      // Verify cancellation one more time before finishing
      const finalCheck = await this.repository.findJob(job.id);
      if (finalCheck?.cancel_requested) {
        throw new Error('Job execution cancelled by client');
      }

      // Mark status as SUCCESS
      await this.repository.updateJob(job.id, {
        status: 'SUCCESS',
        lease_owner: null,
        lease_until: null,
        heartbeat_at: null,
        completed_at: new Date().toISOString(),
      });

      // Write execution log
      await this.repository.createExecutionLog({
        job_id: job.id,
        worker: worker.constructor.name || 'GenericWorker',
        status: 'SUCCESS',
        duration_ms: Date.now() - startTime,
      });

      const updatedJob = await this.repository.findJob(job.id);
      if (updatedJob) {
        await JobQueueHooks.onJobCompleted(updatedJob);
      }
    } catch (err: unknown) {
      if (heartbeatInterval) clearInterval(heartbeatInterval);

      const durationMs = Date.now() - startTime;
      const errorMsg = err instanceof Error ? err.message : String(err);

      await this.repository.createExecutionLog({
        job_id: job.id,
        worker: worker.constructor.name || 'GenericWorker',
        status: 'FAILED',
        duration_ms: durationMs,
        error_message: errorMsg,
      });

      await this.handleFailure(job, errorMsg);
    }
  }

  private async handleFailure(job: JobQueueEntity, errorMsg: string): Promise<void> {
    const nextRetryCount = job.retry_count + 1;
    const maxRetry = job.max_retry ?? QUEUE_CONSTANTS.DEFAULT_MAX_RETRY;

    const freshJob = await this.repository.findJob(job.id);
    if (freshJob?.cancel_requested) {
      // If cancelled, transition status to FAILED immediately without retrying
      await this.repository.updateJob(job.id, {
        status: 'FAILED',
        lease_owner: null,
        lease_until: null,
        heartbeat_at: null,
        error_message: 'Cancelled: ' + errorMsg,
        completed_at: new Date().toISOString(),
      });
      return;
    }

    if (nextRetryCount > maxRetry) {
      // Exceeded limit: Route to dead letter
      await DeadLetterManager.routeToDeadLetter(this.repository, job, errorMsg);
    } else {
      // Calculate Backoff
      const backoffSeconds = QUEUE_CONSTANTS.BACKOFF_STRATEGY[nextRetryCount - 1] || 30;
      const scheduledAt = new Date(Date.now() + backoffSeconds * 1000).toISOString();

      const retryingJob = await this.repository.updateJob(job.id, {
        status: 'FAILED', // or FAILED, then dispatcher picks PENDING/FAILED
        retry_count: nextRetryCount,
        scheduled_at: scheduledAt,
        lease_owner: null,
        lease_until: null,
        heartbeat_at: null,
        error_message: errorMsg,
      });

      await JobQueueHooks.onJobFailed(retryingJob, errorMsg);
    }
  }
}
