export interface SandboxConfig {
  cpuLimitPercentage: number;
  memoryLimitMb: number;
  timeoutMs: number;
}

export class PluginSandbox {
  static async runInSandbox(
    action: () => Promise<void>,
    config: SandboxConfig
  ): Promise<{ success: boolean; error?: string }> {
    // Check CPU/Memory mock limits (e.g. Memory configuration check)
    if (config.memoryLimitMb <= 0 || config.cpuLimitPercentage <= 0) {
      return { success: false, error: 'Resource budget constraint violated' };
    }

    try {
      const timeoutPromise = new Promise<void>((_, reject) =>
        setTimeout(() => reject(new Error('Sandbox execution timeout')), config.timeoutMs)
      );
      const actionPromise = action();

      await Promise.race([actionPromise, timeoutPromise]);

      return { success: true };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  }
}
export default PluginSandbox;
