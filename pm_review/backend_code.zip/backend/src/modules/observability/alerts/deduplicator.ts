import { AlertRule, AlertSeverity } from './rule-repository.js';

export interface AlertInstance {
  ruleId: string;
  message: string;
  timestamp: number;
  value: number;
  severity: AlertSeverity;
  count: number;
  lastFiredAt: number;
  resolved: boolean;
}

export class AlertDeduplicator {
  private static readonly activeAlerts = new Map<string, AlertInstance>();
  private static readonly cooldowns = new Map<string, number>();

  static shouldDispatch(rule: AlertRule, value: number, msg: string): { dispatch: boolean; instance?: AlertInstance } {
    const now = Date.now();
    const ruleId = rule.id;

    // Check cooldown duration
    const lastFired = this.cooldowns.get(ruleId) || 0;
    const cooldownMs = rule.cooldownMinutes * 60000;
    if (now - lastFired < cooldownMs) {
      // Cooldown in progress, suppress execution
      return { dispatch: false };
    }

    let instance = this.activeAlerts.get(ruleId);
    if (!instance || instance.resolved) {
      instance = {
        ruleId,
        message: msg,
        timestamp: now,
        value,
        severity: rule.severity,
        count: 1,
        lastFiredAt: now,
        resolved: false,
      };
    } else {
      instance.count++;
      instance.lastFiredAt = now;
      instance.value = value;
      // Escalation trigger: If triggered more than 5 times consecutively, escalate severity to CRITICAL
      if (instance.count >= 5 && instance.severity !== 'CRITICAL') {
        instance.severity = 'CRITICAL';
        instance.message = `[ESCALATED] ${instance.message}`;
      }
    }

    this.activeAlerts.set(ruleId, instance);
    this.cooldowns.set(ruleId, now);

    return { dispatch: true, instance };
  }

  static resolve(ruleId: string): AlertInstance | undefined {
    const instance = this.activeAlerts.get(ruleId);
    if (instance && !instance.resolved) {
      instance.resolved = true;
      instance.lastFiredAt = Date.now();
      return instance;
    }
    return undefined;
  }

  static getActiveCount(): number {
    return Array.from(this.activeAlerts.values()).filter(a => !a.resolved).length;
  }

  static getCriticalCount(): number {
    return Array.from(this.activeAlerts.values()).filter(a => !a.resolved && a.severity === 'CRITICAL').length;
  }

  static getAlertsList(): AlertInstance[] {
    return Array.from(this.activeAlerts.values());
  }

  static clear(): void {
    this.activeAlerts.clear();
    this.cooldowns.clear();
  }
}
