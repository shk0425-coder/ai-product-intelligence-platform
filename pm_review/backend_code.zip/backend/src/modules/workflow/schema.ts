import { z } from 'zod';

const nodeTypeSchema = z.enum(['Start', 'End', 'Agent', 'Parallel', 'Condition', 'Merge']);
const edgeTypeSchema = z.enum(['Success', 'Failure', 'Timeout', 'Cancel']).optional();

export const workflowNodeSchema = z.object({
  id: z.string().min(1),
  type: nodeTypeSchema,
  name: z.string().min(1),
  agentName: z.string().optional(),
  promptTemplateId: z.string().uuid().optional(),
  conditionExpression: z.string().optional(),
  timeoutMs: z.number().int().min(0).optional(),
  maxRetry: z.number().int().min(0).optional(),
  retryIntervalMs: z.number().int().min(0).optional(),
  parallelNodeIds: z.array(z.string()).optional(),
});

export const workflowEdgeSchema = z.object({
  from: z.string().min(1),
  to: z.string().min(1),
  type: edgeTypeSchema,
});

export const workflowGraphSchema = z.object({
  nodes: z.array(workflowNodeSchema),
  edges: z.array(workflowEdgeSchema),
});

export const createWorkflowSchema = z.object({
  workspaceId: z.string().uuid(),
  name: z.string().min(1),
  description: z.string().optional(),
  graph: workflowGraphSchema,
});

export const createWorkflowVersionSchema = z.object({
  graph: workflowGraphSchema,
  changeSummary: z.string().optional(),
});

export const executeWorkflowSchema = z.object({
  workspaceId: z.string().uuid(),
  input: z.record(z.any()),
});

export const previewWorkflowSchema = z.object({
  workspaceId: z.string().uuid(),
  graph: workflowGraphSchema,
  input: z.record(z.any()),
});
