import { AppEventPayload } from './event-registry.js';
import { MetricsCollector } from '../monitoring/metrics-service.js';

export interface DLEntry {
  event: AppEventPayload;
  reason: string;
  failedAt: string;
  retryCount: number;
  status: 'POISON' | 'IGNORED' | 'ARCHIVED' | 'RESOLVED';
  replayAttempts: number;
}

export class DeadLetterQueue {
  private static readonly dlqStream: DLEntry[] = [];

  static async push(event: AppEventPayload, reason: string, retryCount: number): Promise<void> {
    const entry: DLEntry = {
      event,
      reason,
      failedAt: new Date().toISOString(),
      retryCount,
      status: 'POISON',
      replayAttempts: 0,
    };
    this.dlqStream.push(entry);
    MetricsCollector.recordDlqCount(event.eventType, event.workspaceId);
  }

  static async getEntries(): Promise<DLEntry[]> {
    return [...this.dlqStream];
  }

  static async replay(eventId: string, handler: (event: AppEventPayload) => Promise<void>): Promise<boolean> {
    const idx = this.dlqStream.findIndex((e) => e.event.eventId === eventId);
    if (idx === -1) return false;

    const entry = this.dlqStream[idx];
    if (entry.replayAttempts >= 3) {
      // Reject replay if maximum threshold is reached
      entry.status = 'POISON';
      return false;
    }

    try {
      entry.replayAttempts++;
      await handler(entry.event);
      this.dlqStream.splice(idx, 1);
      return true;
    } catch (err) {
      entry.reason = `Replay failed: ${(err as Error).message}`;
      entry.failedAt = new Date().toISOString();
      return false;
    }
  }

  static async ignore(eventId: string): Promise<boolean> {
    const entry = this.dlqStream.find((e) => e.event.eventId === eventId);
    if (!entry) return false;
    entry.status = 'IGNORED';
    return true;
  }

  static async archive(eventId: string): Promise<boolean> {
    const entry = this.dlqStream.find((e) => e.event.eventId === eventId);
    if (!entry) return false;
    entry.status = 'ARCHIVED';
    return true;
  }

  static clear(): void {
    this.dlqStream.length = 0;
  }
}
export default DeadLetterQueue;
