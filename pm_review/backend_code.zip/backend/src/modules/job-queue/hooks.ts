import { JobQueueEntity } from './types.js';

export interface JobEventPayload {
  jobId: string;
  workspaceId: string;
  status: string;
  timestamp: string;
}

export class JobQueueHooks {
  static async onJobQueued(_job: JobQueueEntity): Promise<void> {
    // Hooks trigger on queue
  }

  static async onJobStarted(_job: JobQueueEntity): Promise<void> {
    // Hooks trigger on run start
  }

  static async onHeartbeatUpdated(_jobId: string, _timestamp: string): Promise<void> {
    // Hooks trigger on heartbeat tick
  }

  static async onJobCompleted(_job: JobQueueEntity): Promise<void> {
    // Hooks trigger on success
  }

  static async onJobFailed(_job: JobQueueEntity, _errorMessage: string): Promise<void> {
    // Hooks trigger on failure
  }

  static async onDeadLetterCreated(_jobId: string, _reason: string): Promise<void> {
    // Hooks trigger on DLQ routing
  }
}
