import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export interface SimulationResult {
  dryRun: boolean;
  successProbability: number;
  report: string;
}

export class SimulationEngine {
  private static readonly history: SimulationResult[] = [];

  static async runSimulation(runbookId: string): Promise<SimulationResult> {
    const successProbability = 95; // Emulated prediction success probability
    const result: SimulationResult = {
      dryRun: true,
      successProbability,
      report: `Dry run simulation passed for Runbook ${runbookId}. Probability: ${successProbability}%`,
    };

    this.history.push(result);
    MetricsRegistry.counter('simulation_total', 1);
    MetricsRegistry.counter('simulation_success_total', 1);

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'SimulationStarted',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { runbookId, successProbability },
    }).catch(() => {});

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'SimulationCompleted',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { runbookId, status: 'success' },
    }).catch(() => {});

    return result;
  }

  static getHistory(): SimulationResult[] {
    return [...this.history];
  }

  static clear(): void {
    this.history.length = 0;
  }
}
export default SimulationEngine;
