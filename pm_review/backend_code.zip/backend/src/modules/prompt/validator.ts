import { PromptTemplateEntity, PromptVersionEntity } from './types.js';
import { ValidationError } from '../../common/errors/index.js';

export class PromptValidator {
  static validate(
    template: PromptTemplateEntity | null,
    version: PromptVersionEntity | null,
    renderedSystem: string,
    renderedUser: string,
    variables: Record<string, unknown>
  ): void {
    // 1. Template & Version presence
    if (!template) {
      throw new ValidationError('Prompt template not found');
    }
    if (!version) {
      throw new ValidationError('Prompt version not found');
    }

    // 2. Approval workflow check
    if (template.status !== 'APPROVED') {
      throw new ValidationError(`Prompt execution is restricted: current status is ${template.status}. Only APPROVED prompts can be run.`);
    }

    // 3. Variable matches verification
    const declaredVars = version.variables || [];
    for (const v of declaredVars) {
      // If variable contains default value spec or optional character in version definition, we strip it in validation
      const cleanVar = v.split('|')[0].replace('?', '');
      if (variables[cleanVar] === undefined && !v.includes('?')) {
        throw new ValidationError(`Required variable "${cleanVar}" was not provided for execution`);
      }
    }

    // 4. Content limit and estimation checks
    const promptLength = renderedSystem.length + renderedUser.length;
    if (promptLength > 1000000) {
      // 1M characters safety limit
      throw new ValidationError(`Rendered prompt size (${promptLength} chars) exceeds security threshold of 1,000,000 characters.`);
    }

    // 5. Schema verification
    if (template.response_schema) {
      const schemaType = template.response_schema.type;
      if (!schemaType) {
        throw new ValidationError('Declared response schema is missing a "type" attribute');
      }
    }
  }
}
export default PromptValidator;
