export interface SpanRecord {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  name: string;
  startTime: number;
  endTime?: number;
  durationMs?: number;
  attributes: Record<string, unknown>;
  status: 'OK' | 'ERROR';
  error?: string;
}

export interface TracingExporter {
  export(span: SpanRecord): void;
}

export class ConsoleTracingExporter implements TracingExporter {
  export(_span: SpanRecord): void {
    // Suppress console spam unless trace logging is enabled
  }
}

export class OltpTracingExporter implements TracingExporter {
  private spans: SpanRecord[] = [];

  export(span: SpanRecord): void {
    this.spans.push(span);
  }

  getExportedSpans(): SpanRecord[] {
    return [...this.spans];
  }

  clear(): void {
    this.spans = [];
  }
}

export class JaegerTracingExporter implements TracingExporter {
  export(_span: SpanRecord): void {
    // Emulated Jaeger thrift/proto HTTP dispatch.
  }
}

export class ZipkinTracingExporter implements TracingExporter {
  export(_span: SpanRecord): void {
    // Emulated Zipkin JSON API ingest.
  }
}
