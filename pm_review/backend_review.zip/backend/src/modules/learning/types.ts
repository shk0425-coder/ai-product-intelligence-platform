export interface LearningPlaceholder {}
