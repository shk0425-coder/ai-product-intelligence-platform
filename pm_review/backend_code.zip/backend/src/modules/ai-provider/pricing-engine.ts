import { ModelMetadata } from './types.js';

export class PricingEngine {
  static calculateCost(promptTokens: number, completionTokens: number, metadata: ModelMetadata): number {
    if (promptTokens < 0 || completionTokens < 0) return 0;

    // inputCost & outputCost are per 1,000 tokens
    const inputCost = (promptTokens * metadata.inputCost) / 1000;
    const outputCost = (completionTokens * metadata.outputCost) / 1000;
    
    const total = inputCost + outputCost;
    if (isNaN(total) || !isFinite(total)) {
      return 0;
    }
    return Math.max(0, total);
  }
}
export default PricingEngine;
