import { NORMALIZATION_LIMITS } from './constants.js';

/**
 * Pure functions for KPI normalization to [0, 100] range.
 */
export const FeedbackNormalization = {
  normalizeSales(salesCount: number): number {
    return Math.min(100.0, (salesCount / NORMALIZATION_LIMITS.SALES_MAX_COUNT) * 100.0);
  },

  normalizeReview(reviewScore: number): number {
    return Math.min(100.0, (reviewScore / NORMALIZATION_LIMITS.REVIEW_MAX_SCORE) * 100.0);
  },

  normalizeConversion(conversionRate: number): number {
    return Math.min(100.0, (conversionRate / NORMALIZATION_LIMITS.CONVERSION_MAX_RATE) * 100.0);
  },

  normalizeCtr(ctr: number): number {
    return Math.min(100.0, (ctr / NORMALIZATION_LIMITS.CTR_MAX_RATE) * 100.0);
  },

  normalizeRoi(roi: number): number {
    return Math.min(100.0, (roi / NORMALIZATION_LIMITS.ROI_MAX_RATE) * 100.0);
  },

  normalizeProfit(profit: number): number {
    return Math.min(
      100.0,
      Math.max(0.0, (profit / NORMALIZATION_LIMITS.PROFIT_MAX_AMOUNT) * 100.0),
    );
  },

  normalizeFavorite(favoriteCount: number): number {
    return Math.min(100.0, (favoriteCount / NORMALIZATION_LIMITS.FAVORITE_MAX_COUNT) * 100.0);
  },

  normalizeRefund(refundCount: number): number {
    return Math.min(100.0, (refundCount / NORMALIZATION_LIMITS.REFUND_MAX_COUNT) * 100.0);
  },
};
