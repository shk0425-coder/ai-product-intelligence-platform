export interface StrategyPlaceholder {}
