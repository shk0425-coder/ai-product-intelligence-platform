import { FeedbackRuleEngine } from './rule-engine.js';
import { BottleneckDetector } from './bottleneck-detector.js';
import { RecommendationEngine } from './recommendation-engine.js';
import { ImpactCalculator } from './impact-calculator.js';
import { ConfidenceCalculator } from './confidence-calculator.js';

export interface AnalyzerInput {
  feedbackScore: {
    sales_score: number;
    review_score: number;
    conversion_score: number;
    engagement_score: number;
    profitability_score: number;
    refund_penalty: number;
    overall_score: number;
  };
  performance:
    | {
        refund_count?: number;
        sales_count?: number;
        [key: string]: unknown;
      }
    | null
    | undefined;
  metrics: Record<string, unknown> | null | undefined;
}

export const FeedbackIntelligenceAnalyzer = {
  analyze(input: AnalyzerInput) {
    const { feedbackScore, performance, metrics } = input;

    // 1. Prepare rule engine payload
    const ruleInput = {
      salesScore: Number(feedbackScore.sales_score),
      reviewScore: Number(feedbackScore.review_score),
      conversionScore: Number(feedbackScore.conversion_score),
      ctrScore: Number(feedbackScore.engagement_score), // mapping to subgroup scores
      roiScore: Number(feedbackScore.profitability_score), // mapping
      profitScore: Number(feedbackScore.profitability_score), // mapping
      favoriteScore: Number(feedbackScore.engagement_score),
      refundPenalty: Number(feedbackScore.refund_penalty),
      metrics: {
        refund_count: performance ? performance.refund_count : undefined,
        sales_count: performance ? performance.sales_count : undefined,
        ...metrics,
      },
    };

    // 2. Match Rules
    const matchedRules = FeedbackRuleEngine.matchRules(ruleInput);

    // 3. Detect Bottlenecks & Root Causes
    const bottleneckResults = BottleneckDetector.detect(matchedRules);

    // 4. Generate Recommendations
    const recommendationResults = RecommendationEngine.generate(matchedRules);

    // 5. Compute Impact and Confidence
    const impactScore = ImpactCalculator.calculate(matchedRules);
    const confidenceScore = ConfidenceCalculator.calculate(performance, metrics);

    // 6. Define Strengths
    let strengthSummary = '검출된 주요 스토어 강점이 없습니다. 전반적인 마케팅 튜닝이 요구됩니다.';
    const strengthCategories: string[] = [];
    if (Number(feedbackScore.review_score) >= 80) strengthCategories.push('리뷰 평점 고객 만족도');
    if (Number(feedbackScore.sales_score) >= 70) strengthCategories.push('스토어 판매 볼륨');
    if (Number(feedbackScore.conversion_score) >= 70)
      strengthCategories.push('구매 고객 타겟 정밀화(전환율)');

    if (strengthCategories.length > 0) {
      strengthSummary = `검출된 스토어 강점 요소: ${strengthCategories.join(', ')} 우수`;
    }

    return {
      strengthSummary,
      weaknessSummary: bottleneckResults.weaknessSummary,
      bottleneckSummary: bottleneckResults.bottleneckSummary,
      improvementSummary: recommendationResults.improvementSummary,
      rootCauses: bottleneckResults.rootCauses,
      recommendations: recommendationResults.recommendations,
      detectedRules: matchedRules.map((r) => ({
        ruleId: r.id,
        category: r.category,
        severity: r.severity,
        message: r.message,
      })),
      impactScore,
      confidenceScore,
    };
  },
};
export default FeedbackIntelligenceAnalyzer;
