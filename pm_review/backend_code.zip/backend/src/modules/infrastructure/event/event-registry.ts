export type EventType =
  | 'WorkflowStarted'
  | 'WorkflowCompleted'
  | 'WorkflowFailed'
  | 'PromptRendered'
  | 'ToolExecuted'
  | 'ApprovalRequested'
  | 'ApprovalApproved'
  | 'AnalysisCompleted'
  | 'JobScheduled'
  | 'JobStarted'
  | 'JobCompleted'
  | 'JobFailed'
  | 'JobRetried'
  | 'JobCancelled'
  | 'LeaderChanged'
  | 'SchedulerSnapshotCreated'
  | 'SchedulerRecovered'
  | 'SchedulerSnapshotCreated'
  | 'SchedulerMaintenanceStarted'
  | 'SchedulerMaintenanceStopped'
  | 'AdmissionRejected'
  | 'AdmissionDelayed'
  | 'PolicyViolation'
  | 'RunbookStarted'
  | 'RunbookCompleted'
  | 'RecoveryStateChanged'
  | 'SimulationStarted'
  | 'SimulationCompleted'
  | 'SimulationValidated'
  | 'IncidentCreated'
  | 'IncidentUpdated'
  | 'IncidentResolved'
  | 'RootCauseDetected'
  | 'RecoveryValidated'
  | 'RollbackCompleted'
  | 'ApprovalRequested'
  | 'ApprovalCompleted';

export interface AppEventPayload {
  eventId: string; // UUID
  eventType: EventType;
  timestamp: string;
  workspaceId: string;
  event_version?: number;
  eventSequenceNumber?: number;
  data: Record<string, unknown>;
}

export class EventRegistry {
  private static readonly eventSchemas = new Map<EventType, string[]>();

  static register(type: EventType, requiredFields: string[]): void {
    this.eventSchemas.set(type, requiredFields);
  }

  static validate(event: AppEventPayload): void {
    if (!event.eventId) throw new Error('EventId is required');
    if (!event.eventType) throw new Error('EventType is required');
    if (!event.workspaceId) throw new Error('WorkspaceId is required');

    const schema = this.eventSchemas.get(event.eventType);
    if (schema) {
      for (const field of schema) {
        if (event.data[field] === undefined) {
          throw new Error(`Invalid Event Payload: Missing required field "${field}" for ${event.eventType}`);
        }
      }
    }
  }
}

// Register basic default requirements
EventRegistry.register('WorkflowStarted', ['workflowId']);
EventRegistry.register('WorkflowCompleted', ['workflowId']);
EventRegistry.register('WorkflowFailed', ['workflowId', 'error']);
EventRegistry.register('PromptRendered', ['promptId']);
EventRegistry.register('ToolExecuted', ['toolId']);
EventRegistry.register('ApprovalRequested', ['approvalId']);
EventRegistry.register('ApprovalApproved', ['approvalId']);
EventRegistry.register('AnalysisCompleted', ['analysisId']);
