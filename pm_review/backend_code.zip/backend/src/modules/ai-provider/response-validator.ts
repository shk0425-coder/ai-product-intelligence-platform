import { GenerateResponse } from './types.js';
import {
  ResponseValidationError,
  StructuredOutputValidationError,
  InvalidTokenUsageError,
  InvalidFinishReasonError,
} from '../../common/errors/index.js';
import { FINISH_REASONS } from './constants.js';

export class ResponseValidator {
  static validate(response: GenerateResponse, responseSchema?: Record<string, unknown>): void {
    // 1. Empty & Schema Validation
    if (!response) {
      throw new ResponseValidationError('AI response cannot be null or undefined');
    }
    if (!response.content || response.content.trim() === '') {
      throw new ResponseValidationError('AI response content cannot be empty');
    }
    if (!response.provider || response.provider.trim() === '') {
      throw new ResponseValidationError('AI response provider field is missing');
    }
    if (!response.model || response.model.trim() === '') {
      throw new ResponseValidationError('AI response model field is missing');
    }
    if (!response.finishReason) {
      throw new ResponseValidationError('AI response finishReason field is missing');
    }

    // 2. Finish Reason Validation
    if (!FINISH_REASONS.includes(response.finishReason as typeof FINISH_REASONS[number])) {
      throw new InvalidFinishReasonError(`AI response returned invalid finish reason: ${response.finishReason}`);
    }

    // 3. Token Usage Validation
    const { promptTokens, completionTokens, totalTokens } = response.usage || {};
    if (promptTokens === undefined || promptTokens < 0) {
      throw new InvalidTokenUsageError(`Prompt tokens must be non-negative: ${promptTokens}`);
    }
    if (completionTokens === undefined || completionTokens < 0) {
      throw new InvalidTokenUsageError(`Completion tokens must be non-negative: ${completionTokens}`);
    }
    if (totalTokens !== promptTokens + completionTokens) {
      throw new InvalidTokenUsageError(
        `Total tokens (${totalTokens}) does not match prompt + completion tokens (${promptTokens + completionTokens})`
      );
    }

    // 4. Cost Validation
    const cost = response.cost;
    if (cost < 0 || isNaN(cost) || !isFinite(cost)) {
      throw new ResponseValidationError(`Cost validation failed: calculated cost is invalid (${cost})`);
    }

    // 5. Structured Output (JSON Schema) Validation
    if (responseSchema) {
      try {
        const parsed = JSON.parse(response.content);
        // Simple schema checks (in production, Ajv or custom validator)
        if (responseSchema.type === 'object' && responseSchema.required && Array.isArray(responseSchema.required)) {
          for (const reqProp of responseSchema.required) {
            if (!(reqProp in parsed)) {
              throw new StructuredOutputValidationError(
                `Structured output missing required property: ${reqProp}`
              );
            }
          }
        }
      } catch (err: unknown) {
        if (err instanceof StructuredOutputValidationError) {
          throw err;
        }
        const errMsg = err instanceof Error ? err.message : String(err);
        throw new StructuredOutputValidationError(`Structured output is not a valid JSON string: ${errMsg}`);
      }
    }
  }
}
export default ResponseValidator;
