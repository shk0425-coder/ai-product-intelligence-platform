export interface ScheduleDefinition {
  jobId: string;
  cronExpression?: string;
  intervalMs?: number;
  timezone: string;
  startDate?: string;
  endDate?: string;
  paused: boolean;
  nextRunTime?: number;
  lastRunTime?: number;
}

export class ScheduleRepository {
  private static readonly schedules = new Map<string, ScheduleDefinition>();

  static async save(schedule: ScheduleDefinition): Promise<void> {
    this.schedules.set(schedule.jobId, { ...schedule });
  }

  static async findByJobId(jobId: string): Promise<ScheduleDefinition | undefined> {
    const s = this.schedules.get(jobId);
    return s ? { ...s } : undefined;
  }

  static async findAll(): Promise<ScheduleDefinition[]> {
    return Array.from(this.schedules.values()).map(s => ({ ...s }));
  }

  static async delete(jobId: string): Promise<boolean> {
    return this.schedules.delete(jobId);
  }

  static clear(): void {
    this.schedules.clear();
  }
}
export default ScheduleRepository;
