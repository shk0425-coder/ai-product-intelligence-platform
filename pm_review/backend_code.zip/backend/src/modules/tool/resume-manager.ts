export interface WorkflowResumeHandler {
  resume(
    workflowId: string,
    executionId: string,
    snapshot: Record<string, unknown>
  ): Promise<void>;
}

export class WorkflowResumeManager {
  private static handler?: WorkflowResumeHandler;

  static registerHandler(h: WorkflowResumeHandler): void {
    this.handler = h;
  }

  static async resumeExecution(
    workflowId: string,
    executionId: string,
    snapshot: Record<string, unknown>
  ): Promise<void> {
    if (!this.handler) {
      throw new Error('Workflow Resume Handler is not registered in runtime environment');
    }
    await this.handler.resume(workflowId, executionId, snapshot);
  }
}
export default WorkflowResumeManager;
