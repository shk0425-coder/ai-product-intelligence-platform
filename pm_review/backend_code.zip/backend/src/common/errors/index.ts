export class AppError extends Error {
  constructor(
    public readonly statusCode: number,
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class ValidationError extends AppError {
  constructor(message: string = 'Validation failed') {
    super(400, 'VALIDATION_ERROR', message);
  }
}

export class AuthenticationError extends AppError {
  constructor(message: string = 'Authentication failed') {
    super(401, 'AUTHENTICATION_ERROR', message);
  }
}

export class DatabaseError extends AppError {
  constructor(message: string = 'Database operation failed') {
    super(500, 'DATABASE_ERROR', message);
  }
}

export class InternalServerError extends AppError {
  constructor(message: string = 'Internal server error') {
    super(500, 'INTERNAL_SERVER_ERROR', message);
  }
}

export class InvalidTokenError extends AppError {
  constructor(message: string = 'Invalid token') {
    super(401, 'AUTH_INVALID_TOKEN', message);
  }
}

export class ExpiredTokenError extends AppError {
  constructor(message: string = 'Token has expired') {
    super(401, 'AUTH_EXPIRED_TOKEN', message);
  }
}

export class InvalidCredentialsError extends AppError {
  constructor(message: string = 'Invalid email or password') {
    super(401, 'AUTH_INVALID_CREDENTIALS', message);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message: string = 'Unauthorized access') {
    super(401, 'AUTH_UNAUTHORIZED', message);
  }
}

export class WorkspaceNotFoundError extends AppError {
  constructor(message: string = 'Workspace not found') {
    super(404, 'WORKSPACE_NOT_FOUND', message);
  }
}

export class WorkspaceAlreadyExistsError extends AppError {
  constructor(message: string = 'Workspace name already exists') {
    super(409, 'WORKSPACE_ALREADY_EXISTS', message);
  }
}

export class WorkspaceForbiddenError extends AppError {
  constructor(message: string = 'Forbidden access to workspace') {
    super(403, 'WORKSPACE_FORBIDDEN', message);
  }
}

export class MarketNotFoundError extends AppError {
  constructor(message: string = 'Market metric not found') {
    super(404, 'MARKET_NOT_FOUND', message);
  }
}

export class MarketForbiddenError extends AppError {
  constructor(message: string = 'Forbidden access to market metric') {
    super(403, 'MARKET_FORBIDDEN', message);
  }
}

export class MarketMetricAlreadyExistsError extends AppError {
  constructor(message: string = 'Market metric already exists for this run') {
    super(409, 'MARKET_METRIC_ALREADY_EXISTS', message);
  }
}

export class AIResponseValidationError extends AppError {
  constructor(message: string = 'AI response validation failed') {
    super(422, 'AI_RESPONSE_VALIDATION_ERROR', message);
  }
}

export class NotFoundError extends AppError {
  constructor(message: string = 'Resource not found') {
    super(404, 'NOT_FOUND', message);
  }
}

export class PerformanceNotFoundError extends AppError {
  constructor(message: string = 'Performance metric not found') {
    super(404, 'PERFORMANCE_NOT_FOUND', message);
  }
}

export class DuplicatePerformanceError extends AppError {
  constructor(message: string = 'Performance metric already exists for this period') {
    super(409, 'DUPLICATE_PERFORMANCE', message);
  }
}

export class InvalidPerformanceDataError extends AppError {
  constructor(message: string = 'Invalid performance data provided') {
    super(422, 'INVALID_PERFORMANCE_DATA', message);
  }
}

export class InvalidDateRangeError extends AppError {
  constructor(
    message: string = 'Invalid date range: period_start must be less than or equal to period_end',
  ) {
    super(400, 'INVALID_DATE_RANGE', message);
  }
}

export class PerformanceValidationError extends AppError {
  constructor(message: string = 'Performance validation failed') {
    super(400, 'PERFORMANCE_VALIDATION_ERROR', message);
  }
}

export class FeedbackNotFoundError extends AppError {
  constructor(message: string = 'Feedback score not found') {
    super(404, 'FEEDBACK_NOT_FOUND', message);
  }
}

export class DuplicateFeedbackError extends AppError {
  constructor(message: string = 'Feedback score already calculated for this performance run') {
    super(409, 'DUPLICATE_FEEDBACK', message);
  }
}

export class InvalidFeedbackDataError extends AppError {
  constructor(message: string = 'Invalid feedback data provided') {
    super(422, 'INVALID_FEEDBACK_DATA', message);
  }
}

export class FeedbackValidationError extends AppError {
  constructor(message: string = 'Feedback validation failed') {
    super(400, 'FEEDBACK_VALIDATION_ERROR', message);
  }
}

export class FeedbackIntelligenceNotFoundError extends AppError {
  constructor(message: string = 'Feedback intelligence report not found') {
    super(404, 'FEEDBACK_INTELLIGENCE_NOT_FOUND', message);
  }
}

export class DuplicateFeedbackIntelligenceError extends AppError {
  constructor(
    message: string = 'Feedback intelligence report already generated for this feedback score',
  ) {
    super(409, 'DUPLICATE_FEEDBACK_INTELLIGENCE', message);
  }
}

export class InvalidFeedbackIntelligenceDataError extends AppError {
  constructor(message: string = 'Invalid feedback intelligence data provided') {
    super(422, 'INVALID_FEEDBACK_INTELLIGENCE_DATA', message);
  }
}

export class IntelligenceNotFoundError extends AppError {
  constructor(message: string = 'Feedback intelligence report not found') {
    super(404, 'INTELLIGENCE_NOT_FOUND', message);
  }
}

export class DuplicateLearningKnowledgeError extends AppError {
  constructor(message: string = 'Learning assets already generated for this version') {
    super(409, 'DUPLICATE_LEARNING_KNOWLEDGE', message);
  }
}

export class LearningKnowledgeNotFoundError extends AppError {
  constructor(message: string = 'Learning knowledge record not found') {
    super(404, 'LEARNING_KNOWLEDGE_NOT_FOUND', message);
  }
}

export class PromptValidationError extends AppError {
  constructor(message: string = 'Prompt validation failed due to missing sections') {
    super(400, 'PROMPT_VALIDATION_ERROR', message);
  }
}

export class PlannerExecutionError extends AppError {
  constructor(message: string = 'AI Planner strategy generation failed') {
    super(502, 'PLANNER_EXECUTION_ERROR', message);
  }
}

export class AutomationConflictError extends AppError {
  constructor(message: string = 'Automation process is already running or completed') {
    super(409, 'AUTOMATION_CONFLICT', message);
  }
}

export class AutomationRetryExceededError extends AppError {
  constructor(message: string = 'Maximum automation retry limit (3) exceeded') {
    super(429, 'AUTOMATION_RETRY_EXCEEDED', message);
  }
}

export class JobNotFoundError extends AppError {
  constructor(message: string = 'Job not found in queue') {
    super(404, 'JOB_NOT_FOUND', message);
  }
}

export class JobConflictError extends AppError {
  constructor(message: string = 'Job is already running or completed') {
    super(409, 'JOB_CONFLICT', message);
  }
}

export class JobLeaseExpiredError extends AppError {
  constructor(message: string = 'Job lease has expired or owner mismatch') {
    super(412, 'JOB_LEASE_EXPIRED', message);
  }
}

export class JobTimeoutError extends AppError {
  constructor(message: string = 'Job execution timed out') {
    super(408, 'JOB_TIMEOUT', message);
  }
}

export class RetryLimitExceededError extends AppError {
  constructor(message: string = 'Job retry limit exceeded') {
    super(429, 'RETRY_LIMIT_EXCEEDED', message);
  }
}

export class DeadLetterError extends AppError {
  constructor(message: string = 'Job has been routed to dead letter archive') {
    super(500, 'DEAD_LETTER_ERROR', message);
  }
}

export class ProviderNotFoundError extends AppError {
  constructor(message: string = 'AI Provider not found') {
    super(404, 'PROVIDER_NOT_FOUND', message);
  }
}

export class ProviderUnavailableError extends AppError {
  constructor(message: string = 'AI Provider is temporarily unavailable') {
    super(503, 'PROVIDER_UNAVAILABLE', message);
  }
}

export class ProviderCapabilityError extends AppError {
  constructor(message: string = 'AI Provider does not support requested capability') {
    super(400, 'PROVIDER_CAPABILITY_ERROR', message);
  }
}

export class ProviderTimeoutError extends AppError {
  constructor(message: string = 'AI Provider request timed out') {
    super(408, 'PROVIDER_TIMEOUT', message);
  }
}

export class ProviderAuthenticationError extends AppError {
  constructor(message: string = 'AI Provider authentication failed') {
    super(401, 'PROVIDER_AUTH_ERROR', message);
  }
}

export class ProviderValidationError extends AppError {
  constructor(message: string = 'AI Provider request validation failed') {
    super(400, 'PROVIDER_VALIDATION_ERROR', message);
  }
}

export class CircuitBreakerOpenError extends AppError {
  constructor(message: string = 'Circuit breaker is OPEN for this provider') {
    super(503, 'CIRCUIT_BREAKER_OPEN', message);
  }
}

export class RateLimitExceededError extends AppError {
  constructor(message: string = 'Rate limit exceeded for the selected provider') {
    super(429, 'RATE_LIMIT_EXCEEDED', message);
  }
}

export class FallbackFailedError extends AppError {
  constructor(message: string = 'All fallback providers failed to execute') {
    super(502, 'FALLBACK_FAILED', message);
  }
}

export class ResponseValidationError extends AppError {
  constructor(message: string = 'AI response validation failed') {
    super(422, 'RESPONSE_VALIDATION_ERROR', message);
  }
}

export class StructuredOutputValidationError extends AppError {
  constructor(message: string = 'AI structured output schema mismatch') {
    super(422, 'STRUCTURED_OUTPUT_VALIDATION_ERROR', message);
  }
}

export class InvalidTokenUsageError extends AppError {
  constructor(message: string = 'AI token usage integrity check failed') {
    super(422, 'INVALID_TOKEN_USAGE', message);
  }
}

export class InvalidFinishReasonError extends AppError {
  constructor(message: string = 'AI provider returned invalid finish reason') {
    super(422, 'INVALID_FINISH_REASON', message);
  }
}


