export interface CacheMetricsEntry {
  cache_provider: string;
  namespace: string;
  workspace_id: string;
  hitCount: number;
  missCount: number;
}

export interface EventMetricsEntry {
  event_type: string;
  workspace_id: string;
  publishes: number;
  receives: number;
  retry_count: number;
  result: 'success' | 'failure' | 'pending';
}

export class MetricsCollector {
  private static readonly cacheMetrics = new Map<string, CacheMetricsEntry>();
  private static readonly eventMetrics = new Map<string, EventMetricsEntry>();
  private static lockWaitCount = 0;
  private static lockAcquireCount = 0;
  private static lockReleaseSuccessCount = 0;
  private static lockReleaseFailureCount = 0;
  private static dlqCount = 0;

  static recordCacheHit(cacheProvider: string, namespace: string, workspaceId: string): void {
    const key = `${cacheProvider}:${namespace}:${workspaceId}`;
    const existing = this.cacheMetrics.get(key) || {
      cache_provider: cacheProvider,
      namespace,
      workspace_id: workspaceId,
      hitCount: 0,
      missCount: 0,
    };
    existing.hitCount++;
    this.cacheMetrics.set(key, existing);
  }

  static recordCacheMiss(cacheProvider: string, namespace: string, workspaceId: string): void {
    const key = `${cacheProvider}:${namespace}:${workspaceId}`;
    const existing = this.cacheMetrics.get(key) || {
      cache_provider: cacheProvider,
      namespace,
      workspace_id: workspaceId,
      hitCount: 0,
      missCount: 0,
    };
    existing.missCount++;
    this.cacheMetrics.set(key, existing);
  }

  static recordEventPublish(eventType: string, workspaceId: string): void {
    const key = `${eventType}:${workspaceId}`;
    const existing = this.eventMetrics.get(key) || {
      event_type: eventType,
      workspace_id: workspaceId,
      publishes: 0,
      receives: 0,
      retry_count: 0,
      result: 'pending',
    };
    existing.publishes++;
    this.eventMetrics.set(key, existing);
  }

  static recordEventReceive(eventType: string, workspaceId: string): void {
    const key = `${eventType}:${workspaceId}`;
    const existing = this.eventMetrics.get(key) || {
      event_type: eventType,
      workspace_id: workspaceId,
      publishes: 0,
      receives: 0,
      retry_count: 0,
      result: 'pending',
    };
    existing.receives++;
    this.eventMetrics.set(key, existing);
  }

  static recordRetryCount(eventType: string, retryCount: number, workspaceId: string): void {
    const key = `${eventType}:${workspaceId}`;
    const existing = this.eventMetrics.get(key) || {
      event_type: eventType,
      workspace_id: workspaceId,
      publishes: 0,
      receives: 0,
      retry_count: 0,
      result: 'pending',
    };
    existing.retry_count = retryCount;
    this.eventMetrics.set(key, existing);
  }

  static recordEventResult(eventType: string, result: 'success' | 'failure', workspaceId: string): void {
    const key = `${eventType}:${workspaceId}`;
    const existing = this.eventMetrics.get(key) || {
      event_type: eventType,
      workspace_id: workspaceId,
      publishes: 0,
      receives: 0,
      retry_count: 0,
      result: 'pending',
    };
    existing.result = result;
    this.eventMetrics.set(key, existing);
  }

  static recordLockWait(_lockKey: string): void {
    this.lockWaitCount++;
  }

  static recordLockAcquire(_lockKey: string): void {
    this.lockAcquireCount++;
  }

  static recordLockRelease(_lockKey: string, result: 'success' | 'failure'): void {
    if (result === 'success') {
      this.lockReleaseSuccessCount++;
    } else {
      this.lockReleaseFailureCount++;
    }
  }

  static recordDlqCount(_eventType: string, _workspaceId: string): void {
    this.dlqCount++;
  }

  static getSummary() {
    return {
      cache: Array.from(this.cacheMetrics.values()),
      events: Array.from(this.eventMetrics.values()),
      locks: {
        waits: this.lockWaitCount,
        acquires: this.lockAcquireCount,
        releasesSuccess: this.lockReleaseSuccessCount,
        releasesFailure: this.lockReleaseFailureCount,
      },
      dlq: {
        totalCount: this.dlqCount,
      },
    };
  }

  static clear(): void {
    this.cacheMetrics.clear();
    this.eventMetrics.clear();
    this.lockWaitCount = 0;
    this.lockAcquireCount = 0;
    this.lockReleaseSuccessCount = 0;
    this.lockReleaseFailureCount = 0;
    this.dlqCount = 0;
  }
}
