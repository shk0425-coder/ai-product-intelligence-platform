import { MetricsRegistry } from '../../observability/metrics/registry.js';

export class MaintenanceManager {
  private static active = false;
  private static readOnlyMode = false;

  static startMaintenance(readOnly = false): void {
    this.active = true;
    this.readOnlyMode = readOnly;
    MetricsRegistry.counter('maintenance_total', 1, { mode: readOnly ? 'ReadOnly' : 'Drain' });
  }

  static stopMaintenance(): void {
    this.active = false;
    this.readOnlyMode = false;
  }

  static isReadOnly(): boolean {
    return this.active && this.readOnlyMode;
  }

  static isMaintenanceActive(): boolean {
    return this.active;
  }

  static clear(): void {
    this.active = false;
    this.readOnlyMode = false;
  }
}
export default MaintenanceManager;
