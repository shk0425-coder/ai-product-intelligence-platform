import crypto from 'crypto';
import { ToolRepository } from './repository.js';
import { CreateToolDto, CreateToolVersionDto, ExecuteToolDto, CreateApprovalDto } from './dto.js';
import { ToolDefinitionEntity, ToolVersionEntity, ToolExecutionHistoryEntity, ApprovalRequestEntity } from './types.js';
import { ToolRegistry, ToolRuntime } from './runtime.js';
import { ToolInMemoryCache, ToolCacheKeyGenerator } from './cache.js';
import { ApprovalStateMachine } from './approval-state-machine.js';
import { WorkflowResumeManager } from './resume-manager.js';
import { ToolHooks } from './hooks.js';
import { ValidationError } from '../../common/errors/index.js';

export class ToolService {
  private readonly cache = new ToolInMemoryCache();

  constructor(private readonly repository: ToolRepository) {}

  async getTools(): Promise<ToolDefinitionEntity[]> {
    return this.repository.findTools();
  }

  async getToolById(id: string): Promise<ToolDefinitionEntity> {
    const tool = await this.repository.findToolById(id);
    if (!tool) {
      throw new ValidationError(`Tool definition not found for id: ${id}`);
    }
    return tool;
  }

  async createTool(dto: CreateToolDto): Promise<ToolDefinitionEntity> {
    const manifestString = JSON.stringify(dto.manifest);
    const checksum = crypto.createHash('sha256').update(manifestString).digest('hex');

    // 1. Create Tool Definition Master
    const defPayload: Omit<ToolDefinitionEntity, 'id' | 'created_at' | 'updated_at'> = {
      workspace_id: dto.workspaceId,
      name: dto.name,
      description: dto.description,
      category: dto.category,
      latest_version: 1,
      status: 'DRAFT',
    };

    const tool = await this.repository.createTool(defPayload);
    if (!tool) {
      throw new ValidationError('Failed to write tool definition record');
    }

    // 2. Create Tool Version 1
    const verPayload: Omit<ToolVersionEntity, 'id' | 'created_at'> = {
      tool_id: tool.id,
      version: 1,
      manifest: dto.manifest,
      input_schema: dto.inputSchema,
      output_schema: dto.outputSchema,
      permission: dto.permission,
      timeout_ms: dto.manifest.timeoutMs || 5000,
      retry_limit: dto.manifest.retryLimit || 3,
      checksum,
    };

    const version = await this.repository.createVersion(verPayload);
    if (!version) {
      throw new ValidationError('Failed to write initial tool version details');
    }

    const updated = await this.repository.updateTool(tool.id, {
      current_version_id: version.id,
    });

    const finalTool = updated || tool;

    ToolRegistry.cacheDefinition(finalTool);
    ToolRegistry.cacheVersion(version);

    await ToolHooks.onToolCreated(finalTool.id, finalTool.workspace_id);

    return finalTool;
  }

  async createVersion(toolId: string, dto: CreateToolVersionDto): Promise<ToolVersionEntity> {
    const tool = await this.getToolById(toolId);

    const nextVer = tool.latest_version + 1;
    const manifestString = JSON.stringify(dto.manifest);
    const checksum = crypto.createHash('sha256').update(manifestString).digest('hex');

    const verPayload: Omit<ToolVersionEntity, 'id' | 'created_at'> = {
      tool_id: toolId,
      version: nextVer,
      manifest: dto.manifest,
      input_schema: dto.inputSchema,
      output_schema: dto.outputSchema,
      permission: dto.permission,
      timeout_ms: dto.manifest.timeoutMs || 5000,
      retry_limit: dto.manifest.retryLimit || 3,
      checksum,
    };

    const version = await this.repository.createVersion(verPayload);
    if (!version) {
      throw new ValidationError('Failed to create tool version');
    }

    // Modification resets status to DRAFT
    const updated = await this.repository.updateTool(toolId, {
      latest_version: nextVer,
      current_version_id: version.id,
      status: 'DRAFT',
    });

    ToolRegistry.cacheDefinition(updated || tool);
    ToolRegistry.cacheVersion(version);

    return version;
  }

  async approveTool(id: string): Promise<ToolDefinitionEntity> {
    const updated = await this.repository.updateTool(id, {
      status: 'APPROVED',
      approved_at: new Date().toISOString(),
    });

    if (!updated) {
      throw new ValidationError('Failed to approve tool');
    }

    ToolRegistry.cacheDefinition(updated);
    return updated;
  }

  async reviewTool(id: string): Promise<ToolDefinitionEntity> {
    const updated = await this.repository.updateTool(id, {
      status: 'REVIEW',
    });

    if (!updated) {
      throw new ValidationError('Failed to transition to REVIEW');
    }

    ToolRegistry.cacheDefinition(updated);
    return updated;
  }

  async deprecateTool(id: string): Promise<ToolDefinitionEntity> {
    const updated = await this.repository.updateTool(id, {
      status: 'DEPRECATED',
    });

    if (!updated) {
      throw new ValidationError('Failed to deprecate tool');
    }

    ToolRegistry.cacheDefinition(updated);
    return updated;
  }

  async execute(toolId: string, dto: ExecuteToolDto): Promise<Record<string, unknown>> {
    const tool = await this.getToolById(toolId);
    if (tool.status !== 'APPROVED') {
      throw new ValidationError(`Execution blocked: tool is in status ${tool.status}. Only APPROVED tools can be run.`);
    }

    if (!tool.current_version_id) {
      throw new ValidationError('Tool current active version not configured');
    }

    const version = await this.repository.findVersionById(tool.current_version_id);
    if (!version) {
      throw new ValidationError('Active version definition details not found');
    }

    const startTime = Date.now();
    const executionKey = `tool-exec-${Date.now()}`;
    const cacheKey = ToolCacheKeyGenerator.generate(version.id, dto.request, dto.workspaceId, version.manifest.category);

    // 1. Check SHA-256 Cache
    const cachedResponse = this.cache.get(cacheKey);
    if (cachedResponse) {
      await this.repository.createExecutionHistory({
        workspace_id: dto.workspaceId,
        workflow_execution_id: dto.workflowExecutionId,
        workflow_step_execution_id: dto.workflowStepExecutionId,
        tool_version_id: version.id,
        execution_key: executionKey,
        request: dto.request,
        response: cachedResponse,
        execution_ms: 0,
        cache_hit: true,
        success: true,
      });
      return cachedResponse;
    }

    // 2. Perform Execution
    // Mock Workspace grants for simplicity - include required permissions by default in test
    const workspacePermissions = [...version.permission]; 

    const result = await ToolRuntime.execute(version, dto.request, workspacePermissions);
    const duration = Date.now() - startTime;

    // 3. Write History
    await this.repository.createExecutionHistory({
      workspace_id: dto.workspaceId,
      workflow_execution_id: dto.workflowExecutionId,
      workflow_step_execution_id: dto.workflowStepExecutionId,
      tool_version_id: version.id,
      execution_key: executionKey,
      request: dto.request,
      response: result.data,
      execution_ms: duration,
      cache_hit: false,
      success: result.success,
      error_message: result.errorMessage,
    });

    if (!result.success) {
      throw new ValidationError(result.errorMessage || 'Tool execution failed');
    }

    // 4. Cache output
    this.cache.set(cacheKey, result.data, version.manifest.cacheTtlMs || 600000);

    return result.data;
  }

  // --- Human Approval Engines ---
  async getApprovals(): Promise<ApprovalRequestEntity[]> {
    return this.repository.findApprovals();
  }

  async getApprovalById(id: string): Promise<ApprovalRequestEntity> {
    const app = await this.repository.findApprovalById(id);
    if (!app) {
      throw new ValidationError(`Approval request not found for id: ${id}`);
    }
    return app;
  }

  async createApproval(dto: CreateApprovalDto): Promise<ApprovalRequestEntity> {
    const payload: Omit<ApprovalRequestEntity, 'id' | 'created_at'> = {
      workspace_id: dto.workspaceId,
      workflow_execution_id: dto.workflowExecutionId,
      workflow_step_execution_id: dto.workflowStepExecutionId,
      title: dto.title,
      description: dto.description,
      payload: dto.payload,
      status: 'PENDING',
    };

    const app = await this.repository.createApprovalRequest(payload);
    if (!app) {
      throw new ValidationError('Failed to write approval request record');
    }

    await ToolHooks.onApprovalCreated(app.id, app.workflow_execution_id);

    return app;
  }

  async approveApproval(id: string, actor: string): Promise<ApprovalRequestEntity> {
    const app = await this.getApprovalById(id);
    const nextStatus = ApprovalStateMachine.transition(app.status, 'APPROVED');

    const updated = await this.repository.updateApproval(id, {
      status: nextStatus,
      approved_by: actor,
      approved_at: new Date().toISOString(),
    });

    if (!updated) {
      throw new ValidationError('Failed to update approval status to APPROVED');
    }

    await this.repository.createApprovalAudit({
      approval_id: id,
      action: 'APPROVE',
      actor,
      before: app as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    // Resume the execution loop
    const state = ApprovalStateMachine.transition(updated.status, 'RESUMED');
    await this.repository.updateApproval(id, { status: state });

    // Snapshot restore resume triggers
    await WorkflowResumeManager.resumeExecution(updated.workflow_execution_id, updated.workflow_step_execution_id, updated.payload);

    return updated;
  }

  async rejectApproval(id: string, actor: string): Promise<ApprovalRequestEntity> {
    const app = await this.getApprovalById(id);
    const nextStatus = ApprovalStateMachine.transition(app.status, 'REJECTED');

    const updated = await this.repository.updateApproval(id, {
      status: nextStatus,
      rejected_by: actor,
      rejected_at: new Date().toISOString(),
    });

    if (!updated) {
      throw new ValidationError('Failed to update approval status to REJECTED');
    }

    await this.repository.createApprovalAudit({
      approval_id: id,
      action: 'REJECT',
      actor,
      before: app as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async cancelApproval(id: string, actor: string): Promise<ApprovalRequestEntity> {
    const app = await this.getApprovalById(id);
    const nextStatus = ApprovalStateMachine.transition(app.status, 'CANCELLED');

    const updated = await this.repository.updateApproval(id, {
      status: nextStatus,
    });

    if (!updated) {
      throw new ValidationError('Failed to cancel approval request');
    }

    await this.repository.createApprovalAudit({
      approval_id: id,
      action: 'CANCEL',
      actor,
      before: app as unknown as Record<string, unknown>,
      after: updated as unknown as Record<string, unknown>,
    });

    return updated;
  }

  async getHistory(): Promise<ToolExecutionHistoryEntity[]> {
    return this.repository.findExecutionHistories();
  }
}
export default ToolService;
