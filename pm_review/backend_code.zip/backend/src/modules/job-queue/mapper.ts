import { JobQueueEntity } from './types.js';
import { JobQueueDto } from './dto.js';

export const JobQueueMapper = {
  toDto(entity: JobQueueEntity): JobQueueDto {
    return {
      jobId: entity.id,
      workspaceId: entity.workspace_id,
      jobType: entity.job_type,
      priority: entity.priority,
      payload: entity.payload,
      payloadVersion: entity.payload_version,
      status: entity.status,
      retryCount: entity.retry_count,
      maxRetry: entity.max_retry,
      leaseOwner: entity.lease_owner,
      leaseUntil: entity.lease_until,
      heartbeatAt: entity.heartbeat_at,
      cancelRequested: entity.cancel_requested,
      scheduledAt: entity.scheduled_at,
      startedAt: entity.started_at,
      completedAt: entity.completed_at,
      errorMessage: entity.error_message,
      createdAt: entity.created_at,
      updatedAt: entity.updated_at,
    };
  },

  toDtoList(entities: JobQueueEntity[]): JobQueueDto[] {
    return entities.map((entity) => this.toDto(entity));
  },
};
