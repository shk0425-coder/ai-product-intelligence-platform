import { JobDefinition, JobRepository } from '../persistence/job-repository.js';
import { ScheduleDefinition, ScheduleRepository } from '../persistence/schedule-repository.js';
import { JobExecution, ExecutionRepository } from '../persistence/execution-repository.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export interface SchedulerSnapshot {
  timestamp: number;
  jobs: JobDefinition[];
  schedules: ScheduleDefinition[];
  executions: JobExecution[];
  checksum: string;
}

export class SnapshotManager {
  private static snapshots: SchedulerSnapshot[] = [];

  static async createSnapshot(): Promise<SchedulerSnapshot> {
    const jobs = await JobRepository.findAll();
    const schedules = await ScheduleRepository.findAll();
    const executions = await ExecutionRepository.getHistory();

    const payload = JSON.stringify({ jobs, schedules, executions });
    const checksum = crypto.createHash('sha256').update(payload).digest('hex');

    const snapshot: SchedulerSnapshot = {
      timestamp: Date.now(),
      jobs,
      schedules,
      executions,
      checksum,
    };

    this.snapshots.push(snapshot);
    MetricsRegistry.counter('scheduler_snapshot_total', 1);

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'SchedulerSnapshotCreated',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { checksum, timestamp: snapshot.timestamp },
    }).catch(() => {});

    return snapshot;
  }

  static async restoreSnapshot(snapshot: SchedulerSnapshot): Promise<boolean> {
    // Validate checksum integrity
    const payload = JSON.stringify({
      jobs: snapshot.jobs,
      schedules: snapshot.schedules,
      executions: snapshot.executions,
    });
    const checksum = crypto.createHash('sha256').update(payload).digest('hex');

    if (checksum !== snapshot.checksum) {
      return false; // Checksum mismatched, refuse restore
    }

    // Clear and restore states
    JobRepository.clear();
    ScheduleRepository.clear();
    ExecutionRepository.clear();

    for (const j of snapshot.jobs) {
      await JobRepository.save(j);
    }
    for (const s of snapshot.schedules) {
      await ScheduleRepository.save(s);
    }
    for (const e of snapshot.executions) {
      await ExecutionRepository.save(e);
    }

    return true;
  }

  static getSnapshotsCount(): number {
    return this.snapshots.length;
  }

  static clear(): void {
    this.snapshots = [];
  }
}
export default SnapshotManager;
