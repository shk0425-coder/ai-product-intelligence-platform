import { ObservabilityContext } from '../context/context-manager.js';

export class TraceContext {
  static serialize(context: ObservabilityContext): string {
    return JSON.stringify({
      traceId: context.traceId,
      spanId: context.spanId,
      correlationId: context.correlationId,
      workspaceId: context.workspaceId,
      userId: context.userId,
      workflowId: context.workflowId,
    });
  }

  static deserialize(serialized: string): ObservabilityContext | null {
    try {
      const parsed = JSON.parse(serialized);
      return {
        traceId: parsed.traceId,
        spanId: parsed.spanId,
        correlationId: parsed.correlationId,
        workspaceId: parsed.workspaceId,
        userId: parsed.userId,
        workflowId: parsed.workflowId,
      };
    } catch {
      return null;
    }
  }
}
