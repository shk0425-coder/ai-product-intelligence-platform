import { AuditTrail, AuditRecord } from '../../resilience/audit/audit-trail.js';
import { MetricsRegistry } from '../../observability/metrics/registry.js';

export interface AuditQueryFilter {
  severity?: string;
  action?: string;
  workspaceId?: string;
  fromTimestamp?: number;
  toTimestamp?: number;
}

export class AuditCenter {
  static searchLogs(filter: AuditQueryFilter): AuditRecord[] {
    MetricsRegistry.counter('audit_query_total', 1);
    
    let logs = AuditTrail.getLogs();

    if (filter.action) {
      logs = logs.filter(l => l.action.includes(filter.action!));
    }
    if (filter.fromTimestamp) {
      logs = logs.filter(l => l.timestamp >= filter.fromTimestamp!);
    }
    if (filter.toTimestamp) {
      logs = logs.filter(l => l.timestamp <= filter.toTimestamp!);
    }

    return logs;
  }

  static getTimeline(): string[] {
    const logs = AuditTrail.getLogs();
    // Order timeline chronological
    return logs.map(l => l.action);
  }

  static exportLogs(filter: AuditQueryFilter, format: 'JSON' | 'CSV'): string {
    MetricsRegistry.counter('audit_export_total', 1, { format });
    const logs = this.searchLogs(filter);

    if (format === 'JSON') {
      return JSON.stringify(logs, null, 2);
    }

    // CSV serialization format
    let csv = 'logId,action,timestamp,hash\n';
    for (const log of logs) {
      csv += `"${log.logId}","${log.action.replace(/"/g, '""')}",${log.timestamp},"${log.hash}"\n`;
    }
    return csv;
  }

  static enforceRetention(retentionDays: number): number {
    const threshold = Date.now() - retentionDays * 24 * 60 * 60 * 1000;
    const logs = AuditTrail.getLogs();
    
    const kept = logs.filter(l => l.timestamp >= threshold);
    const deletedCount = logs.length - kept.length;

    // Synchronize to AuditTrail
    AuditTrail.clear();
    for (const log of kept) {
      // Direct push for retention pruning simulation
      (AuditTrail as unknown as { logs: AuditRecord[] }).logs.push(log);
    }

    return deletedCount;
  }
}
export default AuditCenter;
