import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export type IncidentSeverity = 'Critical' | 'High' | 'Normal' | 'Low';

export interface Incident {
  id: string;
  source: string;
  severity: IncidentSeverity;
  state: 'Open' | 'Resolved';
  detectedAt: number;
  classifiedAt?: number;
  recoveredAt?: number;
  resolvedAt?: number;
  rootCause?: string;
  timeline: { action: string; timestamp: number }[];
}

export class IncidentManager {
  private static readonly incidents = new Map<string, Incident>();
  private static totalMttrSum = 0;
  private static totalMttdSum = 0;
  private static resolvedCount = 0;

  static async createIncident(source: string, severity: IncidentSeverity): Promise<Incident> {
    const now = Date.now();
    const incident: Incident = {
      id: `inc_${crypto.randomUUID().slice(0, 8)}`,
      source,
      severity,
      state: 'Open',
      detectedAt: now,
      timeline: [{ action: 'Incident Detected', timestamp: now }],
    };

    this.incidents.set(incident.id, incident);
    MetricsRegistry.counter('incident_total', 1, { source });
    MetricsRegistry.gauge('incident_open', this.getOpenIncidentsCount());

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'IncidentCreated',
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { incidentId: incident.id, source, severity },
    }).catch(() => {});

    return incident;
  }

  static async classifyIncident(id: string, rootCause: string): Promise<void> {
    const inc = this.incidents.get(id);
    if (inc) {
      inc.classifiedAt = Date.now();
      inc.rootCause = rootCause;
      inc.timeline.push({ action: `Incident Classified: ${rootCause}`, timestamp: inc.classifiedAt });
      
      const mttd = inc.classifiedAt - inc.detectedAt;
      this.totalMttdSum += mttd;
      MetricsRegistry.gauge('incident_mttd', this.totalMttdSum / (this.incidents.size || 1));

      eventBus.publish({
        eventId: crypto.randomUUID(),
        eventType: 'IncidentUpdated',
        timestamp: new Date().toISOString(),
        workspaceId: 'default-workspace',
        data: { incidentId: id, rootCause, mttdMs: mttd },
      }).catch(() => {});
    }
  }

  static async resolveIncident(id: string): Promise<void> {
    const inc = this.incidents.get(id);
    if (inc && inc.state === 'Open') {
      inc.state = 'Resolved';
      inc.resolvedAt = Date.now();
      inc.timeline.push({ action: 'Incident Resolved', timestamp: inc.resolvedAt });

      this.resolvedCount++;
      const mttr = inc.resolvedAt - inc.detectedAt;
      this.totalMttrSum += mttr;
      MetricsRegistry.gauge('incident_mttr', this.totalMttrSum / this.resolvedCount);
      MetricsRegistry.gauge('incident_open', this.getOpenIncidentsCount());
      MetricsRegistry.gauge('incident_closed', this.resolvedCount);

      eventBus.publish({
        eventId: crypto.randomUUID(),
        eventType: 'IncidentResolved',
        timestamp: new Date().toISOString(),
        workspaceId: 'default-workspace',
        data: { incidentId: id, mttrMs: mttr },
      }).catch(() => {});
    }
  }

  static getOpenIncidentsCount(): number {
    return Array.from(this.incidents.values()).filter(i => i.state === 'Open').length;
  }

  static findById(id: string): Incident | undefined {
    return this.incidents.get(id);
  }

  static findAll(): Incident[] {
    return Array.from(this.incidents.values());
  }

  static clear(): void {
    this.incidents.clear();
    this.totalMttrSum = 0;
    this.totalMttdSum = 0;
    this.resolvedCount = 0;
  }
}
export default IncidentManager;
