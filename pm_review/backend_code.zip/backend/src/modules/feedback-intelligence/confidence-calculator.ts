export const ConfidenceCalculator = {
  calculate(
    performance: Record<string, unknown> | null | undefined,
    metrics: Record<string, unknown> | null | undefined,
  ): number {
    let missingCount = 0;

    const requiredPerformanceFields = [
      'sales_count',
      'review_score',
      'conversion_score',
      'favorite_count',
      'refund_count',
    ];

    const requiredMetricsFields = ['ctr', 'roi', 'profit'];

    for (const f of requiredPerformanceFields) {
      if (
        performance === undefined ||
        performance === null ||
        performance[f] === undefined ||
        performance[f] === null
      ) {
        missingCount++;
      }
    }

    for (const f of requiredMetricsFields) {
      if (
        metrics === undefined ||
        metrics === null ||
        metrics[f] === undefined ||
        metrics[f] === null
      ) {
        missingCount++;
      }
    }

    // Confidence starts at 100.0, deducts 15.0 points for each missing metric field, capped lower bound at 0.0
    return Math.max(0.0, 100.0 - missingCount * 15.0);
  },
};
export default ConfidenceCalculator;
