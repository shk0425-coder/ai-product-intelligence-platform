import { AppEventPayload, EventRegistry, EventType } from './event-registry.js';
import { DeadLetterQueue } from './dead-letter-queue.js';
import { MetricsCollector } from '../monitoring/metrics-service.js';

export interface EventBus {
  publish(event: AppEventPayload): Promise<void>;
  subscribe(type: EventType, handler: (event: AppEventPayload) => Promise<void>, version?: number): void;
  unsubscribe(type: EventType, handler: (event: AppEventPayload) => Promise<void>): void;
}

export class DistributedEventBus implements EventBus {
  private readonly handlers = new Map<EventType, { handler: (event: AppEventPayload) => Promise<void>; version?: number }[]>();
  private readonly idempotencyCache = new Set<string>(); // EventId cache
  private readonly lastSequenceMap = new Map<string, number>(); // workflowId -> lastSequenceNumber
  private readonly workflowQueues = new Map<string, Promise<unknown>>(); // workflowId -> Promise chain for FIFO execution
  private isShutdown = false;
  private readonly inFlightOperations = new Set<Promise<unknown>>();

  // Set the shutdown flag to reject new incoming events
  shutdown(): void {
    this.isShutdown = true;
  }

  async getInFlightCount(): Promise<number> {
    return this.inFlightOperations.size;
  }

  async waitInFlight(timeoutMs: number): Promise<boolean> {
    if (this.inFlightOperations.size === 0) return true;
    
    const timeoutPromise = new Promise<boolean>((resolve) => setTimeout(() => resolve(false), timeoutMs));
    const allDonePromise = Promise.all(Array.from(this.inFlightOperations)).then(() => true);

    return Promise.race([allDonePromise, timeoutPromise]);
  }

  async publish(event: AppEventPayload): Promise<void> {
    if (this.isShutdown) {
      throw new Error('EventBus is shutting down. Rejecting new publish requests.');
    }

    EventRegistry.validate(event);
    MetricsCollector.recordEventPublish(event.eventType, event.workspaceId);

    // Event Idempotency Check
    if (this.idempotencyCache.has(event.eventId)) {
      // Event already processed - skip duplicate execution
      return;
    }
    this.idempotencyCache.add(event.eventId);
    // Auto-expiry TTL (10 minutes)
    setTimeout(() => this.idempotencyCache.delete(event.eventId), 600000);

    // Event Ordering Check (Out-of-order drop)
    const workflowId = event.data?.workflowId as string;
    if (workflowId && event.eventSequenceNumber !== undefined) {
      const lastSeq = this.lastSequenceMap.get(workflowId) || 0;
      if (event.eventSequenceNumber <= lastSeq) {
        // Out-of-order event detected. Dropping.
        return;
      }
      this.lastSequenceMap.set(workflowId, event.eventSequenceNumber);
    }

    const subs = this.handlers.get(event.eventType) || [];
    
    // Version Routing filter
    const matchingSubs = subs.filter(sub => {
      if (sub.version === undefined) return true; // Backward compatibility
      return sub.version === event.event_version;
    });

    for (const sub of matchingSubs) {
      const executeFn = async () => {
        await this.dispatchEventWithRetry(event, sub.handler);
      };

      let opPromise: Promise<unknown>;
      if (workflowId) {
        // FIFO queue serialization per workflowId
        const prevPromise = this.workflowQueues.get(workflowId) || Promise.resolve();
        opPromise = prevPromise.then(executeFn).catch(() => {}); // continue chain even if fail
        this.workflowQueues.set(workflowId, opPromise);
        await opPromise; // Await execution to preserve deterministic tests & sequential execution timing
      } else {
        opPromise = executeFn();
      }

      this.inFlightOperations.add(opPromise);
      opPromise.finally(() => this.inFlightOperations.delete(opPromise));
    }
  }

  private async dispatchEventWithRetry(
    event: AppEventPayload,
    handler: (event: AppEventPayload) => Promise<void>
  ): Promise<void> {
    let attempt = 0;
    const maxAttempts = 3;

    while (attempt < maxAttempts) {
      try {
        MetricsCollector.recordEventReceive(event.eventType, event.workspaceId);
        await handler(event);
        MetricsCollector.recordEventResult(event.eventType, 'success', event.workspaceId);
        return; // Success
      } catch (err) {
        attempt++;
        MetricsCollector.recordRetryCount(event.eventType, attempt, event.workspaceId);
        if (attempt >= maxAttempts) {
          MetricsCollector.recordEventResult(event.eventType, 'failure', event.workspaceId);
          // Push to Dead Letter Queue (DLQ)
          await DeadLetterQueue.push(event, (err as Error).message, attempt);
          return;
        }
        // Exponential Backoff: 10ms, 20ms (fast delays for local test runs)
        const delay = Math.pow(2, attempt) * 5;
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  subscribe(type: EventType, handler: (event: AppEventPayload) => Promise<void>, version?: number): void {
    const list = this.handlers.get(type) || [];
    list.push({ handler, version });
    this.handlers.set(type, list);
  }

  unsubscribe(type: EventType, handler: (event: AppEventPayload) => Promise<void>): void {
    const list = this.handlers.get(type) || [];
    const idx = list.findIndex(sub => sub.handler === handler);
    if (idx !== -1) {
      list.splice(idx, 1);
    }
    this.handlers.set(type, list);
  }

  clearIdempotencyCache(): void {
    this.idempotencyCache.clear();
  }

  clearHandlers(): void {
    this.handlers.clear();
  }
}

export const eventBus = new DistributedEventBus();
export default eventBus;
