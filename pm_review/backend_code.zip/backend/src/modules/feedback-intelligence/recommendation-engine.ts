import { FeedbackRule } from './rules.js';

export interface Recommendation {
  priority: number;
  category: string;
  recommendation: string;
  expectedImpact: number;
}

export interface RecommendationResult {
  recommendations: Recommendation[];
  improvementSummary: string;
}

export const RecommendationEngine = {
  generate(matchedRules: FeedbackRule[]): RecommendationResult {
    const recommendations: Recommendation[] = matchedRules.map((rule) => {
      // Calculate expected impact score out of 100 based on severity
      const expectedImpact = rule.severity * 20.0; // 5 -> 100%, 4 -> 80%

      return {
        priority: rule.priority,
        category: rule.category,
        recommendation: rule.recommendation,
        expectedImpact,
      };
    });

    // Sort by priority (lower is higher priority)
    recommendations.sort((a, b) => a.priority - b.priority);

    let improvementSummary = '현재 추가적인 제품 기획/마케팅 개선 조치 권장안이 없습니다.';
    if (recommendations.length > 0) {
      improvementSummary = `최우선 개선 조치 권장안 [${recommendations[0].category}]: ${recommendations[0].recommendation}`;
    }

    return {
      recommendations,
      improvementSummary,
    };
  },
};
export default RecommendationEngine;
