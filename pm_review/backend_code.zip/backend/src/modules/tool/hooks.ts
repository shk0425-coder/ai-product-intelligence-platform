export class ToolHooks {
  static async onToolCreated(_toolId: string, _workspaceId: string): Promise<void> {
    // Triggers when a new tool definition is written
  }

  static async onApprovalCreated(_approvalId: string, _executionId: string): Promise<void> {
    // Triggers when approval request is queued
  }
}
export default ToolHooks;
