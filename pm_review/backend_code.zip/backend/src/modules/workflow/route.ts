import { FastifyInstance } from 'fastify';
import { WorkflowController } from './controller.js';
import { WorkflowService } from './service.js';
import { WorkflowRepository } from './repository.js';
import { PromptRepository } from '../prompt/repository.js';
import { PromptService } from '../prompt/service.js';
import { AIGateway } from '../ai-provider/gateway.js';
import { AIProviderRepository } from '../ai-provider/repository.js';
import { supabase } from '@/config/supabase.js';

export async function workflowRoutes(fastify: FastifyInstance) {
  const repository = new WorkflowRepository(supabase);
  
  const providerRepo = new AIProviderRepository(supabase);
  const gateway = new AIGateway(providerRepo);

  const promptRepo = new PromptRepository(supabase);
  const promptService = new PromptService(promptRepo, gateway);

  const service = new WorkflowService(repository, promptService);
  const controller = new WorkflowController(service);

  // Workflow CRUD
  fastify.get('/', (req, rep) => controller.getWorkflows(req, rep));
  fastify.post('/', (req, rep) =>
    controller.createWorkflow(
      req as import('fastify').FastifyRequest<{ Body: import('./dto.js').CreateWorkflowDto }>,
      rep
    )
  );
  fastify.get('/:id', (req, rep) =>
    controller.getWorkflowById(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );

  // Versions
  fastify.post('/:id/versions', (req, rep) =>
    controller.createVersion(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: import('./dto.js').CreateWorkflowVersionDto }>,
      rep
    )
  );
  fastify.get('/:id/versions', (req, rep) =>
    controller.getVersions(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );

  // Status transitions
  fastify.post('/:id/approve', (req, rep) =>
    controller.approveWorkflow(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );
  fastify.post('/:id/review', (req, rep) =>
    controller.reviewWorkflow(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );
  fastify.post('/:id/deprecate', (req, rep) =>
    controller.deprecateWorkflow(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );
  fastify.post('/:id/rollback', (req, rep) =>
    controller.rollbackWorkflow(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: { versionId: string } }>,
      rep
    )
  );

  // Executions
  fastify.post('/:id/execute', (req, rep) =>
    controller.executeWorkflow(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: import('./dto.js').ExecuteWorkflowDto }>,
      rep
    )
  );
  fastify.post('/:id/cancel', (req, rep) =>
    controller.cancelWorkflow(req as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep)
  );

  // Preview & History
  fastify.post('/preview', (req, rep) =>
    controller.previewWorkflow(
      req as import('fastify').FastifyRequest<{ Body: import('./dto.js').PreviewWorkflowDto }>,
      rep
    )
  );
  fastify.get('/history', (req, rep) => controller.getHistory(req, rep));
  fastify.get('/executions', (req, rep) => controller.getHistory(req, rep));
}
export default workflowRoutes;
