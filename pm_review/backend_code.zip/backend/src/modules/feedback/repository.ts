import { BaseRepository } from '@/repositories/implementations/base.repository.js';
import { FeedbackScoreEntity, IFeedbackRepository } from './types.js';
import { SupabaseClient } from '@supabase/supabase-js';

export class FeedbackRepository
  extends BaseRepository<FeedbackScoreEntity>
  implements IFeedbackRepository
{
  constructor(supabase: SupabaseClient) {
    super(supabase, 'feedback_scores');
  }

  async findByPerformance(
    performanceId: string,
    formulaVersion?: string,
  ): Promise<FeedbackScoreEntity | null> {
    let query = this.supabase.from(this.tableName).select('*').eq('performance_id', performanceId);

    if (formulaVersion) {
      query = query.eq('formula_version', formulaVersion);
    } else {
      query = query.order('calculation_version', { ascending: false });
    }

    const { data, error } = await query.limit(1).maybeSingle();
    if (error || !data) return null;
    return data as FeedbackScoreEntity;
  }

  async findLatest(productId: string): Promise<FeedbackScoreEntity | null> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select(
        `
        *,
        product_performance!inner(product_id)
      `,
      )
      .eq('product_performance.product_id', productId)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error || !data) return null;

    // Remove the joined table property to match the entity type signature
    const { product_performance: _, ...entity } = data as unknown as {
      product_performance: unknown;
    };
    return entity as FeedbackScoreEntity;
  }

  async findHistory(productId: string): Promise<FeedbackScoreEntity[]> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select(
        `
        *,
        product_performance!inner(product_id)
      `,
      )
      .eq('product_performance.product_id', productId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((item: unknown) => {
      const { product_performance: _, ...entity } = item as { product_performance: unknown };
      return entity as FeedbackScoreEntity;
    });
  }

  // Ownership verification helper methods using fast inner joins
  async verifyWorkspaceOwner(workspaceId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('workspaces')
      .select('org_id')
      .eq('workspace_id', workspaceId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const workspace = data as { org_id: string };
    return workspace.org_id === userId;
  }

  async verifyProductOwner(productId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('products')
      .select(
        `
        product_id,
        workspaces!inner(org_id)
      `,
      )
      .eq('product_id', productId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const product = data as unknown as { workspaces: { org_id: string } };
    return product.workspaces?.org_id === userId;
  }

  async verifyPerformanceOwner(performanceId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('product_performance')
      .select(
        `
        id,
        workspaces!inner(org_id)
      `,
      )
      .eq('id', performanceId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const performance = data as unknown as { workspaces: { org_id: string } };
    return performance.workspaces?.org_id === userId;
  }

  async verifyFeedbackOwner(feedbackId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select(
        `
        id,
        product_performance!inner(
          workspaces!inner(org_id)
        )
      `,
      )
      .eq('id', feedbackId)
      .maybeSingle();
    if (error || !data) return false;
    const feedback = data as unknown as { product_performance: { workspaces: { org_id: string } } };
    return feedback.product_performance?.workspaces?.org_id === userId;
  }
}
