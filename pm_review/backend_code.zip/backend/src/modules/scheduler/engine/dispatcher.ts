import { PriorityQueue } from '../queue/priority-queue.js';
import { SchedulerExecutor } from './executor.js';
import { LeaderElection } from '../leader/leader-election.js';
import { SchedulerEngine } from './scheduler-engine.js';

export class SchedulerDispatcher {
  private static activeLoop: NodeJS.Timeout | null = null;
  private static loopTickMs = 2000;
  private static handlers = new Map<string, () => Promise<void>>();

  static registerHandler(jobName: string, handler: () => Promise<void>): void {
    this.handlers.set(jobName, handler);
  }

  static start(loopTickMs = 2000): void {
    this.loopTickMs = loopTickMs;
    this.activeLoop = setInterval(async () => {
      try {
        await this.runDispatch();
      } catch {
        // Enforce resilience
      }
    }, this.loopTickMs);

    if (this.activeLoop.unref) {
      this.activeLoop.unref();
    }
  }

  private static async runDispatch(): Promise<void> {
    // Dispatch execution runs on the Leader node
    if (!LeaderElection.isLeader()) {
      return;
    }

    const job = await PriorityQueue.pop();
    if (!job) return;

    const handler = this.handlers.get(job.name);
    if (!handler) return;

    // Run execution asynchronously in background
    SchedulerExecutor.execute(job, handler, LeaderElection.getNodeId())
      .then((success) => {
        if (success) {
          SchedulerEngine.markJobCompleted(job.id);
        }
      })
      .catch(() => {});
  }

  static stop(): void {
    if (this.activeLoop) {
      clearInterval(this.activeLoop);
      this.activeLoop = null;
    }
  }
}
export default SchedulerDispatcher;
