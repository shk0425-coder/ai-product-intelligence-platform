import { FastifyReply, FastifyRequest } from 'fastify';
import { FeedbackService } from './service.js';
import {
  CalculateFeedbackInput,
  RecalculateFeedbackInput,
  FeedbackPerformanceParamInput,
  FeedbackProductParamInput,
} from './schema.js';
import { successResponse } from '@/common/responses/index.js';

export class FeedbackController {
  constructor(private readonly feedbackService: FeedbackService) {}

  calculate = async (
    request: FastifyRequest<{ Body: CalculateFeedbackInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.feedbackService.calculate(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Feedback score calculated and persisted successfully'));
  };

  recalculate = async (
    request: FastifyRequest<{ Body: RecalculateFeedbackInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.feedbackService.recalculate(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Feedback score recalculated successfully'));
  };

  findByPerformance = async (
    request: FastifyRequest<{ Params: FeedbackPerformanceParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.feedbackService.findByPerformance(
      request.params.performanceId,
      userId,
    );
    return reply.status(200).send(successResponse(result));
  };

  findHistory = async (
    request: FastifyRequest<{ Params: FeedbackProductParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.feedbackService.findHistory(request.params.productId, userId);
    return reply.status(200).send(successResponse(result));
  };

  findLatest = async (
    request: FastifyRequest<{ Params: FeedbackProductParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.feedbackService.findLatest(request.params.productId, userId);
    return reply.status(200).send(successResponse(result));
  };
}
export default FeedbackController;
