import { MetricsRegistry } from '../../observability/metrics/registry.js';

export class RecoveryBudgetManager {
  private static recoveryCount = 0;
  private static hourlyLimit = 5;

  static setLimit(limit: number): void {
    this.hourlyLimit = limit;
  }

  static consume(): boolean {
    if (this.recoveryCount >= this.hourlyLimit) {
      MetricsRegistry.counter('budget_exceeded_total', 1);
      return false; // Budget exceeded
    }

    this.recoveryCount++;
    return true;
  }

  static getRemainingBudget(): number {
    return Math.max(0, this.hourlyLimit - this.recoveryCount);
  }

  static clear(): void {
    this.recoveryCount = 0;
  }
}
export default RecoveryBudgetManager;
