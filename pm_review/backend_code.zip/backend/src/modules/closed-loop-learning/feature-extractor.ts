export interface FeatureSet {
  strengths: string[];
  weaknesses: string[];
  bottlenecks: string[];
  improvements: string[];
  risks: string[];
}

export const FeatureExtractor = {
  extract(intelligence: {
    strengthSummary?: string;
    detectedRules?: Array<{
      category?: string;
      severity?: number;
      message?: string;
      ruleId?: string;
    }>;
    recommendations?: Array<{ category?: string; recommendation?: string }>;
  }): FeatureSet {
    const strengths: string[] = [];
    const weaknesses: string[] = [];
    const bottlenecks: string[] = [];
    const improvements: string[] = [];
    const risks: string[] = [];

    // Parse strengths summary
    if (intelligence.strengthSummary && intelligence.strengthSummary !== '') {
      strengths.push(intelligence.strengthSummary);
    }

    // Parse detected rules and recommendations
    const detectedRules = intelligence.detectedRules || [];
    for (const rule of detectedRules) {
      const message = `${rule.category} issue: ${rule.message}`;
      if (Number(rule.severity || 0) >= 4) {
        bottlenecks.push(message);
        risks.push(`Critical vulnerability in ${rule.category} area`);
      } else {
        weaknesses.push(message);
      }
    }

    const recommendations = intelligence.recommendations || [];
    for (const rec of recommendations) {
      improvements.push(`${rec.category} suggestion: ${rec.recommendation}`);
    }

    return {
      strengths,
      weaknesses,
      bottlenecks,
      improvements,
      risks,
    };
  },
};
export default FeatureExtractor;
