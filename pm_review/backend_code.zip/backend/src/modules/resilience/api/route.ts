import { FastifyInstance } from 'fastify';
import { resilienceController } from './controller.js';

export async function resilienceRoutes(fastify: FastifyInstance) {
  fastify.post('/approval/approve', (req, rep) => resilienceController.approveRecovery(req, rep));
  fastify.get('/dashboard', (req, rep) => resilienceController.getDashboard(req, rep));
}
export default resilienceRoutes;
