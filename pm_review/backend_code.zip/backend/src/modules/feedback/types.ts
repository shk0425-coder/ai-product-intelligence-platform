import { IBaseRepository } from '@/repositories/interfaces/base.repository.js';
import { FeedbackResponseDto } from './dto.js';

export interface FeedbackScoreEntity {
  id: string; // UUID Primary Key
  performance_id: string; // UUID FK
  calculation_version: number; // INTEGER
  sales_score: number; // NUMERIC(6,3)
  review_score: number; // NUMERIC(6,3)
  conversion_score: number; // NUMERIC(6,3)
  engagement_score: number; // NUMERIC(6,3)
  profitability_score: number; // NUMERIC(6,3)
  refund_penalty: number; // NUMERIC(6,3)
  overall_score: number; // NUMERIC(6,3)
  grade: 'S' | 'A+' | 'A' | 'B' | 'C' | 'D'; // VARCHAR(2)
  weight_snapshot: Record<string, number>; // JSONB
  formula_version: string; // VARCHAR(20)
  calculated_at: string; // TIMESTAMPTZ
  created_at: string; // TIMESTAMPTZ
}

export interface IFeedbackRepository extends IBaseRepository<FeedbackScoreEntity> {
  findByPerformance(
    performanceId: string,
    formulaVersion?: string,
  ): Promise<FeedbackScoreEntity | null>;
  findLatest(productId: string): Promise<FeedbackScoreEntity | null>;
  findHistory(productId: string): Promise<FeedbackScoreEntity[]>;
}

export interface FeedbackEventPayload {
  feedback: FeedbackResponseDto;
  actorId: string;
  timestamp: string;
}

export interface IFeedbackHooks {
  onFeedbackCalculated(payload: FeedbackEventPayload): Promise<void>;
  onFeedbackRecalculated(payload: FeedbackEventPayload): Promise<void>;
}
