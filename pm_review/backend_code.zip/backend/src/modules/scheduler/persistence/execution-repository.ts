export type JobState = 'Pending' | 'Scheduled' | 'Running' | 'Success' | 'Failed' | 'Retrying' | 'Cancelled' | 'Timeout';

export interface JobExecution {
  executionId: string;
  jobId: string;
  state: JobState;
  startTime: number;
  endTime?: number;
  durationMs?: number;
  result?: string;
  error?: string;
  retryCount: number;
  nodeId: string;
  leaseExpiresAt?: number;
  idempotencyKey?: string;
}

export class ExecutionRepository {
  private static readonly executions = new Map<string, JobExecution>();
  private static readonly history: JobExecution[] = [];

  static async save(exec: JobExecution): Promise<void> {
    this.executions.set(exec.executionId, { ...exec });
    
    // Maintain chronological execution history stream
    const idx = this.history.findIndex(h => h.executionId === exec.executionId);
    if (idx !== -1) {
      this.history[idx] = { ...exec };
    } else {
      this.history.push({ ...exec });
    }
  }

  static async findById(executionId: string): Promise<JobExecution | undefined> {
    const exec = this.executions.get(executionId);
    return exec ? { ...exec } : undefined;
  }

  static async findByIdempotencyKey(key: string): Promise<JobExecution | undefined> {
    return Array.from(this.executions.values()).find(e => e.idempotencyKey === key);
  }

  static async findOrphanJobs(now: number): Promise<JobExecution[]> {
    // Return Running jobs whose lease expired
    return Array.from(this.executions.values()).filter(
      e => e.state === 'Running' && e.leaseExpiresAt && e.leaseExpiresAt < now
    );
  }

  static async getHistory(limit = 100): Promise<JobExecution[]> {
    return this.history.slice(-limit).map(h => ({ ...h }));
  }

  static runRetentionCleanup(now: number, ttlMs: number): void {
    const threshold = now - ttlMs;
    // Cleanup older executions in map
    for (const [id, exec] of this.executions.entries()) {
      if (exec.endTime && exec.endTime < threshold) {
        this.executions.delete(id);
      }
    }
    // Cleanup history list
    const filtered = this.history.filter(h => !h.endTime || h.endTime >= threshold);
    this.history.length = 0;
    this.history.push(...filtered);
  }

  static clear(): void {
    this.executions.clear();
    this.history.length = 0;
  }
}
export default ExecutionRepository;
