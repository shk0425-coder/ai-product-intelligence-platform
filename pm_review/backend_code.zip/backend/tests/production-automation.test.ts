import { vi, describe, it, expect, beforeAll } from 'vitest';

const { mockQueryBuilder, setResolver, mockSupabase } = vi.hoisted(() => {
  let activeTable = '';
  let activeAction = '';
  let activePayload: any = null;

  let resolver = (table: string, action: string, payload?: any) => 
    Promise.resolve({ data: null, count: 0, error: null });

  const qb: any = {
    select: vi.fn().mockImplementation(() => { activeAction = 'select'; return qb; }),
    insert: vi.fn().mockImplementation((p) => { activeAction = 'insert'; activePayload = p; return qb; }),
    update: vi.fn().mockImplementation((p) => { activeAction = 'update'; activePayload = p; return qb; }),
    delete: vi.fn().mockImplementation(() => { activeAction = 'delete'; return qb; }),
    eq: vi.fn().mockImplementation(() => qb),
    is: vi.fn().mockImplementation(() => qb),
    in: vi.fn().mockImplementation(() => qb),
    order: vi.fn().mockImplementation(() => qb),
    limit: vi.fn().mockImplementation(() => qb),
    maybeSingle: vi.fn().mockImplementation(() => qb),
    single: vi.fn().mockImplementation(() => qb),
  };

  qb.then = (onfulfilled: any) => {
    return resolver(activeTable, activeAction, activePayload).then(onfulfilled);
  };

  const supabaseMock = {
    from: vi.fn().mockImplementation((table) => {
      activeTable = table;
      return qb;
    }),
  };

  return {
    mockQueryBuilder: qb,
    setResolver: (newResolver: any) => {
      resolver = newResolver;
    },
    mockSupabase: supabaseMock,
  };
});

vi.mock('@/config/supabase.js', () => {
  return {
    supabase: mockSupabase,
  };
});

import { createApp } from '@/app.js';
import jwt from 'jsonwebtoken';
import { env } from '@/config/env.js';
import { KnowledgeFilter } from '../src/modules/production-automation/knowledge-filter.js';
import { PromptBuilder } from '../src/modules/production-automation/prompt-builder.js';
import { PromptValidator } from '../src/modules/production-automation/prompt-validator.js';
import { ProductionPlanner } from '../src/modules/production-automation/planner.js';
import { ClosedLoopProductionService } from '../src/modules/production-automation/service.js';
import { ProductionRepository } from '../src/modules/production-automation/repository.js';
import { ProductionHooks } from '../src/modules/production-automation/hooks.js';

const generateTestToken = (userId: string, email: string) => {
  return jwt.sign({ userId, email, role: 'USER' }, env.JWT_SECRET, { expiresIn: '1h' });
};

describe('Production Automation Domain Tests (20 Scenarios)', () => {
  let app: any;
  const mockUserId = '11111111-1111-1111-1111-111111111111';
  const testToken = generateTestToken(mockUserId, 'test@example.com');

  const workspaceId = '22222222-2222-2222-2222-222222222222';
  const knowledgeId = '33333333-3333-3333-3333-333333333333';
  const automationId = '44444444-4444-4444-4444-444444444444';
  const strategyId = 'strategy-12345';

  beforeAll(async () => {
    app = await createApp();
    app.supabase = mockSupabase;
  });

  describe('Pure Engines & Calculations (Scenarios 1-10)', () => {
    it('Scenario 1: should filter out knowledge records below score thresholds', () => {
      const mockList = [
        { id: '1', knowledge_score: 65.0, confidence_score: 90.0 }, // low score
        { id: '2', knowledge_score: 80.0, confidence_score: 60.0 }, // low conf
        { id: '3', knowledge_score: 85.0, confidence_score: 85.0 }, // valid
      ];
      const result = KnowledgeFilter.filter(mockList);
      expect(result.length).toBe(1);
      expect(result[0].id).toBe('3');
    });

    it('Scenario 2: should prioritize latest versions when filtering', () => {
      const mockList = [
        { id: 'v1', knowledge_score: 85.0, confidence_score: 85.0, knowledge_version: 1 },
        { id: 'v2', knowledge_score: 85.0, confidence_score: 85.0, knowledge_version: 2 },
      ];
      const result = KnowledgeFilter.filter(mockList);
      expect(result[0].id).toBe('v2');
    });

    it('Scenario 3: should deduplicate records with identical summary and success patterns', () => {
      const mockList = [
        { id: '1', knowledge_score: 85.0, confidence_score: 85.0, feature_summary: 'same', success_pattern: 'same' },
        { id: '2', knowledge_score: 90.0, confidence_score: 90.0, feature_summary: 'same', success_pattern: 'same' },
      ];
      const result = KnowledgeFilter.filter(mockList);
      // High score first is 2, so it should keep 2 and discard 1
      expect(result.length).toBe(1);
      expect(result[0].id).toBe('2');
    });

    it('Scenario 4: should strictly assemble prompt sections in order using Builder Pattern', () => {
      const builder = new PromptBuilder();
      builder
        .setSystemPrompt('SYS')
        .setUserRequest('REQ')
        .setPlanningRules('RULES');

      const result = builder.build();
      expect(result.prompt).toContain('[System Prompt]\nSYS\n\n[Planning Rules]\nRULES\n\n[User Request]\nREQ');
    });

    it('Scenario 5: should throw PromptValidationError when mandatory validation fields are missing', () => {
      expect(() => {
        PromptValidator.validate({
          workspace: workspaceId,
          // category missing
          learningSummary: 'summary',
        });
      }).toThrow(/Prompt validation failed/);
    });

    it('Scenario 6: should pass validation when all required context fields are present', () => {
      expect(() => {
        PromptValidator.validate({
          workspace: workspaceId,
          category: 'category',
          learningSummary: 'summary',
          patterns: 'patterns',
          featureVector: '{}',
          improvementStrategy: 'strategy',
          bestPractice: 'bestPractice',
          userRequest: 'userRequest',
        });
      }).not.toThrow();
    });

    it('Scenario 7: should calculate correct 64-char SHA-256 checksum for prompt string', () => {
      const builder = new PromptBuilder();
      const res = builder.setSystemPrompt('hello world').build();
      expect(res.checksum.length).toBe(64);
    });

    it('Scenario 8: should calculate consistent tokens estimation count', () => {
      const builder = new PromptBuilder();
      const res = builder.setSystemPrompt('12345678').build(); // '12345678' length 8 -> tokens count should be 6
      expect(res.tokenCount).toBe(6);
    });

    it('Scenario 9: Planner execute must be pure and return strategy payload without calling DB', async () => {
      const res = await ProductionPlanner.execute('prompt context', 'request');
      expect(res.strategyOutput).toContain('AI Product Strategy');
      expect(res.strategyId).toBeDefined();
    });

    it('Scenario 10: Planner must throw error if trigger flag is present in user request', async () => {
      await expect(
        ProductionPlanner.execute('prompt context', 'trigger planner error')
      ).rejects.toThrow(/Mock Planner Strategy/);
    });
  });

  describe('Integration & API Executions (Scenarios 11-20)', () => {
    it('Scenario 11: should block unauthorized automation status query', async () => {
      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/production/status/${automationId}`,
      });
      expect(response.statusCode).toBe(401);
    });

    it('Scenario 12: should block status query if user does not own the workspace', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyAutomationOwnership').mockResolvedValue(false);

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/production/status/${automationId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });
      expect(response.statusCode).toBe(403);
    });

    it('Scenario 13: should block run automation request if user does not own workspace', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(false);

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/production/run',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { workspaceId, knowledgeId, userRequest: 'strategy' },
      });
      expect(response.statusCode).toBe(403);
    });

    it('Scenario 14: should successfully execute run pipeline and audit details in logs', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(true);
      vi.spyOn(ProductionRepository.prototype, 'verifyKnowledgeOwnership').mockResolvedValue(true);

      setResolver((table: string, action: string, payload?: any) => {
        if (table === 'learning_knowledge') {
          return Promise.resolve({
            data: [{
              id: knowledgeId,
              knowledge_score: 95.0,
              confidence_score: 100.0,
              feature_summary: 'feature Summary',
              success_pattern: 'success Pattern',
              improvement_pattern: 'improvement Pattern',
            }],
            error: null,
          });
        }
        if (table === 'production_automations') {
          if (action === 'insert') {
            return Promise.resolve({
              data: {
                id: automationId,
                workspace_id: workspaceId,
                knowledge_id: knowledgeId,
                status: 'PENDING',
                retry_count: 0,
              },
              error: null,
            });
          }
          // updates
          return Promise.resolve({
            data: {
              id: automationId,
              workspace_id: workspaceId,
              knowledge_id: knowledgeId,
              status: payload?.status || 'SUCCESS',
              retry_count: payload?.retry_count || 0,
            },
            error: null,
          });
        }
        if (table === 'learning_vectors') {
          return Promise.resolve({ data: { vector_data: { metrics: true } }, error: null });
        }
        return Promise.resolve({ data: { id: 'generic-id' }, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/production/run',
        headers: { authorization: `Bearer ${testToken}` },
        payload: {
          workspaceId,
          knowledgeId,
          userRequest: 'Optimize detailing layout',
          bestPractice: 'Use lazy image loading',
        },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.success).toBe(true);
      expect(body.data.status).toBe('SUCCESS');
    });

    it('Scenario 15: should fail workflow and persist failed log when knowledge loader returns empty', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(true);
      vi.spyOn(ProductionRepository.prototype, 'verifyKnowledgeOwnership').mockResolvedValue(true);

      setResolver((table: string, action: string, payload?: any) => {
        if (table === 'learning_knowledge') {
          // Loader returns empty list -> will fail FILTER step
          return Promise.resolve({ data: [], error: null });
        }
        if (table === 'production_automations') {
          if (action === 'insert') {
            return Promise.resolve({ data: { id: automationId, workspace_id: workspaceId, status: 'PENDING' }, error: null });
          }
          return Promise.resolve({ data: { id: automationId, workspace_id: workspaceId, status: payload?.status || 'FAILED' }, error: null });
        }
        return Promise.resolve({ data: { id: 'generic-log' }, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/production/run',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { workspaceId, knowledgeId, userRequest: 'Optimize detailing layout' },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200); 
      expect(body.data.status).toBe('FAILED');
    });

    it('Scenario 16: should reject retry request if automation status is RUNNING or SUCCESS', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyAutomationOwnership').mockResolvedValue(true);

      setResolver((table: string) => {
        if (table === 'production_automations') {
          return Promise.resolve({ data: { id: automationId, status: 'SUCCESS' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/production/retry',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { automationId },
      });
      expect(response.statusCode).toBe(409); // AutomationConflictError
    });

    it('Scenario 17: should reject retry if retry count limit (3) is exceeded', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyAutomationOwnership').mockResolvedValue(true);

      setResolver((table: string) => {
        if (table === 'production_automations') {
          return Promise.resolve({ data: { id: automationId, status: 'FAILED', retry_count: 3 }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/production/retry',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { automationId },
      });
      expect(response.statusCode).toBe(429); // AutomationRetryExceededError
    });

    it('Scenario 18: should increment retry count and trigger rerun successfully', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyAutomationOwnership').mockResolvedValue(true);

      const mockAuto = {
        id: automationId,
        workspace_id: workspaceId,
        knowledge_id: knowledgeId,
        status: 'FAILED' as const,
        retry_count: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };

      vi.spyOn(ProductionRepository.prototype, 'findAutomation').mockResolvedValue(mockAuto);
      vi.spyOn(ProductionRepository.prototype, 'updateAutomation').mockImplementation(async (id, payload) => {
        if (payload.retry_count !== undefined) mockAuto.retry_count = payload.retry_count;
        if (payload.status !== undefined) mockAuto.status = payload.status as any;
        return mockAuto;
      });

      setResolver((table: string) => {
        if (table === 'learning_knowledge') {
          return Promise.resolve({ data: [], error: null }); // trigger early failure again
        }
        return Promise.resolve({ data: { id: 'generic-log' }, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/production/retry',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { automationId },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.retryCount).toBe(1);
      expect(body.data.status).toBe('FAILED');
    });

    it('Scenario 19: should fetch history logs associated with the workspace', async () => {
      vi.spyOn(ProductionRepository.prototype, 'verifyWorkspaceOwnership').mockResolvedValue(true);

      setResolver((table: string) => {
        if (table === 'production_automations') {
          return Promise.resolve({
            data: [
              { id: automationId, workspace_id: workspaceId, knowledge_id: knowledgeId, status: 'SUCCESS' },
            ],
            error: null,
          });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/production/history/${workspaceId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.length).toBe(1);
      expect(body.data[0].automationId).toBe(automationId);
    });

    it('Scenario 20: should hit Prompt Cache and reuse planner strategies on identical prompt checksums', async () => {
      const repo = new ProductionRepository(mockSupabase as any);
      const service = new ClosedLoopProductionService(repo);

      let plannerSpyCount = 0;
      vi.spyOn(ProductionPlanner, 'execute').mockImplementation(async () => {
        plannerSpyCount++;
        return { strategyId, strategyOutput: 'mocked', tokensConsumed: 100 };
      });

      const mockAuto = { id: automationId, workspace_id: workspaceId, status: 'SUCCESS' };
      
      setResolver((table: string, action: string, payload?: any) => {
        if (table === 'learning_knowledge') {
          return Promise.resolve({
            data: [{
              id: knowledgeId,
              knowledge_score: 95.0,
              confidence_score: 100.0,
              feature_summary: 'sum',
              success_pattern: 'pat',
              improvement_pattern: 'imp'
            }],
            error: null
          });
        }
        if (table === 'production_automations') {
          return Promise.resolve({ data: mockAuto, error: null });
        }
        if (table === 'learning_vectors') {
          return Promise.resolve({ data: { vector_data: { key: 'val' } }, error: null });
        }
        return Promise.resolve({ data: { id: 'generic-log' }, error: null });
      });

      // Execute twice
      await service.executeWorkflow(automationId, mockUserId);
      await service.executeWorkflow(automationId, mockUserId);

      expect(plannerSpyCount).toBe(1);
    });
  });
});
