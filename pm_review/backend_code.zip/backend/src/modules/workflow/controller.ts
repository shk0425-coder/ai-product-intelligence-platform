import { FastifyRequest, FastifyReply } from 'fastify';
import { WorkflowService } from './service.js';
import { CreateWorkflowDto, CreateWorkflowVersionDto, ExecuteWorkflowDto, PreviewWorkflowDto } from './dto.js';

export class WorkflowController {
  constructor(private readonly service: WorkflowService) {}

  async getWorkflows(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getWorkflows();
    return reply.status(200).send({ data: result });
  }

  async getWorkflowById(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.getWorkflowById(id);
    return reply.status(200).send({ data: result });
  }

  async createWorkflow(req: FastifyRequest<{ Body: CreateWorkflowDto }>, reply: FastifyReply) {
    const result = await this.service.createWorkflow(req.body);
    return reply.status(201).send({ data: result });
  }

  async createVersion(
    req: FastifyRequest<{ Params: { id: string }; Body: CreateWorkflowVersionDto }>,
    reply: FastifyReply
  ) {
    const { id } = req.params;
    const result = await this.service.createVersion(id, req.body);
    return reply.status(201).send({ data: result });
  }

  async approveWorkflow(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.approveWorkflow(id, 'admin-user-id');
    return reply.status(200).send({ data: result });
  }

  async reviewWorkflow(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.reviewWorkflow(id);
    return reply.status(200).send({ data: result });
  }

  async deprecateWorkflow(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.deprecateWorkflow(id);
    return reply.status(200).send({ data: result });
  }

  async rollbackWorkflow(
    req: FastifyRequest<{ Params: { id: string }; Body: { versionId: string } }>,
    reply: FastifyReply
  ) {
    const { id } = req.params;
    const { versionId } = req.body;
    const result = await this.service.rollbackWorkflowVersion(id, versionId);
    return reply.status(200).send({ data: result });
  }

  async executeWorkflow(
    req: FastifyRequest<{ Params: { id: string }; Body: ExecuteWorkflowDto }>,
    reply: FastifyReply
  ) {
    const { id } = req.params;
    const result = await this.service.execute(id, req.body);
    return reply.status(200).send({ data: result });
  }

  async cancelWorkflow(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params; // executionId
    await this.service.cancelExecution(id);
    return reply.status(200).send({ message: 'Cancellation signal dispatched successfully' });
  }

  async previewWorkflow(req: FastifyRequest<{ Body: PreviewWorkflowDto }>, reply: FastifyReply) {
    const result = await this.service.preview(req.body);
    return reply.status(200).send({ data: result });
  }

  async getVersions(req: FastifyRequest<{ Params: { id: string } }>, reply: FastifyReply) {
    const { id } = req.params;
    const result = await this.service.getVersions(id);
    return reply.status(200).send({ data: result });
  }

  async getHistory(req: FastifyRequest, reply: FastifyReply) {
    const result = await this.service.getHistory();
    return reply.status(200).send({ data: result });
  }
}
export default WorkflowController;
