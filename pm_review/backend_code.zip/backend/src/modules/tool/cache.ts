import crypto from 'crypto';

export interface ToolCacheInterface {
  get(key: string): Record<string, unknown> | null;
  set(key: string, value: Record<string, unknown>, ttlMs: number): void;
  delete(key: string): void;
  clear(): void;
}

export class ToolInMemoryCache implements ToolCacheInterface {
  private readonly cache = new Map<string, { value: Record<string, unknown>; expiresAt: number }>();

  get(key: string): Record<string, unknown> | null {
    const item = this.cache.get(key);
    if (!item) return null;

    if (Date.now() > item.expiresAt) {
      this.cache.delete(key);
      return null;
    }
    return item.value;
  }

  set(key: string, value: Record<string, unknown>, ttlMs: number): void {
    this.cache.set(key, {
      value: JSON.parse(JSON.stringify(value)),
      expiresAt: Date.now() + ttlMs,
    });
  }

  delete(key: string): void {
    this.cache.delete(key);
  }

  clear(): void {
    this.cache.clear();
  }
}

export class ToolCacheKeyGenerator {
  static generate(
    versionId: string,
    request: Record<string, unknown>,
    workspaceId: string,
    capability: string
  ): string {
    const payload = JSON.stringify({ versionId, request, workspaceId, capability });
    return crypto.createHash('sha256').update(payload).digest('hex');
  }
}
export default ToolInMemoryCache;
