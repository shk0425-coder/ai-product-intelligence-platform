import { MetricsRegistry } from '../../observability/metrics/registry.js';

export interface NotificationPayload {
  title: string;
  body: string;
  channels: ('Slack' | 'Email' | 'Dashboard' | 'Webhook')[];
}

export class NotificationManager {
  private static readonly history: NotificationPayload[] = [];

  static async dispatch(payload: NotificationPayload): Promise<boolean> {
    this.history.push(payload);

    let allSucceeded = true;
    for (const channel of payload.channels) {
      // Mock notifications delivery
      if (channel === 'Webhook' && payload.body.includes('fail')) {
        MetricsRegistry.counter('notification_failed_total', 1, { channel });
        allSucceeded = false;
      } else {
        MetricsRegistry.counter('notification_sent_total', 1, { channel });
      }
    }

    return allSucceeded;
  }

  static getHistory(): NotificationPayload[] {
    return [...this.history];
  }

  static clear(): void {
    this.history.length = 0;
  }
}
export default NotificationManager;
