import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export interface ReplayEvent {
  eventId: string;
  eventType: string;
  timestamp: number;
  data: Record<string, unknown>;
}

export class EventReplayManager {
  private static readonly store = new Map<string, ReplayEvent>();
  private static readonly replayed = new Set<string>();

  static async recordEvent(event: ReplayEvent): Promise<void> {
    this.store.set(event.eventId, { ...event });
  }

  static async replay(eventId: string): Promise<boolean> {
    const event = this.store.get(eventId);
    if (!event) return false;

    // Enforce Exactly Once Replay
    if (this.replayed.has(eventId)) {
      return false; // Prevent duplicate replay
    }

    this.replayed.add(eventId);
    MetricsRegistry.counter('event_replay_total', 1);

    eventBus.publish({
      eventId: crypto.randomUUID(),
      eventType: 'SimulationValidated', // Map as validation event
      timestamp: new Date().toISOString(),
      workspaceId: 'default-workspace',
      data: { replayedEventId: eventId, originalType: event.eventType },
    }).catch(() => {});

    return true;
  }

  static clear(): void {
    this.store.clear();
    this.replayed.clear();
  }
}
export default EventReplayManager;
