import { FastifyRequest, FastifyReply } from 'fastify';
import { AuditCenter, AuditQueryFilter } from '../audit/audit-center.js';
import { CapabilityRegistry } from '../capability/capability-registry.js';
import { MaintenanceManager } from '../maintenance/maintenance-manager.js';

export class OperationsController {
  async getDashboard(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    rep.send({
      status: 'success',
      data: {
        lockCount: 0,
        quotaExceeded: false,
        maintenanceActive: MaintenanceManager.isMaintenanceActive(),
        readOnly: MaintenanceManager.isReadOnly(),
      },
    });
  }

  async searchAudits(req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const filter = req.body as AuditQueryFilter;
    const logs = AuditCenter.searchLogs(filter);
    rep.send({ status: 'success', data: logs });
  }

  async exportAudits(req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const { format } = req.query as { format: 'JSON' | 'CSV' };
    const spec = AuditCenter.exportLogs({}, format || 'JSON');
    rep.send({ status: 'success', data: spec });
  }

  async getCapabilities(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const caps = CapabilityRegistry.getCapabilities();
    rep.send({ status: 'success', data: caps });
  }

  async getCapability(req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const { name } = req.params as { name: string };
    const cap = CapabilityRegistry.getCapability(name);
    if (!cap) {
      rep.status(404).send({ status: 'error', message: 'Capability not found' });
      return;
    }
    rep.send({ status: 'success', data: cap });
  }
}
export const operationsController = new OperationsController();
export default operationsController;
