export interface CreativePlaceholder {}
