export type WorkflowStatus = 'DRAFT' | 'REVIEW' | 'APPROVED' | 'DEPRECATED';
export type ExecutionStatus = 'PENDING' | 'RUNNING' | 'WAITING' | 'SUCCESS' | 'FAILED' | 'CANCELLED' | 'TIMEOUT';

export type NodeType = 'Start' | 'End' | 'Agent' | 'Parallel' | 'Condition' | 'Merge';
export type EdgeType = 'Success' | 'Failure' | 'Timeout' | 'Cancel';

export interface WorkflowNode {
  id: string;
  type: NodeType;
  name: string;
  agentName?: string;
  promptTemplateId?: string;
  conditionExpression?: string; // e.g. "context.score > 70"
  timeoutMs?: number;
  maxRetry?: number;
  retryIntervalMs?: number;
  parallelNodeIds?: string[]; // IDs for parallel execution sub-steps
}

export interface WorkflowEdge {
  from: string;
  to: string;
  type?: EdgeType; // Success, Failure, Timeout, Cancel
}

export interface WorkflowGraph {
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
}

export interface WorkflowDefinitionEntity {
  id: string;
  workspace_id: string;
  name: string;
  description?: string;
  latest_version: number;
  current_version_id?: string;
  status: WorkflowStatus;
  created_by?: string;
  updated_by?: string;
  approved_by?: string;
  approved_at?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string;
}

export interface WorkflowVersionEntity {
  id: string;
  workflow_id: string;
  version: number;
  graph: WorkflowGraph;
  checksum: string;
  change_summary?: string;
  created_by?: string;
  created_at: string;
}

export interface WorkflowExecutionEntity {
  id: string;
  workspace_id: string;
  workflow_id: string;
  version_id: string;
  status: ExecutionStatus;
  execution_key: string;
  input: Record<string, unknown>;
  output: Record<string, unknown>;
  snapshot: Record<string, unknown>;
  started_at?: string;
  finished_at?: string;
  duration_ms: number;
  estimated_cost: number;
  error_message?: string;
  created_at: string;
}

export interface WorkflowStepExecutionEntity {
  id: string;
  execution_id: string;
  step_id: string;
  agent_name?: string;
  prompt_version_id?: string;
  provider?: string;
  model?: string;
  retry_count: number;
  status: ExecutionStatus;
  input: Record<string, unknown>;
  output: Record<string, unknown>;
  estimated_cost: number;
  execution_ms: number;
  started_at?: string;
  finished_at?: string;
  created_at: string;
}

export interface WorkflowAuditLogEntity {
  id: string;
  workspace_id: string;
  workflow_id: string;
  action: string;
  actor?: string;
  before?: Record<string, unknown>;
  after?: Record<string, unknown>;
  created_at: string;
}
