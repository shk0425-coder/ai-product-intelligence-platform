import { SupabaseClient } from '@supabase/supabase-js';
import { PromptTemplateEntity, PromptVersionEntity, PromptExecutionHistoryEntity, PromptAuditLogEntity } from './types.js';

export class PromptRepository {
  constructor(private readonly supabase: SupabaseClient) {}

  async findTemplates(): Promise<PromptTemplateEntity[]> {
    const { data, error } = await this.supabase
      .from('prompt_templates')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });

    if (error) return [];
    return (data || []) as PromptTemplateEntity[];
  }

  async findTemplateById(id: string): Promise<PromptTemplateEntity | null> {
    const { data, error } = await this.supabase
      .from('prompt_templates')
      .select('*')
      .eq('id', id)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) return null;
    return data as PromptTemplateEntity;
  }

  async createTemplate(entity: Omit<PromptTemplateEntity, 'id' | 'created_at' | 'updated_at'>): Promise<PromptTemplateEntity | null> {
    const { data, error } = await this.supabase
      .from('prompt_templates')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as PromptTemplateEntity;
  }

  async updateTemplate(id: string, payload: Partial<PromptTemplateEntity>): Promise<PromptTemplateEntity | null> {
    const { data, error } = await this.supabase
      .from('prompt_templates')
      .update({
        ...payload,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select('*')
      .maybeSingle();

    if (error) return null;
    return data as PromptTemplateEntity;
  }

  async createVersion(entity: Omit<PromptVersionEntity, 'id' | 'created_at'>): Promise<PromptVersionEntity | null> {
    const { data, error } = await this.supabase
      .from('prompt_versions')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as PromptVersionEntity;
  }

  async findVersionsByTemplateId(templateId: string): Promise<PromptVersionEntity[]> {
    const { data, error } = await this.supabase
      .from('prompt_versions')
      .select('*')
      .eq('template_id', templateId)
      .order('version', { ascending: false });

    if (error) return [];
    return (data || []) as PromptVersionEntity[];
  }

  async findVersionById(id: string): Promise<PromptVersionEntity | null> {
    const { data, error } = await this.supabase
      .from('prompt_versions')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) return null;
    return data as PromptVersionEntity;
  }

  async createHistory(entity: Omit<PromptExecutionHistoryEntity, 'id' | 'created_at'>): Promise<PromptExecutionHistoryEntity | null> {
    const { data, error } = await this.supabase
      .from('prompt_execution_history')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as PromptExecutionHistoryEntity;
  }

  async findHistories(): Promise<PromptExecutionHistoryEntity[]> {
    const { data, error } = await this.supabase
      .from('prompt_execution_history')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) return [];
    return (data || []) as PromptExecutionHistoryEntity[];
  }

  async createAuditLog(entity: Omit<PromptAuditLogEntity, 'id' | 'created_at'>): Promise<PromptAuditLogEntity | null> {
    const { data, error } = await this.supabase
      .from('prompt_audit_logs')
      .insert({
        ...entity,
        created_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (error) return null;
    return data as PromptAuditLogEntity;
  }
}
export default PromptRepository;
