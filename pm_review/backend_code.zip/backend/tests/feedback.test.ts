import { vi, describe, it, expect, beforeAll } from 'vitest';

const { mockQueryBuilder, setResolver, mockSupabase } = vi.hoisted(() => {
  const qb: any = {
    select: vi.fn(),
    insert: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
    eq: vi.fn(),
    is: vi.fn(),
    order: vi.fn(),
    limit: vi.fn(),
    maybeSingle: vi.fn(),
    single: vi.fn(),
  };

  const methods = ['select', 'insert', 'update', 'delete', 'eq', 'is', 'order', 'limit', 'maybeSingle', 'single'];
  for (const m of methods) {
    qb[m].mockImplementation(() => qb);
  }

  let resolver = () => Promise.resolve({ data: null, count: 0, error: null });
  qb.then = (onfulfilled: any) => resolver().then(onfulfilled);

  const supabaseMock = {
    from: vi.fn().mockReturnValue(qb),
  };

  return {
    mockQueryBuilder: qb,
    setResolver: (newResolver: any) => {
      resolver = newResolver;
    },
    mockSupabase: supabaseMock,
  };
});

vi.mock('@/config/supabase.js', () => {
  return {
    supabase: mockSupabase,
  };
});

import { createApp } from '@/app.js';
import jwt from 'jsonwebtoken';
import { env } from '@/config/env.js';
import { FeedbackNormalization } from '../src/modules/feedback/normalization.js';
import { FeedbackGrading } from '../src/modules/feedback/grading.js';
import { FeedbackCalculator } from '../src/modules/feedback/calculator.js';
import { validateWeights, FEEDBACK_WEIGHTS } from '../src/modules/feedback/weights.js';

const generateTestToken = (userId: string, email: string) => {
  return jwt.sign({ userId, email, role: 'USER' }, env.JWT_SECRET, { expiresIn: '1h' });
};

describe('Feedback Domain Module Tests', () => {
  let app: any;
  const mockUserId = '11111111-1111-1111-1111-111111111111';
  const otherUserId = '22222222-2222-2222-2222-222222222222';
  const testToken = generateTestToken(mockUserId, 'test@example.com');

  const performanceId = '33333333-3333-3333-3333-333333333333';
  const productId = '44444444-4444-4444-4444-444444444444';
  const feedbackId = '55555555-5555-5555-5555-555555555555';

  beforeAll(async () => {
    app = await createApp();
  });

  describe('Pure Function Validation Engine', () => {
    it('should correctly normalize raw performance metrics', () => {
      expect(FeedbackNormalization.normalizeSales(500)).toBe(50.0);
      expect(FeedbackNormalization.normalizeSales(1500)).toBe(100.0); // Clamped
      expect(FeedbackNormalization.normalizeReview(4.5)).toBe(90.0);
      expect(FeedbackNormalization.normalizeConversion(10.0)).toBe(50.0);
      expect(FeedbackNormalization.normalizeCtr(5.0)).toBe(50.0);
      expect(FeedbackNormalization.normalizeRoi(500.0)).toBe(50.0);
      expect(FeedbackNormalization.normalizeProfit(5000000.0)).toBe(50.0);
      expect(FeedbackNormalization.normalizeFavorite(250)).toBe(50.0);
      expect(FeedbackNormalization.normalizeRefund(5)).toBe(10.0);
    });

    it('should correctly assign grades based on overall scores', () => {
      expect(FeedbackGrading.calculateGrade(98.5)).toBe('S');
      expect(FeedbackGrading.calculateGrade(95.0)).toBe('S');
      expect(FeedbackGrading.calculateGrade(94.999)).toBe('A+');
      expect(FeedbackGrading.calculateGrade(90.0)).toBe('A+');
      expect(FeedbackGrading.calculateGrade(89.99)).toBe('A');
      expect(FeedbackGrading.calculateGrade(79.99)).toBe('B');
      expect(FeedbackGrading.calculateGrade(65.0)).toBe('C');
      expect(FeedbackGrading.calculateGrade(59.99)).toBe('D');
    });

    it('should calculate deterministic overall score and subgroup metrics', () => {
      const result = FeedbackCalculator.calculate({
        sales_count: 500, // Normalized: 50.0 (w=30) -> 15.0
        review_score: 4.5, // Normalized: 90.0 (w=15) -> 13.5
        conversion_rate: 10.0, // Normalized: 50.0 (w=15) -> 7.5
        ctr: 5.0, // Normalized: 50.0 (w=10) -> 5.0
        roi: 500.0, // Normalized: 50.0 (w=15) -> 7.5
        profit: 5000000.0, // Normalized: 50.0 (w=10) -> 5.0
        favorite_count: 250, // Normalized: 50.0 (w=5) -> 2.5
        refund_count: 5, // Normalized: 10.0 (penalty = 10 * 0.1 = 1.0)
      });

      // Sum of positive weighted scores = 15.0 + 13.5 + 7.5 + 5.0 + 7.5 + 5.0 + 2.5 = 56.0
      // Overall = 56.0 - 1.0 = 55.0
      expect(result.overallScore).toBe(55.0);
      expect(result.salesScore).toBe(50.0);
      expect(result.reviewScore).toBe(90.0);
      expect(result.conversionScore).toBe(50.0);
      expect(result.engagementScore).toBe(50.0);
      expect(result.profitabilityScore).toBe(50.0);
    });

    it('should pass weights validation if sum is 100', () => {
      expect(() => validateWeights()).not.toThrow();
    });

    it('should trigger process.exit if weights sum is invalid', () => {
      const originalExit = process.exit;
      const mockExit = vi.fn();
      process.exit = mockExit as any;

      // Tamper weights sum to exceed 100
      const originalSales = FEEDBACK_WEIGHTS.sales;
      FEEDBACK_WEIGHTS.sales = 999;

      try {
        validateWeights();
        expect(mockExit).toHaveBeenCalledWith(1);
      } finally {
        FEEDBACK_WEIGHTS.sales = originalSales;
        process.exit = originalExit;
      }
    });
  });

  describe('API Integrations / Authentication Checks', () => {
    it('should reject calculation without authentication', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback/calculate',
        payload: { performanceId },
      });
      expect(response.statusCode).toBe(401);
    });

    it('should block calculation when requester does not own target performance record', async () => {
      setResolver(() => {
        // verifyPerformanceOwner -> false
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback/calculate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { performanceId },
      });

      expect(response.statusCode).toBe(403);
    });
  });

  describe('POST /api/v1/feedback/calculate', () => {
    it('should calculate and persist feedback scores successfully', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyPerformanceOwner -> true
        if (callCount === 1) {
          return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        }
        // 2. Fetch Performance Snapshot
        if (callCount === 2) {
          return Promise.resolve({
            data: {
              id: performanceId,
              sales_count: 800,
              review_score: 4.8,
              conversion_score: 12.5,
              favorite_count: 100,
              refund_count: 2,
            },
            error: null,
          });
        }
        // 3. Fetch Metrics Snapshot
        if (callCount === 3) {
          return Promise.resolve({
            data: {
              performance_id: performanceId,
              ctr: 3.5,
              roi: 450.0,
              profit: 3500000.0,
            },
            error: null,
          });
        }
        // 4. Check existing feedback -> null
        if (callCount === 4) {
          return Promise.resolve({ data: null, error: null });
        }
        // 5. Create Entity (Insert)
        if (callCount === 5) {
          return Promise.resolve({
            data: {
              id: feedbackId,
              performance_id: performanceId,
              calculation_version: 1,
              sales_score: 80,
              review_score: 96,
              conversion_score: 62.5,
              engagement_score: 35.0,
              profitability_score: 45.0,
              refund_penalty: 4.0,
              overall_score: 75.5,
              grade: 'B',
              weight_snapshot: FEEDBACK_WEIGHTS,
              formula_version: 'v1',
              calculated_at: new Date().toISOString(),
              created_at: new Date().toISOString(),
            },
            error: null,
          });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback/calculate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { performanceId },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.success).toBe(true);
      expect(body.data.feedbackId).toBe(feedbackId);
      expect(body.data.grade).toBe('B');
      expect(body.data.calculationVersion).toBe(1);
    });

    it('should throw 409 Conflict if feedback is already calculated', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyPerformanceOwner
        if (callCount === 1) return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        // 2. Fetch Performance
        if (callCount === 2) return Promise.resolve({ data: { id: performanceId }, error: null });
        // 3. Fetch Metrics
        if (callCount === 3) return Promise.resolve({ data: { performance_id: performanceId }, error: null });
        // 4. Check existing feedback -> returns existing record
        return Promise.resolve({ data: { id: feedbackId, calculation_version: 1 }, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback/calculate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { performanceId },
      });

      expect(response.statusCode).toBe(409);
    });
  });

  describe('POST /api/v1/feedback/recalculate', () => {
    it('should recalculate and increment calculation version', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyPerformanceOwner
        if (callCount === 1) return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        // 2. Fetch Performance
        if (callCount === 2) {
          return Promise.resolve({
            data: { id: performanceId, sales_count: 500, review_score: 4.0, favorite_count: 10, refund_count: 0 },
            error: null,
          });
        }
        // 3. Fetch Metrics
        if (callCount === 3) return Promise.resolve({ data: { ctr: 1.0, roi: 10.0, profit: 100 }, error: null });
        // 4. Fetch existing feedback -> returns version 1
        if (callCount === 4) return Promise.resolve({ data: { id: feedbackId, calculation_version: 1 }, error: null });
        // 5. Update existing feedback
        return Promise.resolve({
          data: {
            id: feedbackId,
            performance_id: performanceId,
            calculation_version: 2, // version incremented
            overall_score: 72.0,
            grade: 'B',
            weight_snapshot: FEEDBACK_WEIGHTS,
            formula_version: 'v1',
            calculated_at: new Date().toISOString(),
            created_at: new Date().toISOString(),
          },
          error: null,
        });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/feedback/recalculate',
        headers: { authorization: `Bearer ${testToken}` },
        payload: { performanceId },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.calculationVersion).toBe(2);
    });
  });

  describe('GET /api/v1/feedback/latest/:productId', () => {
    it('should retrieve the latest calculated feedback score', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyProductOwner
        if (callCount === 1) return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        // 2. findLatest
        return Promise.resolve({
          data: {
            id: feedbackId,
            performance_id: performanceId,
            calculation_version: 1,
            overall_score: 88.5,
            grade: 'A',
            weight_snapshot: FEEDBACK_WEIGHTS,
          },
          error: null,
        });
      });

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/feedback/latest/${productId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.data.overallScore).toBe(88.5);
      expect(body.data.grade).toBe('A');
    });
  });
});
