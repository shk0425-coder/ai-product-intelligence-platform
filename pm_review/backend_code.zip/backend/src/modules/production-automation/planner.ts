import { PlannerExecutionError } from '@/common/errors/index.js';

export interface PlannerOutput {
  strategyId: string;
  strategyOutput: string;
  tokensConsumed: number;
}

export const ProductionPlanner = {
  async execute(prompt: string, userRequest: string): Promise<PlannerOutput> {
    // 1. Enforce strict rule: Planner must NOT call DB/Repository/Events
    // This is a pure planning agent.

    // 2. Error triggering mock condition
    if (userRequest.toLowerCase().includes('trigger planner error')) {
      throw new PlannerExecutionError('Mock Planner Strategy Generation Failure occurred');
    }

    // Simulate small latency for LLM inference (10ms)
    await new Promise((resolve) => setTimeout(resolve, 10));

    // Mock output matching prompt context footprint
    const strategyId = 'strategy-' + crypto.randomUUID().substring(0, 8);
    const strategyOutput = `AI Product Strategy Generated from Prompt (Checksum: ${prompt.substring(0, 10)})`;

    return {
      strategyId,
      strategyOutput,
      tokensConsumed: Math.ceil(prompt.length / 4) + 120, // Prompt tokens + generated tokens
    };
  },
};
export default ProductionPlanner;
