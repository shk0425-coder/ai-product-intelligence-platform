import { MetricsRegistry } from '../../observability/metrics/registry.js';

export class RecoveryIdempotency {
  private static readonly executionStore = new Set<string>();

  static isDuplicate(executionId: string): boolean {
    if (this.executionStore.has(executionId)) {
      MetricsRegistry.counter('recovery_duplicate_total', 1, { executionId });
      return true; // Already executed
    }
    return false;
  }

  static recordExecution(executionId: string): void {
    this.executionStore.add(executionId);
    MetricsRegistry.counter('recovery_idempotent_total', 1, { executionId });
  }

  static clear(): void {
    this.executionStore.clear();
  }
}
export default RecoveryIdempotency;
