export interface AuditPlaceholder {}
