import { MetricsRegistry } from '../../observability/metrics/registry.js';

export class UsageMeter {
  private static usageCount = 0;

  static recordUsage(units: number): void {
    this.usageCount += units;
    MetricsRegistry.counter('usage_total', units);
  }

  static getUsage(): number {
    return this.usageCount;
  }

  static clear(): void {
    this.usageCount = 0;
  }
}
export default UsageMeter;
