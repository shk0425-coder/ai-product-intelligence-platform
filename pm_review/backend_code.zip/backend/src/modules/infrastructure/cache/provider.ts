export interface CacheProvider {
  get(key: string): Promise<Record<string, unknown> | null>;
  set(key: string, value: Record<string, unknown>, ttlMs: number): Promise<void>;
  delete(key: string): Promise<void>;
  exists(key: string): Promise<boolean>;
  expire(key: string, ttlMs: number): Promise<boolean>;
  ttl(key: string): Promise<number>;
  increment(key: string): Promise<number>;
  decrement(key: string): Promise<number>;
  clearNamespace(namespace: string): Promise<void>;
}
