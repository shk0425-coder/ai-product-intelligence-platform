-- 33_create_performance_foundation.sql
-- Performance Domain Foundation tables and atomic upsert RPC function

BEGIN;

-- 1. product_performance Table
CREATE TABLE IF NOT EXISTS public.product_performance (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    product_id UUID NOT NULL,
    analysis_run_id UUID NOT NULL,
    strategy_id UUID NULL DEFAULT NULL,
    creative_id UUID NULL DEFAULT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    sales_count INTEGER NOT NULL DEFAULT 0,
    sales_amount NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    refund_count INTEGER NOT NULL DEFAULT 0,
    review_count INTEGER NOT NULL DEFAULT 0,
    review_score NUMERIC(2, 1) NOT NULL DEFAULT 0.0,
    favorite_count INTEGER NOT NULL DEFAULT 0,
    version INTEGER NOT NULL DEFAULT 1,
    last_collected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ NULL DEFAULT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NULL DEFAULT NULL,
    deleted_by UUID NULL DEFAULT NULL,

    CONSTRAINT pk_product_performance PRIMARY KEY (id),
    CONSTRAINT uq_product_performance_period UNIQUE (workspace_id, product_id, analysis_run_id, period_start, period_end)
);

COMMENT ON TABLE public.product_performance IS '스토어 판매 성과 원본 및 수집 스냅샷 정보 테이블';
COMMENT ON COLUMN public.product_performance.id IS '성과 스냅샷 식별 UUID';
COMMENT ON COLUMN public.product_performance.workspace_id IS '참조 작업 공간 UUID';
COMMENT ON COLUMN public.product_performance.product_id IS '참조 상품 UUID';
COMMENT ON COLUMN public.product_performance.analysis_run_id IS '참조 분석 실행 차수 UUID';
COMMENT ON COLUMN public.product_performance.strategy_id IS '참조 상품화 기획 보고서 UUID';
COMMENT ON COLUMN public.product_performance.creative_id IS '참조 크리에이티브 기획서 UUID';
COMMENT ON COLUMN public.product_performance.period_start IS '조회 성과 시작 날짜';
COMMENT ON COLUMN public.product_performance.period_end IS '조회 성과 종료 날짜';
COMMENT ON COLUMN public.product_performance.sales_count IS '기간 내 누적 판매 건수';
COMMENT ON COLUMN public.product_performance.sales_amount IS '기간 내 누적 판매 금액';
COMMENT ON COLUMN public.product_performance.refund_count IS '기간 내 누적 환불 건수';
COMMENT ON COLUMN public.product_performance.review_count IS '기간 내 누적 신규 리뷰 수';
COMMENT ON COLUMN public.product_performance.review_score IS '기간 내 신규 리뷰 평균 평점';
COMMENT ON COLUMN public.product_performance.favorite_count IS '기간 내 누적 찜/좋아요 건수';
COMMENT ON COLUMN public.product_performance.version IS '레코드 갱신 버전 차수 (멱등 업데이트 시 누적)';
COMMENT ON COLUMN public.product_performance.last_collected_at IS '최근 정보 수집 일시';
COMMENT ON COLUMN public.product_performance.created_at IS '생성 일시';
COMMENT ON COLUMN public.product_performance.updated_at IS '수정 일시';
COMMENT ON COLUMN public.product_performance.deleted_at IS '소프트 딜리트 삭제 일시';
COMMENT ON COLUMN public.product_performance.created_by IS '최초 등록 행위자 UUID';
COMMENT ON COLUMN public.product_performance.updated_by IS '수정 행위자 UUID';
COMMENT ON COLUMN public.product_performance.deleted_by IS '삭제 행위자 UUID';

-- 2. performance_metrics Table
CREATE TABLE IF NOT EXISTS public.performance_metrics (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    performance_id UUID NOT NULL,
    impressions INTEGER NOT NULL DEFAULT 0,
    clicks INTEGER NOT NULL DEFAULT 0,
    conversion_count INTEGER NOT NULL DEFAULT 0,
    conversion_rate NUMERIC(5, 2) NOT NULL DEFAULT 0.00,
    ctr NUMERIC(5, 2) NOT NULL DEFAULT 0.00,
    ad_cost NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    profit NUMERIC(15, 2) NOT NULL DEFAULT 0.00,
    margin_rate NUMERIC(5, 2) NOT NULL DEFAULT 0.00,
    roi NUMERIC(8, 2) NOT NULL DEFAULT 0.00,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_performance_metrics PRIMARY KEY (id)
);

COMMENT ON TABLE public.performance_metrics IS '스토어 성과 세부 KPI 통계 지표 테이블';
COMMENT ON COLUMN public.performance_metrics.id IS '성과 세부 KPI 식별 UUID';
COMMENT ON COLUMN public.performance_metrics.performance_id IS '부모 스토어 성과 스냅샷 UUID';
COMMENT ON COLUMN public.performance_metrics.impressions IS '누적 노출수';
COMMENT ON COLUMN public.performance_metrics.clicks IS '누적 클릭수';
COMMENT ON COLUMN public.performance_metrics.conversion_count IS '누적 구매 전환 건수';
COMMENT ON COLUMN public.performance_metrics.conversion_rate IS '구매 전환율 (%)';
COMMENT ON COLUMN public.performance_metrics.ctr IS '노출 대비 클릭률 CTR (%)';
COMMENT ON COLUMN public.performance_metrics.ad_cost IS '광고 집행 금액 (광고비)';
COMMENT ON COLUMN public.performance_metrics.profit IS '순수익 금액 (매출 - 매출원가 - 광고비 등)';
COMMENT ON COLUMN public.performance_metrics.margin_rate IS '수익 마진율 (%)';
COMMENT ON COLUMN public.performance_metrics.roi IS '광고비 대비 수익률 ROI (%)';

-- 3. performance_sources Table
CREATE TABLE IF NOT EXISTS public.performance_sources (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    performance_id UUID NOT NULL,
    marketplace_code VARCHAR(50) NOT NULL,
    marketplace_name VARCHAR(100) NOT NULL,
    collection_job_id UUID NULL DEFAULT NULL,
    source_version INTEGER NOT NULL DEFAULT 1,
    collected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    raw_payload_hash VARCHAR(128) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_performance_sources PRIMARY KEY (id)
);

COMMENT ON TABLE public.performance_sources IS '성과 데이터 수집 채널 및 연동 메타데이터 정보 테이블';
COMMENT ON COLUMN public.performance_sources.id IS '성과 소스 정보 식별 UUID';
COMMENT ON COLUMN public.performance_sources.performance_id IS '부모 스토어 성과 스냅샷 UUID';
COMMENT ON COLUMN public.performance_sources.marketplace_code IS '쇼핑몰 구분 코드 (예: NAVER, COUPANG 등)';
COMMENT ON COLUMN public.performance_sources.marketplace_name IS '쇼핑몰 표기명';
COMMENT ON COLUMN public.performance_sources.collection_job_id IS '연동 배치 작업 작업 식별 UUID';
COMMENT ON COLUMN public.performance_sources.source_version IS '원본 소스 데이터 버전';
COMMENT ON COLUMN public.performance_sources.collected_at IS '해당 소스 수집 완료 일시';
COMMENT ON COLUMN public.performance_sources.raw_payload_hash IS '수집 원본 무결성 검증용 SHA-256 해시값';

-- 4. performance_audit_logs Table
CREATE TABLE IF NOT EXISTS public.performance_audit_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    performance_id UUID NOT NULL,
    action VARCHAR(20) NOT NULL,
    actor_id UUID NOT NULL,
    version INTEGER NOT NULL,
    changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,

    CONSTRAINT pk_performance_audit_logs PRIMARY KEY (id)
);

COMMENT ON TABLE public.performance_audit_logs IS '스토어 판매 성과 이력의 생성/수정/삭제 행위자 감사 로그 테이블';
COMMENT ON COLUMN public.performance_audit_logs.id IS '감사 기록 식별 UUID';
COMMENT ON COLUMN public.performance_audit_logs.performance_id IS '부모 스토어 성과 스냅샷 UUID';
COMMENT ON COLUMN public.performance_audit_logs.action IS '수행 행위 유형 (CREATE | UPDATE | DELETE | UPSERT)';
COMMENT ON COLUMN public.performance_audit_logs.actor_id IS '행위를 수행한 유저 식별 UUID';
COMMENT ON COLUMN public.performance_audit_logs.version IS '행위 직후의 레코드 버전 차수';
COMMENT ON COLUMN public.performance_audit_logs.changed_at IS '행위 발생 일시';
COMMENT ON COLUMN public.performance_audit_logs.metadata IS '이전/이후 변경 사항 메타데이터 백업 (JSONB)';

-- 5. Foreign Key Constraints
ALTER TABLE public.product_performance
    ADD CONSTRAINT fk_performance_workspaces FOREIGN KEY (workspace_id) REFERENCES public.workspaces(workspace_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_performance_products FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_performance_analysis FOREIGN KEY (analysis_run_id) REFERENCES public.analysis_runs(run_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_performance_strategy FOREIGN KEY (strategy_id) REFERENCES public.product_strategies(strategy_id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_performance_creative FOREIGN KEY (creative_id) REFERENCES public.creative_briefs(brief_id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_performance_created_by FOREIGN KEY (created_by) REFERENCES public.users(user_id) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_performance_updated_by FOREIGN KEY (updated_by) REFERENCES public.users(user_id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_performance_deleted_by FOREIGN KEY (deleted_by) REFERENCES public.users(user_id) ON DELETE SET NULL;

ALTER TABLE public.performance_metrics
    ADD CONSTRAINT fk_metrics_performance FOREIGN KEY (performance_id) REFERENCES public.product_performance(id) ON DELETE CASCADE;

ALTER TABLE public.performance_sources
    ADD CONSTRAINT fk_source_performance FOREIGN KEY (performance_id) REFERENCES public.product_performance(id) ON DELETE CASCADE;

ALTER TABLE public.performance_audit_logs
    ADD CONSTRAINT fk_audit_performance FOREIGN KEY (performance_id) REFERENCES public.product_performance(id) ON DELETE CASCADE,
    ADD CONSTRAINT fk_audit_actor FOREIGN KEY (actor_id) REFERENCES public.users(user_id) ON DELETE RESTRICT;

-- 6. Indexes for B-Tree Performance Optimization
CREATE INDEX IF NOT EXISTS idx_performance_workspace ON public.product_performance(workspace_id);
CREATE INDEX IF NOT EXISTS idx_performance_product ON public.product_performance(product_id);
CREATE INDEX IF NOT EXISTS idx_performance_analysis ON public.product_performance(analysis_run_id);
CREATE INDEX IF NOT EXISTS idx_performance_period ON public.product_performance(period_start, period_end);
CREATE INDEX IF NOT EXISTS idx_metrics_performance ON public.performance_metrics(performance_id);
CREATE INDEX IF NOT EXISTS idx_source_marketplace ON public.performance_sources(marketplace_code);
CREATE INDEX IF NOT EXISTS idx_source_collection ON public.performance_sources(collection_job_id);
CREATE INDEX IF NOT EXISTS idx_audit_performance ON public.performance_audit_logs(performance_id);
CREATE INDEX IF NOT EXISTS idx_performance_deleted ON public.product_performance(deleted_at) WHERE deleted_at IS NULL;

-- 7. PL/pgSQL Function for Atomic Performance Upsert
CREATE OR REPLACE FUNCTION public.upsert_performance_foundation(
    p_workspace_id UUID,
    p_product_id UUID,
    p_analysis_run_id UUID,
    p_strategy_id UUID,
    p_creative_id UUID,
    p_period_start DATE,
    p_period_end DATE,
    p_sales_count INT,
    p_sales_amount NUMERIC(15,2),
    p_refund_count INT,
    p_review_count INT,
    p_review_score NUMERIC(2,1),
    p_favorite_count INT,
    p_created_by UUID,
    p_metrics JSONB,
    p_source JSONB
) RETURNS JSONB AS $$
DECLARE
    v_performance_id UUID;
    v_version INT;
    v_action VARCHAR(20);
    v_prev_performance JSONB := NULL;
    v_curr_performance JSONB;
    v_prev_metrics JSONB := NULL;
    v_prev_source JSONB := NULL;
BEGIN
    -- 1. 기존 레코드 확인 (이전 상태 백업)
    SELECT id, version, to_jsonb(p.*) 
    INTO v_performance_id, v_version, v_prev_performance
    FROM public.product_performance p
    WHERE workspace_id = p_workspace_id
      AND product_id = p_product_id
      AND analysis_run_id = p_analysis_run_id
      AND period_start = p_period_start
      AND period_end = p_period_end
      AND deleted_at IS NULL;

    IF v_performance_id IS NOT NULL THEN
        v_action := 'UPSERT';
        v_version := v_version + 1;

        -- 기존 자식 데이터 백업
        SELECT to_jsonb(m.*) INTO v_prev_metrics FROM public.performance_metrics m WHERE performance_id = v_performance_id;
        SELECT to_jsonb(s.*) INTO v_prev_source FROM public.performance_sources s WHERE performance_id = v_performance_id;
        
        UPDATE public.product_performance
        SET strategy_id = p_strategy_id,
            creative_id = p_creative_id,
            sales_count = p_sales_count,
            sales_amount = p_sales_amount,
            refund_count = p_refund_count,
            review_count = p_review_count,
            review_score = p_review_score,
            favorite_count = p_favorite_count,
            version = v_version,
            last_collected_at = NOW(),
            updated_at = NOW(),
            updated_by = p_created_by
        WHERE id = v_performance_id;
    ELSE
        v_action := 'CREATE';
        v_version := 1;
        
        INSERT INTO public.product_performance (
            workspace_id, product_id, analysis_run_id, strategy_id, creative_id,
            period_start, period_end, sales_count, sales_amount, refund_count,
            review_count, review_score, favorite_count, version, created_by
        ) VALUES (
            p_workspace_id, p_product_id, p_analysis_run_id, p_strategy_id, p_creative_id,
            p_period_start, p_period_end, p_sales_count, p_sales_amount, p_refund_count,
            p_review_count, p_review_score, p_favorite_count, v_version, p_created_by
        ) RETURNING id INTO v_performance_id;
    END IF;

    -- 2. Metrics 갱신 (Snapshot 전체 교체)
    DELETE FROM public.performance_metrics WHERE performance_id = v_performance_id;
    INSERT INTO public.performance_metrics (
        performance_id, impressions, clicks, conversion_count, conversion_rate,
        ctr, ad_cost, profit, margin_rate, roi
    ) VALUES (
        v_performance_id,
        (p_metrics->>'impressions')::INT,
        (p_metrics->>'clicks')::INT,
        (p_metrics->>'conversionCount')::INT,
        (p_metrics->>'conversionRate')::NUMERIC(5,2),
        (p_metrics->>'ctr')::NUMERIC(5,2),
        (p_metrics->>'adCost')::NUMERIC(15,2),
        (p_metrics->>'profit')::NUMERIC(15,2),
        (p_metrics->>'marginRate')::NUMERIC(5,2),
        (p_metrics->>'roi')::NUMERIC(8,2)
    );

    -- 3. Sources 갱신 (Snapshot 전체 교체)
    DELETE FROM public.performance_sources WHERE performance_id = v_performance_id;
    INSERT INTO public.performance_sources (
        performance_id, marketplace_code, marketplace_name, collection_job_id,
        source_version, collected_at, raw_payload_hash
    ) VALUES (
        v_performance_id,
        (p_source->>'marketplaceCode')::VARCHAR(50),
        (p_source->>'marketplaceName')::VARCHAR(100),
        CASE WHEN (p_source->>'collectionJobId') IS NOT NULL AND (p_source->>'collectionJobId') <> '' THEN (p_source->>'collectionJobId')::UUID ELSE NULL END,
        (p_source->>'sourceVersion')::INT,
        (p_source->>'collectedAt')::TIMESTAMPTZ,
        (p_source->>'rawPayloadHash')::VARCHAR(128)
    );

    -- 최종 엔티티 JSON 생성
    SELECT to_jsonb(p.*) INTO v_curr_performance
    FROM public.product_performance p
    WHERE id = v_performance_id;

    -- 4. Audit Log 기록
    INSERT INTO public.performance_audit_logs (
        performance_id, action, actor_id, version, metadata
    ) VALUES (
        v_performance_id,
        v_action,
        p_created_by,
        v_version,
        jsonb_build_object(
            'previous', CASE WHEN v_prev_performance IS NOT NULL THEN jsonb_build_object(
                'performance', v_prev_performance,
                'metrics', v_prev_metrics,
                'source', v_prev_source
            ) ELSE NULL END,
            'current', jsonb_build_object(
                'performance', v_curr_performance,
                'metrics', p_metrics,
                'source', p_source
            )
        )
    );

    RETURN v_curr_performance;
END;
$$ LANGUAGE plpgsql;

COMMIT;
