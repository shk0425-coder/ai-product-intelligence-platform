import { z } from 'zod';

const metricsSchema = z.object({
  impressions: z.number().int().nonnegative('Impressions must be a non-negative integer'),
  clicks: z.number().int().nonnegative('Clicks must be a non-negative integer'),
  conversionCount: z.number().int().nonnegative('Conversion count must be a non-negative integer'),
  conversionRate: z.number().min(0).max(100, 'Conversion rate must be between 0 and 100'),
  ctr: z.number().min(0).max(100, 'CTR must be between 0 and 100'),
  adCost: z.number().nonnegative('Ad cost must be a non-negative number'),
  profit: z.number(),
  marginRate: z.number().min(0).max(100, 'Margin rate must be between 0 and 100'),
  roi: z.number(),
});

const sourceSchema = z.object({
  marketplaceCode: z.string().trim().min(1, 'Marketplace code is required').max(50),
  marketplaceName: z.string().trim().min(1, 'Marketplace name is required').max(100),
  collectionJobId: z.string().uuid('Invalid collection job ID').nullable().optional(),
  sourceVersion: z.number().int().positive('Source version must be a positive integer'),
  collectedAt: z.string().datetime({ message: 'Invalid datetime format for collectedAt' }),
  rawPayloadHash: z.string().trim().length(64, 'Payload hash must be exactly 64 hex characters'),
});

export const createPerformanceSchema = z
  .object({
    workspaceId: z.string().uuid('Invalid workspace ID format'),
    productId: z.string().uuid('Invalid product ID format'),
    analysisRunId: z.string().uuid('Invalid analysis run ID format'),
    strategyId: z.string().uuid('Invalid strategy ID format').nullable().optional(),
    creativeId: z.string().uuid('Invalid creative ID format').nullable().optional(),
    periodStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format (YYYY-MM-DD)'),
    periodEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format (YYYY-MM-DD)'),
    salesCount: z.number().int().nonnegative('Sales count must be a non-negative integer'),
    salesAmount: z.number().nonnegative('Sales amount must be a non-negative number'),
    refundCount: z.number().int().nonnegative('Refund count must be a non-negative integer'),
    reviewCount: z.number().int().nonnegative('Review count must be a non-negative integer'),
    reviewScore: z.number().min(0).max(5, 'Review score must be between 0.0 and 5.0'),
    favoriteCount: z.number().int().nonnegative('Favorite count must be a non-negative integer'),
    metrics: metricsSchema,
    source: sourceSchema,
  })
  .refine((data) => new Date(data.periodStart) <= new Date(data.periodEnd), {
    message: 'periodStart must be less than or equal to periodEnd',
    path: ['periodEnd'],
  })
  .refine((data) => data.refundCount <= data.salesCount, {
    message: 'refundCount must be less than or equal to salesCount',
    path: ['refundCount'],
  });

export const updatePerformanceSchema = z
  .object({
    strategyId: z.string().uuid('Invalid strategy ID format').nullable().optional(),
    creativeId: z.string().uuid('Invalid creative ID format').nullable().optional(),
    salesCount: z.number().int().nonnegative('Sales count must be a non-negative integer'),
    salesAmount: z.number().nonnegative('Sales amount must be a non-negative number'),
    refundCount: z.number().int().nonnegative('Refund count must be a non-negative integer'),
    reviewCount: z.number().int().nonnegative('Review count must be a non-negative integer'),
    reviewScore: z.number().min(0).max(5, 'Review score must be between 0.0 and 5.0'),
    favoriteCount: z.number().int().nonnegative('Favorite count must be a non-negative integer'),
    metrics: metricsSchema,
    source: sourceSchema,
  })
  .refine((data) => data.refundCount <= data.salesCount, {
    message: 'refundCount must be less than or equal to salesCount',
    path: ['refundCount'],
  });

export const performanceIdParamSchema = z.object({
  id: z.string().uuid('Invalid performance ID format'),
});

export const performanceProductParamSchema = z.object({
  productId: z.string().uuid('Invalid product ID format'),
});

export const performanceAnalysisParamSchema = z.object({
  analysisRunId: z.string().uuid('Invalid analysis run ID format'),
});

export const performanceHistoryQuerySchema = z.object({
  startDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format (YYYY-MM-DD)')
    .optional(),
  endDate: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format (YYYY-MM-DD)')
    .optional(),
  page: z.coerce.number().int().positive().max(100000).default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),
  sort: z
    .enum(['period_start', 'period_end', 'sales_count', 'sales_amount', 'created_at'])
    .default('period_start'),
  order: z.enum(['asc', 'desc']).default('desc'),
});

export const performanceQuerySchema = z.object({
  page: z.coerce.number().int().positive().max(100000).default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),
  sort: z
    .enum(['period_start', 'period_end', 'sales_count', 'sales_amount', 'created_at'])
    .default('period_start'),
  order: z.enum(['asc', 'desc']).default('desc'),
});

export type CreatePerformanceInput = z.infer<typeof createPerformanceSchema>;
export type UpdatePerformanceInput = z.infer<typeof updatePerformanceSchema>;
export type PerformanceIdParamInput = z.infer<typeof performanceIdParamSchema>;
export type PerformanceProductParamInput = z.infer<typeof performanceProductParamSchema>;
export type PerformanceAnalysisParamInput = z.infer<typeof performanceAnalysisParamSchema>;
export type PerformanceHistoryQueryInput = z.infer<typeof performanceHistoryQuerySchema>;
export type PerformanceQueryInput = z.infer<typeof performanceQuerySchema>;
