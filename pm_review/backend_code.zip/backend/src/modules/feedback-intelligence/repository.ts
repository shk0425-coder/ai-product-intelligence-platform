import { BaseRepository } from '@/repositories/implementations/base.repository.js';
import { FeedbackIntelligenceEntity, IFeedbackIntelligenceRepository } from './types.js';
import { SupabaseClient } from '@supabase/supabase-js';

export class FeedbackIntelligenceRepository
  extends BaseRepository<FeedbackIntelligenceEntity>
  implements IFeedbackIntelligenceRepository
{
  constructor(supabase: SupabaseClient) {
    super(supabase, 'feedback_intelligence');
  }

  async findByFeedback(
    feedbackScoreId: string,
    ruleVersion?: string,
  ): Promise<FeedbackIntelligenceEntity | null> {
    let query = this.supabase
      .from(this.tableName)
      .select('*')
      .eq('feedback_score_id', feedbackScoreId);

    if (ruleVersion) {
      query = query.eq('rule_version', ruleVersion);
    } else {
      query = query.order('analysis_version', { ascending: false });
    }

    const { data, error } = await query.limit(1).maybeSingle();
    if (error || !data) return null;
    return data as FeedbackIntelligenceEntity;
  }

  async findLatest(productId: string): Promise<FeedbackIntelligenceEntity | null> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select(
        `
        *,
        feedback_scores!inner(
          product_performance!inner(product_id)
        )
      `,
      )
      .eq('feedback_scores.product_performance.product_id', productId)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error || !data) return null;

    // Discard nested join payload mapping to keep strict return signature
    const { feedback_scores: _, ...entity } = data as unknown as { feedback_scores: unknown };
    return entity as FeedbackIntelligenceEntity;
  }

  async findHistory(productId: string): Promise<FeedbackIntelligenceEntity[]> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select(
        `
        *,
        feedback_scores!inner(
          product_performance!inner(product_id)
        )
      `,
      )
      .eq('feedback_scores.product_performance.product_id', productId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((item: unknown) => {
      const { feedback_scores: _, ...entity } = item as { feedback_scores: unknown };
      return entity as FeedbackIntelligenceEntity;
    });
  }

  // Ownership verification helper methods using fast inner joins
  async verifyProductOwner(productId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('products')
      .select(
        `
        product_id,
        workspaces!inner(org_id)
      `,
      )
      .eq('product_id', productId)
      .is('deleted_at', null)
      .maybeSingle();
    if (error || !data) return false;
    const product = data as unknown as { workspaces: { org_id: string } };
    return product.workspaces?.org_id === userId;
  }

  async verifyFeedbackOwner(feedbackScoreId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('feedback_scores')
      .select(
        `
        id,
        product_performance!inner(
          workspaces!inner(org_id)
        )
      `,
      )
      .eq('id', feedbackScoreId)
      .maybeSingle();
    if (error || !data) return false;
    const feedback = data as unknown as { product_performance: { workspaces: { org_id: string } } };
    return feedback.product_performance?.workspaces?.org_id === userId;
  }

  async verifyIntelligenceOwner(intelligenceId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from(this.tableName)
      .select(
        `
        id,
        feedback_scores!inner(
          product_performance!inner(
            workspaces!inner(org_id)
          )
        )
      `,
      )
      .eq('id', intelligenceId)
      .maybeSingle();
    if (error || !data) return false;
    const intel = data as unknown as {
      feedback_scores: { product_performance: { workspaces: { org_id: string } } };
    };
    return intel.feedback_scores?.product_performance?.workspaces?.org_id === userId;
  }
}
export default FeedbackIntelligenceRepository;
