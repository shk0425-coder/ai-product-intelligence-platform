import { FastifyRequest, FastifyReply } from 'fastify';
import { JobQueueService } from './service.js';
import { EnqueueJobDto, JobActionDto } from './dto.js';

export class JobQueueController {
  constructor(private readonly service: JobQueueService) {}

  async enqueue(req: FastifyRequest<{ Body: EnqueueJobDto }>, reply: FastifyReply) {
    const actorId = (req as { user?: { orgId?: string } }).user?.orgId || 'default-user';
    const result = await this.service.enqueueJob(req.body, actorId);
    return reply.status(201).send({ data: result });
  }

  async retry(req: FastifyRequest<{ Body: JobActionDto }>, reply: FastifyReply) {
    const actorId = (req as { user?: { orgId?: string } }).user?.orgId || 'default-user';
    const result = await this.service.retryJob(req.body.jobId, actorId);
    return reply.status(200).send({ data: result });
  }

  async cancel(req: FastifyRequest<{ Body: JobActionDto }>, reply: FastifyReply) {
    const actorId = (req as { user?: { orgId?: string } }).user?.orgId || 'default-user';
    const result = await this.service.cancelJob(req.body.jobId, actorId);
    return reply.status(200).send({ data: result });
  }

  async getStatus(req: FastifyRequest<{ Params: { jobId: string } }>, reply: FastifyReply) {
    const actorId = (req as { user?: { orgId?: string } }).user?.orgId || 'default-user';
    const result = await this.service.getJobStatus(req.params.jobId, actorId);
    return reply.status(200).send({ data: result });
  }

  async getHistory(req: FastifyRequest<{ Querystring: { workspaceId: string } }>, reply: FastifyReply) {
    const actorId = (req as { user?: { orgId?: string } }).user?.orgId || 'default-user';
    const result = await this.service.getJobHistory(req.query.workspaceId, actorId);
    return reply.status(200).send({ data: result });
  }

  async getDeadLetters(req: FastifyRequest, reply: FastifyReply) {
    const actorId = (req as { user?: { orgId?: string } }).user?.orgId || 'default-user';
    const result = await this.service.getDeadLetters(actorId);
    return reply.status(200).send({ data: result });
  }

  async recoverDeadLetter(req: FastifyRequest<{ Body: { deadLetterId: string } }>, reply: FastifyReply) {
    const actorId = (req as { user?: { orgId?: string } }).user?.orgId || 'default-user';
    const result = await this.service.recoverDeadLetter(req.body.deadLetterId, actorId);
    return reply.status(200).send({ data: result });
  }
}
