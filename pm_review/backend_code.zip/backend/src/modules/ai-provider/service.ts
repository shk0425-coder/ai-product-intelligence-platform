import { AIProviderRepository } from './repository.js';
import { AIGateway } from './gateway.js';
import { PatchAIProviderConfigDto, TestAIProviderDto, AIProviderConfigDto, AIProviderHealthDto } from './dto.js';
import { AIProviderConfigEntity, GenerateResponse } from './types.js';
import { AIProviderMapper } from './mapper.js';
import { ProviderMetricsCollector } from './provider-metrics.js';
import { ProviderHealthChecker } from './provider-health.js';
import { ProviderNotFoundError } from '../../common/errors/index.js';

export class AIProviderService {
  private readonly gateway: AIGateway;

  constructor(private readonly repository: AIProviderRepository) {
    this.gateway = new AIGateway(repository);
  }

  async getConfigs(): Promise<AIProviderConfigDto[]> {
    const configs = await this.repository.findConfigs();
    return AIProviderMapper.toConfigDtoList(configs);
  }

  async patchConfig(provider: string, model: string, dto: PatchAIProviderConfigDto): Promise<AIProviderConfigDto> {
    const payload: Partial<AIProviderConfigEntity> = {};
    if (dto.priority !== undefined) payload.priority = dto.priority;
    if (dto.enabled !== undefined) payload.enabled = dto.enabled;
    if (dto.rpm !== undefined) payload.rpm = dto.rpm;
    if (dto.tpm !== undefined) payload.tpm = dto.tpm;
    if (dto.retry_count !== undefined) payload.retry_count = dto.retry_count;
    if (dto.timeout_seconds !== undefined) payload.timeout_seconds = dto.timeout_seconds;
    if (dto.metadata !== undefined) payload.metadata = dto.metadata as import('./types.js').ModelMetadata;

    const updated = await this.repository.updateConfig(provider, model, payload);
    if (!updated) {
      throw new ProviderNotFoundError(`AI Provider configuration not found for ${provider}:${model}`);
    }
    return AIProviderMapper.toConfigDto(updated);
  }

  async getHealthStatus(): Promise<AIProviderHealthDto[]> {
    const healths = await this.repository.findHealths();
    return AIProviderMapper.toHealthDtoList(healths);
  }

  async runHealthCheck(): Promise<void> {
    await ProviderHealthChecker.runBatchCheck(this.repository);
  }

  async getMetricsSummary(): Promise<Record<string, unknown>[]> {
    const metrics = ProviderMetricsCollector.getMetrics();
    return metrics.map((m) => ({
      provider: m.provider,
      model: m.model,
      status: m.status,
      latencyMs: m.latency_ms,
      promptTokens: m.prompt_tokens,
      completionTokens: m.completion_tokens,
      totalTokens: m.total_tokens,
      estimatedCost: m.estimated_cost,
      cacheHit: m.cache_hit,
      createdAt: m.created_at,
    }));
  }

  async testCall(dto: TestAIProviderDto): Promise<GenerateResponse> {
    return this.gateway.generate(
      {
        prompt: dto.prompt,
        workspaceId: dto.workspaceId,
        capabilities: dto.capabilities,
        systemInstruction: dto.systemInstruction,
        temperature: dto.temperature,
        responseSchema: dto.responseSchema,
      },
      { provider: dto.provider, model: dto.model }
    );
  }

  async getSupportedModels(): Promise<Record<string, unknown>[]> {
    const configs = await this.repository.findConfigs();
    return configs.map((c) => ({
      provider: c.provider,
      model: c.model,
      version: c.version,
      capabilities: c.metadata ? Object.keys(c.metadata).filter((k) => !!(c.metadata as unknown as Record<string, unknown>)[k]) : [],
      enabled: c.enabled,
    }));
  }
}
export default AIProviderService;
