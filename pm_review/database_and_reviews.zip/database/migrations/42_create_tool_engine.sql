-- 42_create_tool_engine.sql
-- Tool Calling Engine & Human Approval Tables

BEGIN;

-- 1. tool_definitions
CREATE TABLE IF NOT EXISTS public.tool_definitions (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL DEFAULT 'custom',
    latest_version INTEGER NOT NULL DEFAULT 1,
    current_version_id UUID,
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT', -- DRAFT, REVIEW, APPROVED, DEPRECATED
    created_by UUID,
    updated_by UUID,
    approved_by UUID,
    approved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,

    CONSTRAINT pk_tool_definitions PRIMARY KEY (id),
    CONSTRAINT fk_tools_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.tool_definitions IS 'Tool 명세 마스터 테이블';

-- 2. tool_versions
CREATE TABLE IF NOT EXISTS public.tool_versions (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    tool_id UUID NOT NULL,
    version INTEGER NOT NULL,
    manifest JSONB NOT NULL DEFAULT '{}'::jsonb,
    input_schema JSONB NOT NULL DEFAULT '{}'::jsonb,
    output_schema JSONB NOT NULL DEFAULT '{}'::jsonb,
    permission JSONB NOT NULL DEFAULT '[]'::jsonb,
    timeout_ms INTEGER NOT NULL DEFAULT 5000,
    retry_limit INTEGER NOT NULL DEFAULT 3,
    checksum VARCHAR(64) NOT NULL,
    created_by UUID,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_tool_versions PRIMARY KEY (id),
    CONSTRAINT fk_tool_versions_master FOREIGN KEY (tool_id) REFERENCES public.tool_definitions(id) ON DELETE CASCADE,
    CONSTRAINT uq_tool_version UNIQUE (tool_id, version)
);

COMMENT ON TABLE public.tool_versions IS 'Tool 변경 불가 버전 상세 명세';

-- Add cyclic foreign key constraint for active current version safely
ALTER TABLE public.tool_definitions
    ADD CONSTRAINT fk_tools_current_version
    FOREIGN KEY (current_version_id) REFERENCES public.tool_versions(id) ON DELETE SET NULL;

-- 3. tool_execution_history
CREATE TABLE IF NOT EXISTS public.tool_execution_history (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    workflow_execution_id UUID,
    workflow_step_execution_id UUID,
    tool_version_id UUID NOT NULL,
    execution_key VARCHAR(100) NOT NULL,
    request JSONB NOT NULL DEFAULT '{}'::jsonb,
    response JSONB NOT NULL DEFAULT '{}'::jsonb,
    execution_ms INTEGER NOT NULL DEFAULT 0,
    cache_hit BOOLEAN NOT NULL DEFAULT FALSE,
    success BOOLEAN NOT NULL DEFAULT TRUE,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_tool_execution_history PRIMARY KEY (id),
    CONSTRAINT fk_tool_exec_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT fk_tool_exec_version FOREIGN KEY (tool_version_id) REFERENCES public.tool_versions(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.tool_execution_history IS 'Tool 실행 이력 로깅';

-- 4. approval_requests
CREATE TABLE IF NOT EXISTS public.approval_requests (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    workflow_execution_id UUID NOT NULL,
    workflow_step_execution_id UUID NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED, TIMEOUT, CANCELLED
    timeout_at TIMESTAMPTZ,
    requested_by UUID,
    approved_by UUID,
    approved_at TIMESTAMPTZ,
    rejected_by UUID,
    rejected_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_approval_requests PRIMARY KEY (id),
    CONSTRAINT fk_approvals_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.approval_requests IS 'Human Approval 대기 큐 및 최종 결과 상태 기록';

-- 5. approval_audit_logs
CREATE TABLE IF NOT EXISTS public.approval_audit_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    approval_id UUID NOT NULL,
    action VARCHAR(50) NOT NULL,
    actor UUID,
    before JSONB,
    after JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_approval_audit_logs PRIMARY KEY (id),
    CONSTRAINT fk_approval_audit_parent FOREIGN KEY (approval_id) REFERENCES public.approval_requests(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.approval_audit_logs IS 'Human Approval 감사 로그 이력';

-- Indexes
CREATE INDEX IF NOT EXISTS idx_tools_workspace ON public.tool_definitions(workspace_id);
CREATE INDEX IF NOT EXISTS idx_tool_versions_master ON public.tool_versions(tool_id);
CREATE INDEX IF NOT EXISTS idx_tool_history_version ON public.tool_execution_history(tool_version_id);
CREATE INDEX IF NOT EXISTS idx_approvals_workspace ON public.approval_requests(workspace_id);
CREATE INDEX IF NOT EXISTS idx_approval_audit_parent ON public.approval_audit_logs(approval_id);

COMMIT;
