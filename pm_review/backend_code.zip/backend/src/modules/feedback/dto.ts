export interface CalculateFeedbackDto {
  performanceId: string;
  formulaVersion?: string;
}

export interface RecalculateFeedbackDto {
  performanceId: string;
  formulaVersion?: string;
}

export interface FeedbackResponseDto {
  feedbackId: string;
  performanceId: string;
  calculationVersion: number;
  salesScore: number;
  reviewScore: number;
  conversionScore: number;
  engagementScore: number;
  profitabilityScore: number;
  refundPenalty: number;
  overallScore: number;
  grade: 'S' | 'A+' | 'A' | 'B' | 'C' | 'D';
  weightSnapshot: Record<string, number>;
  formulaVersion: string;
  calculatedAt: string;
  createdAt: string;
}

export interface FeedbackHistoryDto {
  history: FeedbackResponseDto[];
  totalCount: number;
}
