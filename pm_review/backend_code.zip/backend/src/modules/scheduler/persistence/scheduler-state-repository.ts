export interface SchedulerState {
  leaderNodeId?: string;
  leaderLeaseExpiresAt?: number;
  maintenanceMode: boolean;
}

export class SchedulerStateRepository {
  private static state: SchedulerState = {
    maintenanceMode: false,
  };

  static async getState(): Promise<SchedulerState> {
    return { ...this.state };
  }

  static async saveState(update: Partial<SchedulerState>): Promise<void> {
    this.state = { ...this.state, ...update };
  }

  static clear(): void {
    this.state = {
      maintenanceMode: false,
    };
  }
}
export default SchedulerStateRepository;
