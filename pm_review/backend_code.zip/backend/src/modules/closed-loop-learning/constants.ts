/**
 * Closed-loop Learning Domain Constants
 */

export const LEARNING_MONITORING = {
  WARN_LATENCY_MS: 100,
  CRITICAL_LATENCY_MS: 300,
};

export const LEARNING_SCORING_CONSTANTS = {
  MAX_KNOWLEDGE_SCORE: 100.0,
};
