export class MarketRepository {}
