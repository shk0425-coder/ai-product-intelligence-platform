import { TraceManager, Span } from '../tracing/trace-manager.js';
import { AiMetricsCollector } from '../metrics/collector/ai-collector.js';

export class AiProviderInstrumentation {
  static startCall(provider: string, model: string): Span {
    const span = TraceManager.startSpan(`AI Call ${provider} ${model}`);
    span.setAttribute('provider', provider);
    span.setAttribute('model', model);
    return span;
  }

  static endCall(span: Span, provider: string, model: string, tokens: number, latencyMs: number, cost: number, success = true): void {
    span.setStatus(success ? 'OK' : 'ERROR');
    span.end();

    if (success) {
      AiMetricsCollector.recordRequest(provider, model, tokens, latencyMs, cost);
    }
  }
}
