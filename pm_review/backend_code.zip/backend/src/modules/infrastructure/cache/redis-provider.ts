import { CacheProvider } from './provider.js';
import { CacheSerializer } from './serializer.js';

export class RedisCacheProvider implements CacheProvider {
  private readonly store = new Map<string, { value: string; expiresAt: number }>();
  private readonly counters = new Map<string, number>();
  private isOnline = true;

  // Simulate network disruption for testing Circuit Breaker
  setOnlineStatus(online: boolean): void {
    this.isOnline = online;
  }

  private checkConnection(): void {
    if (!this.isOnline) {
      throw new Error('Redis connection lost (Simulated network exception)');
    }
  }

  async get(key: string): Promise<Record<string, unknown> | null> {
    this.checkConnection();
    const item = this.store.get(key);
    if (!item) return null;
    if (Date.now() > item.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return CacheSerializer.deserialize(item.value) as Record<string, unknown> | null;
  }

  async set(key: string, value: Record<string, unknown>, ttlMs: number): Promise<void> {
    this.checkConnection();
    this.store.set(key, {
      value: CacheSerializer.serialize(value),
      expiresAt: Date.now() + ttlMs,
    });
  }

  async delete(key: string): Promise<void> {
    this.checkConnection();
    this.store.delete(key);
    this.counters.delete(key);
  }

  async exists(key: string): Promise<boolean> {
    this.checkConnection();
    const item = this.store.get(key);
    if (!item) return false;
    if (Date.now() > item.expiresAt) {
      this.store.delete(key);
      return false;
    }
    return true;
  }

  async expire(key: string, ttlMs: number): Promise<boolean> {
    this.checkConnection();
    const item = this.store.get(key);
    if (!item) return false;
    item.expiresAt = Date.now() + ttlMs;
    return true;
  }

  async ttl(key: string): Promise<number> {
    this.checkConnection();
    const item = this.store.get(key);
    if (!item) return -2;
    const diff = item.expiresAt - Date.now();
    return diff > 0 ? diff : -1;
  }

  async increment(key: string): Promise<number> {
    this.checkConnection();
    const val = (this.counters.get(key) || 0) + 1;
    this.counters.set(key, val);
    return val;
  }

  async decrement(key: string): Promise<number> {
    this.checkConnection();
    const val = (this.counters.get(key) || 0) - 1;
    this.counters.set(key, val);
    return val;
  }

  async clearNamespace(namespace: string): Promise<void> {
    this.checkConnection();
    const prefix = `${namespace}:`;
    for (const key of this.store.keys()) {
      if (key.startsWith(prefix)) {
        this.store.delete(key);
      }
    }
    for (const key of this.counters.keys()) {
      if (key.startsWith(prefix)) {
        this.counters.delete(key);
      }
    }
  }

  // Ping method for health and circuit recovery checks
  async ping(): Promise<string> {
    this.checkConnection();
    return 'PONG';
  }
}
export default RedisCacheProvider;
