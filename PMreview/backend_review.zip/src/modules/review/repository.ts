export class ReviewRepository {}
