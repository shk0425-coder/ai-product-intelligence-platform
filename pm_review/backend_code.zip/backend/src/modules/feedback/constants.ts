/**
 * Feedback Domain Constants
 */

export const NORMALIZATION_LIMITS = {
  SALES_MAX_COUNT: 1000, // Sales count 1000 -> 100 points
  REVIEW_MAX_SCORE: 5.0, // Review score 5.0 -> 100 points
  CONVERSION_MAX_RATE: 20.0, // Conversion rate 20% -> 100 points
  CTR_MAX_RATE: 10.0, // CTR 10% -> 100 points
  ROI_MAX_RATE: 1000.0, // ROI 1000% -> 100 points
  PROFIT_MAX_AMOUNT: 10000000.0, // Profit 10,000,000 won -> 100 points
  FAVORITE_MAX_COUNT: 500, // Favorite count 500 -> 100 points
  REFUND_MAX_COUNT: 50, // Refund count 50 -> 100 points penalty base
};

export const FEEDBACK_MONITORING = {
  COMPUTE_WARN_LATENCY_MS: 50,
  COMPUTE_CRITICAL_LATENCY_MS: 150,
};
