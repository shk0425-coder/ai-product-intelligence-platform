import { z } from 'zod';

export const createPromptTemplateSchema = z.object({
  workspaceId: z.string().uuid(),
  category: z.string().min(1),
  name: z.string().min(1),
  description: z.string().optional(),
  systemPrompt: z.string().min(1),
  userPrompt: z.string().min(1),
  modelCapability: z.string().optional(),
  defaultProvider: z.string().optional(),
  defaultModel: z.string().optional(),
  temperature: z.number().min(0.0).max(2.0).optional(),
  topP: z.number().min(0.0).max(1.0).optional(),
  maxTokens: z.number().int().min(1).optional(),
  responseSchema: z.record(z.any()).optional(),
  tags: z.array(z.string()).optional(),
});

export const createPromptVersionSchema = z.object({
  systemPrompt: z.string().min(1),
  userPrompt: z.string().min(1),
  changeSummary: z.string().optional(),
});

export const renderPromptSchema = z.object({
  workspaceId: z.string().uuid(),
  variables: z.record(z.any()),
  provider: z.string().optional(),
  model: z.string().optional(),
});

export const previewPromptSchema = z.object({
  workspaceId: z.string().uuid(),
  templateId: z.string().uuid(),
  versionId: z.string().uuid(),
  variables: z.record(z.any()),
  model: z.string().optional(),
});
