import { pino } from 'pino';
import { FeedbackEventPayload, IFeedbackHooks } from './types.js'; // types에 선언된 규격 임포트 (또는 types.ts에 기재)

const logger = pino();

export const FeedbackHooks: IFeedbackHooks = {
  async onFeedbackCalculated(payload: FeedbackEventPayload): Promise<void> {
    logger.info(
      {
        feedbackId: payload.feedback.feedbackId,
        performanceId: payload.feedback.performanceId,
        actorId: payload.actorId,
        overallScore: payload.feedback.overallScore,
        grade: payload.feedback.grade,
      },
      'Domain Hook [FeedbackCalculated] triggered',
    );
    // Future integration point for Sprint 5-3 Feedback Intelligence Engine
  },

  async onFeedbackRecalculated(payload: FeedbackEventPayload): Promise<void> {
    logger.info(
      {
        feedbackId: payload.feedback.feedbackId,
        performanceId: payload.feedback.performanceId,
        actorId: payload.actorId,
        overallScore: payload.feedback.overallScore,
        grade: payload.feedback.grade,
      },
      'Domain Hook [FeedbackRecalculated] triggered',
    );
    // Future integration point for Sprint 5-3 Feedback Intelligence Engine
  },
};
