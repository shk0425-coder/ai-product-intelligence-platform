import { CircuitBreakerOpenError } from '../../common/errors/index.js';

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export class CircuitBreaker {
  private static readonly states = new Map<string, CircuitState>();
  private static readonly failureCounts = new Map<string, number>();
  private static readonly openTimestamps = new Map<string, number>();

  private static cooldownMs = 5000; // default 5 seconds recovery

  static setCooldown(ms: number): void {
    this.cooldownMs = ms;
  }

  static getState(provider: string, model: string): CircuitState {
    const key = `${provider}:${model}`.toUpperCase();
    const state = this.states.get(key) || 'CLOSED';

    if (state === 'OPEN') {
      const openTime = this.openTimestamps.get(key) || 0;
      if (Date.now() - openTime > this.cooldownMs) {
        // Automatically transition from OPEN to HALF_OPEN after cooldown expires
        this.states.set(key, 'HALF_OPEN');
        return 'HALF_OPEN';
      }
    }
    return state;
  }

  static checkCall(provider: string, model: string): void {
    const state = this.getState(provider, model);
    if (state === 'OPEN') {
      throw new CircuitBreakerOpenError(`Circuit breaker is OPEN for provider ${provider}:${model}`);
    }
  }

  static recordSuccess(provider: string, model: string): void {
    const key = `${provider}:${model}`.toUpperCase();
    this.states.set(key, 'CLOSED');
    this.failureCounts.set(key, 0);
    this.openTimestamps.delete(key);
  }

  static recordFailure(provider: string, model: string): void {
    const key = `${provider}:${model}`.toUpperCase();
    const count = (this.failureCounts.get(key) || 0) + 1;
    this.failureCounts.set(key, count);

    if (count >= 5) {
      this.states.set(key, 'OPEN');
      this.openTimestamps.set(key, Date.now());
    }
  }

  static clear(): void {
    this.states.clear();
    this.failureCounts.clear();
    this.openTimestamps.clear();
  }
}
export default CircuitBreaker;
