export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export class RedisCircuitBreaker {
  private state: CircuitState = 'CLOSED';
  private failureCount = 0;
  private readonly failureThreshold = 3;
  private lastStateChangeTime: number = Date.now();
  private readonly cooldownMs = 3000; // Fast cooldown for local tests, normally 10000ms

  constructor(
    private readonly onStateChange?: (oldState: CircuitState, newState: CircuitState) => void
  ) {}

  getState(): CircuitState {
    // If state is OPEN and cooldown has passed, switch to HALF_OPEN to check health
    if (this.state === 'OPEN' && Date.now() - this.lastStateChangeTime > this.cooldownMs) {
      this.transitionTo('HALF_OPEN');
    }
    return this.state;
  }

  recordSuccess(): void {
    if (this.state === 'HALF_OPEN') {
      this.transitionTo('CLOSED');
    }
    this.failureCount = 0;
  }

  recordFailure(): void {
    this.failureCount++;
    if (this.state === 'CLOSED' && this.failureCount >= this.failureThreshold) {
      this.transitionTo('OPEN');
    } else if (this.state === 'HALF_OPEN') {
      this.transitionTo('OPEN');
    }
  }

  private transitionTo(newState: CircuitState): void {
    const oldState = this.state;
    this.state = newState;
    this.lastStateChangeTime = Date.now();
    if (newState === 'CLOSED') {
      this.failureCount = 0;
    }
    if (this.onStateChange) {
      this.onStateChange(oldState, newState);
    }
  }
}
