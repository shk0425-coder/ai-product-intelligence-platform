import { FastifyInstance } from 'fastify';
import { ToolController } from './controller.js';
import { ToolService } from './service.js';
import { ToolRepository } from './repository.js';
import { supabase } from '@/config/supabase.js';

export async function toolRoutes(fastify: FastifyInstance) {
  const repository = new ToolRepository(supabase);
  const service = new ToolService(repository);
  const controller = new ToolController(service);

  // Tools CRUD & Execute
  fastify.get('/', (req, rep) => controller.getTools(req, rep));
  fastify.post('/', (req, rep) =>
    controller.createTool(
      req as import('fastify').FastifyRequest<{ Body: import('./dto.js').CreateToolDto }>,
      rep
    )
  );
  fastify.get('/:id', (req, rep) => controller.getToolById(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
  fastify.post('/:id/versions', (req, rep) =>
    controller.createVersion(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: import('./dto.js').CreateToolVersionDto }>,
      rep
    )
  );

  fastify.post('/:id/approve', (req, rep) => controller.approveTool(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
  fastify.post('/:id/review', (req, rep) => controller.reviewTool(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
  fastify.post('/:id/deprecate', (req, rep) => controller.deprecateTool(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
  fastify.post('/:id/execute', (req, rep) =>
    controller.executeTool(
      req as import('fastify').FastifyRequest<{ Params: { id: string }; Body: import('./dto.js').ExecuteToolDto }>,
      rep
    )
  );
  fastify.get('/history', (req, rep) => controller.getHistory(req, rep));
}

export async function approvalRoutes(fastify: FastifyInstance) {
  const repository = new ToolRepository(supabase);
  const service = new ToolService(repository);
  const controller = new ToolController(service);

  // Human Approvals
  fastify.get('/', (req, rep) => controller.getApprovals(req, rep));
  fastify.get('/:id', (req, rep) => controller.getApprovalById(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
  fastify.post('/:id/approve', (req, rep) => controller.approveApproval(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
  fastify.post('/:id/reject', (req, rep) => controller.rejectApproval(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
  fastify.post('/:id/cancel', (req, rep) => controller.cancelApproval(req as unknown as import('fastify').FastifyRequest<{ Params: { id: string } }>, rep));
}
