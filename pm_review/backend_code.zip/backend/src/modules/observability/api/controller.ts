import { FastifyRequest, FastifyReply } from 'fastify';
import { HealthDashboard } from '../dashboard/health.js';
import { DiagnosticsEngine } from '../diagnostics/diagnostics-engine.js';
import { PerformanceProfiler } from '../diagnostics/profiler.js';
import { AlertDeduplicator } from '../alerts/deduplicator.js';
import { MetricsAggregator } from '../metrics/aggregator.js';
import { AiMetricsCollector } from '../metrics/collector/ai-collector.js';
import { MetricsProviderFactory, PrometheusProvider } from '../metrics/metrics-provider.js';

export class ObservabilityController {
  async getSummary(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const health = await HealthDashboard.getHealthData();
    const diag = DiagnosticsEngine.getRuntimeDiagnostics();
    const activeAlerts = AlertDeduplicator.getActiveCount();
    const criticalAlerts = AlertDeduplicator.getCriticalCount();

    // Fetch metrics summaries
    const cacheHits = MetricsAggregator.getAggregated('cache_hits_total', 1)?.sum || 0;
    const cacheMisses = MetricsAggregator.getAggregated('cache_misses_total', 1)?.sum || 0;
    const hitRate = cacheHits + cacheMisses > 0 ? (cacheHits / (cacheHits + cacheMisses)) * 100 : 100;

    rep.send({
      status: 'success',
      data: {
        system: {
          healthStatus: health.overall,
          uptime: process.uptime(),
          version: '1.0.0',
        },
        cache: {
          hitRate,
          missRate: 100 - hitRate,
        },
        redis: {
          status: health.components.redis.status,
          connectionCount: diag.openSockets,
        },
        queue: {
          queueDepth: 0,
          activeWorker: 1,
        },
        workflow: {
          running: 0,
          completed: MetricsAggregator.getAggregated('workflow_completed_total', 24 * 60)?.sum || 0,
          failed: MetricsAggregator.getAggregated('workflow_failed_total', 24 * 60)?.sum || 0,
        },
        ai: {
          provider: 'Gemini',
          todayRequests: MetricsAggregator.getAggregated('ai_requests_total', 24 * 60)?.sum || 0,
          todayTokens: MetricsAggregator.getAggregated('ai_tokens_total', 24 * 60)?.sum || 0,
          todayCost: AiMetricsCollector.getAccumulatedCost(),
        },
        runtime: {
          cpu: diag.cpuLoadAverage,
          memory: diag.heapUsagePercentage,
          eventLoopDelay: diag.eventLoopDelayMs,
        },
        alert: {
          activeAlertCount: activeAlerts,
          criticalAlertCount: criticalAlerts,
        },
      },
    });
  }

  async getHealth(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const data = await HealthDashboard.getHealthData();
    rep.send({ status: 'success', data });
  }

  async getMetrics(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const provider = MetricsProviderFactory.getProvider();
    if (provider instanceof PrometheusProvider) {
      rep.header('Content-Type', 'text/plain; version=0.0.4');
      rep.send(provider.toPrometheusFormat());
    } else {
      rep.send({ status: 'success', data: {} });
    }
  }

  async getLogs(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    // Return emulated log collection
    rep.send({ status: 'success', data: { logs: [] } });
  }

  async getTraces(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    // Return trace profile list
    rep.send({ status: 'success', data: { traces: [] } });
  }

  async getAlerts(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const alerts = AlertDeduplicator.getAlertsList();
    rep.send({ status: 'success', data: { alerts } });
  }

  async getDiagnostics(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const report = await DiagnosticsEngine.analyze();
    rep.send({ status: 'success', data: report });
  }

  async getDashboard(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const slowEndpoints = PerformanceProfiler.getTopSlowEndpoints();
    rep.send({
      status: 'success',
      data: {
        performance: {
          slowEndpoints,
        },
      },
    });
  }
}
export const observabilityController = new ObservabilityController();
export default observabilityController;
