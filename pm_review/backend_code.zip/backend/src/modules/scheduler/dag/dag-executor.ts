export interface JobNode {
  jobId: string;
  parents: string[]; // Parent jobIds
  children: string[]; // Child jobIds
}

export class DagExecutor {
  private static readonly nodes = new Map<string, JobNode>();

  static registerDependency(jobId: string, parentJobId: string): void {
    const node = this.nodes.get(jobId) || { jobId, parents: [], children: [] };
    const parentNode = this.nodes.get(parentJobId) || { jobId: parentJobId, parents: [], children: [] };

    if (!node.parents.includes(parentJobId)) {
      node.parents.push(parentJobId);
    }
    if (!parentNode.children.includes(jobId)) {
      parentNode.children.push(jobId);
    }

    this.nodes.set(jobId, node);
    this.nodes.set(parentJobId, parentNode);

    // Run DFS cycle detection immediately on dependency register
    this.detectCycle();
  }

  private static detectCycle(): void {
    const visited = new Set<string>();
    const recStack = new Set<string>();

    const dfs = (nodeId: string): boolean => {
      visited.add(nodeId);
      recStack.add(nodeId);

      const node = this.nodes.get(nodeId);
      if (node) {
        for (const child of node.children) {
          if (!visited.has(child)) {
            if (dfs(child)) return true;
          } else if (recStack.has(child)) {
            return true; // Cycle detected
          }
        }
      }

      recStack.delete(nodeId);
      return false;
    };

    for (const nodeId of this.nodes.keys()) {
      if (!visited.has(nodeId)) {
        if (dfs(nodeId)) {
          // Reset dependencies and throw error
          this.clear();
          throw new Error('DAG Cycle Detected: Circular dependency is not allowed in scheduler');
        }
      }
    }
  }

  static async getExecutableJobs(completedJobIds: Set<string>): Promise<string[]> {
    const executable: string[] = [];
    for (const [jobId, node] of this.nodes.entries()) {
      if (completedJobIds.has(jobId)) {
        continue;
      }
      // Check if all parents are completed
      const parentsResolved = node.parents.every(parent => completedJobIds.has(parent));
      if (parentsResolved) {
        executable.push(jobId);
      }
    }
    return executable;
  }

  static getParents(jobId: string): string[] {
    return this.nodes.get(jobId)?.parents || [];
  }

  static clear(): void {
    this.nodes.clear();
  }
}
export default DagExecutor;
