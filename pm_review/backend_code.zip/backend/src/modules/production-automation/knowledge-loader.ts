import { SupabaseClient } from '@supabase/supabase-js';

export class KnowledgeLoader {
  constructor(private readonly supabase: SupabaseClient) {}

  async loadKnowledgeList(
    workspaceId: string,
    category?: string,
    version?: number,
  ): Promise<Record<string, unknown>[]> {
    // We will inner join learning_knowledge -> feedback_intelligence -> feedback_scores -> product_performance -> workspaces
    let query = this.supabase
      .from('learning_knowledge')
      .select(
        `
        *,
        feedback_intelligence!inner(
          *,
          feedback_scores!inner(
            *,
            product_performance!inner(
              *,
              workspaces!inner(id)
            )
          )
        )
      `,
      )
      .eq('feedback_intelligence.feedback_scores.product_performance.workspaces.id', workspaceId);

    if (version !== undefined) {
      query = query.eq('knowledge_version', version);
    }

    // Sort priority: knowledge_score DESC -> confidence_score DESC -> knowledge_version DESC -> created_at DESC
    query = query
      .order('knowledge_score', { ascending: false })
      .order('confidence_score', { ascending: false })
      .order('knowledge_version', { ascending: false })
      .order('created_at', { ascending: false });

    const { data, error } = await query;
    if (error || !data) return [];

    // Filter by category in nested structure manually if provided
    if (category) {
      return (data as Record<string, unknown>[]).filter((item: Record<string, unknown>) => {
        const intel = item.feedback_intelligence as Record<string, unknown> | undefined;
        const score = intel?.feedback_scores as Record<string, unknown> | undefined;
        const cat = score?.category;
        return cat ? String(cat).toLowerCase() === category.toLowerCase() : false;
      });
    }

    return data;
  }
}
export default KnowledgeLoader;
