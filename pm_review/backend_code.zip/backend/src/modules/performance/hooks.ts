import { ProductPerformance } from './types.js';
import { pino } from 'pino';

const logger = pino();

export interface PerformanceEventPayload {
  performance: ProductPerformance;
  actorId: string;
  timestamp: string;
}

/**
 * Domain hooks placeholder for Sprint 5-1.
 * These will be fully integrated with the Feedback Intelligence Engine in Sprint 5-2.
 */
export const PerformanceHooks = {
  /**
   * Called immediately after a new performance snapshot is created.
   */
  onPerformanceCreated: async (payload: PerformanceEventPayload): Promise<void> => {
    logger.info(
      { performanceId: payload.performance.id, actorId: payload.actorId },
      'Domain Hook [PerformanceCreated] triggered',
    );
    // TODO: Connect to Feedback Intelligence Engine in Sprint 5-2
  },

  /**
   * Called immediately after an existing performance snapshot is updated/upserted.
   */
  onPerformanceUpdated: async (payload: PerformanceEventPayload): Promise<void> => {
    logger.info(
      { performanceId: payload.performance.id, actorId: payload.actorId },
      'Domain Hook [PerformanceUpdated] triggered',
    );
    // TODO: Connect to Feedback Intelligence Engine in Sprint 5-2
  },

  /**
   * Called immediately after a performance snapshot is soft-deleted.
   */
  onPerformanceDeleted: async (payload: PerformanceEventPayload): Promise<void> => {
    logger.info(
      { performanceId: payload.performance.id, actorId: payload.actorId },
      'Domain Hook [PerformanceDeleted] triggered',
    );
    // TODO: Connect to Feedback Intelligence Engine in Sprint 5-2
  },
};
export default PerformanceHooks;
