-- 37_create_production_automation.sql
-- Production Automation Domain tables

BEGIN;

-- 1. production_automations
CREATE TABLE IF NOT EXISTS public.production_automations (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL,
    knowledge_id UUID NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    retry_count INTEGER NOT NULL DEFAULT 0,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_production_automations PRIMARY KEY (id),
    CONSTRAINT fk_production_automations_workspace FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE,
    CONSTRAINT fk_production_automations_knowledge FOREIGN KEY (knowledge_id) REFERENCES public.learning_knowledge(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.production_automations IS '지식 자산 자동 피딩 파이프라인 관리 테이블';
COMMENT ON COLUMN public.production_automations.id IS '자동화 오케스트레이션 식별 UUID';
COMMENT ON COLUMN public.production_automations.status IS '진행 상태 (PENDING, RUNNING, SUCCESS, FAILED)';
COMMENT ON COLUMN public.production_automations.retry_count IS '에러 발생 후 재시도 수행 누적 횟수';

-- 2. production_prompt_logs
CREATE TABLE IF NOT EXISTS public.production_prompt_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    automation_id UUID NOT NULL,
    prompt_version VARCHAR(20) NOT NULL DEFAULT 'v1',
    prompt_checksum VARCHAR(128) NOT NULL DEFAULT '',
    token_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_production_prompt_logs PRIMARY KEY (id),
    CONSTRAINT fk_production_prompt_logs_auto FOREIGN KEY (automation_id) REFERENCES public.production_automations(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.production_prompt_logs IS '조립 프롬프트 무결성 검증을 위한 체크섬 로그 테이블';

-- 3. production_execution_logs
CREATE TABLE IF NOT EXISTS public.production_execution_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    automation_id UUID NOT NULL,
    step VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_production_execution_logs PRIMARY KEY (id),
    CONSTRAINT fk_production_execution_logs_auto FOREIGN KEY (automation_id) REFERENCES public.production_automations(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.production_execution_logs IS '자동화 하위 단계별 수행 소요 성능 로그';

-- Indexes for performance optimization
CREATE INDEX IF NOT EXISTS idx_prod_auto_workspace ON public.production_automations(workspace_id);
CREATE INDEX IF NOT EXISTS idx_prod_auto_knowledge ON public.production_automations(knowledge_id);
CREATE INDEX IF NOT EXISTS idx_prod_auto_status ON public.production_automations(status);
CREATE INDEX IF NOT EXISTS idx_prod_auto_created ON public.production_automations(created_at DESC);

COMMIT;
