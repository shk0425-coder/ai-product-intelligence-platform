import { MetricsRegistry } from '../registry.js';
import os from 'os';

export class SystemMetricsCollector {
  private static lastCpuUsage: { user: number; system: number } | null = null;
  private static lastCpuTime = 0;

  static collect(): void {
    const memory = process.memoryUsage();
    MetricsRegistry.gauge('memory_usage_bytes', memory.heapUsed, { instance: os.hostname() });

    // Calculate CPU Load Average
    const loadAvg = os.loadavg()[0];
    MetricsRegistry.gauge('cpu_load_average', loadAvg, { instance: os.hostname() });

    // Emulate Event Loop Delay
    const start = Date.now();
    setTimeout(() => {
      const delayMs = Date.now() - start;
      MetricsRegistry.gauge('event_loop_delay_seconds', delayMs / 1000, { instance: os.hostname() });
    }, 0);
  }
}
