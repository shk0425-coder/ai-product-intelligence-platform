export class WorkflowSnapshotManager {
  static createSnapshot(
    completedStepIds: string[],
    currentContext: Record<string, unknown>,
    stateGraphProgress: Record<string, unknown>
  ): Record<string, unknown> {
    return {
      completedStepIds: [...completedStepIds],
      context: { ...currentContext },
      progress: { ...stateGraphProgress },
      timestamp: new Date().toISOString(),
    };
  }
}
export default WorkflowSnapshotManager;
