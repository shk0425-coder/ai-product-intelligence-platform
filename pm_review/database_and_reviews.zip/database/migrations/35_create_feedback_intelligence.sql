-- 35_create_feedback_intelligence.sql
-- Feedback Intelligence Domain tables

BEGIN;

CREATE TABLE IF NOT EXISTS public.feedback_intelligence (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    feedback_score_id UUID NOT NULL,
    analysis_version INTEGER NOT NULL DEFAULT 1,
    rule_version VARCHAR(20) NOT NULL DEFAULT 'v1',
    strength_summary TEXT NOT NULL DEFAULT '',
    weakness_summary TEXT NOT NULL DEFAULT '',
    bottleneck_summary TEXT NOT NULL DEFAULT '',
    improvement_summary TEXT NOT NULL DEFAULT '',
    root_causes JSONB NOT NULL DEFAULT '[]'::jsonb,
    recommendations JSONB NOT NULL DEFAULT '[]'::jsonb,
    detected_rules JSONB NOT NULL DEFAULT '[]'::jsonb,
    impact_score NUMERIC(6, 3) NOT NULL DEFAULT 0.000,
    confidence_score NUMERIC(6, 3) NOT NULL DEFAULT 100.000,
    execution_time_ms INTEGER NOT NULL DEFAULT 0,
    analyzed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_feedback_intelligence PRIMARY KEY (id),
    CONSTRAINT uq_feedback_intel_score_rule UNIQUE (feedback_score_id, rule_version),
    CONSTRAINT fk_feedback_intel_score FOREIGN KEY (feedback_score_id) REFERENCES public.feedback_scores(id) ON DELETE CASCADE
);

COMMENT ON TABLE public.feedback_intelligence IS '피드백 스코어 기반 결정론적 병목 분석 및 권장안 보고서 테이블';
COMMENT ON COLUMN public.feedback_intelligence.id IS '피드백 인텔리전스 보고서 식별 UUID';
COMMENT ON COLUMN public.feedback_intelligence.feedback_score_id IS '부모 피드백 스코어 UUID';
COMMENT ON COLUMN public.feedback_intelligence.analysis_version IS '성과 재분석에 따른 보고서 버전 차수';
COMMENT ON COLUMN public.feedback_intelligence.rule_version IS '분석에 적용된 룰 버전 코드';
COMMENT ON COLUMN public.feedback_intelligence.strength_summary IS '긍정 강점 지표에 대한 요약문';
COMMENT ON COLUMN public.feedback_intelligence.weakness_summary IS '우려 약점 지표에 대한 요약문';
COMMENT ON COLUMN public.feedback_intelligence.bottleneck_summary IS '병목 요인에 대한 요약문';
COMMENT ON COLUMN public.feedback_intelligence.improvement_summary IS '개선 권장안에 대한 요약문';
COMMENT ON COLUMN public.feedback_intelligence.root_causes IS '식별된 원인 목록 (JSON 배열)';
COMMENT ON COLUMN public.feedback_intelligence.recommendations IS '도출된 구체적 액션 아이템 권장안 목록 (JSON 배열)';
COMMENT ON COLUMN public.feedback_intelligence.detected_rules IS '검출된 규칙들의 메타 정보 목록 (JSON 배열)';
COMMENT ON COLUMN public.feedback_intelligence.impact_score IS '비즈니스 영향도 종합 점수';
COMMENT ON COLUMN public.feedback_intelligence.confidence_score IS '분석 신뢰도 및 데이터 정합성 점수';
COMMENT ON COLUMN public.feedback_intelligence.execution_time_ms IS '연산 수행 소요 밀리초';

-- Indexes for performance optimization
CREATE INDEX IF NOT EXISTS idx_feedback_intelligence_feedback ON public.feedback_intelligence(feedback_score_id);
CREATE INDEX IF NOT EXISTS idx_feedback_intelligence_rule ON public.feedback_intelligence(rule_version);
CREATE INDEX IF NOT EXISTS idx_feedback_intelligence_created ON public.feedback_intelligence(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_feedback_intelligence_analysis ON public.feedback_intelligence(analysis_version);

COMMIT;
