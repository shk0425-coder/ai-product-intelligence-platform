import { FeedbackScoreEntity } from './types.js';
import { FeedbackResponseDto } from './dto.js';

export class FeedbackMapper {
  static toResponseDto(entity: FeedbackScoreEntity): FeedbackResponseDto {
    return {
      feedbackId: entity.id,
      performanceId: entity.performance_id,
      calculationVersion: entity.calculation_version,
      salesScore: Number(entity.sales_score),
      reviewScore: Number(entity.review_score),
      conversionScore: Number(entity.conversion_score),
      engagementScore: Number(entity.engagement_score),
      profitabilityScore: Number(entity.profitability_score),
      refundPenalty: Number(entity.refund_penalty),
      overallScore: Number(entity.overall_score),
      grade: entity.grade,
      weightSnapshot: entity.weight_snapshot,
      formulaVersion: entity.formula_version,
      calculatedAt: entity.calculated_at,
      createdAt: entity.created_at,
    };
  }

  static toResponseDtoList(entities: FeedbackScoreEntity[]): FeedbackResponseDto[] {
    return entities.map((entity) => this.toResponseDto(entity));
  }
}
export default FeedbackMapper;
