import { AIProvider, AIProviderConfigEntity, AIProviderHealthEntity, AIProviderMetricEntity, ProviderCapability } from './types.js';
import { ProviderSelector } from './provider-selector.js';
import { ProviderFactory } from './provider-factory.js';
import { ProviderNotFoundError, ProviderUnavailableError } from '../../common/errors/index.js';

export class ProviderResolver {
  static resolve(
    configs: AIProviderConfigEntity[],
    healths: AIProviderHealthEntity[],
    metrics: AIProviderMetricEntity[],
    requestCapabilities: ProviderCapability[],
    workspaceId: string,
    workspaceOverride?: { provider: string; model: string }
  ): AIProvider {
    const selectedConfig = ProviderSelector.select(
      configs,
      healths,
      metrics,
      requestCapabilities,
      workspaceId,
      workspaceOverride
    );

    if (!selectedConfig) {
      throw new ProviderNotFoundError(
        `No eligible AI Provider found matching requested capabilities: ${JSON.stringify(requestCapabilities)}`
      );
    }

    // Check if unavailable in health status
    const health = healths.find(
      (h) =>
        h.provider.toUpperCase() === selectedConfig.provider.toUpperCase() &&
        h.model.toUpperCase() === selectedConfig.model.toUpperCase()
    );
    if (health && health.status === 'UNAVAILABLE') {
      throw new ProviderUnavailableError(
        `The chosen provider ${selectedConfig.provider}:${selectedConfig.model} is currently marked UNAVAILABLE.`
      );
    }

    return ProviderFactory.create(selectedConfig.provider, selectedConfig.model);
  }
}
