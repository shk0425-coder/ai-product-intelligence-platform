import { ProductionRepository } from './repository.js';
import { RunProductionDto, RetryProductionDto, ProductionAutomationDto } from './dto.js';
import { ProductionMapper } from './mapper.js';
import { KnowledgeLoader } from './knowledge-loader.js';
import { KnowledgeFilter } from './knowledge-filter.js';
import { PromptBuilder } from './prompt-builder.js';
import { PromptValidator } from './prompt-validator.js';
import { ProductionPlanner } from './planner.js';
import { ProductionHooks } from './hooks.js';
import {
  LearningKnowledgeNotFoundError,
  WorkspaceForbiddenError,
  AutomationConflictError,
  AutomationRetryExceededError,
  ValidationError,
} from '@/common/errors/index.js';
import { SupabaseClient } from '@supabase/supabase-js';

export class ClosedLoopProductionService {
  // Prompt cache to prevent redundant planning for identical prompt checksums
  private readonly promptCache = new Map<string, { strategyId: string; strategyOutput: string }>();

  constructor(private readonly repository: ProductionRepository) {}

  async run(dto: RunProductionDto, actorId: string): Promise<ProductionAutomationDto> {
    const { workspaceId, knowledgeId, userRequest, bestPractice = '' } = dto;

    // 1. Verify Ownerships
    const ownsWorkspace = await this.repository.verifyWorkspaceOwnership(workspaceId, actorId);
    if (!ownsWorkspace) {
      throw new WorkspaceForbiddenError('You do not have permission to access this workspace');
    }

    const ownsKnowledge = await this.repository.verifyKnowledgeOwnership(knowledgeId, actorId);
    if (!ownsKnowledge) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this knowledge record',
      );
    }

    // 2. Verify Knowledge Exists
    const supabase = (this.repository as unknown as { supabase: SupabaseClient }).supabase;
    const { data: knowledgeRecord } = await supabase
      .from('learning_knowledge')
      .select('*')
      .eq('id', knowledgeId)
      .maybeSingle();

    if (!knowledgeRecord) {
      throw new LearningKnowledgeNotFoundError('Learning knowledge record not found');
    }

    // 3. Create Automation record in PENDING state
    const automation = await this.repository.createAutomation({
      workspace_id: workspaceId,
      knowledge_id: knowledgeId,
      status: 'PENDING',
      retry_count: 0,
    });

    // 4. Trigger Orchestration flow synchronously with context parameters
    const finalState = await this.executeWorkflow(automation.id, actorId, {
      userRequest,
      bestPractice,
    });

    // Fetch userRequest and bestPractice context from options parameter dynamically inside executeWorkflow
    // So we will pass context mapping using temp states or parameters.
    // For simplicity, we can invoke executeWorkflow with extra parameters.

    return ProductionMapper.toResponseDto(finalState);
  }

  async executeWorkflow(
    automationId: string,
    actorId: string,
    extraContext?: { userRequest: string; bestPractice: string },
  ): Promise<import('./types.js').ProductionAutomationEntity> {
    const startTime = Date.now();

    // 1. Fetch Automation record
    const automation = await this.repository.findAutomation(automationId);
    if (!automation) {
      throw new ValidationError('Automation record not found');
    }

    // Update status to RUNNING
    let currentAuto = await this.repository.updateAutomation(automationId, {
      status: 'RUNNING',
      started_at: new Date().toISOString(),
    });

    await ProductionHooks.onProductionAutomationStarted({
      automationId: currentAuto.id,
      workspaceId: currentAuto.workspace_id,
      status: 'RUNNING',
      timestamp: new Date().toISOString(),
    });

    const supabase = (this.repository as unknown as { supabase: SupabaseClient }).supabase;

    // Default mock requests if not passed in parameters
    const userRequest = extraContext?.userRequest || 'Mock request: Optimize detailing page layout';
    const bestPractice = extraContext?.bestPractice || 'Best Practice: Use lazy image loading';

    try {
      // Step A: Load Knowledge (Knowledge Retrieval)
      const stepALoadStart = Date.now();
      const loader = new KnowledgeLoader(supabase);
      // Fetch knowledge categories and details
      const rawList = await loader.loadKnowledgeList(currentAuto.workspace_id);
      await this.repository.createExecutionLog({
        automation_id: automationId,
        step: 'LOAD',
        status: 'SUCCESS',
        duration_ms: Date.now() - stepALoadStart,
      });

      // Step B: Filter Knowledge (Knowledge Filtering)
      const stepBFilterStart = Date.now();
      const filteredList = KnowledgeFilter.filter(rawList);
      if (filteredList.length === 0) {
        throw new LearningKnowledgeNotFoundError(
          'No qualified learning knowledge assets found after filtering',
        );
      }
      const targetKnowledge = filteredList[0] as { id: string; feature_summary?: string; success_pattern?: string; improvement_pattern?: string };
      await this.repository.createExecutionLog({
        automation_id: automationId,
        step: 'FILTER',
        status: 'SUCCESS',
        duration_ms: Date.now() - stepBFilterStart,
      });

      // Fetch vector data related to the knowledge
      const { data: vectorRecord } = await supabase
        .from('learning_vectors')
        .select('*')
        .eq('knowledge_id', targetKnowledge.id)
        .maybeSingle();

      const vectorDataString = vectorRecord ? JSON.stringify(vectorRecord.vector_data) : '{}';

      // Step C: Build Prompt (Prompt Builder)
      const stepCBuildStart = Date.now();
      const builder = new PromptBuilder();
      builder
        .setSystemPrompt('You are an expert product strategy planning agent.')
        .setPlanningRules('Rule 1: Always target high margin categories.')
        .setLearningSummary(targetKnowledge.feature_summary || 'N/A')
        .setDetectedPatterns(targetKnowledge.success_pattern || 'N/A')
        .setFeatureVector(vectorDataString)
        .setImprovementStrategy(targetKnowledge.improvement_pattern || 'N/A')
        .setBestPractice(bestPractice)
        .setUserRequest(userRequest);

      const buildResult = builder.build();
      await this.repository.createExecutionLog({
        automation_id: automationId,
        step: 'BUILD',
        status: 'SUCCESS',
        duration_ms: Date.now() - stepCBuildStart,
      });

      // Step D: Validate Prompt (Prompt Validation)
      const stepDValidateStart = Date.now();
      PromptValidator.validate({
        workspace: currentAuto.workspace_id,
        category: 'Conversion', // Mock category
        learningSummary: targetKnowledge.feature_summary,
        patterns: targetKnowledge.success_pattern,
        featureVector: vectorDataString,
        improvementStrategy: targetKnowledge.improvement_pattern,
        bestPractice,
        userRequest,
      });
      await this.repository.createExecutionLog({
        automation_id: automationId,
        step: 'VALIDATE',
        status: 'SUCCESS',
        duration_ms: Date.now() - stepDValidateStart,
      });

      // Write Prompt Log
      await this.repository.createPromptLog({
        automation_id: automationId,
        prompt_version: 'v1',
        prompt_checksum: buildResult.checksum,
        token_count: buildResult.tokenCount,
      });

      // Step E: Planner Execution (Production Planner)
      const stepEPlannerStart = Date.now();
      await ProductionHooks.onPlannerStarted({
        automationId,
        timestamp: new Date().toISOString(),
      });

      let plannerResult;

      // Apply Prompt Cache
      const cached = this.promptCache.get(buildResult.checksum);
      if (cached) {
        plannerResult = cached;
      } else {
        plannerResult = await ProductionPlanner.execute(buildResult.prompt, userRequest);
        this.promptCache.set(buildResult.checksum, plannerResult);
      }

      await ProductionHooks.onPlannerCompleted({
        automationId,
        strategyId: plannerResult.strategyId,
        timestamp: new Date().toISOString(),
      });

      await this.repository.createExecutionLog({
        automation_id: automationId,
        step: 'PLANNER',
        status: 'SUCCESS',
        duration_ms: Date.now() - stepEPlannerStart,
      });

      // Step F: Mark automation as SUCCESS
      currentAuto = await this.repository.updateAutomation(automationId, {
        status: 'SUCCESS',
        completed_at: new Date().toISOString(),
      });

      await ProductionHooks.onProductionCompleted({
        automationId,
        workspaceId: currentAuto.workspace_id,
        status: 'SUCCESS',
        timestamp: new Date().toISOString(),
      });

      return currentAuto;
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      // Step G: Handle failed execution status & logs
      currentAuto = await this.repository.updateAutomation(automationId, {
        status: 'FAILED',
        error_message: errMsg,
        completed_at: new Date().toISOString(),
      });

      await this.repository.createExecutionLog({
        automation_id: automationId,
        step: 'WORKFLOW',
        status: 'FAILED',
        duration_ms: Date.now() - startTime,
        error_message: errMsg,
      });

      await ProductionHooks.onProductionCompleted({
        automationId,
        workspaceId: currentAuto.workspace_id,
        status: 'FAILED',
        timestamp: new Date().toISOString(),
      });

      return currentAuto;
    }
  }

  async retry(dto: RetryProductionDto, actorId: string): Promise<ProductionAutomationDto> {
    const { automationId } = dto;

    // 1. Verify Ownership
    const isOwner = await this.repository.verifyAutomationOwnership(automationId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this automation record',
      );
    }

    // 2. Fetch Automation
    const automation = await this.repository.findAutomation(automationId);
    if (!automation) {
      throw new ValidationError('Automation record not found');
    }

    // 3. Status checks: FAILED only
    if (automation.status === 'RUNNING' || automation.status === 'SUCCESS') {
      throw new AutomationConflictError(
        `Automation process status is ${automation.status}. Retry only allowed for FAILED processes.`,
      );
    }

    // 4. Check maximum retry count limit (3)
    if (automation.retry_count >= 3) {
      throw new AutomationRetryExceededError('Maximum automation retry limit (3) exceeded');
    }

    // 5. Increment retry count and rerun workflow
    const updatedAuto = await this.repository.updateAutomation(automationId, {
      retry_count: automation.retry_count + 1,
      status: 'RUNNING',
    });

    const finalState = await this.executeWorkflow(updatedAuto.id, actorId);

    return ProductionMapper.toResponseDto(finalState);
  }

  async findStatus(automationId: string, actorId: string): Promise<ProductionAutomationDto> {
    const isOwner = await this.repository.verifyAutomationOwnership(automationId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError(
        'You do not have permission to access this automation record',
      );
    }

    const entity = await this.repository.findAutomation(automationId);
    if (!entity) {
      throw new ValidationError(`Automation record ${automationId} not found`);
    }

    return ProductionMapper.toResponseDto(entity);
  }

  async findHistory(workspaceId: string, actorId: string): Promise<ProductionAutomationDto[]> {
    const isOwner = await this.repository.verifyWorkspaceOwnership(workspaceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have permission to access this workspace');
    }

    const entities = await this.repository.findHistory(workspaceId);
    return ProductionMapper.toResponseDtoList(entities);
  }
}
export default ClosedLoopProductionService;
