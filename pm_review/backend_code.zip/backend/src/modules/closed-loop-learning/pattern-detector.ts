import crypto from 'crypto';

export interface DetectedPattern {
  category: string;
  severity: number;
  frequency: number;
  patternHash: string;
  patternData: Record<string, unknown>;
}

export const PatternDetector = {
  detect(intelligence: {
    detectedRules?: Array<{ category?: string; severity?: number; ruleId?: string }>;
  }): DetectedPattern[] {
    const detectedRules = intelligence.detectedRules || [];
    const patternsMap = new Map<string, { severity: number; frequency: number; rules: string[] }>();

    for (const rule of detectedRules) {
      const cat = rule.category || 'General';
      const existing = patternsMap.get(cat) || { severity: 0, frequency: 0, rules: [] };

      patternsMap.set(cat, {
        severity: Math.max(existing.severity, Number(rule.severity || 0)),
        frequency: existing.frequency + 1,
        rules: [...existing.rules, rule.ruleId || ''],
      });
    }

    const results: DetectedPattern[] = [];

    patternsMap.forEach((val, key) => {
      // Deterministic hash generation based on category, frequency, and rules
      const signatureString = `${key}:${val.frequency}:${val.severity}:${val.rules.sort().join(',')}`;
      const patternHash = crypto.createHash('sha256').update(signatureString).digest('hex');

      results.push({
        category: key,
        severity: val.severity,
        frequency: val.frequency,
        patternHash,
        patternData: {
          associatedRules: val.rules,
          detectedTimestamp: new Date().toISOString(),
        },
      });
    });

    return results;
  },
};
export default PatternDetector;
