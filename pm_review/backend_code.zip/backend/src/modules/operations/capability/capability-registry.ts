import { MetricsRegistry } from '../../observability/metrics/registry.js';
import { ConfigurationManager } from '../configuration/configuration-manager.js';
import { LicenseManager } from '../subscription/license-manager.js';

export interface CapabilityInfo {
  name: string;
  version: string;
  enabled: boolean;
  requiredLicense: 'Starter' | 'Pro' | 'Enterprise';
  dependencies: string[];
}

export class CapabilityRegistry {
  private static readonly capabilities = new Map<string, CapabilityInfo>();

  static register(cap: CapabilityInfo): void {
    this.capabilities.set(cap.name, cap);
  }

  static getCapabilities(): CapabilityInfo[] {
    MetricsRegistry.counter('capability_lookup_total', 1);

    const list = Array.from(this.capabilities.values());
    const currentTier = LicenseManager.getTier();

    return list.map(c => {
      // Evaluate actual capability status based on Feature Flag & License & Health
      const flagEnabled = ConfigurationManager.getFeatureFlag(c.name);
      
      let licenseOk = true;
      if (c.requiredLicense === 'Enterprise') {
        licenseOk = currentTier === 'Enterprise';
      } else if (c.requiredLicense === 'Pro') {
        licenseOk = currentTier === 'Pro' || currentTier === 'Enterprise';
      }

      return {
        ...c,
        enabled: c.enabled && flagEnabled && licenseOk,
      };
    });
  }

  static getCapability(name: string): CapabilityInfo | undefined {
    const caps = this.getCapabilities();
    return caps.find(c => c.name === name);
  }

  static clear(): void {
    this.capabilities.clear();
  }
}
export default CapabilityRegistry;
