export interface AuthPlaceholder {}
