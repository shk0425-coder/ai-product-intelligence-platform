import { vi, describe, it, expect, beforeAll } from 'vitest';

const { mockQueryBuilder, setResolver, mockSupabase } = vi.hoisted(() => {
  const qb: any = {
    select: vi.fn(),
    insert: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
    eq: vi.fn(),
    is: vi.fn(),
    gte: vi.fn(),
    lte: vi.fn(),
    order: vi.fn(),
    range: vi.fn(),
    maybeSingle: vi.fn(),
    single: vi.fn(),
    limit: vi.fn(),
  };

  const methods = [
    'select',
    'insert',
    'update',
    'delete',
    'eq',
    'is',
    'gte',
    'lte',
    'order',
    'range',
    'maybeSingle',
    'single',
    'limit',
  ];
  for (const m of methods) {
    qb[m].mockImplementation(() => qb);
  }

  let resolver = () => Promise.resolve({ data: null, count: 0, error: null });
  qb.then = (onfulfilled: any) => resolver().then(onfulfilled);

  const supabaseMock = {
    from: vi.fn().mockReturnValue(qb),
    rpc: vi.fn().mockReturnValue(qb),
  };

  return {
    mockQueryBuilder: qb,
    setResolver: (newResolver: any) => {
      resolver = newResolver;
    },
    mockSupabase: supabaseMock,
  };
});

vi.mock('@/config/supabase.js', () => {
  return {
    supabase: mockSupabase,
  };
});

import { createApp } from '@/app.js';
import jwt from 'jsonwebtoken';
import { env } from '@/config/env.js';

const generateTestToken = (userId: string, email: string) => {
  return jwt.sign({ userId, email, role: 'USER' }, env.JWT_SECRET, { expiresIn: '1h' });
};

describe('Performance Module Integration Tests', () => {
  let app: any;
  const mockUserId = '11111111-1111-1111-1111-111111111111';
  const otherUserId = '22222222-2222-2222-2222-222222222222';
  const testToken = generateTestToken(mockUserId, 'test@example.com');

  const workspaceId = '33333333-3333-3333-3333-333333333333';
  const productId = '44444444-4444-4444-4444-444444444444';
  const analysisRunId = '55555555-5555-5555-5555-555555555555';
  const performanceId = '66666666-6666-6666-6666-666666666666';

  const validPayload = {
    workspaceId,
    productId,
    analysisRunId,
    periodStart: '2026-06-01',
    periodEnd: '2026-06-15',
    salesCount: 100,
    salesAmount: 2000000,
    refundCount: 1,
    reviewCount: 10,
    reviewScore: 4.5,
    favoriteCount: 50,
    metrics: {
      impressions: 10000,
      clicks: 500,
      conversionCount: 100,
      conversionRate: 10,
      ctr: 5,
      adCost: 100000,
      profit: 500000,
      marginRate: 25,
      roi: 500,
    },
    source: {
      marketplaceCode: 'NAVER',
      marketplaceName: 'Naver Smartstore',
      collectionJobId: '77777777-7777-7777-7777-777777777777',
      sourceVersion: 1,
      collectedAt: new Date().toISOString(),
      rawPayloadHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    },
  };

  beforeAll(async () => {
    app = await createApp();
  });

  describe('Authentication Check', () => {
    it('should return 401 without authorization header', async () => {
      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/performance',
        payload: validPayload,
      });
      expect(response.statusCode).toBe(401);
    });
  });

  describe('POST /api/v1/performance (Upsert)', () => {
    it('should successfully create/upsert performance data', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyWorkspaceOwner
        // 2. verifyProductOwner
        // 3. verifyRunOwner
        if (callCount <= 3) {
          return Promise.resolve({ data: { org_id: mockUserId, workspaces: { org_id: mockUserId }, products: { workspaces: { org_id: mockUserId } } }, error: null });
        }
        // 4. rpc ('upsert_performance_foundation')
        if (callCount === 4) {
          return Promise.resolve({
            data: {
              id: performanceId,
              workspace_id: workspaceId,
              product_id: productId,
              analysis_run_id: analysisRunId,
              period_start: '2026-06-01',
              period_end: '2026-06-15',
              sales_count: 100,
              sales_amount: 2000000,
              refund_count: 1,
              review_count: 10,
              review_score: 4.5,
              favorite_count: 50,
              version: 1,
              last_collected_at: new Date().toISOString(),
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            },
            error: null,
          });
        }
        // 5. findMetrics
        if (callCount === 5) {
          return Promise.resolve({
            data: {
              id: 'metrics-id',
              performance_id: performanceId,
              impressions: 10000,
              clicks: 500,
              conversion_count: 100,
              conversion_rate: 10,
              ctr: 5,
              ad_cost: 100000,
              profit: 500000,
              margin_rate: 25,
              roi: 500,
            },
            error: null,
          });
        }
        // 6. findSource
        return Promise.resolve({
          data: {
            id: 'source-id',
            performance_id: performanceId,
            marketplace_code: 'NAVER',
            marketplace_name: 'Naver Smartstore',
            source_version: 1,
            collected_at: new Date().toISOString(),
            raw_payload_hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
          },
          error: null,
        });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/performance',
        headers: { authorization: `Bearer ${testToken}` },
        payload: validPayload,
      });

      const body = JSON.parse(response.payload);
      expect(response.statusCode).toBe(200);
      expect(body.success).toBe(true);
      expect(body.data.performanceId).toBe(performanceId);
      expect(body.data.metrics.impressions).toBe(10000);
      expect(body.data.source.marketplaceCode).toBe('NAVER');
    });

    it('should return 400 when periodStart is after periodEnd', async () => {
      const invalidPayload = {
        ...validPayload,
        periodStart: '2026-06-15',
        periodEnd: '2026-06-01',
      };

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/performance',
        headers: { authorization: `Bearer ${testToken}` },
        payload: invalidPayload,
      });

      expect(response.statusCode).toBe(400);
      const body = JSON.parse(response.payload);
      expect(body.success).toBe(false);
      expect(body.error.code).toBe('VALIDATION_ERROR');
    });

    it('should return 400 when refundCount is greater than salesCount', async () => {
      const invalidPayload = {
        ...validPayload,
        salesCount: 10,
        refundCount: 11,
      };

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/performance',
        headers: { authorization: `Bearer ${testToken}` },
        payload: invalidPayload,
      });

      expect(response.statusCode).toBe(400);
      const body = JSON.parse(response.payload);
      expect(body.success).toBe(false);
    });

    it('should return 403 when user does not own workspace', async () => {
      setResolver(() => {
        // verifyWorkspaceOwner returns workspace belonging to other user
        return Promise.resolve({ data: { org_id: otherUserId }, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/performance',
        headers: { authorization: `Bearer ${testToken}` },
        payload: validPayload,
      });

      expect(response.statusCode).toBe(403);
    });
  });

  describe('PUT /api/v1/performance/:id (Update)', () => {
    const updatePayload = {
      salesCount: 120,
      salesAmount: 2500000,
      refundCount: 0,
      reviewCount: 15,
      reviewScore: 4.8,
      favoriteCount: 60,
      metrics: {
        impressions: 12000,
        clicks: 600,
        conversionCount: 120,
        conversionRate: 10,
        ctr: 5,
        adCost: 120000,
        profit: 600000,
        marginRate: 24,
        roi: 500,
      },
      source: {
        marketplaceCode: 'NAVER',
        marketplaceName: 'Naver Smartstore',
        sourceVersion: 2,
        collectedAt: new Date().toISOString(),
        rawPayloadHash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      },
    };

    it('should successfully update performance record', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        // 1. verifyPerformanceOwner
        if (callCount === 1) {
          return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        }
        // 2. findById
        if (callCount === 2) {
          return Promise.resolve({
            data: {
              id: performanceId,
              workspace_id: workspaceId,
              product_id: productId,
              analysis_run_id: analysisRunId,
              version: 1,
            },
            error: null,
          });
        }
        // 3. findMetrics
        if (callCount === 3) {
          return Promise.resolve({ data: null, error: null });
        }
        // 4. findSource
        if (callCount === 4) {
          return Promise.resolve({ data: null, error: null });
        }
        // 5. update parent
        if (callCount === 5) {
          return Promise.resolve({
            data: {
              id: performanceId,
              version: 2,
            },
            error: null,
          });
        }
        // 6. delete metrics (part of updates)
        // 7. insert metrics
        // 8. delete source
        // 9. insert source
        // 10. createAudit
        return Promise.resolve({
          data: {
            id: 'success',
          },
          error: null,
        });
      });

      const response = await app.inject({
        method: 'PUT',
        url: `/api/v1/performance/${performanceId}`,
        headers: { authorization: `Bearer ${testToken}` },
        payload: updatePayload,
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.success).toBe(true);
    });

    it('should return 404 when updating non-existent performance record', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        if (callCount === 1) {
          // verifyPerformanceOwner
          return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        }
        // findById returns null
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'PUT',
        url: `/api/v1/performance/${performanceId}`,
        headers: { authorization: `Bearer ${testToken}` },
        payload: updatePayload,
      });

      expect(response.statusCode).toBe(404);
    });
  });

  describe('GET /api/v1/performance/:id (Find By ID)', () => {
    it('should return 200 with DTO on success', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        if (callCount === 1) {
          // verifyPerformanceOwner
          return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        }
        if (callCount === 2) {
          // findById
          return Promise.resolve({
            data: {
              id: performanceId,
              workspace_id: workspaceId,
              product_id: productId,
              analysis_run_id: analysisRunId,
            },
            error: null,
          });
        }
        // findMetrics & findSource
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/performance/${performanceId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data.performanceId).toBe(performanceId);
    });
  });

  describe('GET /api/v1/performance/latest/:productId (Latest)', () => {
    it('should return latest performance data on success', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        if (callCount === 1) {
          // verifyProductOwner
          return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        }
        if (callCount === 2) {
          // findLatest
          return Promise.resolve({
            data: {
              id: performanceId,
              product_id: productId,
            },
            error: null,
          });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'GET',
        url: `/api/v1/performance/latest/${productId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data.performanceId).toBe(performanceId);
    });
  });

  describe('DELETE /api/v1/performance/:id (Soft Delete)', () => {
    it('should soft delete performance record', async () => {
      let callCount = 0;
      setResolver(() => {
        callCount++;
        if (callCount === 1) {
          // verifyPerformanceOwner
          return Promise.resolve({ data: { workspaces: { org_id: mockUserId } }, error: null });
        }
        if (callCount === 2) {
          // findById
          return Promise.resolve({
            data: {
              id: performanceId,
              version: 1,
            },
            error: null,
          });
        }
        // findMetrics, findSource, update, createAudit
        return Promise.resolve({ data: { id: performanceId }, error: null });
      });

      const response = await app.inject({
        method: 'DELETE',
        url: `/api/v1/performance/${performanceId}`,
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.success).toBe(true);
    });
  });
});
