import { describe, it, expect, vi, beforeEach, beforeAll } from 'vitest';
import crypto from 'crypto';
import { createApp } from '../src/app.js';
import { PromptRegistry } from '../src/modules/prompt/registry.js';
import { PromptRenderer } from '../src/modules/prompt/renderer.js';
import { PromptValidator } from '../src/modules/prompt/validator.js';
import { VariableParser } from '../src/modules/prompt/variable-parser.js';
import { DynamicContextBuilder } from '../src/modules/prompt/context-builder.js';
import { promptCache } from '../src/modules/prompt/cache.js';
import { PromptRepository } from '../src/modules/prompt/repository.js';
import { PromptService } from '../src/modules/prompt/service.js';
import { AIGateway } from '../src/modules/ai-provider/gateway.js';
import { AIProviderRepository } from '../src/modules/ai-provider/repository.js';
import { ProviderRegistry } from '../src/modules/ai-provider/provider-registry.js';
import { GeneralAIProvider } from '../src/modules/ai-provider/provider-registry.js';
import { AIProviderRequest, GenerateResponse, ModelMetadata, ProviderHealthStatus } from '../src/modules/ai-provider/types.js';
import { PromptTemplateEntity, PromptVersionEntity, PromptStatus } from '../src/modules/prompt/types.js';
import { ValidationError } from '../src/common/errors/index.js';
import jwt from 'jsonwebtoken';

vi.hoisted(() => {
  (globalThis as any).__activeResolver = () => Promise.resolve({ data: null, error: null });

  const queryMockObj = {
    insert: vi.fn().mockImplementation((payload) => {
      return {
        select: vi.fn().mockImplementation(() => {
          return {
            single: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'insert', payload)),
          };
        }),
      };
    }),
    update: vi.fn().mockImplementation((payload) => {
      return {
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            eq: vi.fn().mockImplementation((col2, val2) => {
              return {
                select: vi.fn().mockImplementation(() => {
                  return {
                    maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', { col, val, col2, val2, payload })),
                  };
                }),
              };
            }),
            select: vi.fn().mockImplementation(() => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', { col, val, payload })),
              };
            }),
          };
        }),
        eqSimple: vi.fn().mockImplementation((col, val) => {
          return {
            select: vi.fn().mockImplementation(() => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'update', { col, val, payload })),
              };
            }),
          };
        }),
      };
    }),
    select: vi.fn().mockImplementation((cols) => {
      const chain = {
        is: vi.fn().mockImplementation((col, val) => {
          return {
            order: vi.fn().mockImplementation((col2, val2) => {
              return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_all_templates'));
            }),
          };
        }),
        eq: vi.fn().mockImplementation((col, val) => {
          return {
            is: vi.fn().mockImplementation((col2, val2) => {
              return {
                maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'select_template_by_id', { col, val })),
              };
            }),
            order: vi.fn().mockImplementation((col2, val2) => {
              return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_versions', { col, val }));
            }),
            maybeSingle: vi.fn().mockImplementation(() => (globalThis as any).__activeResolver(queryMockObj._table, 'select_by_id_simple', { col, val })),
          };
        }),
        order: vi.fn().mockImplementation((col, val) => {
          return Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_ordered_general'));
        }),
      };
      const promiseObj = Promise.resolve((globalThis as any).__activeResolver(queryMockObj._table, 'select_all_general'));
      Object.assign(promiseObj, chain);
      return promiseObj;
    }),
    _table: '',
  };

  (globalThis as any).__mockSupabase = {
    from: vi.fn().mockImplementation((table) => {
      queryMockObj._table = table;
      return queryMockObj;
    }),
  };
});

export const setResolver = (fn: any) => {
  (globalThis as any).__activeResolver = fn;
};

vi.mock('@supabase/supabase-js', async (importOriginal) => {
  const actual = await importOriginal() as any;
  return {
    ...actual,
    createClient: (url: string, key: string, options: any) => {
      if ((globalThis as any).__mockSupabase) {
        return (globalThis as any).__mockSupabase;
      }
      return actual.createClient(url, key, options);
    },
  };
});

// Mock Provider Adapter
class MockAdapter {
  async generate(request: AIProviderRequest, metadata: ModelMetadata): Promise<GenerateResponse> {
    return {
      content: `AI response to: ${request.prompt}`,
      finishReason: 'STOP',
      usage: { promptTokens: 100, completionTokens: 50, totalTokens: 150 },
      provider: 'GEMINI',
      model: metadata.model,
      cost: 0.005,
    };
  }

  async generateStream(request: AIProviderRequest, _metadata: ModelMetadata): Promise<AsyncIterable<string>> {
    const text = `AI Stream Response`;
    const chunks = text.split(' ');
    return {
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) {
          yield chunk + ' ';
        }
      },
    };
  }
}

describe('Prompt Registry & Dynamic Context Injection Engine (Integration Tests)', () => {
  let app: any;
  let repository: PromptRepository;
  let service: PromptService;
  let gateway: AIGateway;

  const testToken = jwt.sign({ orgId: 'test-workspace-owner-123' }, 'test-jwt-secret');
  const workspaceId = '11111111-1111-1111-1111-111111111111';

  const mockMeta: ModelMetadata = {
    provider: 'GEMINI',
    model: 'gemini-1.5-pro',
    version: 'v1.5',
    contextWindow: 100000,
    maxOutputTokens: 2048,
    supportsStreaming: true,
    supportsVision: true,
    supportsText: true,
    supportsImageGeneration: false,
    supportsImageEditing: false,
    supportsEmbedding: true,
    supportsStructuredOutput: true,
    supportsFunctionCalling: true,
    inputCost: 0.00125,
    outputCost: 0.00375,
    enabled: true,
  };

  const sampleTemplate: PromptTemplateEntity = {
    id: 'template-uuid-1',
    workspace_id: workspaceId,
    category: 'INTELLIGENCE',
    name: 'test-strategy-prompt',
    description: 'Generates product strategies',
    latest_version: 1,
    current_version_id: 'version-uuid-1',
    status: 'APPROVED',
    model_capability: 'TEXT',
    default_provider: 'GEMINI',
    default_model: 'gemini-1.5-pro',
    temperature: 0.7,
    top_p: 0.9,
    max_tokens: 1024,
    variables: ['productName', 'workspaceName'],
    tags: ['strategy'],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  const sampleVersion: PromptVersionEntity = {
    id: 'version-uuid-1',
    template_id: 'template-uuid-1',
    version: 1,
    system_prompt: 'You are an assistant in workspace {{workspaceName}}.',
    user_prompt: 'Analyze marketing plan for {{productName}}.',
    variables: ['workspaceName', 'productName'],
    checksum: 'mock-checksum',
    created_at: new Date().toISOString(),
  };

  beforeAll(async () => {
    app = await createApp();
    
    // Register general mock provider to gateway factory
    ProviderRegistry.clear();
    const provider = new GeneralAIProvider('GEMINI', 'gemini-1.5-pro', mockMeta, 100, 50000, new MockAdapter());
    ProviderRegistry.register(provider);

    const providerRepo = new AIProviderRepository((globalThis as any).__mockSupabase as any);
    gateway = new AIGateway(providerRepo);

    repository = new PromptRepository((globalThis as any).__mockSupabase as any);
    service = new PromptService(repository, gateway);
  });

  beforeEach(() => {
    promptCache.clear();
    PromptRegistry.clear();
  });

  // 1. Variable Parser Tests
  describe('VariableParser tests', () => {
    it('should parse simple variables', () => {
      const vars = VariableParser.parse('Hello {{name}}');
      expect(vars[0].name).toBe('name');
      expect(vars[0].isNullable).toBe(false);
    });

    it('should parse nullable variables', () => {
      const vars = VariableParser.parse('Optional: {{description?}}');
      expect(vars[0].name).toBe('description');
      expect(vars[0].isNullable).toBe(true);
    });

    it('should parse variables with default value', () => {
      const vars = VariableParser.parse('Locale: {{country|KR}}');
      expect(vars[0].name).toBe('country');
      expect(vars[0].defaultValue).toBe('KR');
    });

    it('should inject variables successfully', () => {
      const sys = 'System: {{workspaceName}}';
      const rendered = VariableParser.validateAndInject(sys, { workspaceName: 'MyOrg' }, [{ name: 'workspaceName', isNullable: false }]);
      expect(rendered).toBe('System: MyOrg');
    });

    it('should inject default values if missing in payload', () => {
      const sys = 'Locale: {{country|KR}}';
      const rendered = VariableParser.validateAndInject(sys, {}, [{ name: 'country', defaultValue: 'KR', isNullable: false }]);
      expect(rendered).toBe('Locale: KR');
    });

    it('should throw ValidationError on missing required variable', () => {
      const sys = 'Required: {{apiKey}}';
      expect(() =>
        VariableParser.validateAndInject(sys, {}, [{ name: 'apiKey', isNullable: false }])
      ).toThrow(ValidationError);
    });

    it('should render empty string for missing optional/nullable variables', () => {
      const sys = 'Option: {{notes?}}';
      const rendered = VariableParser.validateAndInject(sys, {}, [{ name: 'notes', isNullable: true }]);
      expect(rendered).toBe('Option: ');
    });
  });

  // 2. Context Builder & Provider Tests
  describe('DynamicContextBuilder tests', () => {
    it('should determine context values from providers sequentially', async () => {
      const context = await DynamicContextBuilder.build(workspaceId, {
        workspaceName: 'SeoulWorkspace',
        userName: 'Kim',
        productName: 'Notebook',
        productPrice: '1000',
        totalReviews: 20,
        reviewScore: 4.8,
        jtbdNeeds: 'Easy typing',
        marketTrend: 'Bullish',
        lastExecutionAction: 'SCRAPING',
      });

      expect(context.workspace_context).toContain('SeoulWorkspace');
      expect(context.user_context).toContain('Kim');
      expect(context.product_context).toContain('Notebook');
      expect(context.review_context).toContain('20');
      expect(context.jtbd_context).toContain('Easy typing');
      expect(context.market_context).toContain('Bullish');
      expect(context.history_context).toContain('SCRAPING');
    });
  });

  // 3. Validator Tests
  describe('PromptValidator tests', () => {
    it('should fail validation if template status is not APPROVED', () => {
      const draftTemplate = { ...sampleTemplate, status: 'DRAFT' as PromptStatus };
      expect(() =>
        PromptValidator.validate(draftTemplate, sampleVersion, 'sys', 'usr', { workspaceName: 'ws', productName: 'prod' })
      ).toThrow(ValidationError);
    });

    it('should pass validation if template is APPROVED and all required variables exist', () => {
      expect(() =>
        PromptValidator.validate(sampleTemplate, sampleVersion, 'sys', 'usr', { workspaceName: 'ws', productName: 'prod' })
      ).not.toThrow();
    });
  });

  // 4. Renderer Tests
  describe('PromptRenderer tests', () => {
    it('should render system and user prompts deterministically', async () => {
      const result = await PromptRenderer.render(
        sampleTemplate,
        sampleVersion,
        { workspaceName: 'WS1', productName: 'Prod1' },
        'gemini-1.5-pro'
      );

      expect(result.systemPrompt).toBe('You are an assistant in workspace WS1.');
      expect(result.userPrompt).toBe('Analyze marketing plan for Prod1.');
      expect(result.checksum).toBeDefined();
    });
  });

  // 5. Caching Tests
  describe('PromptCache tests', () => {
    it('should write and hit prompt cache', () => {
      const key = promptCache.generateKey('t1', 'v1', { a: 1 }, { ctx: 'test' }, 'model');
      promptCache.set(key, 'rendered-content');
      expect(promptCache.get(key)).toBe('rendered-content');
    });

    it('should expire prompt cache after TTL', async () => {
      const key = promptCache.generateKey('t1', 'v1', { a: 1 }, { ctx: 'test' }, 'model');
      promptCache.set(key, 'rendered-content', 2); // 2ms TTL
      await new Promise((resolve) => setTimeout(resolve, 5));
      expect(promptCache.get(key)).toBeNull();
    });
  });

  // 6. Service & Lifecycles Tests
  describe('PromptService operations', () => {
    it('should create prompt template and initial version successfully', async () => {
      setResolver((table: string, action: string, payload: any) => {
        if (table === 'prompt_templates') {
          const base = {
            id: 'template-id',
            latest_version: 1,
            status: 'DRAFT',
            workspace_id: workspaceId,
            category: 'MARKETING',
            name: 'test-prompt',
            temperature: 0.7,
            top_p: 0.9,
            max_tokens: 2048,
          };
          const resolvedData = action === 'update' ? { ...base, ...payload.payload } : { ...base, ...payload };
          return Promise.resolve({ data: resolvedData, error: null });
        }
        if (table === 'prompt_versions') {
          return Promise.resolve({ data: { ...payload, id: 'version-id' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const template = await service.createTemplate({
        workspaceId,
        category: 'MARKETING',
        name: 'test-prompt',
        systemPrompt: 'System {{workspaceName}}',
        userPrompt: 'User {{productName}}',
      });

      expect(template.latest_version).toBe(1);
      expect(template.status).toBe('DRAFT');
    });

    it('should increment version number and reset status to DRAFT on new version creation', async () => {
      setResolver((table: string, action: string, payload: any) => {
        if (table === 'prompt_templates' && action === 'select_template_by_id') {
          return Promise.resolve({ data: sampleTemplate, error: null });
        }
        if (table === 'prompt_versions' && action === 'insert') {
          return Promise.resolve({ data: { ...payload, id: 'ver-2' }, error: null });
        }
        if (table === 'prompt_templates' && action === 'update') {
          return Promise.resolve({ data: { ...sampleTemplate, latest_version: 2, status: 'DRAFT' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const newVer = await service.createVersion('template-uuid-1', {
        systemPrompt: 'System v2 {{workspaceName}}',
        userPrompt: 'User v2 {{productName}}',
        changeSummary: 'Update prompts content',
      });

      expect(newVer.version).toBe(2);
    });

    it('should change status to APPROVED inside approve method', async () => {
      setResolver((table: string, action: string, payload: any) => {
        if (table === 'prompt_templates' && action === 'select_template_by_id') {
          return Promise.resolve({ data: sampleTemplate, error: null });
        }
        if (table === 'prompt_templates' && action === 'update') {
          return Promise.resolve({ data: { ...sampleTemplate, status: 'APPROVED' }, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const approved = await service.approveTemplate('template-uuid-1', 'admin-user');
      expect(approved.status).toBe('APPROVED');
    });
  });

  // 7. REST API Endpoints Tests
  describe('REST API endpoints mapping', () => {
    it('should return 200 and list templates on GET /api/v1/prompts', async () => {
      setResolver(() => Promise.resolve({ data: [sampleTemplate], error: null }));

      const response = await app.inject({
        method: 'GET',
        url: '/api/v1/prompts',
        headers: { authorization: `Bearer ${testToken}` },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data[0].name).toBe('test-strategy-prompt');
    });

    it('should return 200 and preview details on POST /api/v1/prompts/preview', async () => {
      setResolver((table: string, action: string) => {
        if (table === 'prompt_templates') {
          return Promise.resolve({ data: sampleTemplate, error: null });
        }
        if (table === 'prompt_versions') {
          return Promise.resolve({ data: sampleVersion, error: null });
        }
        return Promise.resolve({ data: null, error: null });
      });

      const response = await app.inject({
        method: 'POST',
        url: '/api/v1/prompts/preview',
        headers: { authorization: `Bearer ${testToken}` },
        payload: {
          workspaceId,
          templateId: 'template-uuid-1',
          versionId: 'version-uuid-1',
          variables: {
            workspaceName: 'OrgName',
            productName: 'Sneakers',
          },
        },
      });

      expect(response.statusCode).toBe(200);
      const body = JSON.parse(response.payload);
      expect(body.data.renderedSystemPrompt).toContain('OrgName');
    });
  });
});
