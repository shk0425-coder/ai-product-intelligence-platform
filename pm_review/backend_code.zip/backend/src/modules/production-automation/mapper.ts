import { ProductionAutomationEntity } from './types.js';
import { ProductionAutomationDto } from './dto.js';

export class ProductionMapper {
  static toResponseDto(entity: ProductionAutomationEntity): ProductionAutomationDto {
    return {
      automationId: entity.id,
      workspaceId: entity.workspace_id,
      knowledgeId: entity.knowledge_id,
      status: entity.status,
      retryCount: entity.retry_count,
      startedAt: entity.started_at,
      completedAt: entity.completed_at,
      errorMessage: entity.error_message,
      createdAt: entity.created_at,
      updatedAt: entity.updated_at,
    };
  }

  static toResponseDtoList(entities: ProductionAutomationEntity[]): ProductionAutomationDto[] {
    return entities.map((entity) => this.toResponseDto(entity));
  }
}
export default ProductionMapper;
