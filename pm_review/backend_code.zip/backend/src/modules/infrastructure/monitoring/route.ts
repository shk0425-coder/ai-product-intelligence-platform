import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { InfrastructureHealthMonitor } from './health-service.js';
import { MetricsCollector } from './metrics-service.js';
import { DeadLetterQueue } from '../event/dead-letter-queue.js';
import { RedisPoolManager } from '../config/connection-pool.js';

export class InfrastructureController {
  async getHealth(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const health = await InfrastructureHealthMonitor.checkHealth();
    rep.send({ status: 'success', data: health });
  }

  async getCacheStatus(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const summary = MetricsCollector.getSummary();
    rep.send({ status: 'success', data: { cache: summary.cache } });
  }

  async getEventsStatus(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const summary = MetricsCollector.getSummary();
    const dlq = await DeadLetterQueue.getEntries();
    rep.send({ status: 'success', data: { events: summary.events, dlq } });
  }

  async getMetrics(_req: FastifyRequest, rep: FastifyReply): Promise<void> {
    const summary = MetricsCollector.getSummary();
    const pools = RedisPoolManager.getSummary();
    rep.send({ status: 'success', data: { ...summary, pools } });
  }
}

export async function systemRoutes(fastify: FastifyInstance) {
  const controller = new InfrastructureController();

  fastify.get('/health', (req, rep) => controller.getHealth(req, rep));
  fastify.get('/cache', (req, rep) => controller.getCacheStatus(req, rep));
  fastify.get('/events', (req, rep) => controller.getEventsStatus(req, rep));
  fastify.get('/metrics', (req, rep) => controller.getMetrics(req, rep));
}
