export interface MarketPlaceholder {}
