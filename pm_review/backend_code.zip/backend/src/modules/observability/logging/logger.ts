import { LogSink, ConsoleSink } from './sink.js';
import { LogMasker } from './masking.js';
import { AsyncContextManager } from '../context/context-manager.js';

export type LogLevel = 'TRACE' | 'DEBUG' | 'INFO' | 'WARN' | 'ERROR' | 'FATAL';

export interface LogPayload {
  message: string;
  requestId?: string;
  executionId?: string;
  eventId?: string;
  module?: string;
  action?: string;
  durationMs?: number;
  status?: string;
  errorCode?: string;
  [key: string]: unknown;
}

export class Logger {
  private static sinks: LogSink[] = [new ConsoleSink()];
  private static levelPriority: Record<LogLevel, number> = {
    TRACE: 0,
    DEBUG: 1,
    INFO: 2,
    WARN: 3,
    ERROR: 4,
    FATAL: 5,
  };
  private static minLevel: LogLevel = 'INFO';

  static setMinLevel(level: LogLevel): void {
    this.minLevel = level;
  }

  static setSinks(sinks: LogSink[]): void {
    this.sinks = sinks;
  }

  static addSink(sink: LogSink): void {
    this.sinks.push(sink);
  }

  static log(level: LogLevel, payload: LogPayload): void {
    // Feature flag check
    const enabled = process.env.OBS_LOGGING_ENABLED !== 'false';
    if (!enabled) return;

    if (this.levelPriority[level] < this.levelPriority[this.minLevel]) {
      return;
    }

    const context = AsyncContextManager.getStore() || {};

    const baseLog: Record<string, unknown> = {
      timestamp: new Date().toISOString(),
      level,
      trace_id: context.traceId || null,
      span_id: context.spanId || null,
      correlation_id: context.correlationId || null,
      workspace_id: context.workspaceId || null,
      workflow_id: context.workflowId || null,
      request_id: payload.requestId || null,
      execution_id: payload.executionId || null,
      event_id: payload.eventId || null,
      module: payload.module || null,
      action: payload.action || null,
      duration_ms: payload.durationMs !== undefined ? payload.durationMs : null,
      status: payload.status || null,
      error_code: payload.errorCode || null,
      message: payload.message,
    };

    // Merge other custom properties
    for (const key of Object.keys(payload)) {
      if (
        ![
          'message',
          'requestId',
          'executionId',
          'eventId',
          'module',
          'action',
          'durationMs',
          'status',
          'errorCode',
        ].includes(key)
      ) {
        baseLog[key] = payload[key];
      }
    }

    // Apply PII masking
    const maskedLog = LogMasker.mask(baseLog) as Record<string, unknown>;

    // Dispatch to all configured sinks
    for (const sink of this.sinks) {
      try {
        sink.write(maskedLog);
      } catch {
        // Enforce resilience: sink failures should not disrupt the application
      }
    }
  }

  static trace(payload: LogPayload): void { this.log('TRACE', payload); }
  static debug(payload: LogPayload): void { this.log('DEBUG', payload); }
  static info(payload: LogPayload): void { this.log('INFO', payload); }
  static warn(payload: LogPayload): void { this.log('WARN', payload); }
  static error(payload: LogPayload): void { this.log('ERROR', payload); }
  static fatal(payload: LogPayload): void { this.log('FATAL', payload); }
}
