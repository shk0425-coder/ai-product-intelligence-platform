export const ALLOWED_NAMESPACES = [
  'prompt',
  'workflow',
  'tool',
  'provider',
  'workspace',
  'user',
  'analysis',
  'market',
  'strategy',
  'system',
] as const;

export type CacheNamespace = typeof ALLOWED_NAMESPACES[number];

export class CacheNamespaceValidator {
  static validate(ns: string): void {
    if (!ALLOWED_NAMESPACES.includes(ns as CacheNamespace)) {
      throw new Error(`Forbidden Cache Namespace attempted: "${ns}"`);
    }
  }
}
