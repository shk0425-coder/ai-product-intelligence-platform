export interface JobDefinition {
  id: string;
  name: string;
  priority: 'Critical' | 'High' | 'Normal' | 'Low';
  timeoutMs: number;
  maxRetry: number;
  backoffMs: number;
  tags: string[];
  metadata: Record<string, unknown>;
}

export class JobRepository {
  private static readonly jobs = new Map<string, JobDefinition>();

  static async save(job: JobDefinition): Promise<void> {
    this.jobs.set(job.id, { ...job });
  }

  static async findById(id: string): Promise<JobDefinition | undefined> {
    const job = this.jobs.get(id);
    return job ? { ...job } : undefined;
  }

  static async findByName(name: string): Promise<JobDefinition | undefined> {
    return Array.from(this.jobs.values()).find(j => j.name === name);
  }

  static async delete(id: string): Promise<boolean> {
    return this.jobs.delete(id);
  }

  static async findAll(): Promise<JobDefinition[]> {
    return Array.from(this.jobs.values()).map(j => ({ ...j }));
  }

  static clear(): void {
    this.jobs.clear();
  }
}
export default JobRepository;
