import { MetricsRegistry } from '../../observability/metrics/registry.js';

export interface SecretValue {
  key: string;
  value: string;
  expiresAt: number;
}

export class SecretManager {
  private static readonly secrets = new Map<string, SecretValue>();

  static setSecret(key: string, value: string, expiresMs = 86400000): void {
    this.secrets.set(key, {
      key,
      value,
      expiresAt: Date.now() + expiresMs,
    });
  }

  static getSecret(key: string): string | null {
    const existing = this.secrets.get(key);
    if (!existing || existing.expiresAt <= Date.now()) {
      return null; // Expired or missing
    }
    return existing.value;
  }

  static rotateSecret(key: string, newValue: string): void {
    this.setSecret(key, newValue);
    MetricsRegistry.counter('secret_rotation_total', 1, { key });
  }

  static clear(): void {
    this.secrets.clear();
  }
}
export default SecretManager;
