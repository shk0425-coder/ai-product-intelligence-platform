import { LearningKnowledgeEntity, LearningVectorEntity } from './types.js';
import { LearningKnowledgeDto, LearningVectorDto } from './dto.js';

export class LearningMapper {
  static toVectorDto(entity: LearningVectorEntity): LearningVectorDto {
    return {
      vectorId: entity.id,
      knowledgeId: entity.knowledge_id,
      vectorVersion: entity.vector_version,
      vectorData: entity.vector_data,
      featureCount: entity.feature_count,
      checksum: entity.checksum,
      createdAt: entity.created_at,
    };
  }

  static toKnowledgeDto(
    knowledge: LearningKnowledgeEntity,
    vector?: LearningVectorEntity,
  ): LearningKnowledgeDto {
    return {
      knowledgeId: knowledge.id,
      intelligenceId: knowledge.intelligence_id,
      knowledgeVersion: knowledge.knowledge_version,
      featureSummary: knowledge.feature_summary,
      successPattern: knowledge.success_pattern,
      failurePattern: knowledge.failure_pattern,
      improvementPattern: knowledge.improvement_pattern,
      knowledgeScore: Number(knowledge.knowledge_score),
      confidenceScore: Number(knowledge.confidence_score),
      vector: vector ? this.toVectorDto(vector) : undefined,
      createdAt: knowledge.created_at,
      updatedAt: knowledge.updated_at,
    };
  }

  static toKnowledgeDtoList(
    knowledges: LearningKnowledgeEntity[],
    vectorsMap?: Map<string, LearningVectorEntity>,
  ): LearningKnowledgeDto[] {
    return knowledges.map((k) => {
      const v = vectorsMap ? vectorsMap.get(k.id) : undefined;
      return this.toKnowledgeDto(k, v);
    });
  }
}
export default LearningMapper;
