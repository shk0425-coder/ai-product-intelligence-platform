import { MetricsRegistry } from '../registry.js';

export class AiMetricsCollector {
  private static accumulatedCost = 0;

  static recordRequest(provider: string, model: string, tokens: number, latencyMs: number, cost: number): void {
    MetricsRegistry.counter('ai_requests_total', 1, { provider, model });
    MetricsRegistry.counter('ai_tokens_total', tokens, { provider, model });
    MetricsRegistry.histogram('ai_latency_seconds', latencyMs / 1000, { provider, model });

    this.accumulatedCost += cost;
    MetricsRegistry.gauge('ai_cost_usd_accumulated', this.accumulatedCost, { provider, model });
  }

  static getAccumulatedCost(): number {
    return this.accumulatedCost;
  }

  static resetCost(): void {
    this.accumulatedCost = 0;
  }
}
