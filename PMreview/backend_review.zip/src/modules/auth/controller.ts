export class AuthController {}
