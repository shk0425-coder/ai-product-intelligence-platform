# Implementation Plan - Phase 7-5 (Version 2.2 - Final)

## Enterprise Platform Completion & Production Operations Foundation (최종)

SaaS Production 서비스 출시에 필요한 운영(Operations), 배포(Deployment), 설정(Configuration), 보안(Security), 멀티테넌시(Isolation), 과금(Billing), 감사(Audit) 및 System Capability를 포괄하는 종합 Enterprise Operations Control Plane을 구축합니다.

이 단계를 마지막으로 Phase 7 백엔드 플랫폼 전 영역을 마감하고 **Backend Freeze**를 선언하여, 차기 단계인 Phase 8(프론트엔드 UI/UX 결합 개발) 진입 시 추가적인 백엔드 구조 수정이 필요 없도록 견고성을 끌어올립니다.

---

## User Review Required

> [!IMPORTANT]
> **1. Read Only Mode Maintenance & Pre-Deployment Validation**
> - 유지보수 시 안전한 큐 Drain 및 쓰기 요청 차단을 위한 Read Only Mode 기능을 탑재합니다.
> - 무중단 배포(Canary/Blue-Green) 기동 전 설정 상태 및 권한 검사를 수행하는 Pre-Deployment Validation 기능을 가동합니다.

> [!IMPORTANT]
> **2. Backend Freeze & Phase 8 Entry Criteria**
> - 이 Sprint를 끝으로 Core Backend 구조 변경을 동결하고, Phase 8에서는 오직 프론트엔드 개발 및 기존 API 연동에만 집중합니다.
> - 핵심 구조 변경 필요 시 RFC 아키텍처 리뷰를 필수로 거쳐야 하는 Governance 정책을 적용합니다.

---

## Proposed Changes

### Operations Module

#### [NEW] [lock](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/lock/)
- `recovery-lock-manager.ts` / `lease-manager.ts` / `lock-registry.ts`: 임기 획득, 자동 연장 및 Dead Lock 타임아웃 해제기.

#### [NEW] [idempotency](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/idempotency/)
- `recovery-idempotency.ts` / `execution-registry.ts`: 복구 Exactly Once 멱등 통제기.

#### [NEW] [notification](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/notification/)
- `notification-manager.ts` / `notification-dispatcher.ts` / `template-engine.ts`: Email/Slack/Webhook 및 대시보드 전송 분배기.

#### [NEW] [validator](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/validator/)
- `health-validator.ts` / `readiness-validator.ts` / `liveness-validator.ts` / `dependency-validator.ts`: Liveness/Readiness 종합 헬스 검증기.

#### [NEW] [maintenance](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/maintenance/)
- `maintenance-manager.ts` / `drain-controller.ts`: Read Only Mode가 추가 지원되는 안전배포용 큐 Drain 제어기.

#### [NEW] [audit](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/audit/)
- `audit-center.ts` / `audit-query.ts` / `audit-retention.ts` / `audit-exporter.ts`: 검색, CSV/JSON 내보내기, 타임라인 정렬 및 만료 로그 파기 제어기.

#### [NEW] [capability](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/capability/)
- `capability-registry.ts` / `capability-provider.ts` / `capability-controller.ts` / `capability-route.ts`: Feature Flag 와 Subscription 등급 변경 시 실시간 반영 기능을 제공하는 기능 가용성 명세 제어기.

#### [NEW] [workspace](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/workspace/)
- `isolation-auditor.ts`: 워크스페이스 간 캐시/이벤트/데이터 교차 검출 감사기.

#### [NEW] [compatibility](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/compatibility/)
- `api-compatibility-checker.ts`: API Breaking Change 자동 검출기.

#### [NEW] [configuration](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/configuration/)
- `configuration-manager.ts` / `configuration-registry.ts` / `configuration-schema.ts` / `runtime-config.ts`: 무중단 Dynamic Reload 지원 중앙 런타임 설정 모듈.

#### [NEW] [secret](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/secret/)
- `secret-manager.ts` / `secret-provider.ts` / `secret-rotator.ts`: 런타임 키 갱신 및 암호 관리기.

#### [NEW] [subscription](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/subscription/)
- `license-manager.ts` / `subscription-manager.ts` / `feature-gate.ts`: SaaS 등급(Starter/Pro/Enterprise) 기능 및 AI 사용량 제어 통문.

#### [NEW] [metering](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/metering/)
- `usage-meter.ts` / `usage-repository.ts`: API, Token, Scheduler Job 과금 수집기.

#### [NEW] [quota](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/quota/)
- `quota-manager.ts` / `quota-validator.ts`: 계정별 한도 위반 검증기.

#### [NEW] [deployment](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/deployment/)
- `deployment-coordinator.ts` / `rollout-manager.ts`: Pre-Deployment Validation 기능이 탑재되어 무중단 배포 검증을 수행하는 배포 관리기.

#### [NEW] [upgrade](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/upgrade/)
- `upgrade-manager.ts` / `migration-coordinator.ts`: 런타임 롤백 및 DDL 자동 호환성 마이그레이션 도우미.

#### [NEW] [api](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/api/)
- `route.ts` & `controller.ts`: Operations Dashboard 및 Audit Center, Capability Registry REST API 라우트 연동.

#### [NEW] [index.ts](file:///Users/kimsanghyeon/Projects/앱개발/naver_shopping_dashboard/backend/src/modules/operations/index.ts)
- 모듈 통합 진입점.

---

## Verification Plan

### Automated Tests
- `backend/tests/operations.test.ts` 통합 테스트 스위트 작성.
- **핵심 테스트 검증 항목**:
  1. Distributed Recovery Lock & Renewal: 락 점유 및 lease 자동 연장, 타임아웃 해제 검증.
  2. Recovery Idempotency & Duplicate: 동일 Execution ID 중복 복구 요청 시 Exactly Once 처리 검증.
  3. Pre-Deployment Validation & Rollback: 배포 사전 검증 오류 발생 시 롤백 차단 검증.
  4. Maintenance Read Only Mode: Read Only 모드 기동 시 쓰기 작업 차단 예외 검증.
  5. Audit Search & Timeline & Export: 기간, Severity 필터 및 JSON/CSV 내보내기, Retention 정책에 따른 데이터 만료 청소 검증.
  6. Capability Discovery API: Feature Flag 및 라이선스 등급 Pro 변경 시 AI capability 락 해제 동적 검증.
  7. Multi-Tenant Isolation Audit: 다른 테넌트 간 데이터 누수 시도 시 예외 차단 검출 감사 검증.
  8. TSC 빌드 컴파일 무결성 검증 및 ESLint 0 Errors 통과 검사.

```bash
# 로컬 테스트 검증 구동 명령어
npm run test -- tests/operations.test.ts --run
```
