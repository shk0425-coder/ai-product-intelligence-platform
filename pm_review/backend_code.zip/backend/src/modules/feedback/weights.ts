import { pino } from 'pino';

const logger = pino();

export interface FeedbackWeights {
  [key: string]: number;
  sales: number;
  review: number;
  conversion: number;
  ctr: number;
  roi: number;
  profit: number;
  favorite: number;
}

export const FEEDBACK_WEIGHTS: FeedbackWeights = {
  sales: 30,
  review: 15,
  conversion: 15,
  ctr: 10,
  roi: 15,
  profit: 10,
  favorite: 5,
};

export const PENALTY_WEIGHTS = {
  refund: -10, // Refund penalty weighting factor
};

/**
 * Validates that the sum of the configured feedback weights equals exactly 100.
 * If validation fails, the server process will exit with status 1.
 */
export const validateWeights = (): void => {
  const sum =
    FEEDBACK_WEIGHTS.sales +
    FEEDBACK_WEIGHTS.review +
    FEEDBACK_WEIGHTS.conversion +
    FEEDBACK_WEIGHTS.ctr +
    FEEDBACK_WEIGHTS.roi +
    FEEDBACK_WEIGHTS.profit +
    FEEDBACK_WEIGHTS.favorite;

  if (sum !== 100) {
    logger.fatal(
      { sum, configuredWeights: FEEDBACK_WEIGHTS },
      'CRITICAL: Feedback weights configuration sum must be exactly 100. Server startup blocked.',
    );
    process.exit(1);
  }
  logger.info({ sum }, 'Feedback weights validation successful.');
};
