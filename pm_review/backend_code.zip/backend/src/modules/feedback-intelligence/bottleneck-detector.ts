import { FeedbackRule } from './rules.js';

export interface BottleneckResult {
  bottleneckSummary: string;
  rootCauses: string[];
  weaknessSummary: string;
}

export const BottleneckDetector = {
  detect(matchedRules: FeedbackRule[]): BottleneckResult {
    // Filter critical rules (severity >= 4) or highest priority
    const severeRules = matchedRules.filter((r) => r.severity >= 4);

    // Sort severe rules by priority (ascending), then severity (descending)
    const sortedSevere = [...severeRules].sort((a, b) => {
      if (a.priority !== b.priority) {
        return a.priority - b.priority;
      }
      return b.severity - a.severity;
    });

    const rootCauses = matchedRules.map((r) => `${r.category} issue: ${r.message}`);

    let bottleneckSummary = '검출된 주요 병목 현상이 없습니다. 현재 판매가 정상 진행 중입니다.';
    let weaknessSummary = '보완할 점이 발견되지 않았습니다.';

    if (sortedSevere.length > 0) {
      bottleneckSummary = `우선순위 요인 [${sortedSevere[0].category}] 병목 검출: ${sortedSevere[0].message}`;
    }

    const weaknesses = matchedRules.filter((r) => r.severity >= 3);
    if (weaknesses.length > 0) {
      weaknessSummary = weaknesses.map((w) => `[${w.category}] ${w.message}`).join(' | ');
    }

    return {
      bottleneckSummary,
      rootCauses,
      weaknessSummary,
    };
  },
};
export default BottleneckDetector;
