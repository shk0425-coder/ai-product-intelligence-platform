import { SupabaseClient } from '@supabase/supabase-js';
import { JobQueueEntity, JobExecutionLogEntity, JobDeadLetterEntity } from './types.js';

export class JobQueueRepository {
  constructor(private readonly supabase: SupabaseClient) {}

  async createJob(payload: Partial<JobQueueEntity>): Promise<JobQueueEntity> {
    const { data, error } = await this.supabase
      .from('job_queue')
      .insert(payload)
      .select('*')
      .single();

    if (error || !data) {
      throw new Error(`Failed to create job: ${error?.message}`);
    }
    return data;
  }

  async updateJob(id: string, payload: Partial<JobQueueEntity>): Promise<JobQueueEntity> {
    const { data, error } = await this.supabase
      .from('job_queue')
      .update({ ...payload, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('*')
      .single();

    if (error || !data) {
      throw new Error(`Failed to update job: ${error?.message}`);
    }
    return data;
  }

  async findJob(id: string): Promise<JobQueueEntity | null> {
    const { data, error } = await this.supabase
      .from('job_queue')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) return null;
    return data;
  }

  async findHistory(workspaceId: string): Promise<JobQueueEntity[]> {
    const { data, error } = await this.supabase
      .from('job_queue')
      .select('*')
      .eq('workspace_id', workspaceId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];
    return data;
  }

  async acquireLease(jobId: string, owner: string, durationSeconds: number): Promise<JobQueueEntity | null> {
    const now = new Date().toISOString();
    const until = new Date(Date.now() + durationSeconds * 1000).toISOString();

    // Atomic Optimistic Lock update: can acquire if PENDING or FAILED, or lease expired
    const { data, error } = await this.supabase
      .from('job_queue')
      .update({
        status: 'RUNNING',
        lease_owner: owner,
        lease_until: until,
        heartbeat_at: now,
        started_at: now,
        updated_at: now,
      })
      .eq('id', jobId)
      .or(`status.eq.PENDING,status.eq.FAILED,lease_until.lt.${now}`)
      .select('*')
      .maybeSingle();

    if (error || !data) return null;
    return data;
  }

  async updateHeartbeat(jobId: string, durationSeconds: number): Promise<JobQueueEntity | null> {
    const now = new Date().toISOString();
    const until = new Date(Date.now() + durationSeconds * 1000).toISOString();

    const { data, error } = await this.supabase
      .from('job_queue')
      .update({
        heartbeat_at: now,
        lease_until: until,
        updated_at: now,
      })
      .eq('id', jobId)
      .eq('status', 'RUNNING')
      .select('*')
      .maybeSingle();

    if (error || !data) return null;
    return data;
  }

  async createExecutionLog(payload: Partial<JobExecutionLogEntity>): Promise<JobExecutionLogEntity> {
    const { data, error } = await this.supabase
      .from('job_execution_logs')
      .insert(payload)
      .select('*')
      .single();

    if (error || !data) {
      throw new Error(`Failed to create execution log: ${error?.message}`);
    }
    return data;
  }

  async createDeadLetter(payload: Partial<JobDeadLetterEntity>): Promise<JobDeadLetterEntity> {
    const { data, error } = await this.supabase
      .from('job_dead_letters')
      .insert(payload)
      .select('*')
      .single();

    if (error || !data) {
      throw new Error(`Failed to create dead letter log: ${error?.message}`);
    }
    return data;
  }

  async findDeadLetters(): Promise<JobDeadLetterEntity[]> {
    const { data, error } = await this.supabase
      .from('job_dead_letters')
      .select('*')
      .order('created_at', { ascending: false });

    if (error || !data) return [];
    return data;
  }

  async verifyWorkspaceOwnership(workspaceId: string, userId: string): Promise<boolean> {
    // Multi-level inner join validation matching workspaces.id to workspaces_members (if exists) or workspaces owners
    const { data, error } = await this.supabase
      .from('workspaces')
      .select('id')
      .eq('id', workspaceId)
      .eq('org_id', userId) // Mocking validation logic against org_id mapping
      .maybeSingle();

    if (error || !data) return false;
    return true;
  }

  async verifyJobOwnership(jobId: string, userId: string): Promise<boolean> {
    const { data, error } = await this.supabase
      .from('job_queue')
      .select('id, workspaces!inner(org_id)')
      .eq('id', jobId)
      .eq('workspaces.org_id', userId)
      .maybeSingle();

    if (error || !data) return false;
    return true;
  }
}
