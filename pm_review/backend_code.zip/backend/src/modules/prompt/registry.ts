import { PromptTemplateEntity, PromptVersionEntity } from './types.js';

export class PromptRegistry {
  private static readonly templateCache = new Map<string, PromptTemplateEntity>();
  private static readonly versionCache = new Map<string, PromptVersionEntity>();

  static cacheTemplate(template: PromptTemplateEntity): void {
    this.templateCache.set(template.id, template);
  }

  static getTemplate(templateId: string): PromptTemplateEntity | null {
    return this.templateCache.get(templateId) || null;
  }

  static cacheVersion(version: PromptVersionEntity): void {
    this.versionCache.set(version.id, version);
  }

  static getVersion(versionId: string): PromptVersionEntity | null {
    return this.versionCache.get(versionId) || null;
  }

  static clear(): void {
    this.templateCache.clear();
    this.versionCache.clear();
  }
}
export default PromptRegistry;
