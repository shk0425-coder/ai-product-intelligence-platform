export interface AnalyzeFeedbackDto {
  feedbackScoreId: string;
  ruleVersion?: string;
}

export interface ReanalyzeFeedbackDto {
  feedbackScoreId: string;
  ruleVersion?: string;
}

export interface FeedbackIntelligenceDto {
  intelligenceId: string;
  feedbackScoreId: string;
  analysisVersion: number;
  ruleVersion: string;
  strengthSummary: string;
  weaknessSummary: string;
  bottleneckSummary: string;
  improvementSummary: string;
  rootCauses: string[];
  recommendations: Array<{
    priority: number;
    category: string;
    recommendation: string;
    expectedImpact: number;
  }>;
  detectedRules: Array<{
    ruleId: string;
    category: string;
    severity: number;
    message: string;
  }>;
  impactScore: number;
  confidenceScore: number;
  executionTimeMs: number;
  analyzedAt: string;
  createdAt: string;
}

export interface FeedbackIntelligenceHistoryDto {
  history: FeedbackIntelligenceDto[];
  totalCount: number;
}
