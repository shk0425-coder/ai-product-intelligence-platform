import crypto from 'crypto';
import { PromptTemplateEntity, PromptVersionEntity } from './types.js';
import { VariableParser } from './variable-parser.js';
import { DynamicContextBuilder } from './context-builder.js';
import { PromptValidator } from './validator.js';
import { promptCache } from './cache.js';

export interface RenderedPromptResult {
  systemPrompt: string;
  userPrompt: string;
  checksum: string;
  cacheKey: string;
  estimatedTokens: number;
}

export class PromptRenderer {
  static async render(
    template: PromptTemplateEntity,
    version: PromptVersionEntity,
    variables: Record<string, unknown>,
    model: string
  ): Promise<RenderedPromptResult> {
    // 1. Dynamic Context Build
    const context = await DynamicContextBuilder.build(template.workspace_id, variables);

    // Merge original variables with injected context parameters
    const mergedVariables = {
      ...variables,
      ...context,
    };

    // 2. Variable Parsing
    const systemVars = VariableParser.parse(version.system_prompt);
    const userVars = VariableParser.parse(version.user_prompt);

    // 3. Execution Validation
    // Validate variables match defined ones
    const renderedSystem = VariableParser.validateAndInject(version.system_prompt, mergedVariables, systemVars);
    const renderedUser = VariableParser.validateAndInject(version.user_prompt, mergedVariables, userVars);

    PromptValidator.validate(template, version, renderedSystem, renderedUser, variables);

    // 4. Token Estimation (1 character ~ 0.25 tokens rough safety scale)
    const estimatedTokens = Math.floor((renderedSystem.length + renderedUser.length) / 4) + 10;

    // 5. Generate Cache Key
    const cacheKey = promptCache.generateKey(template.id, version.id, variables, context, model);
    const checksum = crypto.createHash('sha256').update(renderedSystem + renderedUser).digest('hex');

    return {
      systemPrompt: renderedSystem,
      userPrompt: renderedUser,
      checksum,
      cacheKey,
      estimatedTokens,
    };
  }
}
export default PromptRenderer;
