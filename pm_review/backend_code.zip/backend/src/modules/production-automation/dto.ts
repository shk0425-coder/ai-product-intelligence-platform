export interface RunProductionDto {
  workspaceId: string;
  knowledgeId: string;
  userRequest: string;
  bestPractice?: string;
}

export interface RetryProductionDto {
  automationId: string;
}

export interface ProductionAutomationDto {
  automationId: string;
  workspaceId: string;
  knowledgeId: string;
  status: 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED';
  retryCount: number;
  startedAt?: string;
  completedAt?: string;
  errorMessage?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProductionHistoryDto {
  history: ProductionAutomationDto[];
  totalCount: number;
}
