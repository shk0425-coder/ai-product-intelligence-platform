import { ApprovalStatus } from './types.js';
import { ValidationError } from '../../common/errors/index.js';

export class ApprovalStateMachine {
  private static readonly transitions: Record<ApprovalStatus, ApprovalStatus[]> = {
    PENDING: ['APPROVED', 'REJECTED', 'TIMEOUT', 'CANCELLED'],
    APPROVED: ['RESUMED'],
    RESUMED: [], // terminal
    REJECTED: [], // terminal
    TIMEOUT: [], // terminal
    CANCELLED: [], // terminal
  };

  static transition(current: ApprovalStatus, next: ApprovalStatus): ApprovalStatus {
    const allowed = this.transitions[current] || [];
    if (!allowed.includes(next)) {
      throw new ValidationError(`Invalid approval state transition requested from ${current} to ${next}`);
    }
    return next;
  }
}
export default ApprovalStateMachine;
