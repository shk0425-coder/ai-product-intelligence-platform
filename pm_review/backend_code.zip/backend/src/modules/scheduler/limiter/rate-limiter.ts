export class DistributedRateLimiter {
  // Map containing sliding window timestamps: key -> [timestamps]
  private static windows = new Map<string, number[]>();

  static async isAllowed(key: string, limit: number, windowMs: number): Promise<boolean> {
    const enabled = process.env.RATE_LIMITER_ENABLED !== 'false';
    if (!enabled) return true;

    const now = Date.now();
    const timestamps = this.windows.get(key) || [];

    // Filter out timestamps outside window duration
    const activeTimestamps = timestamps.filter(t => now - t < windowMs);

    if (activeTimestamps.length >= limit) {
      this.windows.set(key, activeTimestamps);
      return false; // Limit exceeded
    }

    activeTimestamps.push(now);
    this.windows.set(key, activeTimestamps);
    return true;
  }

  static clear(): void {
    this.windows.clear();
  }
}
export default DistributedRateLimiter;
