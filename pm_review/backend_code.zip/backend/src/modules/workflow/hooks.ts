export class WorkflowHooks {
  static async onWorkflowCreated(_workflowId: string, _workspaceId: string): Promise<void> {
    // Triggers when workflow is created
  }

  static async onVersionCreated(_workflowId: string, _versionId: string, _version: number): Promise<void> {
    // Triggers when workflow version is generated
  }

  static async onExecutionStateTransition(
    _executionId: string,
    _prev: string,
    _next: string
  ): Promise<void> {
    // Triggers on execution state transition
  }
}
export default WorkflowHooks;
