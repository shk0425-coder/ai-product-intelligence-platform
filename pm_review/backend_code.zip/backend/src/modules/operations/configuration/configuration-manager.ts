import { MetricsRegistry } from '../../observability/metrics/registry.js';

export interface RuntimeConfig {
  redisTimeoutMs: number;
  queueConcurrency: number;
  aiModelName: string;
  schedulerTickIntervalMs: number;
  featureFlags: Record<string, boolean>;
}

export class ConfigurationManager {
  private static config: RuntimeConfig = {
    redisTimeoutMs: 2000,
    queueConcurrency: 10,
    aiModelName: 'gemini-1.5-pro',
    schedulerTickIntervalMs: 5000,
    featureFlags: {},
  };

  static getConfig(): RuntimeConfig {
    return { ...this.config };
  }

  static updateConfig(newConfig: Partial<RuntimeConfig>): void {
    // Basic validation
    if (newConfig.redisTimeoutMs !== undefined && newConfig.redisTimeoutMs <= 0) {
      throw new Error('redisTimeoutMs must be positive');
    }

    this.config = {
      ...this.config,
      ...newConfig,
      featureFlags: {
        ...this.config.featureFlags,
        ...(newConfig.featureFlags || {}),
      },
    };

    MetricsRegistry.counter('configuration_reload_total', 1);
  }

  static getFeatureFlag(flag: string): boolean {
    return this.config.featureFlags[flag] ?? true; // Defaults to enabled
  }

  static clear(): void {
    this.config = {
      redisTimeoutMs: 2000,
      queueConcurrency: 10,
      aiModelName: 'gemini-1.5-pro',
      schedulerTickIntervalMs: 5000,
      featureFlags: {},
    };
  }
}
export default ConfigurationManager;
