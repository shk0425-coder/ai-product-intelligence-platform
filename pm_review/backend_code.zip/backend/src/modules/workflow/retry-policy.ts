import { DEFAULT_STEP_RETRY_LIMIT } from './constants.js';

export class StepRetryPolicy {
  static getDelayMs(retryCount: number, customIntervalMs?: number): number {
    const base = customIntervalMs !== undefined ? customIntervalMs : DEFAULT_STEP_RETRY_LIMIT;
    // Exponential Backoff: interval * 2^retry
    return base * Math.pow(2, retryCount);
  }

  static shouldRetry(retryCount: number, maxRetry?: number): boolean {
    const limit = maxRetry !== undefined ? maxRetry : DEFAULT_STEP_RETRY_LIMIT;
    return retryCount < limit;
  }
}
export default StepRetryPolicy;
