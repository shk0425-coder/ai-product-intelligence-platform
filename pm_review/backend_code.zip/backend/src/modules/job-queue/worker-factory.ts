import { WorkerRegistry, IWorker } from './worker-registry.js';

export const WorkerFactory = {
  getWorker(type: string): IWorker {
    const worker = WorkerRegistry.getWorker(type);
    if (!worker) {
      throw new Error(`No registered worker instance found for job type: ${type}`);
    }
    return worker;
  },
};
