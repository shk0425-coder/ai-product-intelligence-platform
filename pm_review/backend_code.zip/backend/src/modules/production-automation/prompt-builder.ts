import crypto from 'crypto';

export interface PromptSections {
  systemPrompt: string;
  planningRules: string;
  learningSummary: string;
  detectedPatterns: string;
  featureVector: string;
  improvementStrategy: string;
  bestPractice: string;
  userRequest: string;
}

export interface PromptBuildResult {
  prompt: string;
  checksum: string;
  tokenCount: number;
}

export class PromptBuilder {
  private sections: Partial<PromptSections> = {};

  setSystemPrompt(val: string): this {
    this.sections.systemPrompt = val;
    return this;
  }

  setPlanningRules(val: string): this {
    this.sections.planningRules = val;
    return this;
  }

  setLearningSummary(val: string): this {
    this.sections.learningSummary = val;
    return this;
  }

  setDetectedPatterns(val: string): this {
    this.sections.detectedPatterns = val;
    return this;
  }

  setFeatureVector(val: string): this {
    this.sections.featureVector = val;
    return this;
  }

  setImprovementStrategy(val: string): this {
    this.sections.improvementStrategy = val;
    return this;
  }

  setBestPractice(val: string): this {
    this.sections.bestPractice = val;
    return this;
  }

  setUserRequest(val: string): this {
    this.sections.userRequest = val;
    return this;
  }

  build(): PromptBuildResult {
    const list: string[] = [];

    // Enforce strict order
    if (this.sections.systemPrompt) list.push(`[System Prompt]\n${this.sections.systemPrompt}`);
    if (this.sections.planningRules) list.push(`[Planning Rules]\n${this.sections.planningRules}`);
    if (this.sections.learningSummary)
      list.push(`[Learning Summary]\n${this.sections.learningSummary}`);
    if (this.sections.detectedPatterns)
      list.push(`[Detected Patterns]\n${this.sections.detectedPatterns}`);
    if (this.sections.featureVector) list.push(`[Feature Vector]\n${this.sections.featureVector}`);
    if (this.sections.improvementStrategy)
      list.push(`[Improvement Strategy]\n${this.sections.improvementStrategy}`);
    if (this.sections.bestPractice) list.push(`[Best Practices]\n${this.sections.bestPractice}`);
    if (this.sections.userRequest) list.push(`[User Request]\n${this.sections.userRequest}`);

    const prompt = list.join('\n\n');

    // Compute SHA-256 Checksum
    const checksum = crypto.createHash('sha256').update(prompt).digest('hex');

    // Estimate token count (char count divided by 4 as a basic estimator)
    const tokenCount = Math.ceil(prompt.length / 4);

    return {
      prompt,
      checksum,
      tokenCount,
    };
  }
}
export default PromptBuilder;
