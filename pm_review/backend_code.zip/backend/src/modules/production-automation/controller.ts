import { FastifyReply, FastifyRequest } from 'fastify';
import { ClosedLoopProductionService } from './service.js';
import {
  RunProductionInput,
  RetryProductionInput,
  AutomationIdParamInput,
  AutomationWorkspaceParamInput,
} from './schema.js';
import { successResponse } from '@/common/responses/index.js';

export class ClosedLoopProductionController {
  constructor(private readonly service: ClosedLoopProductionService) {}

  run = async (
    request: FastifyRequest<{ Body: RunProductionInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.run(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Production automation process completed successfully'));
  };

  retry = async (
    request: FastifyRequest<{ Body: RetryProductionInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.retry(request.body, userId);
    return reply
      .status(200)
      .send(successResponse(result, 'Production automation retry completed successfully'));
  };

  findStatus = async (
    request: FastifyRequest<{ Params: AutomationIdParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findStatus(request.params.automationId, userId);
    return reply.status(200).send(successResponse(result));
  };

  findHistory = async (
    request: FastifyRequest<{ Params: AutomationWorkspaceParamInput }>,
    reply: FastifyReply,
  ): Promise<void> => {
    const userId = request.user!.userId;
    const result = await this.service.findHistory(request.params.workspaceId, userId);
    return reply.status(200).send(successResponse(result));
  };
}
export default ClosedLoopProductionController;
