import { FastifyInstance } from 'fastify';
import { schedulerController } from './controller.js';

export async function schedulerRoutes(fastify: FastifyInstance) {
  fastify.post('/run', (req, rep) => schedulerController.runJob(req, rep));
  fastify.post('/maintenance/start', (req, rep) => schedulerController.startMaintenance(req, rep));
  fastify.post('/maintenance/stop', (req, rep) => schedulerController.stopMaintenance(req, rep));
  fastify.get('/maintenance/status', (req, rep) => schedulerController.getMaintenanceStatus(req, rep));
  fastify.get('/dashboard', (req, rep) => schedulerController.getDashboard(req, rep));
}
export default schedulerRoutes;
