import { AIProviderAdapter, AIProviderRequest, ModelMetadata, GenerateResponse } from './types.js';
import { ProviderAuthenticationError, ProviderTimeoutError, ProviderValidationError, InternalServerError } from '../../common/errors/index.js';

export class GeminiProviderAdapter implements AIProviderAdapter {
  async generate(request: AIProviderRequest, metadata: ModelMetadata): Promise<GenerateResponse> {
    this.validateApiKey('GEMINI_API_KEY');

    // Simulate validation error if payload is empty
    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    try {
      // Logic would invoke Google GenAI SDK here. For mock/sim, we return resolved response.
      const tokens = request.prompt.length / 4;
      const promptTokens = Math.floor(tokens) + 1;
      const completionTokens = 20;
      const totalTokens = promptTokens + completionTokens;

      return {
        content: `[Gemini Response to "${request.prompt}"]`,
        finishReason: 'STOP',
        usage: { promptTokens, completionTokens, totalTokens },
        provider: 'GEMINI',
        model: metadata.model,
        cost: (promptTokens * metadata.inputCost + completionTokens * metadata.outputCost) / 1000,
      };
    } catch (err: unknown) {
      throw this.mapError(err);
    }
  }

  async generateStream(request: AIProviderRequest, _metadata: ModelMetadata): Promise<AsyncIterable<string>> {
    this.validateApiKey('GEMINI_API_KEY');

    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    const responseText = `[Gemini Stream Response to "${request.prompt}"]`;
    const chunks = responseText.split(' ');

    return {
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) {
          await new Promise((resolve) => setTimeout(resolve, 5));
          yield chunk + ' ';
        }
      },
    };
  }

  private validateApiKey(envVar: string) {
    // API Keys must be resolved from process.env, never stored in DB
    const key = process.env[envVar] || 'mock-api-key';
    if (key === 'invalid-key') {
      throw new ProviderAuthenticationError(`Authentication failed for environment variable ${envVar}`);
    }
  }

  private mapError(err: unknown): Error {
    const errorObj = err as Record<string, unknown>;
    const status = errorObj['status'];
    const statusCode = errorObj['statusCode'];
    const name = errorObj['name'];
    const code = errorObj['code'];
    const message = errorObj['message'];

    if (status === 401 || statusCode === 401) {
      return new ProviderAuthenticationError('Gemini API key is invalid or expired');
    }
    if (status === 400 || statusCode === 400) {
      return new ProviderValidationError('Gemini API request validation error');
    }
    if (name === 'TimeoutError' || code === 'ETIMEDOUT') {
      return new ProviderTimeoutError('Gemini API request timed out');
    }
    return new InternalServerError(typeof message === 'string' ? message : 'Gemini SDK call failed');
  }
}

export class OpenAIProviderAdapter implements AIProviderAdapter {
  async generate(request: AIProviderRequest, metadata: ModelMetadata): Promise<GenerateResponse> {
    this.validateApiKey('OPENAI_API_KEY');

    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    try {
      const tokens = request.prompt.length / 4;
      const promptTokens = Math.floor(tokens) + 1;
      const completionTokens = 25;
      const totalTokens = promptTokens + completionTokens;

      return {
        content: `[OpenAI Response to "${request.prompt}"]`,
        finishReason: 'STOP',
        usage: { promptTokens, completionTokens, totalTokens },
        provider: 'OPENAI',
        model: metadata.model,
        cost: (promptTokens * metadata.inputCost + completionTokens * metadata.outputCost) / 1000,
      };
    } catch (err: unknown) {
      throw this.mapError(err);
    }
  }

  async generateStream(request: AIProviderRequest, _metadata: ModelMetadata): Promise<AsyncIterable<string>> {
    this.validateApiKey('OPENAI_API_KEY');

    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    const responseText = `[OpenAI Stream Response to "${request.prompt}"]`;
    const chunks = responseText.split(' ');

    return {
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) {
          await new Promise((resolve) => setTimeout(resolve, 5));
          yield chunk + ' ';
        }
      },
    };
  }

  private validateApiKey(envVar: string) {
    const key = process.env[envVar] || 'mock-api-key';
    if (key === 'invalid-key') {
      throw new ProviderAuthenticationError(`Authentication failed for environment variable ${envVar}`);
    }
  }

  private mapError(err: unknown): Error {
    const errorObj = err as Record<string, unknown>;
    const status = errorObj['status'];
    const statusCode = errorObj['statusCode'];
    const name = errorObj['name'];
    const code = errorObj['code'];
    const message = errorObj['message'];

    if (status === 401 || statusCode === 401) {
      return new ProviderAuthenticationError('OpenAI API key is invalid or expired');
    }
    if (status === 400 || statusCode === 400) {
      return new ProviderValidationError('OpenAI API request validation error');
    }
    if (name === 'TimeoutError' || code === 'ETIMEDOUT') {
      return new ProviderTimeoutError('OpenAI API request timed out');
    }
    return new InternalServerError(typeof message === 'string' ? message : 'OpenAI SDK call failed');
  }
}

export class ClaudeProviderAdapter implements AIProviderAdapter {
  async generate(request: AIProviderRequest, metadata: ModelMetadata): Promise<GenerateResponse> {
    this.validateApiKey('CLAUDE_API_KEY');

    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    try {
      const tokens = request.prompt.length / 4;
      const promptTokens = Math.floor(tokens) + 1;
      const completionTokens = 30;
      const totalTokens = promptTokens + completionTokens;

      return {
        content: `[Claude Response to "${request.prompt}"]`,
        finishReason: 'STOP',
        usage: { promptTokens, completionTokens, totalTokens },
        provider: 'CLAUDE',
        model: metadata.model,
        cost: (promptTokens * metadata.inputCost + completionTokens * metadata.outputCost) / 1000,
      };
    } catch (err: unknown) {
      throw this.mapError(err);
    }
  }

  async generateStream(request: AIProviderRequest, _metadata: ModelMetadata): Promise<AsyncIterable<string>> {
    this.validateApiKey('CLAUDE_API_KEY');

    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    const responseText = `[Claude Stream Response to "${request.prompt}"]`;
    const chunks = responseText.split(' ');

    return {
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) {
          await new Promise((resolve) => setTimeout(resolve, 5));
          yield chunk + ' ';
        }
      },
    };
  }

  private validateApiKey(envVar: string) {
    const key = process.env[envVar] || 'mock-api-key';
    if (key === 'invalid-key') {
      throw new ProviderAuthenticationError(`Authentication failed for environment variable ${envVar}`);
    }
  }

  private mapError(err: unknown): Error {
    const errorObj = err as Record<string, unknown>;
    const status = errorObj['status'];
    const statusCode = errorObj['statusCode'];
    const name = errorObj['name'];
    const code = errorObj['code'];
    const message = errorObj['message'];

    if (status === 401 || statusCode === 401) {
      return new ProviderAuthenticationError('Claude API key is invalid or expired');
    }
    if (status === 400 || statusCode === 400) {
      return new ProviderValidationError('Claude API request validation error');
    }
    if (name === 'TimeoutError' || code === 'ETIMEDOUT') {
      return new ProviderTimeoutError('Claude API request timed out');
    }
    return new InternalServerError(typeof message === 'string' ? message : 'Claude SDK call failed');
  }
}

export class LocalLLMProviderAdapter implements AIProviderAdapter {
  async generate(request: AIProviderRequest, metadata: ModelMetadata): Promise<GenerateResponse> {
    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    const tokens = request.prompt.length / 4;
    const promptTokens = Math.floor(tokens) + 1;
    const completionTokens = 15;
    const totalTokens = promptTokens + completionTokens;

    return {
      content: `[LocalLLM Response to "${request.prompt}"]`,
      finishReason: 'STOP',
      usage: { promptTokens, completionTokens, totalTokens },
      provider: 'LOCAL_LLM',
      model: metadata.model,
      cost: 0.0, // Local processing cost is free
    };
  }

  async generateStream(request: AIProviderRequest, _metadata: ModelMetadata): Promise<AsyncIterable<string>> {
    if (!request.prompt || request.prompt.trim() === '') {
      throw new ProviderValidationError('Prompt cannot be empty');
    }

    const responseText = `[LocalLLM Stream Response to "${request.prompt}"]`;
    const chunks = responseText.split(' ');

    return {
      async *[Symbol.asyncIterator]() {
        for (const chunk of chunks) {
          yield chunk + ' ';
        }
      },
    };
  }
}
