import { ExecutionStatus } from './types.js';
import { ValidationError } from '../../common/errors/index.js';

export class WorkflowStateMachine {
  private static readonly allowedTransitions: Record<ExecutionStatus, ExecutionStatus[]> = {
    PENDING: ['RUNNING', 'CANCELLED', 'TIMEOUT'],
    RUNNING: ['WAITING', 'SUCCESS', 'FAILED', 'CANCELLED', 'TIMEOUT'],
    WAITING: ['RUNNING', 'SUCCESS', 'FAILED', 'CANCELLED', 'TIMEOUT'],
    SUCCESS: [], // terminal state
    FAILED: [], // terminal state
    CANCELLED: [], // terminal state
    TIMEOUT: [], // terminal state
  };

  static transition(current: ExecutionStatus, next: ExecutionStatus): ExecutionStatus {
    const allowed = this.allowedTransitions[current] || [];
    if (!allowed.includes(next)) {
      throw new ValidationError(`Invalid state transition requested from ${current} to ${next}`);
    }
    return next;
  }
}
export default WorkflowStateMachine;
