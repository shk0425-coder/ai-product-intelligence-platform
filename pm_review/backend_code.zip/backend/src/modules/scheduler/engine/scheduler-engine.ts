import { JobDefinition, JobRepository } from '../persistence/job-repository.js';
import { ScheduleRepository } from '../persistence/schedule-repository.js';
import { PriorityQueue } from '../queue/priority-queue.js';
import { AdmissionController } from '../admission/admission-controller.js';
import { PolicyEngine } from '../policy/policy-engine.js';
import { DistributedRateLimiter } from '../limiter/rate-limiter.js';
import { DagExecutor } from '../dag/dag-executor.js';
import { LeaderElection } from '../leader/leader-election.js';
import { SchedulerStateRepository } from '../persistence/scheduler-state-repository.js';
import { eventBus } from '../../infrastructure/event/event-bus.js';
import crypto from 'crypto';

export class SchedulerEngine {
  private static activeLoop: NodeJS.Timeout | null = null;
  private static loopTickMs = 2000;
  private static completedJobs = new Set<string>();

  static start(loopTickMs = 2000): void {
    this.loopTickMs = loopTickMs;
    const enabled = process.env.SCHEDULER_ENABLED !== 'false';
    if (!enabled) return;

    this.activeLoop = setInterval(async () => {
      try {
        await this.runTick();
      } catch {
        // Enforce resilience
      }
    }, this.loopTickMs);

    if (this.activeLoop.unref) {
      this.activeLoop.unref();
    }
  }

  static async runTick(): Promise<void> {
    const isCronEnabled = process.env.CRON_ENABLED !== 'false';
    if (!isCronEnabled) return;

    // Only the elected Leader Node evaluates schedules
    if (!LeaderElection.isLeader()) {
      return;
    }

    const state = await SchedulerStateRepository.getState();
    if (state.maintenanceMode) {
      // In maintenance mode, block scheduling of new jobs
      return;
    }

    const now = Date.now();
    const schedules = await ScheduleRepository.findAll();

    for (const schedule of schedules) {
      if (schedule.paused) continue;

      // Cron/Fixed Interval check
      let shouldTrigger = false;
      if (schedule.cronExpression) {
        // Emulating deterministic Cron evaluation
        if (!schedule.nextRunTime || now >= schedule.nextRunTime) {
          shouldTrigger = true;
          // Calculate next run time (e.g. current + 1 minute interval for emulated cron)
          schedule.nextRunTime = now + 60000;
        }
      } else if (schedule.intervalMs) {
        if (!schedule.nextRunTime || now >= schedule.nextRunTime) {
          shouldTrigger = true;
          schedule.nextRunTime = now + schedule.intervalMs;
        }
      }

      if (shouldTrigger) {
        const job = await JobRepository.findById(schedule.jobId);
        if (job) {
          await this.triggerJob(job);
        }
        schedule.lastRunTime = now;
        await ScheduleRepository.save(schedule);
      }
    }
  }

  static async triggerJob(job: JobDefinition, force = false): Promise<boolean> {
    // 1. Admission Control check
    const queueDepth = PriorityQueue.getDepth();
    const admission = await AdmissionController.inspect(job, queueDepth);
    if (!force && admission.decision === 'REJECT') {
      return false;
    }
    if (!force && admission.decision === 'DELAY') {
      // Re-push delayed job to queue later
      setTimeout(() => this.triggerJob(job), 1000);
      return false;
    }

    // 2. Policy Engine verification
    const policyCheck = await PolicyEngine.inspect(job);
    if (!force && !policyCheck.allowed) {
      return false;
    }

    // 3. Distributed Rate Limiter
    const rateLimitKey = `rate:limit:job:${job.name}`;
    const allowed = await DistributedRateLimiter.isAllowed(rateLimitKey, 10, 60000); // 10 calls per minute
    if (!force && !allowed) {
      return false;
    }

    // 4. DAG Dependencies resolution
    const parents = DagExecutor.getParents(job.id);
    if (!force && parents.length > 0) {
      const allParentsDone = parents.every(p => this.completedJobs.has(p));
      if (!allParentsDone) {
        return false; // Blocks execution until dependencies resolve
      }
    }

    // Push into Priority Queue
    const idempotencyKey = `job:${job.id}:${Date.now()}`;
    const success = await PriorityQueue.push(job, idempotencyKey);

    if (success) {
      eventBus.publish({
        eventId: crypto.randomUUID(),
        eventType: 'JobScheduled',
        timestamp: new Date().toISOString(),
        workspaceId: (job.metadata.workspaceId as string) || 'default-workspace',
        data: { jobId: job.id, priority: job.priority },
      }).catch(() => {});
    }

    return success;
  }

  static markJobCompleted(jobId: string): void {
    this.completedJobs.add(jobId);
  }

  static getCompletedJobs(): Set<string> {
    return this.completedJobs;
  }

  static clearCompletedJobs(): void {
    this.completedJobs.clear();
  }

  static stop(): void {
    if (this.activeLoop) {
      clearInterval(this.activeLoop);
      this.activeLoop = null;
    }
  }
}
export default SchedulerEngine;
