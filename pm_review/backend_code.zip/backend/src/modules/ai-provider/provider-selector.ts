import { AIProviderConfigEntity, AIProviderHealthEntity, AIProviderMetricEntity, ProviderCapability } from './types.js';

export class ProviderSelector {
  static select(
    configs: AIProviderConfigEntity[],
    healths: AIProviderHealthEntity[],
    metrics: AIProviderMetricEntity[],
    requestCapabilities: ProviderCapability[],
    workspaceId: string,
    workspaceOverride?: { provider: string; model: string }
  ): AIProviderConfigEntity | null {
    // 1. Workspace Override
    if (workspaceOverride) {
      const matched = configs.find(
        (c) =>
          c.provider.toUpperCase() === workspaceOverride.provider.toUpperCase() &&
          c.model.toUpperCase() === workspaceOverride.model.toUpperCase() &&
          c.enabled
      );
      if (matched) return matched;
    }

    // Filter enabled configs
    let eligible = configs.filter((c) => c.enabled);

    // 2. Capability Match
    // Capability is dynamic property checking on metadata object
    if (requestCapabilities && requestCapabilities.length > 0) {
      eligible = eligible.filter((c) => {
        const meta = (c.metadata || {}) as unknown as Record<string, unknown>;
        return requestCapabilities.every((cap) => {
          // e.g. mapping TEXT -> supportsText or supportsStructuredOutput mapping
          const propName = `supports${this.capitalize(cap)}`;
          return !!meta[propName] || !!meta[cap.toLowerCase()] || !!meta[cap];
        });
      });
    }

    if (eligible.length === 0) return null;

    // Map health records
    const healthMap = new Map<string, string>();
    for (const h of healths) {
      healthMap.set(`${h.provider}:${h.model}`.toUpperCase(), h.status);
    }

    // 3. Health check filter (Prefer HEALTHY / DEGRADED over UNAVAILABLE)
    const sortedByHealth = [...eligible].sort((a, b) => {
      const statusA = healthMap.get(`${a.provider}:${a.model}`.toUpperCase()) || 'HEALTHY';
      const statusB = healthMap.get(`${b.provider}:${b.model}`.toUpperCase()) || 'HEALTHY';

      const weight: Record<string, number> = { HEALTHY: 3, DEGRADED: 2, UNAVAILABLE: 1 };
      return (weight[statusB] || 0) - (weight[statusA] || 0);
    });

    // 4. Rate Limit & Priority Match
    // Filter out UNAVAILABLE if possible, but keep fallback
    const topGroup = sortedByHealth.filter((a) => {
      const status = healthMap.get(`${a.provider}:${a.model}`.toUpperCase()) || 'HEALTHY';
      return status !== 'UNAVAILABLE';
    });

    const activeList = topGroup.length > 0 ? topGroup : sortedByHealth;

    // Sort by priority DESC
    activeList.sort((a, b) => b.priority - a.priority);

    return activeList[0] || null;
  }

  private static capitalize(str: string): string {
    // converts IMAGE_GENERATION -> ImageGeneration
    return str
      .toLowerCase()
      .split('_')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join('');
  }
}
export default ProviderSelector;
