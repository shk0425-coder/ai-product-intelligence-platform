import { PromptExecutionHistoryEntity, PromptAuditLogEntity } from './types.js';

export class PromptHistoryCollector {
  private static readonly historyBuffer: PromptExecutionHistoryEntity[] = [];

  static record(history: Omit<PromptExecutionHistoryEntity, 'id' | 'created_at'>): void {
    const entry: PromptExecutionHistoryEntity = {
      id: crypto.randomUUID(),
      ...history,
      created_at: new Date().toISOString(),
    };
    this.historyBuffer.push(entry);
    if (this.historyBuffer.length > 500) {
      this.historyBuffer.shift();
    }
  }

  static getHistory(): PromptExecutionHistoryEntity[] {
    return [...this.historyBuffer];
  }

  static clear(): void {
    this.historyBuffer.length = 0;
  }
}

export class PromptAuditLogger {
  private static readonly auditBuffer: PromptAuditLogEntity[] = [];

  static record(audit: Omit<PromptAuditLogEntity, 'id' | 'created_at'>): void {
    const entry: PromptAuditLogEntity = {
      id: crypto.randomUUID(),
      ...audit,
      created_at: new Date().toISOString(),
    };
    this.auditBuffer.push(entry);
    if (this.auditBuffer.length > 500) {
      this.auditBuffer.shift();
    }
  }

  static getAudits(): PromptAuditLogEntity[] {
    return [...this.auditBuffer];
  }

  static clear(): void {
    this.auditBuffer.length = 0;
  }
}
