import { GenerateResponse, TokenUsage } from './types.js';

export class ResponseNormalizer {
  static normalize(
    content: string,
    provider: string,
    model: string,
    finishReason: string,
    usage: TokenUsage,
    cost: number = 0
  ): GenerateResponse {
    // Normalizes finish reason into acceptable enum
    let normalizedFinish: 'STOP' | 'LENGTH' | 'TOOL_CALL' | 'CONTENT_FILTER' | 'ERROR' = 'STOP';
    const upperReason = finishReason.toUpperCase();

    if (upperReason === 'STOP' || upperReason === 'END_TURN') {
      normalizedFinish = 'STOP';
    } else if (upperReason === 'LENGTH' || upperReason === 'MAX_TOKENS') {
      normalizedFinish = 'LENGTH';
    } else if (upperReason === 'TOOL_CALL' || upperReason === 'TOOL_CALLS' || upperReason === 'FUNCTION_CALL') {
      normalizedFinish = 'TOOL_CALL';
    } else if (upperReason === 'CONTENT_FILTER' || upperReason === 'SAFETY') {
      normalizedFinish = 'CONTENT_FILTER';
    } else if (upperReason === 'ERROR') {
      normalizedFinish = 'ERROR';
    }

    return {
      content: content || '',
      finishReason: normalizedFinish,
      usage: {
        promptTokens: usage.promptTokens >= 0 ? usage.promptTokens : 0,
        completionTokens: usage.completionTokens >= 0 ? usage.completionTokens : 0,
        totalTokens: usage.totalTokens >= 0 ? usage.totalTokens : (usage.promptTokens + usage.completionTokens),
      },
      provider: provider.toUpperCase(),
      model,
      cost,
    };
  }
}
export default ResponseNormalizer;
