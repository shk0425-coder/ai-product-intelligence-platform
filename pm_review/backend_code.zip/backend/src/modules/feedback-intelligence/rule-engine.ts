import { FeedbackRule, FEEDBACK_RULES } from './rules.js';

export interface RuleEngineInput {
  salesScore: number;
  reviewScore: number;
  conversionScore: number;
  ctrScore: number;
  roiScore: number;
  profitScore: number;
  favoriteScore: number;
  refundPenalty: number;
  metrics: {
    refund_count?: number;
    sales_count?: number;
    [key: string]: unknown;
  };
}

export const FeedbackRuleEngine = {
  matchRules(input: RuleEngineInput): FeedbackRule[] {
    const detected: FeedbackRule[] = [];

    for (const rule of FEEDBACK_RULES) {
      let scoreToEvaluate = 100.0;

      // Map rule category to the respective score field
      switch (rule.category) {
        case 'Sales':
          scoreToEvaluate = input.salesScore;
          break;
        case 'Review':
          scoreToEvaluate = input.reviewScore;
          break;
        case 'Conversion':
          scoreToEvaluate = input.conversionScore;
          break;
        case 'CTR':
          scoreToEvaluate = input.ctrScore;
          break;
        case 'ROI':
          scoreToEvaluate = input.roiScore;
          break;
        case 'Profit':
          scoreToEvaluate = input.profitScore;
          break;
        case 'Favorite':
          scoreToEvaluate = input.favoriteScore;
          break;
        case 'Refund':
          scoreToEvaluate = input.refundPenalty; // In feedback_scores it's stored as refund_penalty
          break;
      }

      if (rule.condition(scoreToEvaluate, input.metrics)) {
        detected.push(rule);
      }
    }

    // Sort by priority (ascending, where 1 is highest priority)
    return detected.sort((a, b) => a.priority - b.priority);
  },
};
export default FeedbackRuleEngine;
