import { JobQueueRepository } from './repository.js';
import { QueueManager } from './queue-manager.js';
import { DeadLetterManager } from './dead-letter.js';
import { JobQueueMapper } from './mapper.js';
import { EnqueueJobDto, JobQueueDto } from './dto.js';
import { WorkspaceForbiddenError, JobNotFoundError, JobConflictError } from '@/common/errors/index.js';

export class JobQueueService {
  private readonly queueManager: QueueManager;

  constructor(private readonly repository: JobQueueRepository) {
    this.queueManager = new QueueManager(this.repository);
  }

  async enqueueJob(dto: EnqueueJobDto, actorId: string): Promise<JobQueueDto> {
    const isOwner = await this.repository.verifyWorkspaceOwnership(dto.workspaceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have ownership access to this workspace');
    }

    const job = await this.queueManager.enqueue(dto);
    return JobQueueMapper.toDto(job);
  }

  async retryJob(jobId: string, actorId: string): Promise<JobQueueDto> {
    const isOwner = await this.repository.verifyJobOwnership(jobId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have ownership access to this job');
    }

    const job = await this.repository.findJob(jobId);
    if (!job) {
      throw new JobNotFoundError(`Job with ID ${jobId} not found`);
    }

    if (job.status !== 'FAILED') {
      throw new JobConflictError(`Job ${jobId} is not in FAILED state. Current status: ${job.status}`);
    }

    // Rerun job: reset retry count and schedule to run immediately
    const retried = await this.repository.updateJob(jobId, {
      status: 'PENDING',
      retry_count: 0,
      scheduled_at: new Date().toISOString(),
      error_message: null,
    });

    return JobQueueMapper.toDto(retried);
  }

  async cancelJob(jobId: string, actorId: string): Promise<JobQueueDto> {
    const isOwner = await this.repository.verifyJobOwnership(jobId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have ownership access to this job');
    }

    const cancelled = await this.queueManager.cancel(jobId);
    return JobQueueMapper.toDto(cancelled);
  }

  async getJobStatus(jobId: string, actorId: string): Promise<JobQueueDto> {
    const isOwner = await this.repository.verifyJobOwnership(jobId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have ownership access to this job');
    }

    const job = await this.repository.findJob(jobId);
    if (!job) {
      throw new JobNotFoundError(`Job with ID ${jobId} not found`);
    }

    return JobQueueMapper.toDto(job);
  }

  async getJobHistory(workspaceId: string, actorId: string): Promise<JobQueueDto[]> {
    const isOwner = await this.repository.verifyWorkspaceOwnership(workspaceId, actorId);
    if (!isOwner) {
      throw new WorkspaceForbiddenError('You do not have ownership access to this workspace');
    }

    const history = await this.repository.findHistory(workspaceId);
    return JobQueueMapper.toDtoList(history);
  }

  async getDeadLetters(_actorId: string): Promise<unknown[]> {
    // Return all dead letters (admin query or scoped for workspace, simplified globally here)
    const deadLetters = await this.repository.findDeadLetters();
    return deadLetters.map((dl) => ({
      id: dl.id,
      jobId: dl.job_id,
      payload: dl.payload,
      reason: dl.reason,
      retryCount: dl.retry_count,
      failedAt: dl.failed_at,
      createdAt: dl.created_at,
    }));
  }

  async recoverDeadLetter(deadLetterId: string, _actorId: string): Promise<JobQueueDto> {
    // Recovery trigger
    const recovered = await DeadLetterManager.recoverJob(this.repository, deadLetterId);
    return JobQueueMapper.toDto(recovered);
  }
}
