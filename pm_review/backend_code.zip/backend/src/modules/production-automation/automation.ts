export const AutomationEngine = {
  async runWorkflow(
    service: { executeWorkflow(automationId: string, actorId: string): Promise<unknown> },
    automationId: string,
    actorId: string,
  ): Promise<unknown> {
    // Automation Engine is only responsible for executing the workflow orchestration steps
    return service.executeWorkflow(automationId, actorId);
  },
};
export default AutomationEngine;
