export interface ProductionAutomationEntity {
  id: string; // UUID Primary Key
  workspace_id: string; // UUID FK
  knowledge_id: string; // UUID FK
  status: 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED'; // VARCHAR(20)
  retry_count: number; // INTEGER
  started_at?: string; // TIMESTAMPTZ
  completed_at?: string; // TIMESTAMPTZ
  error_message?: string; // TEXT
  created_at: string; // TIMESTAMPTZ
  updated_at: string; // TIMESTAMPTZ
}

export interface ProductionPromptLogEntity {
  id: string; // UUID Primary Key
  automation_id: string; // UUID FK
  prompt_version: string; // VARCHAR(20)
  prompt_checksum: string; // VARCHAR(128)
  token_count: number; // INTEGER
  created_at: string; // TIMESTAMPTZ
}

export interface ProductionExecutionLogEntity {
  id: string; // UUID Primary Key
  automation_id: string; // UUID FK
  step: string; // VARCHAR(50)
  status: 'SUCCESS' | 'FAILED'; // VARCHAR(20)
  duration_ms: number; // INTEGER
  error_message?: string; // TEXT
  created_at: string; // TIMESTAMPTZ
}

export interface IProductionRepository {
  createAutomation(
    payload: Partial<ProductionAutomationEntity>,
  ): Promise<ProductionAutomationEntity>;
  updateAutomation(
    id: string,
    payload: Partial<ProductionAutomationEntity>,
  ): Promise<ProductionAutomationEntity>;
  findAutomation(id: string): Promise<ProductionAutomationEntity | null>;
  findHistory(workspaceId: string): Promise<ProductionAutomationEntity[]>;

  createPromptLog(payload: Partial<ProductionPromptLogEntity>): Promise<ProductionPromptLogEntity>;
  createExecutionLog(
    payload: Partial<ProductionExecutionLogEntity>,
  ): Promise<ProductionExecutionLogEntity>;
  findExecutionLogs(automationId: string): Promise<ProductionExecutionLogEntity[]>;

  // Ownership verification helpers
  verifyWorkspaceOwnership(workspaceId: string, userId: string): Promise<boolean>;
  verifyKnowledgeOwnership(knowledgeId: string, userId: string): Promise<boolean>;
  verifyAutomationOwnership(automationId: string, userId: string): Promise<boolean>;
}

export interface ProductionEventPayload {
  automationId: string;
  workspaceId: string;
  status: string;
  timestamp: string;
}

export interface IProductionHooks {
  onProductionAutomationStarted(payload: ProductionEventPayload): Promise<void>;
  onPlannerStarted(payload: { automationId: string; timestamp: string }): Promise<void>;
  onPlannerCompleted(payload: {
    automationId: string;
    strategyId: string;
    timestamp: string;
  }): Promise<void>;
  onProductionCompleted(payload: ProductionEventPayload): Promise<void>;
}
